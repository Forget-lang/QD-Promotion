// 正式环境 APPID：wxcb35468c13e5ac7e

let config = {
    apiUrl: 'https://uaaeuqvc.lenmy.com/api', // 接口正式地址，注意：结尾请勿添加： /
    appSecret: 'AVyuDXSEWC1McxHVsoR6IS7KC09VvI25', // 应用秘钥
    version: '1.6.5', // 当前版本
    default: {
        avatar: 'https://cdn.lenmy.com/img/avatar.png',
        cover: 'https://cdn.lenmy.com/quandao/assets/home-hero-default.jpg',
    },
    // 企业微信客服
    customerService: {
        appId: 'wwa50712d31a77adb5',
        url: 'https://work.weixin.qq.com/kfid/kfc7ef2efc710e321fa',
    },
    // 订阅消息（正式环境）
    subscribeMessage: {
        feedback: ['MNpLFV7uhT8-2h7fclWhcv3ktosq_1VmlZomF_LZtyo'], // [反馈结果通知]
        pendingAudit: ['4Q0o0i_Or9Q5TNyP5KuWz6oVj5zxm7R7W57Gi4GofHU'], // [进店申请审核通知]
        couponReceive: ['AVzd5aCho9hMdqBg7_KkcA0916MTAl1NyVE8cnqUvkk', 'WSnrf3h_itI1Uf0eGOWnmXIQJqUit2Lkdy23LmuLqyk'], // [卡券领取成功通知,卡券到期提醒]
        upgrade: ['R5tMRACKLESsOUgKdnhLkiJS4wUJCeRcT3mqoGzxRs4'], // [版本更新通知]
        sellerMessage: ['fKWqzHNdEyQMsawAm_NRFhOCspnTNmTPSxj_fwgI52o'], // [商家站内消息]
        merchantAuth: ['RASDxpn5o9Z7vvi0BLvT0JwyDDaLCJ0ht-yfzlqcf0M'], // [商家认证通知]
        massComplete: ['GC0pQKEa-9kU33oDKNvTo8K1ceWrH0ARMdVNyU9XKI4'], // [群发任务完成提醒]
        invoice: ['qig6yYmBC85TKbWmyjcflaZxedlnbf6AJhtXLqAj204'], // [电子发票开具成功通知]
        pointChange: ['_Ofweydrf3LH1hZ6gVeXYkos-tZ7LjqpL76aQkyRm-k'], // [积分变更通知]
    },
    //广告位
    adUnit: {
        merchantHome: 'adunit-b3ebfb04136745c7', // 商家主页
        cardDetail: 'adunit-302d9a03576641cc', // 次卡详情页
        couponDetail: 'adunit-c798433e9a4aa548', // 优惠券详情页
        verify: 'adunit-e592ff2b6bae9ec6', // 核销页
        couponReceivePrivate: 'adunit-6b661343c38e1b65', // 私密领券页
        couponReceivePublic: 'adunit-1d118e1ae46def37', // 公开领券页
        couponHome: 'adunit-36f440081df2c708', // 我的卡包主页
    },

}

export default config
