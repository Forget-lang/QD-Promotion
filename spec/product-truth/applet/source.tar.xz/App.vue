<script setup>
    import { onLaunch, onShow, onHide } from '@dcloudio/uni-app';
    import monitor from './utils/monitor.js';
    import { useSessionStore } from '@/stores/session';
    import { cleanupTempFiles } from '@/hooks/useFile.js';
    import utils from "@/utils/utils";

    const session = useSessionStore()
    const MERCHANT_SOURCE_KEY = 'merchant_source'

    // 跨小程序 / 启动参数携带 source（任意中文）时写入本地，创建商户页再读取
    const persistSource = (options) => {
        if (!options) return
        let source = options.query?.source || ''
        if (!source && options.referrerInfo?.extraData?.source) {
            source = options.referrerInfo.extraData.source
        }
        if (!source) return
        uni.setStorageSync(MERCHANT_SOURCE_KEY, decodeURIComponent(String(source)))
    }

    // 只能在App.vue里监听应用的生命周期
    onLaunch((options) => {
        console.log('App Launch')
        console.log('应用启动路径：', options.path)
        persistSource(options)
        // 初始化监控
        monitor.init()
        // 清理超过 7 天的临时导出/下载文件
        cleanupTempFiles()
    })

    onShow((options) => {
        console.log('App Show')
        console.log('应用启动路径：', options.path)
        persistSource(options)
        if (options.scene) {
            session.setAppletScene(options.scene)
        }

       utils.checkUpdateVersion()
    })

    onHide(() => {
        console.log('App Hide')
    })

</script>

<style>
	@import './static/css/app.css';
</style>
<style lang="less">
	page {

        --td-brand-color: #07C160; // 主主题色（微信绿）
        --td-brand-color-active: #06ad56;
        --td-brand-color-disabled: #92DAB2FF;
        --td-brand-color-focus: #e8f8ee;
        --td-brand-color-light: #e8f8ee;

		// ===== 全局按钮高度配置 =====
        //--td-button-border-radius: 24rpx;
        //--td-button-extra-small-height: 56rpx;  // 超小尺寸高度
        //--td-button-small-height: 72rpx;        // 小尺寸高度
        //--td-button-medium-height: 96rpx;       // 中等尺寸高度（默认）
        //--td-button-large-height: 100rpx;       // 大尺寸高度

		// ===== 按钮 danger 主题色 =====
		--td-button-danger-bg-color: #e2453d;
		--td-button-danger-border-color: #e2453d;
		--td-button-danger-active-bg-color: #b22f2a;
		--td-button-danger-active-border-color: #b22f2a;
		--td-button-danger-disabled-bg: #ffb9af;
		--td-button-danger-disabled-border-color: #ffb9af;
		--td-button-danger-text-color: #e2453d;

		--td-search-bg-color:#fff; // 搜索框背景颜色

		// ===== 版本主题色（4版本 × color/bg/border 共 12 个；与 constants/edition.js 的 EDITION_THEME 一一对应，改色需两处同步）=====
		// token 语义：color 主色（文字/数字/进度条/图标）/ bg 徽章浅底 / border 描边；大面积浅背景场景较少，走 edition.js 的 theme.light，不入全局
		--edition-free-color: #07C160;
		--edition-free-bg: #e8f8ee;
		--edition-free-border: #BCE6CD;

		--edition-standard-color: #007AFF;
		--edition-standard-bg: #E6F2FF;
		--edition-standard-border: #B8D5FF;

		--edition-professional-color: #FF9500;
		--edition-professional-bg: #FFF5E6;
		--edition-professional-border: #FFD9A8;

		--edition-enterprise-color: #7B61FF;
		--edition-enterprise-bg: #F0EBFF;
		--edition-enterprise-border: #D4C9FF;

		// ===== Tabs 配置 =====
        --td-tab-nav-bg-color: #e2453d; // Tabs 背景色默认为页面背景
        --td-tab-item-color: #fff1ae;
        --td-badge-content-text-color: rgba(255, 255, 255, .5);
        --td-tab-item-active-color: #fff1ae;
        --td-tab-track-color: #e2453d;
        --td-tab-border-color: #f2f2f2;

        // ===== 全局input配置 =====
        --td-input-label-max-width: 320rpx;
        --td-input-border-left-space: 0;

        // ===== 全局cell配置 =====
        --td-cell-border-left-space: 0;

        // ===== 全局NAVBAR配置 =====
        --td-navbar-background:transparent;

        // ===== 全局Switch配置 =====
        --td-switch-checked-color: #00a870;
        --td-switch-checked-disabled-color: #92DAB2FF;

	}

</style>