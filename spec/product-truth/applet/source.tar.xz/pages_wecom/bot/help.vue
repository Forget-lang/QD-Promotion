<template>
    <image class="w-100" src="https://cdn.lenmy.com/quandao/2026/06/24/d8tn625b4ek1lsh6h1r0.jpg" mode="widthFix"
           width="100%" show-menu-by-longpress lazy></image>
</template>
<script setup>

</script>
<style scoped>

</style>