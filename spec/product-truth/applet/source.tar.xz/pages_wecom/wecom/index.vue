<template>
    <m-loading v-if="corp === undefined"></m-loading>
    <view v-else class="container-safety">
        <view class="container">
            <!-- 授权状态提示 -->
            <view v-if="corpLoaded" class="section status-bar mt-2">
                <view v-if="corp.status === CORP_STATUS.AUTHORIZED" class="d-flex align-items-center">
                    <t-icon name="check-circle-filled" size="32rpx" color="#07C160"/>
                    <text class="status-text-ok ml-1">已授权：{{ corp.corpName }}</text>
                </view>
                <view v-else-if="corp.status === CORP_STATUS.UNBOUND" class="d-flex align-items-center">
                    <t-icon name="check-circle-filled" size="32rpx" color="#07C160"/>
                    <text class="status-text-ok ml-1">已解绑：{{ corp.corpName }}</text>
                </view>
                <view v-else class="d-flex align-items-center">
                    <t-icon name="error-circle-filled" size="32rpx" color="#ed7b2f"/>
                    <text class="status-text-warn ml-1">尚未授权企业微信，功能不可用</text>
                </view>
            </view>
            <!-- /授权状态提示 -->
            <!-- 功能卡片 -->
            <view class="row col-2 func-grid mt-2">
                <view v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" class="section func-card" @click="push('/pages_wecom/wecom/auth')">
                    <view class="func-icon func-icon-auth">
                        <t-icon name="secured" size="48rpx" color="#07C160"/>
                    </view>
                    <text class="func-title">授权管理</text>
                    <text class="func-desc">绑定或管理企业微信</text>
                </view>
                <view v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" class="section func-card" @click="push('/pages_wecom/staff/list')">
                    <view class="func-icon func-icon-staff">
                        <t-icon name="user-add" size="48rpx" color="#1890ff"/>
                    </view>
                    <text class="func-title">加好友发券</text>
                    <text class="func-desc">添加员工配置发券规则</text>
                </view>
                <view v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" class="section func-card" @click="push('/pages_wecom/group/list')">
                    <view class="func-icon func-icon-group">
                        <t-icon name="chat-add" size="48rpx" color="#ed7b2f"/>
                    </view>
                    <text class="func-title">进企微群发券</text>
                    <text class="func-desc">进群自动发送优惠券</text>
                </view>
                <view v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" class="section func-card" @click="push('/pages_wecom/batch/index')">
                    <view class="func-icon func-icon-group-send">
                        <t-icon name="share" size="48rpx" color="#e74c3c"/>
                    </view>
                    <text class="func-title">群发卡券</text>
                    <text class="func-desc">向企微好友群群发优惠券</text>
                </view>
            </view>
            <!-- /功能卡片 -->


            <!-- CTA 按钮 -->
            <view class="cta-wrap">
                <t-button v-if="checkPermission(PERM_WECOM.CORP_CONFIG) && corp.status !== CORP_STATUS.AUTHORIZED" block theme="primary" size="large"
                          @click="push('/pages_wecom/wecom/auth')">
                    立即授权企业微信
                </t-button>
                <t-button v-else block theme="danger" size="large" @click="push('/pages_wecom/staff/add')">
                    添加发券员工
                </t-button>
            </view>
            <!-- /CTA 按钮 -->
        </view>
    </view>
</template>

<script setup>
import {ref} from 'vue'
import {onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {CORP_STATUS} from '@/constants/wecom.js'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_WECOM} from '@/constants/permission.js'

const {push} = useLink()
const {checkPermission} = useAuth()

const corp = ref()
const corpLoaded = ref(false)

const loadCorp = () => {
    return request.get('/seller/wecom/corp').then(res => {
        corp.value = res.data || {}
    }).catch((err) => {

    }).finally(() => {
        corpLoaded.value = true
    })
}

onShow(() => {
    loadCorp()
})

onPullDownRefresh(() => {
    loadCorp().finally(() => {
        setTimeout(() => uni.stopPullDownRefresh(), 500)
    })
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>

/* 功能卡片 */
.func-grid {
    margin-top: -12rpx;
}

.func-card {
    padding: 36rpx 16rpx 28rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.func-card:active {
    opacity: 0.8;
}

.func-icon {
    width: 88rpx;
    height: 88rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 16rpx;
}

.func-icon-auth {
    background-color: #e8f8ee;
}

.func-icon-staff {
    background-color: #e6f4ff;
}

.func-icon-group {
    background-color: #fff3e0;
}

.func-icon-group-send {
    background-color: #fde8e8;
}

.func-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
    text-align: center;
}

.func-desc {
    font-size: 22rpx;
    color: #999;
    margin-top: 6rpx;
    text-align: center;
}

/* 授权状态条 */
.status-bar {
    padding: 24rpx;
}

.status-text-ok {
    font-size: 26rpx;
    color: #07C160;
}

.status-text-warn {
    font-size: 26rpx;
    color: #ed7b2f;
}

/* CTA */
.cta-wrap {
    margin-top: 32rpx;
    padding: 0 8rpx;
}
</style>
