<template>
    <m-loading v-if="corp === undefined"></m-loading>
    <view v-else class="page">
        <!-- 已授权：展示企业信息 -->
        <template v-if="corp.status === CORP_STATUS.AUTHORIZED">
            <t-cell-group theme="card" t-class="mt-2">
                <t-cell :title="corp.corpName">
                    <template #left-icon>
                        <image v-if="corp.corpLogoUrl" class="corp-logo" :src="corp.corpLogoUrl"
                               mode="aspectFill"></image>
                        <view v-else class="corp-logo corp-logo-default">
                            <t-icon name="building" size="48rpx" color="#666"/>
                        </view>
                    </template>
                    <template #description>
                        <view class="corp-status-row">
                            <view class="corp-status-dot"></view>
                            <text class="corp-status-text">已授权</text>
                        </view>
                    </template>
                </t-cell>
                <t-cell title="CorpID" t-class-note="text-ellipsis text-scroll-hidden" :note="corp.corpId"/>
                <t-cell title="授权时间" :note="corp.authorizedAt"/>
                <t-cell title="企微员工" note="管理企微员工二维码" arrow
                        url="/pages_wecom/staff/manage"/>
            </t-cell-group>
            <view class="container">
                <view class="section tips-card mt-2">
                    <view class="d-flex align-items-center">
                        <t-icon name="info-circle-filled" size="32rpx" color="#d46b08"/>
                        <text class="tips-title ml-1">温馨提示</text>
                    </view>
                    <view class="tips-text mt-2">
                        若成员在企微后台配置了固定欢迎语，本系统可能无法发送小程序卡片。
                    </view>
                    <view class="tips-text mt-2">
                        企业微信首次授权后90天试用期，超出将被企微拦截，请及时联系客服续费。
                    </view>
                    <view class="tips-text mt-2" style="font-weight:600;color:#c41d00;">
                        如需解绑企业微信，请在企业微信管理后台「管理企业/应用管理/券到卡包」中删除本应用。
                    </view>
                </view>
            </view>
        </template>

        <!-- 未授权 / 已解绑：展示授权二维码 -->
        <template v-else>
            <view class="container">
                <view class="section qrcode-card mt-2">
                    <view class="qrcode-header">
                        <text class="qrcode-title">扫码授权</text>
                        <text class="qrcode-desc">使用企业微信扫码完成授权</text>
                    </view>
                    <view class="qrcode-frame">
                        <image v-if="authQrcode" class="qrcode-img" :src="authQrcode" mode="aspectFit"
                               show-menu-by-longpress></image>
                        <m-empty v-else :height="320" description="暂无授权二维码"></m-empty>
                    </view>
                    <text class="qrcode-tip mt-2">长按识别图中二维码</text>
                </view>

                <view class="section tips-card mt-2">
                    <view class="d-flex align-items-center">
                        <t-icon name="info-circle-filled" size="32rpx" color="#d46b08"/>
                        <text class="tips-title ml-1">温馨提示</text>
                    </view>
                    <view class="tips-text mt-2">
                        若成员在企微后台配置了固定欢迎语，本系统可能无法发送小程序卡片。
                    </view>
                </view>
            </view>
        </template>
    </view>
</template>

<script setup>
import {ref, computed} from 'vue'
import {onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {CORP_STATUS} from '@/constants/wecom.js'
import dayjs from 'dayjs'

const corp = ref()
const authQrcode = ref('')

const getCorp = () => request.get('/seller/wecom/corp').then(res => {
    const data = res.data || {}
    // 已授权时清空授权二维码
    if (data.status === CORP_STATUS.AUTHORIZED) {
        corp.value = data
        authQrcode.value = ''
    } else {
        corp.value = data
        authQrcode.value = data.authQrcode || ''
    }
}).catch(() => {
    corp.value = {}
})

onShow(() => {
    getCorp()
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
.page {
    padding-bottom: 48rpx;
}

/* 企业信息卡片 */
.corp-card {
    padding: 32rpx;
}

.corp-body {
    display: flex;
    align-items: center;
}

.corp-logo {
    width: 96rpx;
    height: 96rpx;
    border-radius: 20rpx;
    flex-shrink: 0;
    background: #f5f5f5;
}

.corp-logo-default {
    display: flex;
    align-items: center;
    justify-content: center;
}

.corp-info {
    flex: 1;
    margin-left: 24rpx;
    min-width: 0;
}

.corp-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
    display: block;
}

.corp-status-row {
    display: flex;
    align-items: center;
    margin-top: 8rpx;
}

.corp-status-dot {
    width: 12rpx;
    height: 12rpx;
    border-radius: 50%;
    background: #07C160;
}

.corp-status-text {
    font-size: 24rpx;
    color: #07C160;
    margin-left: 8rpx;
}

.corp-divider {
    height: 1rpx;
    background: #f0f0f0;
    margin: 24rpx 0;
}

.corp-id-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.corp-id-label {
    font-size: 24rpx;
    color: #999;
}

.corp-id-value {
    font-size: 24rpx;
    color: #666;
}

/* 解绑按钮 */
.unbind-wrap {
    padding: 0 8rpx;
}

/* 二维码卡片 */
.qrcode-card {
    padding: 32rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.qrcode-header {
    text-align: center;
    margin-bottom: 32rpx;
}

.qrcode-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
    display: block;
    margin-bottom: 8rpx;
}

.qrcode-desc {
    font-size: 24rpx;
    color: #999;
}

.qrcode-frame {
    width: 520rpx;
    height: 620rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fafafa;
    border-radius: 16rpx;
}

.qrcode-img {
    width: 480rpx;
    height: 480rpx;
}

.qrcode-tip {
    font-size: 24rpx;
    color: #999;
    text-align: center;
}

/* 授权说明 */
.tips-card {
    padding: 24rpx;
    background: #fff7e6;
    border: 1px solid #ffd591;
}

.tips-title {
    font-size: 26rpx;
    font-weight: 600;
    color: #d46b08;
}

.tips-text {
    font-size: 24rpx;
    color: #874d00;
    line-height: 1.6;
}
</style>
