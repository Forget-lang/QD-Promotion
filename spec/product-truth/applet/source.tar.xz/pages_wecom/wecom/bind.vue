<template>
    <view class="page-wrapper">
        <m-navigation-bar homeUrl="/pages/merchant/index">
        </m-navigation-bar>

        <view>
            <!-- 顶部品牌区域 -->
            <view class="header">
                <view class="header-bg"></view>
                <view class="header-content">
                    <image class="brand-logo" src="/static/logo.png" mode="aspectFill"></image>
                    <text class="brand-name">券到卡包</text>
                    <text class="brand-slogan">商户制券 · 发券 · 核销一体化</text>
                </view>
            </view>

            <!-- 绑定状态卡片 -->
            <view class="container bind-container">
                <view class="section bind-card">
                    <!-- 加载中 -->
                    <template v-if="status === 'loading'">
                        <view class="status-icon status-icon-loading">
                            <t-loading theme="circular" size="48rpx"></t-loading>
                        </view>
                        <text class="status-title">正在查询商户信息...</text>
                        <text class="status-desc">正在通过企业微信验证身份，请稍候</text>
                    </template>

                    <!-- 绑定成功 - status=3 -->
                    <template v-else-if="status === 'success'">
                        <view class="status-icon status-icon-success">
                            <t-icon name="check-circle-filled" size="64rpx" color="#07C160"/>
                        </view>
                        <text class="status-title">商户已授权</text>
                        <view class="status-info">
                            <text class="status-desc" v-if="corpName">企业：{{ corpName }}</text>
                            <text class="status-desc" v-if="merchantName">商户：{{ merchantName }}</text>
                        </view>
                        <view class="bind-actions">
                            <t-button theme="primary" size="large" block @click="goIndex">进入商户中心</t-button>
                        </view>
                    </template>

                    <!-- 警告状态 - status=2 或 status=4 -->
                    <template v-else-if="status === 'warning'">
                        <view class="status-icon status-icon-warning">
                            <t-icon name="info-circle-filled" size="64rpx" color="#ed7b2f"/>
                        </view>
                       <template v-if="authStatus === 2 && merchantName">
                           <text class="status-title">您尚未加入该商户</text>
                           <view class="status-info">
                               <text class="status-desc" v-if="corpName">企业：{{ corpName }}</text>
                               <!-- status=2 时显示绑定的商户 -->
                               <text class="status-desc">商户：{{ merchantName }}</text>
                               <text class="status-tips">请联系商户管理员邀请您加入该商户</text>
                           </view>
                       </template>
                        <template v-if="authStatus === 4">
                            <text class="status-title">该商户尚未授权</text>
                            <view class="status-info">
                                <text class="status-desc" v-if="corpName">企业：{{ corpName }}</text>
                                <!-- status=4 时显示未关联商户 -->
                                <text class="status-desc">该企业微信未关联商户</text>
                                <text v-if="merchants.length > 0" class="status-tips">请联系企微管理员绑定商户</text>
                                <text v-else class="status-tips">请联系企微管理员注册商户</text>
                            </view>
                            <!-- status=4 时显示绑定商户按钮 -->
                            <view class="bind-actions">
                                <t-button v-if="merchants.length > 0" theme="primary" size="large" block @click="showBindMerchantPopup">绑定商户</t-button>
                                <t-button v-else theme="primary" size="large" block @click="goRegister">注册商户</t-button>
                            </view>
                        </template>
                    </template>

                    <!-- 绑定失败 -->
                    <template v-else-if="status === 'error'">
                        <view class="status-icon status-icon-error">
                            <t-icon name="close-circle-filled" size="64rpx" color="#e74c3c"/>
                        </view>
                        <text class="status-title">{{ errorTitle }}</text>
                        <text class="status-desc">{{ errorMsg }}</text>
                        <view class="bind-actions" v-if="isWecom">
                            <t-button theme="danger" size="large" block @click="qyLogin">重新查询</t-button>
                        </view>
                    </template>

                    <!-- 待绑定（初始态） -->
                    <template v-else>
                        <view class="status-icon status-icon-pending">
                            <t-icon name="secured" size="64rpx" color="#1890ff"/>
                        </view>
                        <text class="status-title">企业微信商户绑定</text>
                        <text class="status-desc" v-if="!isLoggedIn">请先登录，登录后查询商户信息</text>
                        <text class="status-desc" v-else>点击下方按钮，将企业微信绑定商户信息，即可使用企微发券功能</text>
                        <view class="bind-actions">
                            <get-user-info v-if="!isLoggedIn" @success="onGetUserInfoSuccess" @fail="onGetUserInfoFail">
                                <button class="button-normal" :style="{ height: '98rpx', backgroundColor: 'var(--td-brand-color)', color: '#fff', fontWeight: 600 }">商家登录
                                </button>
                            </get-user-info>
                            <t-button v-else theme="primary" size="large" block @click="qyLogin">查询商户信息</t-button>
                        </view>
                    </template>
                </view>

                <!-- 使用场景推荐位 -->
                <view class="section feature-card mt-2" v-if="positionItems === undefined || positionItems.length > 0">
                    <view class="feature-header">
                        <view class="feature-bar"></view>
                        <text class="feature-title">使用场景</text>
                    </view>
                    <view class="feature-list">
                        <template v-if="positionItems === undefined">
                            <m-loading></m-loading>
                        </template>
                        <template v-else>
                            <view class="feature-item media" v-for="(item,index) in positionItems" :key="index">
                                <view class="media-header">
                                    <t-image :src="item.thumb" mode="aspectFill" width="36" height="36"/>
                                </view>
                                <view class="media-body">
                                    <view class="media-content">
                                        <view class="media-title">{{item.title}}</view>
                                        <view class="media-desc">{{item.description}}</view>
                                    </view>
                                    <view class="media-action">
                                        <view v-if="item.url" class="button-gold" @click="utils.openPosition(item)">预览</view>
                                    </view>
                                </view>
                            </view>
                        </template>
                    </view>
                </view>

                <!-- 温馨提示 -->
                <view class="section tips-card mt-2">
                    <view class="d-flex align-items-center">
                        <t-icon name="info-circle-filled" size="32rpx" color="#d46b08"/>
                        <text class="tips-title ml-1">温馨提示</text>
                    </view>
                    <view v-if="status === 'success'" class="tips-body mt-2">
                        <text class="tips-text">1. 企业微信首次授权后90天试用期，超出将被企微拦截，请及时联系客服续费。</text>
                        <text class="tips-text">2. 绑定后可在企业微信中添加发券员工、配置加好友 / 进群自动发券规则</text>
                        <text class="tips-text">3. 绑定成功后，请先添加发券员工，再配置发券规则</text>
                        <text class="tips-text">4. 若员工在企微后台已配置固定欢迎语，本系统的自动发券可能无法生效</text>
                    </view>
                    <view v-else class="tips-body mt-2">
                        <text class="tips-text">1. 绑定后可在企业微信中添加发券员工、配置加好友 / 进群自动发券规则</text>
                        <text class="tips-text">2. 绑定成功后，请先添加发券员工，再配置发券规则</text>
                        <text class="tips-text">3. 若员工在企微后台已配置固定欢迎语，本系统的自动发券可能无法生效</text>
                    </view>
                </view>

                <!-- 底部版本号 -->
                <view class="version-text">版本号：{{ config.version }}</view>
            </view>
        </view>

        <!-- 底部导航栏 -->
<!--        <t-tab-bar :split="false" @change="onTabChange">-->
<!--            <t-tab-bar-item :value="1">-->
<!--                <template #icon>-->
<!--                    <image class="tab-bar-icon" src="/static/img/index.png" mode="aspectFit"/>-->
<!--                </template>-->
<!--                <view class="tab-bar-text">我的卡包</view>-->
<!--            </t-tab-bar-item>-->
<!--            <t-tab-bar-item :value="2">-->
<!--                <template #icon>-->
<!--                    <image class="tab-bar-icon" src="/static/img/me-active.png" mode="aspectFit"/>-->
<!--                </template>-->
<!--                <view class="tab-bar-text">商户中心</view>-->
<!--            </t-tab-bar-item>-->
<!--        </t-tab-bar>-->

        <!-- 商户选择底部弹框 -->
        <t-popup v-model:visible="showMerchantPopup" placement="bottom" @visible-change="onPopupChange">
            <view class="popup-header">
                <view class="popup-header-cancel" @click="showMerchantPopup = false">取消</view>
                <view class="popup-header-title">选择商户</view>
                <view class="popup-header-confirm" @click="confirmBindMerchant">确定</view>
            </view>
            <view class="popup-body">
                <t-radio-group v-model:value="selectedMerchantId" @change="onMerchantSelectChange">
                    <view class="popup-merchant-item" v-for="item in merchants" :key="item.merchantId" @click="selectPopupMerchant(item)">
                        <image class="popup-merchant-logo" :src="item.merchantLogo || '/static/logo.png'" mode="aspectFill"></image>
                        <view class="popup-merchant-info">
                            <text class="popup-merchant-name">{{ item.merchantName }}</text>
                            <text class="popup-merchant-staff" v-if="item.staffName">{{ item.staffName }} · {{ item.roleName }}</text>
                        </view>
                        <t-radio v-model:value="item.merchantId"/>
                    </view>
                </t-radio-group>
                <view class="popup-empty" v-if="merchants.length === 0">
                    <text class="popup-empty-text">暂无可绑定的商户</text>
                </view>
            </view>
        </t-popup>
    </view>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad,onShow, onPageScroll} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import utils from '@/utils/utils.js'
import {POSITION_ID} from '@/constants/common.js'
import config from "@/config";

const {push, switchTab} = useLink()
const {isLoggedIn, login} = useAuth()

const scrollY = ref(0)

const status = ref('pending') // pending | loading | success | error | warning
const authStatus = ref(0) // 接口返回的授权状态：0-4
const errorTitle = ref('')
const errorMsg = ref('')
const corpId = ref('')
const corpName = ref('')
const merchantName = ref('')
const merchantLogo = ref('')
const merchantAddress = ref('')
const merchants = ref([]) // 员工加入的商户列表
const selectedMerchantId = ref('') // 选中的商户ID
const selectedMerchantName = ref('') // 选中的商户名称
const showMerchantPopup = ref(false) // 商户选择弹框
const qyCodeRes = ref('')
const isWecom = ref(false)
const currentTab = ref(null) // 底部导航栏当前选中
// 使用场景推荐位列表（undefined=加载中 / []=空 / 有数据）
const positionItems = ref()
// 小程序版本号
const appVersion = ref('')

onPageScroll((e) => {
    if (e.scrollTop < 360) {
        scrollY.value = e.scrollTop
    }
})

// 调用企微登录凭证接口
const qyLogin = () => {
    status.value = 'loading'
    wx.qy.login({
        //suiteId:'wwxxxxxx', //非必填，第三方应用的suiteid，自建应用不填。若第三方小程序绑定多个第三方应用时，建议填上该字段
        success: (res) => {
            console.log('qyLogin:', JSON.stringify(res))
            qyCodeRes.value = JSON.stringify(res)
            if (res.code) {
                getWecomCorp(res.code)
            } else {
                status.value = 'error'
                errorTitle.value = '获取凭证失败'
                errorMsg.value = '获取企微登录凭证失败'
            }
        },
        fail: (err) => {
            console.log('qyLogin-error:', JSON.stringify(err))
            status.value = 'error'
            errorTitle.value = '请在企业微信中打开本页'
            errorMsg.value = '请企业微信管理员先授权企业微信，再进行操作'
        }
    })
}

// 显示绑定商户弹框
const showBindMerchantPopup = () => {
    selectedMerchantId.value = ''
    showMerchantPopup.value = true
}

// 弹框状态变化
const onPopupChange = (visible) => {
    showMerchantPopup.value = visible
}

// 选择弹框中的商户
const selectPopupMerchant = (merchant) => {
    selectedMerchantId.value = merchant.merchantId
    selectedMerchantName.value = merchant.merchantName
    console.log('selectPopupMerchant:','selectedMerchantId:', selectedMerchantId.value, 'selectedMerchantName:', selectedMerchantName.value)
}

// 商户单选变更
const onMerchantSelectChange = (e) => {
    selectedMerchantId.value = e.value
    if (selectedMerchantId.value){
        selectedMerchantName.value = merchants.value.find(item => item.merchantId === selectedMerchantId.value).merchantName
    }
    console.log('onMerchantSelectChange:','selectedMerchantId:', selectedMerchantId.value, 'selectedMerchantName:', selectedMerchantName.value)
}

// 确认绑定商户
const confirmBindMerchant = () => {
    console.log('confirmBindMerchant:','selectedMerchantId:', selectedMerchantId.value, 'selectedMerchantName:', selectedMerchantName.value)
    if (!selectedMerchantId.value) {
        utils.toast('请选择要绑定的商户')
        return
    }
    status.value = 'loading'
    request.post('/user/wecom/corp/bind', {
        corpId: corpId.value,
        merchantId: selectedMerchantId.value
    }).then((res) => {
        console.log('bindResult:', JSON.stringify(res))

        if (res.code === 0) {
            // 绑定成功
            status.value = 'success'
            merchantName.value = selectedMerchantName.value
        } else {
            // 其他状态
            status.value = 'error'
            errorTitle.value = '绑定失败'
            errorMsg.value = res.message
            // utils.toast('绑定失败，请稍后重试')
        }
        showMerchantPopup.value = false
    }).catch((err) => {
        console.log('bindError:', JSON.stringify(err))
        showMerchantPopup.value = false
        status.value = 'error'
        errorTitle.value = '绑定失败'
        errorMsg.value = (err && err.message) ? err.message : '绑定商户失败，请稍后重试'
    })
}

// 提交绑定
const getWecomCorp = (code) => {
    status.value = 'loading'
    request.get('/user/wecom/corp/query', {
        code: code,
    }).then((res) => {
        console.log('wecomCorpResult:', JSON.stringify(res))
        const data = res.data || {}
        authStatus.value = data.status || 0

        // 保存企业信息
        corpId.value = data.corpId || ''
        corpName.value = data.corpName || ''
        merchantName.value = data.merchantName || ''
        merchantLogo.value = data.merchantLogo || ''
        merchantAddress.value = data.merchantAddress || ''
        merchants.value = data.merchants || []

        if (authStatus.value === 0) {
            // 查无此企微
            status.value = 'error'
            errorTitle.value = '查无此企微'
            errorMsg.value = '未找到对应的企业微信，请确认企业微信已开通此应用'
        } else if (authStatus.value === 1) {
            // 此企微不是管理员授权
            status.value = 'error'
            errorTitle.value = '非管理员授权'
            errorMsg.value = '此企业微信非管理员授权，请联系企微管理员进行授权操作'
        } else if (authStatus.value === 2) {
            // 当前员工没有加入到企业绑定的商户
            status.value = 'warning'
        } else if (authStatus.value === 3) {
            // 企业微信授权成功并绑定商户
            status.value = 'success'
        } else if (authStatus.value === 4) {
            // 企微没有关联商户
            status.value = 'warning'
        } else {
            status.value = 'error'
            errorTitle.value = '状态异常'
            errorMsg.value = '未知的授权状态'
        }
    }).catch((err) => {
        console.log('wecomCorpError:', JSON.stringify(err))
        status.value = 'error'
        errorTitle.value = '授权信息查询失败'
        errorMsg.value = (err && err.message) ? err.message : '授权信息查询失败，请稍后重试'
    })
}

// 获取企微绑定页推荐位
const getWecomPosition = () => {
    request.get('/position', {id: POSITION_ID.WECOM_BIND}, {showLoading: false}).then(res => {
        positionItems.value = res.data?.items || []
    })
}

// 进入商户中心
const goIndex = () => {
    switchTab('/pages/merchant/index')
}

// 跳转到商家注册页面
const goRegister = () => {
    push('/pages/merchant/create?source=' + encodeURIComponent('企业微信') + '&corpId=' + corpId.value + '&corpName=' + corpName.value)
}

// 底部导航栏点击
const onTabChange = (context) => {
    // if (status.value !== 'success') {
    //     currentTab.value = null
    //     utils.toast('请先绑定')
    //     return
    // }

    const value = context.value
    if (value === 1) {
        switchTab('/pages/index/index')
    } else if (value === 2) {
        switchTab('/pages/merchant/index')
    }
}

// 用户授权成功回调
const onGetUserInfoSuccess = async (e) => {
    utils.showLoading()
    login({
        nickname: e.detail.userInfo.nickName,
        avatar: e.detail.userInfo.avatarUrl
    }).then(() => {
        // 登录成功后自动执行绑定流程
        qyLogin()
    }).finally(() =>
        utils.hideLoading()
    )
}

// 用户授权失败回调
const onGetUserInfoFail = () => {
    utils.toast('登录失败，请重试')
}

onLoad((e) => {
    // 获取使用场景推荐位数据
    getWecomPosition()

    // 1. 检查是否在企业微信环境中
    const systemInfo = wx.getSystemInfoSync()
    isWecom.value = systemInfo.environment === 'wxwork' || (typeof wx.qy !== 'undefined')

    if (!isWecom.value) {
        // 非企微环境，提示错误
        status.value = 'error'
        errorTitle.value = '请在企业微信中打开本页'
        errorMsg.value = '请企业微信管理员先授权企业微信，再进行操作'
        return
    }

    // 2. 企微环境，检测登录状态（通过 isLoggedIn 控制模板显示）
    if (isLoggedIn.value) {
        // 已登录，执行绑定流程
        qyLogin()
    }
})

onShow(() => {
    utils.checkUpdateVersion()
})

</script>

<style scoped>
/* 顶部品牌区域 */
.header {
    position: relative;
    padding: 240rpx 0 120rpx;
    overflow: hidden;
}

.header-bg {
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: linear-gradient(135deg, #e2453d 0%, #c0392b 100%);
    border-radius: 0;
}

.header-content {
    position: relative;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.brand-logo {
    width: 120rpx;
    height: 120rpx;
    border-radius: 28rpx;
    background: #fff;
    box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.15);
}

.brand-name {
    font-size: 40rpx;
    font-weight: 700;
    color: #fff;
    margin-top: 20rpx;
    letter-spacing: 2rpx;
}

.brand-slogan {
    font-size: 26rpx;
    color: rgba(255, 255, 255, 0.85);
    margin-top: 8rpx;
}

/* 绑定状态卡片 */
.bind-container {
    position: relative;
    margin-top: -80rpx;
    padding-bottom: 80rpx;
}

.bind-card {
    padding: 48rpx 32rpx 40rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

.status-icon {
    width: 120rpx;
    height: 120rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 24rpx;
}

.status-icon-pending {
    background: #e6f4ff;
}

.status-icon-loading {
    background: #fff7e6;
}

.status-icon-success {
    background: #e8f8ee;
}

.status-icon-warning {
    background: #fff3e0;
}

.status-icon-error {
    background: #fde8e8;
}

.status-title {
    font-size: 34rpx;
    font-weight: 600;
    color: #333;
    margin-bottom: 12rpx;
}

.status-desc {
    font-size: 28rpx;
    color: #999;
    line-height: 1.6;
    padding: 0 16rpx;
}

.status-tips {
    font-size: 26rpx;
    color: #d46b08;
    line-height: 1.6;
    padding: 0 16rpx;
    margin-top: 16rpx;
    text-align: center;
}

.status-info {
    display: flex;
    flex-direction: column;
    align-items: center;
    margin-top: 12rpx;
}

.bind-actions {
    width: 100%;
    margin-top: 32rpx;
    padding: 0 16rpx;
}

/* 功能说明卡片 */
.feature-card {
    padding: 0;
    overflow: hidden;
}

.feature-header {
    display: flex;
    align-items: center;
    padding: 28rpx 32rpx 0;
}

.feature-bar {
    width: 6rpx;
    height: 32rpx;
    background: #e2453d;
    border-radius: 3rpx;
    margin-right: 12rpx;
}

.feature-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
}

.feature-list {
    margin-top: 16rpx;
}

/*
 * 自定义样式原因：app.css 的 .media 无内边距与分隔线，
 * 此处仅补充推荐位列表项在卡片内的间距与分隔视觉。
 */
.feature-item {
    padding: 28rpx 32rpx;
    border-bottom: 1rpx solid #f5f5f5;
}

.feature-item:last-child {
    border-bottom: none;
}

.feature-item:active {
    background: #fafafa;
}

/* 温馨提示 */
.tips-card {
    padding: 24rpx;
    background: #fff7e6;
    border: 1px solid #ffd591;
}

.tips-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #d46b08;
}

.tips-body {
    display: flex;
    flex-direction: column;
}

.tips-text {
    font-size: 26rpx;
    color: #874d00;
    line-height: 1.8;
}

/* 底部版本号 */
.version-text {
    text-align: center;
    font-size: 24rpx;
    color: #bbb;
    padding: 24rpx 0 40rpx;
}

/* 商户选择底部弹框 */
.popup-merchant-item {
    display: flex;
    align-items: center;
    padding: 24rpx 0 24rpx 24rpx;
    border-bottom: 1rpx solid #f5f5f5;
}

.popup-merchant-item:last-child {
    border-bottom: none;
}

.popup-merchant-logo {
    width: 96rpx;
    height: 96rpx;
    border-radius: 12rpx;
    background: #f5f5f5;
    flex-shrink: 0;
}

.popup-merchant-info {
    flex: 1;
    margin-left: 24rpx;
    display: flex;
    flex-direction: column;
}

.popup-merchant-name {
    font-size: 30rpx;
    font-weight: 500;
    color: #333;
}

.popup-merchant-staff {
    font-size: 26rpx;
    color: #999;
    margin-top: 8rpx;
}

.popup-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 80rpx 0;
}

.popup-empty-text {
    font-size: 28rpx;
    color: #999;
}

/* 底部导航栏图标
 * 自定义样式原因：TDesign tab-bar-item 的 .t-tab-bar-item__icon 使用 display: contents，
 * 导致 #icon 插槽内容成为 flex 直接子元素，需 flex-shrink: 0 防止被容器压缩。
 */
.tab-bar-icon {
    display: block;
    width: 56rpx;
    height: 56rpx;
    flex-shrink: 0;
}
.tab-bar-text {
    font-size: 20rpx;
    color: #666666;
    line-height: 28rpx;
}
</style>
