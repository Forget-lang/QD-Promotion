<template>
    <template v-if="showSuccess">
        <m-result type="success" title="修改成功" description="企微群欢迎语已更新" back>
            <view class="d-flex justify-content-center mt-3">
                <image src="https://cdn.lenmy.com/quandao/2026/06/20/d8r4vjhl4ekdf4fd369g.png" mode="widthFix"></image>
            </view>
            <view class="mt-3 mb-3 alert-success">现在打开企业微信，确认欢迎语配置已更新。</view>
        </m-result>
    </template>
    <view v-else class="container-safety">
        <m-loading v-if="!loaded"></m-loading>
        <template v-else>
            <t-cell-group theme="card" t-class="mt-2">
                <t-input label="模版名称" v-model:value="form.name" align="right"
                         placeholder="例如：券到卡包"></t-input>
                <t-input label="卡片标题" v-model:value="form.shareTitle" align="right"
                         placeholder="例如：会员专享，点击领取。"></t-input>
            </t-cell-group>

            <view class="container">
                <view class="section mt-2">
                    <view class="section-header">
                        <view class="section-title">消息内容<text class="required-mark">*</text></view>
                    </view>
                    <t-textarea v-model:value="form.content" :bordered="true"
                                custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                                placeholder="请输入消息内容（必填，每次发放时与优惠券卡片一起显示）">
                    </t-textarea>
                </view>
            </view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存修改</m-submit>
        </template>
    </view>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'

const form = ref({
    productType: 1,
})
// 详情是否加载完成
const loaded = ref(false)
// 是否提交中（控制按钮 loading 与禁用）
const loading = ref(false)
// 是否提交成功展示结果页
const showSuccess = ref(false)
let groupId = ''

// 保存企业微信群欢迎语修改
const onSubmit = () => {
    // 防重复提交
    if (loading.value) return
    loading.value = true
    request.post('/seller/wecom/group/update', {...form.value, id: groupId}).then(() => {
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}

const loadDetail = () => {
    request.get('/seller/wecom/group/detail', {id: groupId}).then(res => {
        const data = res.data
        form.value = {
            name: data.name,
            productType: data.productType,
            productId: data.productId,
            content: data.content,
            shareTitle: data.shareTitle,
        }
        loaded.value = true
    }).catch(() => {
        uni.showToast({title: '加载失败', icon: 'none'})
    })
}

onLoad((options) => {
    if (options.id) {
        groupId = options.id
        loadDetail()
    }
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
/* 必填星号，使用主题错误色 */
.required-mark {
    margin-left: 4rpx;
    color: var(--td-error-color, #e34d59);
}
</style>
