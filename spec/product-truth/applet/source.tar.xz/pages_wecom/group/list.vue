<template>
    <m-loading v-if="corp === undefined"></m-loading>
    <template v-else>
        <template v-if="corp.status === CORP_STATUS.UNAUTHORIZED">
            <view class="container mt-2">
                <view class="tips-card">
                    <text class="tips-title">功能介绍</text>
                    <view class="tips-item">
                        <text class="tips-text">设置企微群欢迎语，每当有新成员进群时，就会弹出欢迎语及领券小程序卡片</text>
                    </view>
                    <view class="tips-item">
                        <text class="tips-text">成员点击卡片，即可领取优惠券</text>
                    </view>
                    <view class="tips-item">
                        <text class="tips-text">适合企业微信群拉新任务。</text>
                    </view>
                </view>
            </view>
            <!-- 未授权 -->
            <view class="container mt-2">
                <view class="section">
                    <m-result type="info" title="企业微信未授权" description="请企业微信管理员先授权企业微信，然后进行配置。">
                        <template #actions>
                            <t-button theme="primary" @click="push('/pages_wecom/wecom/auth')">授权企业微信</t-button>
                        </template>
                    </m-result>
                </view>
            </view>
        </template>
        <template v-else-if="corp.status === CORP_STATUS.AUTHORIZED">
            <!-- 已授权 -->
            <m-loading v-if="items === undefined"></m-loading>
            <view v-else class="page bottom-safety">
                <m-empty v-if="!items.length">暂无进群欢迎语，请先添加，然后应用到企微群。</m-empty>
                <template v-else>
                    <view class="container">
                        <view class="section mt-3" v-for="item in items" :key="item.id">
                            <view class="section-header bottom-line">
                                <view class="section-title">{{ item.name }}</view>
                                <view class="section-more" :class="productTypeClass(item.productType)">
                                    {{ productTypeLabel(item.productType) }}
                                </view>
                            </view>
                            <view class="section-body">
                                <view v-if="item.productName">推广卡券：{{ item.productName }}</view>
                                <view class="mt-1" v-if="item.content">消息内容：{{ item.content }}</view>
                                <view class="mt-1" v-if="item.shareTitle">卡片标题：{{ item.shareTitle }}</view>
                            </view>
                            <view class="section-footer">
                                <view class="text-small">{{ item.createdAt }}</view>
                                <view class="d-flex flex-gap-1">
                                    <t-tag theme="default" variant="outline" @click.stop="onDelete(item.id)">删除</t-tag>
                                    <t-tag theme="default" variant="outline" @click.stop="onEdit(item.id)">修改</t-tag>
                                    <t-tag theme="primary" variant="outline" @click.stop="push('/pages_wecom/group/help')">
                                        使用
                                    </t-tag>
                                </view>
                            </view>
                        </view>
                    </view>

                </template>
                <m-submit @click="push('/pages_wecom/group/add?productType=' + productType + '&productId=' + productId)">
                    添加群欢迎语模版
                </m-submit>
            </view>
        </template>
    </template>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {ref} from 'vue'
import {onShow, onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {PRODUCT_TYPE} from '@/constants/product.js'
import {CORP_STATUS} from '@/constants/wecom.js'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils.js'
import MResult from "@/components/m/m-result/m-result.vue";

const {push} = useLink()
const items = ref()
const total = ref(0)
// 企业微信授权信息（undefined 表示加载中）
const corp = ref()
const productType = ref(0)
const productId = ref(0)

const productTypeMap = {[PRODUCT_TYPE.COUPON]: '优惠券', [PRODUCT_TYPE.BUNDLE]: '券包', [PRODUCT_TYPE.CARD]: '次卡'}
const productTypeLabel = (type) => productTypeMap[type] || '未知'
const productTypeClass = (type) => type === PRODUCT_TYPE.COUPON ? 'tag-on' : type === PRODUCT_TYPE.BUNDLE ? 'tag-warn' : 'tag-off'

// 获取企业微信授权状态
const getCorp = () => {
    request.get('/seller/wecom/corp').then(res => {
        // 兜底空数据，避免 corp.status 取 undefined 报错
        corp.value = res.data || {}
        // 已授权
        if (corp.value.status === CORP_STATUS.AUTHORIZED) {
            getItems()
        }
    }).catch(() => {
        // 接口失败时置空对象，进入未授权分支
        corp.value = {}
    })
}

const getItems = () => {
    return request.get('/seller/wecom/group/list', {
        page: 1,
        pageSize: 50,
        productType: productType.value,
        productId: productId.value
    }, {showLoading: false}).then(res => {
        items.value = res.data.items
        total.value = res.data.total
    }).catch(() => {
        items.value = []
    })
}

// 删除群欢迎语模版
const onDelete = (id) => {
    uni.showModal({
        title: '删除确认',
        content: '删除后，使用该欢迎语的企微群，新成员进群将无法弹出领券卡片，请谨慎操作。',
        success: (res) => {
            if (res.confirm) {
                request.post('/seller/wecom/group/delete', {id}, {showLoading: true}).then(() => {
                    utils.toast('删除成功')
                    getItems()
                })
            }
        }
    })
}

const onEdit = (id) => {
    push('/pages_wecom/group/edit?id=' + id)
}

onShow(() => {
    getCorp()
})

onLoad((e) => {
    productType.value = e.productType
    productId.value = e.productId
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>

</style>
