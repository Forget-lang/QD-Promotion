<template>
    <template v-if="showSuccess">
        <m-result type="success" title="添加成功" description="打开企业微信，配置欢迎语到群聊" back>
            <view class="d-flex justify-content-center mt-3">
                <image src="https://cdn.lenmy.com/quandao/2026/06/20/d8r4vjlb4ekdf4fd369g.png" mode="widthFix"></image>
            </view>
            <view class="mt-3 mb-3 alert-success">现在打开企业微信，把欢迎语配置到 您想要的企微群中。</view>
        </m-result>
    </template>
    <view v-else class="container-safety">
        <t-cell-group theme="card" t-class="mt-2">
            <t-input label="模版名称" v-model:value="form.name" align="right"
                     placeholder="例如：企微5群"></t-input>
            <t-input label="卡片标题" v-model:value="form.shareTitle" align="right"
                     placeholder="例如：会员专享，点击领取。"></t-input>
        </t-cell-group>

        <view class="container">
            <view class="section mt-2">
                <view class="section-header">
                    <view class="section-title">消息内容<text class="required-mark">*</text></view>
                </view>
                <t-textarea v-model:value="form.content" :bordered="true"
                            custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                            placeholder="请输入消息内容（必填，每次发放时与优惠券卡片一起显示）">
                </t-textarea>
            </view>

            <view class="section mt-2">
                <view class="section-header">
                    <view class="section-title">发放备注</view>
                </view>
                <t-textarea v-model:value="form.issueRemark" :bordered="true" :maxlength="32" :indicator="true"
                            custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                            placeholder="请输入备注信息（选填，仅商家可见，客户不可见）">
                </t-textarea>
            </view>
        </view>
        <m-submit :loading="loading" :disabled="loading" @click="onSubmit">添加企业微信群欢迎语</m-submit>
    </view>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'

// 表单数据
const form = ref({
    productType: 1,
})
// 是否提交中（控制按钮 loading 与禁用）
const loading = ref(false)
// 是否提交成功展示结果页
const showSuccess = ref(false)

// 提交企业微信群欢迎语
const onSubmit = () => {
    // 防重复提交
    if (loading.value) return
    loading.value = true
    request.post('/seller/wecom/group/create', form.value).then(() => {
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    form.value.productType = e.productType
    form.value.productId = e.productId
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
/* 必填星号，使用主题错误色 */
.required-mark {
    margin-left: 4rpx;
    color: var(--td-error-color, #e34d59);
}
</style>
