<template>
    <m-loading v-if="items === undefined"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <m-empty v-if="!items.length">暂无企微员工，请从加好友发券入口添加</m-empty>
            <template v-else>
                <view class="section mt-2" v-for="item in items" :key="item.id">
                    <view class="section-header bottom-line">
                        <view class="section-title title-wrap">
                            <ww-open-data v-if="item.corpId" type="userName" :corpid="item.corpId"
                                          :openid="item.corpUserId"></ww-open-data>
                        </view>
                        <view class="section-more">
                            <t-tag
                                v-if="item.productType"
                                :theme="productTypeTheme(item.productType)"
                                variant="light"
                                size="small"
                            >{{ productTypeLabel(item.productType) }}
                            </t-tag>
                            <t-tag v-else theme="default" variant="light" size="small">未绑定</t-tag>
                        </view>
                    </view>
                    <view class="section-body body-compact">
                        <view class="meta-row">
                            <text class="meta-label">卡券</text>
                            <text class="meta-value">{{ item.productName || '未绑定卡券' }}</text>
                        </view>
                        <view class="meta-row">
                            <text class="meta-label">关联员工</text>
                            <text class="meta-value">{{ item.name || '—' }}</text>
                        </view>
                    </view>
                    <view class="section-footer">
                        <text class="created-at">{{ item.createdAt }}</text>
                        <view class="d-flex flex-gap-1">
                            <t-tag
                                v-if="item.productType"
                                theme="default"
                                variant="outline"
                                size="large"
                                @click="onUnbind(item.id)"
                            >解绑卡券
                            </t-tag>
                            <t-tag theme="danger" variant="outline" size="large" @click="onDelete(item.id)">删除</t-tag>
                            <t-tag theme="primary" variant="outline" size="large" @click="goDetail(item.id)">
                                下载二维码
                            </t-tag>
                        </view>
                    </view>
                </view>
            </template>
        </view>
    </template>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {ref} from 'vue'
import {onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {PRODUCT_TYPE} from '@/constants/product.js'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils'

const {push} = useLink()
const items = ref()

const productTypeMap = {
    [PRODUCT_TYPE.COUPON]: '优惠券',
    [PRODUCT_TYPE.BUNDLE]: '券包',
    [PRODUCT_TYPE.CARD]: '次卡',
}

const productTypeThemeMap = {
    [PRODUCT_TYPE.COUPON]: 'danger',
    [PRODUCT_TYPE.BUNDLE]: 'primary',
    [PRODUCT_TYPE.CARD]: 'warning',
}

const productTypeLabel = (type) => productTypeMap[type] || '未知'
const productTypeTheme = (type) => productTypeThemeMap[type] || 'default'

const getItems = () => {
    return request.get('/seller/wecom/staff/list', {page: 1, pageSize: 100}, {showLoading: false}).then(res => {
        items.value = res.data.items || []
    }).catch(() => {
        items.value = []
    })
}

const onUnbind = (id) => {
    uni.showModal({
        title: '解绑确认',
        content: '解绑卡券后员工二维码可继续使用；但客户扫码添加好友后，将不再自动发放卡券。',
        success: (res) => {
            if (res.confirm) {
                request.post('/seller/wecom/staff/unbind', {id}).then(() => {
                    utils.toast('解绑成功')
                    getItems()
                })
            }
        }
    })
}

const onDelete = (id) => {
    uni.showModal({
        title: '删除确认',
        content: '删除后该员工的企微联系我二维码将失效，需重新添加员工并获取新二维码；已绑定的卡券关联一并清除。',
        success: (res) => {
            if (res.confirm) {
                request.post('/seller/wecom/staff/delete', {id}).then(() => {
                    utils.toast('删除成功')
                    getItems()
                })
            }
        }
    })
}

const goDetail = (id) => push('/pages_wecom/staff/detail?id=' + id)

onShow(() => {
    getItems()
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
.title-wrap {
    flex: 1;
    min-width: 0;
    margin-right: 16rpx;
    overflow: hidden;
}

.body-compact {
    padding-top: 20rpx !important;
    padding-bottom: 20rpx !important;
}

.meta-row {
    display: flex;
    align-items: baseline;
    line-height: 1.5;
}

.meta-row + .meta-row {
    margin-top: 10rpx;
}

.meta-label {
    width: 128rpx;
    flex-shrink: 0;
    font-size: 24rpx;
    color: #999;
}

.meta-value {
    flex: 1;
    min-width: 0;
    font-size: 26rpx;
    color: #333;
    word-break: break-all;
}

.created-at {
    font-size: 22rpx;
    color: #bbb;
}
</style>
