<template>
    <m-loading v-if="items === undefined"></m-loading>
    <m-empty v-else-if="items === null">
        <view>加载失败</view>
        <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
    </m-empty>
    <view v-else class="page bottom-safety">
        <m-empty v-if="!items.length" description="暂无发送记录"></m-empty>
        <t-cell-group v-else theme="card" t-class="mt-2">
            <t-cell v-for="item in items" :key="item.id">
                <template #title>
                    <view class="log-title">{{ item.statusLabel }}</view>
                </template>
                <template #note>
                    <view class="log-note">
                        <text>{{ item.createdAt }}</text>
                        <text v-if="item.errMsg" class="err">{{ item.errMsg }}</text>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>
        <m-loading v-if="loadingMore" text="正在加载..."/>
        <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
    </view>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import {CHANNEL_TYPE} from '@/constants/common.js'
import to from '@/hooks/to'

// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref(undefined)
// 列表查询参数
const search = ref({page: 1, pageSize: 20, channelType: CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT})
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)
// 发送记录总数
const total = ref(0)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取发送记录列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/wecom-send-log/list', search.value, {showLoading: search.value.page === 1}).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

onLoad(() => {
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.log-title {
    font-size: 28rpx;
}

.log-note {
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    font-size: 24rpx;
    color: #999;
}

.err {
    color: #e34d59;
    margin-top: 4rpx;
}
</style>
