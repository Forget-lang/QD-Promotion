<template>
    <m-loading v-if="loading"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <view class="tips-card mt-2">
                <text class="tips-title">使用说明</text>
                <view class="tips-item">
                    <text class="tips-text">保存二维码图片，客户扫码即可添加企微好友并自动收到领券卡片</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">二维码可打印在海报、宣传单、台卡等物料上使用</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">每个员工的二维码唯一，不可混用</text>
                </view>
            </view>

            <view class="qrcode-wrap">
                <image v-if="staff.qrcodeUrl" class="qrcode-image" :src="staff.qrcodeUrl"
                       mode="widthFix" show-menu-by-longpress></image>
                <m-empty v-else>暂无二维码</m-empty>
            </view>
        </view>
        <m-submit v-if="staff.qrcodeUrl" @click="onDownload">下载二维码</m-submit>
    </template>
    <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
    <m-vip-upgrade/>

</template>

<script setup>
import {ref} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import utils from '@/utils/utils.js'

const loading = ref(true)
const staffId = ref('')
const staff = ref({})

const getDetail = () => request.get('/seller/wecom/staff/detail', {id: staffId.value}, {showLoading: false}).then(res => {
    staff.value = res.data || {}
}).catch(() => {
    utils.toast('加载失败')
})

const onDownload = () => {
    utils.showLoading()
    wx.downloadFile({
        url: staff.value.qrcodeUrl,
        success(res) {
            wx.saveImageToPhotosAlbum({
                filePath: res.tempFilePath,
                success() {
                    utils.hideLoading()
                    utils.toast('已保存到相册')
                },
                fail() {
                    utils.hideLoading()
                    utils.toast('保存失败，请授权相册权限')
                }
            })
        },
        fail() {
            utils.hideLoading()
            utils.toast('下载失败')
        }
    })
}

onLoad((query) => {
    staffId.value = query.id || ''
    if (!staffId.value) {
        utils.toast('参数错误')
        loading.value = false
        return
    }
    getDetail().finally(() => {
        loading.value = false
    })
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
.qrcode-wrap {
    margin: 32rpx 24rpx;
    text-align: center;
}

.qrcode-image {
    width: 500rpx;
    border-radius: 12rpx;
}
</style>
