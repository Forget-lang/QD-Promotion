<template>
    <template v-if="showSuccess">
        <m-result type="success" title="修改成功" description="企微员工发券规则已更新" back>
            <view class="mt-3 mb-3 alert-success">修改后的规则将在下次客户添加好友时生效。</view>
        </m-result>
    </template>
    <view v-else class="container-safety">
        <m-loading v-if="!loaded"></m-loading>
        <template v-else>
            <t-cell-group theme="card" t-class="mt-2">
                <t-input label="分享标题" v-model:value="form.shareTitle" align="right"
                         placeholder="例如：会员专享，点击领取。"></t-input>
                <t-cell title="每次发放数量">
                    <template #note>
                        <view class="quantity-control">
                            <view class="quantity-btn" @click="decreaseIssueCount">
                                <t-icon name="minus" size="20px"/>
                            </view>
                            <input class="quantity-input" type="number" v-model="form.issueCount" :max="10" :min="1"/>
                            <view class="quantity-btn quantity-add" @click="increaseIssueCount">
                                <t-icon name="add" size="20px" color="#fff"/>
                            </view>
                        </view>
                    </template>
                </t-cell>
                <t-cell title="超时时间">
                    <template #description>
                        <view>
                            <view class="mt-2">
                                <m-tag-select v-model:value="form.expireMinute" :column="5"
                                              :options="durationOptions"></m-tag-select>
                            </view>
                        </view>
                    </template>
                </t-cell>
                <view class="cell-helper top-line">超过有效期后，领取链接失效，需要重新发放。</view>
            </t-cell-group>

            <view class="container">
                <view class="section mt-2">
                    <view class="section-header">
                        <view class="section-title">消息内容<text class="required-mark">*</text></view>
                    </view>
                    <t-textarea v-model:value="form.content" :bordered="true"
                                custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                                placeholder="请输入消息内容（必填，每次发放时与优惠券卡片一起显示）">
                    </t-textarea>
                </view>

                <view class="section mt-2">
                    <view class="section-header">
                        <view class="section-title">发放备注</view>
                    </view>
                    <t-textarea v-model:value="form.issueRemark" :bordered="true" :maxlength="32" :indicator="true"
                                custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                                placeholder="请输入备注信息（选填，仅商家可见，客户不可见）">
                    </t-textarea>
                </view>
            </view>

            <m-submit @click="onSubmit">保存修改</m-submit>
        </template>
    </view>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import utils from '@/utils/utils.js'

const loaded = ref(false)
const showSuccess = ref(false)
let staffId = ''

const form = ref({
    productType: 1,
    productId: '',
    shareTitle: '',
    issueCount: 1,
    expireMinute: 0,
    issueRemark: '',
})

const durationOptions = [
    {label: '5分钟', value: 5},
    {label: '1天', value: 1440},
    {label: '7天', value: 10080},
    {label: '30天', value: 43200},
    {label: '永久', value: 0},
]

const getDetail = () => {
    request.get('/seller/wecom/staff/detail', {id: staffId}).then(res => {
        form.value = res.data
        loaded.value = true
    }).catch(() => {
        uni.showToast({title: '加载失败', icon: 'none'})
    })
}

const onSubmit = () => {
    request.post('/seller/wecom/staff/update', form.value).then(() => {
        showSuccess.value = true
    })
}

const decreaseIssueCount = () => {
    if (form.value.issueCount > 1) {
        form.value.issueCount--
    }
}

const increaseIssueCount = () => {
    if (form.value.issueCount >= 10) {
        utils.toast('最多可发放10张')
        return
    }
    form.value.issueCount++
}

onLoad((options) => {
    if (options.id) {
        staffId = options.id
        getDetail()
    }
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
/* 数量控制 */
.quantity-control {
    display: flex;
    align-items: center;
}

.quantity-btn {
    width: 56rpx;
    height: 56rpx;
    background-color: #f5f5f5;
    border-radius: 8rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.quantity-add {
    background-color: #07c160;
}

.quantity-input {
    flex: 1;
    height: 56rpx;
    width: 80rpx;
    margin: 0 20rpx;
    text-align: center;
    font-size: 28rpx;
    border: none;
    outline: none;
}

/* 必填星号，使用主题错误色 */
.required-mark {
    margin-left: 4rpx;
    color: var(--td-error-color, #e34d59);
}
</style>
