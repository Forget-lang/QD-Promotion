<template>
    <view class="container-safety">
        <t-cell-group theme="card" t-class="mt-2">
            <m-loading v-if="items === undefined"></m-loading>
            <t-cell v-else title="企业成员" arrow hover required @click="onOpenCorpUser">
                <template #note>
                    <ww-open-data v-if="form.corpUserId" type="userName" :corpid="corpId"
                                  :openid="form.corpUserId"></ww-open-data>
                    <text v-else class="lh-24">请选择企业成员</text>
                </template>
            </t-cell>
            <m-staff-select v-if="form.productId" v-model:value="form.staffId" :multiple="false" title="关联员工"
                            :gateway="staffGateway" :params="staffParams"
                            placeholder="请选择发券员工"></m-staff-select>
            <t-input label="分享标题" v-model:value="form.shareTitle" align="right"
                     placeholder="例如：会员专享，点击领取。"></t-input>
            <t-cell title="每次发放数量">
                <template #note>
                    <view class="quantity-control">
                        <view class="quantity-btn" @click="decreaseIssueCount">
                            <t-icon name="minus" size="20px"/>
                        </view>
                        <input class="quantity-input" type="number" v-model="form.issueCount" :max="10" :min="1"/>
                        <view class="quantity-btn quantity-add" @click="increaseIssueCount">
                            <t-icon name="add" size="20px" color="#fff"/>
                        </view>
                    </view>
                </template>
            </t-cell>
            <t-cell title="超时时间">
                <template #description>
                    <view>
                        <view class="mt-2">
                            <m-tag-select v-model:value="form.expireMinute" :column="5"
                                          :options="durationOptions"></m-tag-select>
                        </view>
                    </view>
                </template>
            </t-cell>
            <view class="cell-helper top-line">超过有效期后，领取链接失效，需要重新发放。</view>
        </t-cell-group>

        <view class="container">
            <view class="section mt-2">
                <view class="section-header">
                    <view class="section-title">消息内容<text class="required-mark">*</text></view>
                </view>
                <t-textarea v-model:value="form.content" :bordered="true"
                            custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                            placeholder="请输入消息内容（必填，每次发放时与优惠券卡片一起显示）">
                </t-textarea>
            </view>

            <view class="section mt-2">
                <view class="section-header">
                    <view class="section-title">发放备注</view>
                </view>
                <t-textarea v-model:value="form.issueRemark" :bordered="true" :maxlength="32" :indicator="true"
                            custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                            placeholder="请输入备注信息（选填，仅商家可见，客户不可见）">
                </t-textarea>
            </view>
        </view>


    </view>

    <t-popup v-model:visible="showCorpUserPopup" placement="bottom">
        <view class="popup-header">
            <view class="popup-header-cancel" @click="onCancelCorpUser">取消</view>
            <view class="popup-header-title">请选择企业成员</view>
            <view class="popup-header-confirm" @click="onConfirmCorpUser">确定</view>
        </view>
        <scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
            <m-empty v-if="!items || items.length === 0" description="暂无可添加的成员"></m-empty>
            <template v-else>
                <t-radio-group v-model:value="tempCorpUserId">
                    <t-radio v-for="item in items" :disabled="item.isConfig" :key="item.corpUserId"
                             :value="item.corpUserId">
                        <ww-open-data type="userName" :corpid="corpId"
                                      :openid="item.corpUserId"></ww-open-data>
                    </t-radio>
                </t-radio-group>
                <view class="mt-5 text-wechat text-center" @click="push('/pages_wecom/staff/manage')">企业成员无法选择？前往解绑卡券。</view>
            </template>
        </scroll-view>

    </t-popup>

    <m-submit @click="onSubmit" :loading="loading" :disabled="loading">添加企业成员</m-submit>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>

</template>

<script setup>
import {ref, computed} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {PRODUCT_TYPE} from '@/constants/product.js'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils.js'
import {CARD_TYPE} from "@/constants/card";

const {replace, back, push} = useLink()

const loading = ref(false)
const items = ref(undefined)
const corpId = ref('')
const corpName = ref('')
const showCorpUserPopup = ref(false)
const tempCorpUserId = ref('')
const search = ref({
    page: 1,
    pageSize: 20,
})
const form = ref({
    productId: '',
    productType: 1,
    issueCount: 1,
    expireMinute: 0,
    shareTitle: '',
    corpUserId: '',
    staffId: '',
    content: '',
    issueRemark: '',
})

const staffGateway = computed(() => {
    const productType = form.value.productType
    if (productType === PRODUCT_TYPE.BUNDLE) {
        return '/seller/bundle/staff/list'
    }
    if (productType === PRODUCT_TYPE.CARD) {
        return '/seller/card/staff/list'
    }
    return '/seller/coupon/staff/list'
})

const staffParams = computed(() => {
    const productId = form.value.productId
    const productType = form.value.productType
    const base = {page: 1, pageSize: 100}
    if (productType === PRODUCT_TYPE.BUNDLE) {
        return {...base, bundleId: productId}
    }
    if (productType === PRODUCT_TYPE.CARD) {
        return {...base, cardId: productId}
    }
    return {...base, couponId: productId}
})

const durationOptions = [
    {label: '5分钟', value: 5},
    {label: '1天', value: 1440},
    {label: '7天', value: 10080},
    {label: '30天', value: 43200},
    {label: '永久', value: 0},
]

const getCorpUsers = () => {
    request.get('/seller/wecom/follow-users', search.value).then(res => {
        corpId.value = res.data.corpId
        corpName.value = res.data.corpName
        items.value = res.data.items || []
    })
}

const onOpenCorpUser = () => {
    if (items.value === undefined) {
        return
    }
    tempCorpUserId.value = form.value.corpUserId || ''
    showCorpUserPopup.value = true
}

const onCancelCorpUser = () => {
    showCorpUserPopup.value = false
}

const onConfirmCorpUser = () => {
    form.value.corpUserId = tempCorpUserId.value || ''
    showCorpUserPopup.value = false
}

// 用产品详情预填分享标题，避免经 URL 多次 encode 后出现 %E8%8A%B1 这类乱码
const fillShareTitle = () => {
    const productType = form.value.productType
    const productId = form.value.productId
    if (productType === PRODUCT_TYPE.COUPON) {
        request.get('/seller/coupon/detail', {id: productId}, {showLoading: false}).then(res => {
            form.value.shareTitle = res.data.shareTitle || res.data.name || ''
        })
    } else if (productType === PRODUCT_TYPE.BUNDLE) {
        request.get('/seller/bundle/get/detail', {id: productId}, {showLoading: false}).then(res => {
            form.value.shareTitle = res.data.shareTitle || res.data.name || ''
        })
    } else if (productType === PRODUCT_TYPE.CARD) {
        request.get('/seller/card/get/detail', {id: productId}, {showLoading: false}).then(res => {
            form.value.shareTitle = res.data.name || ''
        })
    }
}

const onSubmit = () => {
    if (!form.value.corpUserId) {
        utils.toast('请选择企业成员')
        return
    }
    request.post('/seller/wecom/staff/create', form.value, {showLoading: true}).then(res => {
        utils.toast('添加成功')
        const id = res.data.id
        if (id) {
            replace('/pages_wecom/staff/detail?id=' + id)
        } else {
            back()
        }
    }).finally(() => {

    })
}

const decreaseIssueCount = () => {
    if (form.value.issueCount > 1) {
        form.value.issueCount--;
    }
}

const increaseIssueCount = () => {
    if (form.value.issueCount >= 10) {
        utils.toast('最多可发放10张')
        return
    }
    form.value.issueCount++;
}

onLoad((e) => {
    if (!e.productType || !e.productId) {
        utils.toast('缺少卡券信息，请从券包、优惠券或次卡发放入口进入')
        setTimeout(() => uni.navigateBack(), 1500)
        return
    }
    form.value.productType = Number(e.productType) || 1
    form.value.productId = e.productId
    fillShareTitle()
    getCorpUsers()
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>

/* 数量控制 */
.quantity-control {
    display: flex;
    align-items: center;
}

.quantity-btn {
    width: 56rpx;
    height: 56rpx;
    background-color: #f5f5f5;
    border-radius: 8rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.quantity-add {
    background-color: #07c160;
}

.quantity-input {
    flex: 1;
    height: 56rpx;
    width: 80rpx;
    margin: 0 20rpx;
    text-align: center;
    font-size: 28rpx;
    border: none;
    outline: none;
}

/* 文本域标题，与 TDesign label 字号对齐 */
.textarea-label {
    font-size: 28rpx;
    line-height: 44rpx;
    color: var(--td-text-color-primary, rgba(0, 0, 0, 0.9));
}

/* 必填星号，使用主题错误色 */
.required-mark {
    margin-left: 4rpx;
    color: var(--td-error-color, #e34d59);
}
</style>
