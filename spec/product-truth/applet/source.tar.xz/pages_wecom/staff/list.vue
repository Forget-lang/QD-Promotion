<template>
    <m-loading v-if="corp === undefined"></m-loading>
    <template v-else>
        <template v-if="corp.status === CORP_STATUS.UNAUTHORIZED">
            <view class="container mt-2">
                <view class="tips-card">
                    <text class="tips-title">功能介绍</text>
                    <view class="tips-item">
                        <text class="tips-text">客户扫码添加员工为企微好友后，自动发送领券卡片。</text>
                    </view>
                    <view class="tips-item">
                        <text class="tips-text">无需员工干预，全程自动完成。</text>
                    </view>
                    <view class="tips-item">
                        <text class="tips-text">适合员工拉新任务。</text>
                    </view>
                </view>
            </view>
            <!-- 未授权 -->
            <view class="container mt-2">
                <view class="section">
                    <m-result type="info" title="企业微信未授权" description="请企业微信管理员先授权企业微信，然后进行配置。">
                        <template #actions>
                            <t-button theme="primary" @click="push('/pages_wecom/wecom/auth')">授权企业微信</t-button>
                        </template>
                    </m-result>
                </view>
            </view>
        </template>
        <template v-else>
            <m-loading v-if="items === undefined"></m-loading>
            <template v-else>
                <view class="container container-safety">
                    <m-empty v-if="!items.length">没有为员工配置加好友发券，请先添加</m-empty>
                    <template v-else>
                        <view class="section mt-2" v-for="item in items" :key="item.id">
                            <view class="section-header bottom-line">
                                <view class="section-title">
                                    <ww-open-data v-if="item.corpId" type="userName" :corpid="item.corpId"
                                                  :openid="item.corpUserId"></ww-open-data>
                                </view>
                                <view class="section-more">
                                    <text class="text-muted">{{ item.createdAt }}</text>
                                </view>
                            </view>
                            <view class="section-body">
                                <view class="info-row">
                                    <text class="info-label">卡券名称</text>
                                    <text class="info-value">{{ item.productName }}</text>
                                </view>
                                <view class="info-row">
                                    <text class="info-label">每次发放</text>
                                    <text class="info-value">{{ item.issueCount }} 张</text>
                                </view>
                                <view class="info-row" v-if="item.content">
                                    <text class="info-label">消息内容</text>
                                    <text class="info-value text-ellipsis">{{ item.content }}</text>
                                </view>
                                <view class="info-row" v-if="item.issueRemark">
                                    <text class="info-label">发放备注</text>
                                    <text class="info-value text-ellipsis">{{ item.issueRemark }}</text>
                                </view>
                            </view>
                            <view class="section-footer">
                                <view></view>
                                <view class="d-flex flex-gap-1">
                                    <t-tag theme="default" variant="outline" size="large" @click="onUnbind(item.id)">解绑
                                    </t-tag>
                                    <t-tag theme="default" variant="outline" size="large" @click="onUpdate(item.id)">修改
                                    </t-tag>
                                    <t-tag theme="primary" variant="outline" size="large" @click="goDetail(item.id)">
                                        下载二维码
                                    </t-tag>
                                </view>
                            </view>
                        </view>
                    </template>
                </view>
                <m-submit @click="goAddStaff">
                    添加员工
                </m-submit>
            </template>
        </template>
    </template>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {ref} from 'vue'
import {onShow, onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import {CORP_STATUS} from '@/constants/wecom.js'
import {useLink} from '@/hooks/useLink.js'
import utils from "@/utils/utils";

const {push} = useLink()
const items = ref()
const total = ref(0)
const productType = ref('')
const productId = ref('')

const goAddStaff = () => {
    if (!productType.value || !productId.value) {
        utils.toast('缺少产品信息，请从券包、优惠券或次卡发放入口进入')
        return
    }
    push('/pages_wecom/staff/add?productType=' + productType.value + '&productId=' + productId.value)
}

// 企业微信授权信息（undefined 表示加载中）
const corp = ref()
const getCorp = () => {
    request.get('/seller/wecom/corp').then(res => {
        // 兜底空数据，避免 corp.status 取 undefined 报错
        corp.value = res.data || {}
        // 已授权
        if (corp.value.status === CORP_STATUS.AUTHORIZED) {
            getItems()
        }
    }).catch(() => {
        // 接口失败时置空对象，进入未授权分支
        corp.value = {}
    })
}

const getItems = () => {
    const params = {page: 1, pageSize: 100}
    if (productType.value) {
        params.productType = Number(productType.value)
    }
    if (productId.value) {
        params.productId = productId.value
    }
    return request.get('/seller/wecom/staff/list', params, {showLoading: false}).then(res => {
        items.value = res.data.items || []
        total.value = res.data.total
    }).catch(() => {
        items.value = []
    })
}

const onUnbind = (id) => {
    uni.showModal({
        title: '解绑确认',
        content: '解绑后，客户扫码添加员工为好友将不再弹出领券卡片。员工二维码可继续使用；重新绑定卡券即可恢复发券。',
        success: (res) => {
            if (res.confirm) {
                request.post('/seller/wecom/staff/unbind', {id: id}).then(() => {
                    utils.toast('解绑成功')
                    getItems()
                })
            }
        }
    })
}


const onUpdate = (id) => push('/pages_wecom/staff/edit?id=' + id)

const goDetail = (id) => push('/pages_wecom/staff/detail?id=' + id)

onShow(() => {
    getCorp()
})

onLoad((e) => {
    productType.value = e.productType || ''
    productId.value = e.productId || ''
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
.info-row {
    display: flex;
    align-items: baseline;
    margin-bottom: 8rpx;
}

.info-row:last-child {
    margin-bottom: 0;
}

.info-label {
    font-size: 28rpx;
    color: #999;
    width: 140rpx;
    flex-shrink: 0;
}

.info-value {
    font-size: 28rpx;
    color: #333;
    flex: 1;
}

.text-ellipsis {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.text-muted {
    font-size: 24rpx;
    color: #bbb;
}
</style>
