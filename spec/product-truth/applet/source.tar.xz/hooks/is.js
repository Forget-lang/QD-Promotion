// 基础数据类型判断模块：基于 Object.prototype.toString 精准校验，避免 typeof 的误判

// 判断是否为字符串
const isString = (value) => Object.prototype.toString.call(value) === '[object String]'

// 判断是否为数字（仅匹配 number 原始类型，不含 NaN 校验）
const isNumber = (value) => Object.prototype.toString.call(value) === '[object Number]'

// 判断是否为整数（基于 Number.isInteger，自动排除 NaN / Infinity / 非 number）
const isInt = (value) => Number.isInteger(value)

// 判断是否为布尔值
const isBoolean = (value) => Object.prototype.toString.call(value) === '[object Boolean]'

// 判断是否为数组
const isArray = (value) => Object.prototype.toString.call(value) === '[object Array]'

// 判断是否为普通对象（{} 或 new Object，不含 Array/Date/RegExp 等）
const isObject = (value) => Object.prototype.toString.call(value) === '[object Object]'

// 判断是否为函数（typeof 可同时覆盖普通函数与 async 函数）
const isFunction = (value) => typeof value === 'function'

// 判断是否为 null
const isNull = (value) => value === null

// 判断是否为 undefined
const isUndefined = (value) => typeof value === 'undefined'

// 导出 is 对象
export const is = {
    String: isString,
    Number: isNumber,
    Int: isInt,
    Boolean: isBoolean,
    Array: isArray,
    Object: isObject,
    Function: isFunction,
    Null: isNull,
    Undefined: isUndefined,
}

export default is
