import {
    ref,
    computed
} from 'vue';
import request from '@/hooks/request.js';
import {
    useSessionStore
} from '@/stores/session.js';
import utils from '@/utils/utils';

/**
 * 认证授权 Hook
 * 负责处理微信登录、Token 管理、用户信息获取
 */
export function useAuth() {
    const sessionStore = useSessionStore();
    const isLogging = ref(false); // 防止重复点击登录
    const merchantCount = ref(0)
    const session = ref({})

    const login = async (options = {}) => {
        if (isLogging.value) return Promise.reject(new Error('正在登录中...'));

        return new Promise((resolve, reject) => {
            isLogging.value = true;
            uni.login({
                provider: 'weixin',
                timeout: 10000,
                success: async (loginRes) => {
                    if (!loginRes.code) {
                        uni.showToast({
                            title: '获取登录凭证失败',
                            icon: 'none'
                        });
                        isLogging.value = false;
                        return reject(new Error(loginRes.errMsg));
                    }

                    try {
                        let deviceInfo = utils.getDeviceInfo()
                        const res = await request.post('/login', {
                            loginCode: loginRes.code,
                            ...options,
                            ...deviceInfo,
                        });
                        if (res.code === 0) {
                            merchantCount.value = res.data.merchantCount
                            sessionStore.login({
                                token: res.data.token,
                                nickname: res.data.nickname,
                                avatar: res.data.avatar,
                                userId: res.data.userId
                            });
                            resolve(res.data);
                        } else {
                            reject(new Error('登录接口返回数据格式错误'));
                        }
                    } catch (err) {
                        reject(err);
                    } finally {
                        isLogging.value = false;
                    }
                },
                fail: (err) => {
                    uni.showToast({
                        title: '微信登录接口调用失败',
                        icon: 'none'
                    });
                    isLogging.value = false;
                    reject(err);
                }
            });
        });
    };


    // 退出登录
    const logout = () => {
        sessionStore.logout()
        uni.reLaunch({
            url: '/pages/index/index'
        })
    }

    // 是否已登录
    const isLoggedIn = computed(() => {
        return sessionStore.token != ''
    })

    // 是否已切换商家
    const isEntry = computed(() => {
        console.log(sessionStore.merchantId)
        return sessionStore.merchantId != ""
    })

    // 昵称
    const nickname = computed(() => {
        return sessionStore.nickname
    })

    // 头像
    const avatar = computed(() => {
        return sessionStore.avatar
    })

    // 选择商家
    const setMerchant = (info) => {
        const merchantId = info?.merchantId
        if (!merchantId || merchantId === '0' || merchantId === 0) {
            utils.toast('商家编号不正确')
            return
        }
        sessionStore.setMerchant({
            merchantId: info.merchantId,
            merchantName: info.merchantName,
            merchantLogo: info.merchantLogo,
            permissions: info.permissions
        })
    }

    // 检查权限
    const checkPermission = (alias) => {
        if (!isEntry.value) return false
        if (!sessionStore.permissions) return false
        return utils.inArray(alias, sessionStore.permissions)
    }

    // 刷新账户信息
    const getAccount = () => {
        console.log('useAuth--isLoggedIn: ', isLoggedIn.value)
        if (!isLoggedIn.value) {
            utils.toast('账户尚未登录')
            return
        }
        request.get('/user/account').then(res => {
            sessionStore.setAccount({
                nickname: res.data.nickname,
                avatar: res.data.avatar,
            })
            merchantCount.value = res.data.merchantCount
        })
    }

    // 刷新员工的会话（返回请求 Promise，调用方可等待结果；未选商家时静默返回）
    const getSession = (loading) => {
        if (!isEntry.value) {
            console.log('当前用户尚未选择商家，获取session失败')
            return Promise.resolve()
        }
        return request.get('/seller/staff/session').then(res => {
            session.value = res.data
            return res.data
        })
    }

    return {
        login,
        logout,
        isLoggedIn, // 是否已登录
        isLogging, // 是否正在登录中
        isEntry, // 是否加入商家
        setMerchant, // 设置当前商家
        merchantCount, // 登录此用户当前所拥有的商户数量
        checkPermission, // 检查权限
        getAccount, // 获取账户信息
        getSession, // 获取员工的会话信息
        nickname, // 用户昵称
        avatar, // 用户头像
        session, // 员工会话
    };
}