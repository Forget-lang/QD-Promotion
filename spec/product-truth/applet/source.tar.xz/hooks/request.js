import { useSessionStore } from "@/stores/session";
import config from "@/config.js"
import utils from "@/utils/utils.js"
import { useLink } from "@/hooks/useLink.js"
import {showLoading, hideLoading} from "@/utils/loading.js"
import { RESPONSE_CODE } from "@/constants/code.js"
import {VIP_UPGRADE_OPEN} from "@/constants/vipUpgrade.js"

const BASE_URL = config.apiUrl
const TIMEOUT = 10000; // 超时时间：10秒

// 不可在模块顶层 useSessionStore：避免被过早 import 时早于 app.use(pinia)
const getSession = () => useSessionStore()
const { reLaunch } = useLink();

// 鉴权失败互斥：并发 1000/1001/401 只弹一次 modal、只清一次 session
let isHandlingAuthError = false

// 版本升级提示互斥：同时多个接口返回 2006 时只弹一次
let isShowingEditionUpgrade = false

/**
 * 版本权益不足（CodeEditionUpgrade=2006）：弹 modal，用户点「去升级」后
 * 通过 uni.$emit(VIP_UPGRADE_OPEN) 打开当前页挂载的 m-vip-upgrade 支付抽屉
 */
const handleEditionUpgrade = (payload, options) => {
	if (isShowingEditionUpgrade) {
		return Promise.reject(payload)
	}
	isShowingEditionUpgrade = true
	return new Promise((_, reject) => {
		wx.showModal({
			title: '版本升级',
			content: payload.message || '当前版本不支持此功能，升级后可使用',
			confirmText: '去升级',
			cancelText: '取消',
			success: (res) => {
				if (res.confirm) {
                    uni.$emit(VIP_UPGRADE_OPEN)
				}
				isShowingEditionUpgrade = false
			},
			fail: () => {
				isShowingEditionUpgrade = false
			},
		})
		reject(payload)
	})
}

const handleAuthError = ({message, redirectUrl, payload, onClearSession}) => {
	if (isHandlingAuthError) {
		return Promise.reject(payload)
	}
	isHandlingAuthError = true
	onClearSession?.()
	return new Promise((_, reject) => {
		wx.showModal({
			title: '提示',
			content: message,
			showCancel: false,
			success: () => {
				reLaunch(redirectUrl)
				isHandlingAuthError = false
			},
			fail: () => {
				isHandlingAuthError = false
			},
		})
		reject(payload)
	})
}

/**
 * 请求封装主函数
 * @param {Object} req - 请求配置项 { url, method, data, showLoading }
 * @returns {Promise}
 */
const useRequest = (req) => {
	const {
		url,
		method = 'GET',
		data = {},
		options = {
			showLoading: false, // 开启Loading
			disableErrorToast: false, // 禁用自动错误提示
			header: {}
		},
	} = req;
    const session = getSession()
	// console.log('URL:', url, 'Options:', options)
	// 显示 Loading
	if (options.showLoading) showLoading();

	return new Promise((resolve, reject) => {
		// 构建请求头 (自动携带 Token，与 Merchant-Id 统一从 Pinia 读取)
		const header = {
			'Content-Type': 'application/json',
			'Authorization': session.token || '',
			'Merchant-Id': session.merchantId,
			'Version': config.version,
			...options.header // 允许覆盖默认头
		};
		let params = JSON.parse(JSON.stringify(data))
		let timestamp = utils.getUnixTime()
		params.sign = utils.signParam(params, config.appSecret, timestamp)
		params.timestamp = timestamp
		// console.log('URL:', url, 'header: ', header, 'params:', params)
		wx.request({
			url: BASE_URL + url, // 拼接完整地址
			method: method,
			data: params,
			header: header,
			timeout: TIMEOUT,

			success: (res) => {
				let traceId = res.header['Trace-Id']
				// 4. 统一响应处理
				const statusCode = res.statusCode;

				// HTTP 状态码判断
				if (statusCode === 200) {
					if (res.data.code === RESPONSE_CODE.SUCCESS) {
						resolve(res.data); // 直接返回 data 数据
					} else if (res.data.code === RESPONSE_CODE.STAFF_EXIT) {
						// 员工须退出门店，前往商户中心
						handleAuthError({
							message: res.data.message,
							redirectUrl: '/pages/merchant/index',
							payload: res.data,
							onClearSession: () => session.logout(),
						}).catch(reject)
					} else if (res.data.code === RESPONSE_CODE.TOKEN_EXPIRED) {
						// 用户 token 过期，前往我的卡包
						handleAuthError({
							message: res.data.message,
							redirectUrl: '/pages/index/index',
							payload: res.data,
							onClearSession: () => session.logout(),
						}).catch(reject)
					} else if (res.data.code === RESPONSE_CODE.NEED_AUTH) {
						// 商户未认证，前往商家认证页
						handleAuthError({
							message: res.data.message,
							redirectUrl: '/pages_merchant/setting/auth',
							payload: res.data,
						}).catch(reject)
					} else if (res.data.code === RESPONSE_CODE.EDITION_UPGRADE) {
						// 版本权益不足，弹升级提示并打开支付抽屉
						handleEditionUpgrade(res.data, options).catch(reject)
					} else {
						if (!options.disableErrorToast) {
							utils.toast(res.data.message)
						}
						reject(res.data);
					}
				} else if (statusCode === 401) {
					handleAuthError({
						message: '登录已过期，请重新登录',
						redirectUrl: '/pages/index/index',
						payload: res.data,
						onClearSession: () => session.logout(),
					}).catch(reject)
				} else if (statusCode === 404) {
					utils.toast('找不到页面')
					reject(res.data);
				} else {
					// 其他 HTTP 错误
					utils.toast(`网络错误: ${statusCode}\nTraceId：${traceId}`)
					reject(res);
				}
			},

			fail: (err) => {
				// 5. 网络错误处理
				utils.toast('请求失败:' + err.errMsg)
				console.error('请求失败:', err.errMsg);
				reject(err);
			},

			complete: () => {
				// 6. 无论成功失败，都关闭 Loading
				if (options.showLoading) hideLoading();
			}
		});
	});
};

/**
 * 快捷方法封装
 * 使用方式：request.get('/user/info')
 */
const request = {
	get: (url, data, options = {}) => useRequest({
		url,
		method: 'GET',
		data,
		options
	}),
	post: (url, data, options = {}) => useRequest({
		url,
		method: 'POST',
		data,
		options
	}),
	put: (url, data, options = {}) => useRequest({
		url,
		method: 'PUT',
		data,
		options
	}),
	delete: (url, data, options = {}) => useRequest({
		url,
		method: 'DELETE',
		data,
		options
	}),
};

export default request;
