// 数据安全转换模块：对 null/undefined/非预期类型进行容错，返回安全默认值
import { is } from './is'

// 判断是否为空值（null 或 undefined）：统一处理两种"未定义态"，避免依赖 == 隐式行为
const isNil = (value) => is.Null(value) || is.Undefined(value)

// 安全转换为数组：null/undefined 返回空数组，已有数组原样返回，其余包一层数组
const toArray = (value) => {
    if (isNil(value)) return []
    if (is.Array(value)) return value
    return [value]
}

// 安全转换为整数：null/undefined 或无法解析时返回 0；number 直接截断，避免 parseInt 对科学计数法误解析
const toInt = (value) => {
    if (isNil(value)) return 0
    if (is.Number(value)) return Number.isFinite(value) ? Math.trunc(value) : 0
    const num = parseInt(value, 10)
    return Number.isNaN(num) ? 0 : num
}

// 安全转换为字符串：null/undefined 返回空串，字符串直接返回，对象/数组走 JSON 序列化
const toString = (value) => {
    if (isNil(value)) return ''
    if (is.String(value)) return value
    if (is.Object(value) || is.Array(value)) {
        try {
            return JSON.stringify(value)
        } catch (e) {
            return ''
        }
    }
    if (typeof value === 'symbol') return value.toString()
    try {
        return String(value)
    } catch (e) {
        return ''
    }
}

// 安全转换为数字：null/undefined、无法解析或非有限数（NaN/Infinity）时返回 0；number 直接返回，免去重复转换
const toNumber = (value) => {
    if (isNil(value)) return 0
    if (is.Number(value)) return Number.isFinite(value) ? value : 0
    const num = Number(value)
    return Number.isFinite(num) ? num : 0
}

// 安全转换为对象：null/undefined 返回空对象，普通对象原样返回，JSON 字符串尝试解析
const toObject = (value) => {
    if (isNil(value)) return {}
    if (is.Object(value)) return value
    if (is.String(value)) {
        try {
            const parsed = JSON.parse(value)
            if (is.Object(parsed)) return parsed
        } catch (e) {
            // 非 JSON 字符串直接降级为空对象
        }
    }
    return {}
}

// 导出 to 对象
export const to = {
    Array: toArray,
    Int: toInt,
    String: toString,
    Number: toNumber,
    Object: toObject,
}

export default to
