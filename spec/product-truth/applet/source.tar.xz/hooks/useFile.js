import utils from "@/utils/utils";

// 删除 USER_DATA_PATH 下的临时文件（忽略不存在等失败）
function removeTempFile(filePath) {
    if (!filePath) return
    wx.getFileSystemManager().unlink({
        filePath: filePath,
        fail() {
        },
    })
}

// 保存二维码：兼容 base64 数据 URL 与远程图片 URL
function downloadImage(file) {
    if (!file) {
        utils.toast('图片加载失败')
        return
    }
    utils.showLoading()
    // base64 数据 URL：直接写入本地文件
    if (file.indexOf('data:image') === 0) {
        let filePath = wx.env.USER_DATA_PATH + '/' + utils.randomNum(1000, 9999) + '.jpeg'
        let image = file.replace(/^data:image\/\w+;base64,/, "")
        wx.getFileSystemManager().writeFile({
            filePath: filePath,
            data: image,
            encoding: 'base64',
            success() {
                showShareImageMenu(filePath)
            },
            fail() {
                utils.hideLoading()
                utils.toast('二维码下载失败')
            },
        })
        return
    }
    // 远程图片 URL：先下载到本地临时文件
    wx.downloadFile({
        url: file,
        success(res) {
            if (res.statusCode === 200) {
                showShareImageMenu(res.tempFilePath)
            } else {
                utils.hideLoading()
                utils.toast('二维码下载失败')
            }
        },
        fail() {
            utils.hideLoading()
            utils.toast('二维码下载失败')
        },
    })
}

// 调起微信图片分享菜单（可长按保存到相册）
function showShareImageMenu(filePath) {
    wx.showShareImageMenu({
        path: filePath,
        needShowEntrance: false,
        success() {
            utils.hideLoading()
            utils.toast('保存成功')
            removeTempFile(filePath)
        },
        fail(e) {
            utils.hideLoading()
            if (e.errMsg != 'showShareImageMenu:fail cancel') {
                utils.toast('二维码下载失败')
            }
            removeTempFile(filePath)
        },
    })
}

//分享文件
function downloadShareFile(file, fileName, complete) {
    var filePath = wx.env.USER_DATA_PATH + '/' + fileName + '.xlsx'
    wx.downloadFile({
        url: file,
        filePath: filePath,
        success: function (res) {
            wx.shareFileMessage({
                filePath: filePath,
                fileName: fileName + '.xlsx',
                success() {
                    complete()
                },
                fail(err) {
                    console.log(err)
                    utils.toast('文件分享失败')
                    complete()
                },
            })
        },
        fail: function (res) {
            utils.toast('文件加载失败')
            complete()
        }
    })
}

// 分享 base64 Excel：将后端返回的 base64 内容写入本地 .xlsx 后调用 openDocument 打开
// 注意：不能直接用 wx.shareFileMessage，因为它必须在用户 tap 事件的同步调用链中触发，
// 而导出接口是异步请求，回调已脱离手势上下文，会报 "can only be invoked by user TAP gesture"。
// 替代方案：写入本地 → wx.openDocument 打开文档预览，用户可在预览页右上角菜单转发/收藏。
function openBase64Excel(base64, fileName, complete) {
    const done = () => {
        complete && complete()
    }
    if (!base64) {
        utils.toast('文件加载失败')
        done()
        return
    }
    // 兼容 data URL 前缀（如 data:application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;base64,）
    const data = base64.replace(/^data:[^;]+;base64,/, '')
    const timestamp = Date.now()
    const filePath = wx.env.USER_DATA_PATH + '/' + fileName + timestamp + '.xlsx'
    wx.getFileSystemManager().writeFile({
        filePath: filePath,
        data: data,
        encoding: 'base64',
        success() {
            wx.openDocument({
                filePath: filePath,
                fileType: 'xlsx',
                showMenu: true,
                success() {
                    done()
                    removeTempFile(filePath)
                },
                fail(err) {
                    console.log(err)
                    utils.toast('文件打开失败')
                    done()
                    removeTempFile(filePath)
                },
            })
        },
        fail(err) {
            console.log('writeFile: ', err)
            utils.toast('文件加载失败')
            done()
        },
    })
}

// 保存 base64 为本地 .xlsx 文件，完成后用 actionSheet 提供「打开」和「分享」两个操作
async function saveBase64Excel(base64, fileName) {
    if (!base64) {
        utils.toast('文件加载失败')
        throw new Error('no base64 data')
    }
    const data = base64.replace(/^data:[^;]+;base64,/, '')
    const exportFileName = fileName + '_' + Date.now() + '.xlsx'
    const filePath = wx.env.USER_DATA_PATH + '/' + exportFileName
    await new Promise((resolve, reject) => {
        wx.getFileSystemManager().writeFile({
            filePath: filePath,
            data: data,
            encoding: 'base64',
            success: resolve,
            fail: reject,
        })
    })
    // 用 actionSheet 而非 showModal：避免安卓返回键被归为 cancel 而误触发操作；
    // 点选项 = 新 tap 手势，满足 shareFileMessage 必须在手势链中调用的约束。
    uni.showActionSheet({
        itemList: ['打开', '分享'],
        success(res) {
            if (res.tapIndex === 0) {
                wx.openDocument({
                    filePath: filePath,
                    fileType: 'xlsx',
                    showMenu: true,
                    fail() {
                        utils.toast('文件打开失败')
                    },
                })
            } else if (res.tapIndex === 1) {
                wx.shareFileMessage({
                    filePath: filePath,
                    fileName: fileName + '.xlsx',
                    success() {
                    },
                    fail() {
                        utils.toast('文件分享失败')
                    },
                })
            }
        },
        fail() {
            // 取消 / 返回键 / 点蒙层关闭：不做任何操作，遗留文件由 onLaunch 兜底清理
        },
    })
}

// 分享本地文件（wx.shareFileMessage 必须在用户 tap 手势的同步调用链中触发）
function shareExcelFile(filePath, fileName) {
    return new Promise((resolve, reject) => {
        wx.shareFileMessage({
            filePath: filePath,
            fileName: fileName,
            success: resolve,
            fail: reject,
        })
    })
}

// 保存图片到相册：处理授权与保存全流程
function saveImageToAlbum(filePath) {
    if (!filePath) {
        utils.toast('图片加载失败')
        return
    }
    utils.showLoading()
    wx.getSetting({
        success(res) {
            if (!res.authSetting['scope.writePhotosAlbum']) {
                wx.authorize({
                    scope: 'scope.writePhotosAlbum',
                    success() {
                        doSaveImageToAlbum(filePath)
                    },
                    fail() {
                        utils.hideLoading()
                        uni.showModal({
                            cancelText: '取消',
                            cancelColor: '#999',
                            confirmText: '前往设置',
                            title: '提示',
                            content: '您尚未授权添加到相册',
                            success(e) {
                                if (e.confirm) {
                                    wx.openSetting({
                                        success(settingRes) {
                                            if (settingRes.authSetting['scope.writePhotosAlbum'] === true) {
                                                utils.showLoading()
                                                doSaveImageToAlbum(filePath)
                                            }
                                        }
                                    })
                                }
                            }
                        })
                    }
                })
            } else {
                doSaveImageToAlbum(filePath)
            }
        },
        fail() {
            utils.hideLoading()
            utils.toast('保存失败！')
        }
    })
}

function doSaveImageToAlbum(filePath) {
    wx.saveImageToPhotosAlbum({
        filePath: filePath,
        success() {
            utils.hideLoading()
            utils.toast('已成功保存至手机相册')
        },
        fail(error) {
            console.log(error)
            utils.hideLoading()
            utils.toast('保存失败！')
        }
    })
}

// 清理 USER_DATA_PATH 下超过 7 天的 .xlsx / .jpeg 临时文件（登录成功后触发，兜底清理异步导出/保存遗留的文件）
function cleanupTempFiles() {
    const fs = wx.getFileSystemManager()
    const dirPath = wx.env.USER_DATA_PATH
    // 过期阈值：7 天（毫秒）
    const expireMs = 7 * 24 * 60 * 60 * 1000
    const now = Date.now()
    fs.readdir({
        dirPath: dirPath,
        success(res) {
            const files = (res.files || []).filter(name => /\.(xlsx|jpeg)$/i.test(name))
            files.forEach(name => {
                const filePath = dirPath + '/' + name
                fs.stat({
                    path: filePath,
                    success(statRes) {
                        // lastModifiedTime 单位为秒，转为毫秒比较
                        const mtime = statRes.stats.lastModifiedTime * 1000
                        if (now - mtime > expireMs) {
                            removeTempFile(filePath)
                        }
                    },
                    fail() {
                    },
                })
            })
        },
        fail() {
        },
    })
}

export {
    downloadImage,
    downloadShareFile,
    openBase64Excel,
    saveBase64Excel,
    shareExcelFile,
    saveImageToAlbum,
    cleanupTempFiles
}
