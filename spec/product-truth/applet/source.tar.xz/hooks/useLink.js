import { ref } from 'vue';

/**
 * 核心跳转方法
 * @param {Object} options - 配置项
 * @param {String} options.url - 页面路径 (如: '/pages/detail/detail')
 * @param {Object} [options.query] - 参数对象 (如: { id: 1, type: 'book' })
 * @param {String} [options.type] - 跳转类型: navigateTo, redirectTo, reLaunch, switchTab
 */
const jump = (options) => {
    const {url, type = 'navigateTo'} = options;
    if (type === 'switchTab') {
		uni.switchTab({
            url: options.url,
			fail(err) {
				console.log(err)
			}
		})
        return
	}
    if (type === 'reLaunch') {
        uni.reLaunch({url})
        return
	}
    if (type === 'redirectTo') {
        uni.redirectTo({url})
        return
	}
    uni.navigateTo({url})
};

/**
 * 组合式函数：useLink
 * 在组件的 setup 中调用
 */
export function useLink() {
  // 定义一个状态，用于防止快速重复点击跳转（可选的防抖逻辑）
  const isJumping = ref(false);

  /**
   * 普通跳转 (保留当前页面，压入栈)
   * @param {String} url - 路径
   * @param {Object} query - 参数
   */
  const push = (url, query) => {
    if (isJumping.value) return; // 简单的防抖
    isJumping.value = true;
	jump({ url, query, type: 'navigateTo' })
	setTimeout(()=>{
		isJumping.value = false
	},300)
  };

  /**
   * 重定向 (关闭当前页面)
   * 常用于：登录成功后跳转，不想让用户返回到登录页
   */
  const replace = (url, query) => {
    return jump({ url, query, type: 'redirectTo' });
  };

  /**
   * 重置启动 (关闭所有页面，打开到应用内的某个页面)
   * 常用于：退出登录回到首页，或流程结束回到首页
   */
  const reLaunch = (url, query) => {
    return jump({ url, query, type: 'reLaunch' });
  };

  /**
   * 切换 TabBar (仅用于配置了 tabBar 的页面)
   */
  const switchTab = (url) => {
    // TabBar 页面通常不建议带参数，这里强制忽略 query
    return jump({ url, query: {}, type: 'switchTab' });
  };

  /**
   * 返回上一页
   * @param {Number} delta - 返回的层数，默认 1
   */
  const back = (delta = 1) => {
    return new Promise((resolve) => {
      uni.navigateBack({ delta, success: resolve });
    });
  };

  return {
    push,
    replace,
    reLaunch,
    switchTab,
    back
  };
}