import {useAuth} from '@/hooks/useAuth'
import utils from '@/utils/utils'
import {getFeatureContent, hasEdition} from '@/constants/edition'
import {VIP_UPGRADE_CLOSE, VIP_UPGRADE_OPEN} from '@/constants/vipUpgrade'

export {VIP_UPGRADE_OPEN, VIP_UPGRADE_CLOSE, VIP_UPGRADE_SUCCESS} from '@/constants/vipUpgrade'

// 获取当前版本 ID：每次检测都重新请求员工会话，保证升级后版本数据即时生效，不读任何缓存
const ensureEditionId = async () => {
    const {getSession} = useAuth()
    const data = await getSession()
    if (data?.editionId == null) {
        throw new Error('版本信息获取失败')
    }
    return Number(data.editionId)
}

/**
 * 检测当前版本是否支持某功能；不支持时弹出「功能受限提醒」，点「升级版本」打开全局升级抽屉并预选目标版本。
 * @param {object} target EDITION_FEATURES 项，或 {edition, content} 自定义
 * @returns {Promise<boolean>} 放行 true；受限 false（版本信息失败时 toast 后放行 true，与后端最终校验一致）
 */
const check = async (target) => {
    const feature = target?.requiredEdition ? target : null
    const edition = feature ? feature.requiredEdition : target?.edition
    const content = feature ? getFeatureContent(feature) : target?.content
    let editionId
    try {
        editionId = await ensureEditionId()
    } catch (e) {
        utils.toast('版本信息获取失败，请稍后重试')
        return true
    }
    if (hasEdition(editionId, edition)) return true
    uni.showModal({
        showCancel: true,
        title: '功能受限提醒',
        content,
        confirmText: '升级版本',
        cancelText: '取消',
        success(res) {
            if (res.confirm) {
                uni.$emit(VIP_UPGRADE_OPEN, {editionId: edition})
            }
        },
    })
    return false
}

/** 打开 VIP 升级抽屉（当前页挂载的 m-vip-upgrade 监听） */
const open = (editionId) => {
    uni.$emit(VIP_UPGRADE_OPEN, editionId != null ? {editionId} : undefined)
}

/** 关闭 VIP 升级抽屉 */
const close = () => {
    uni.$emit(VIP_UPGRADE_CLOSE)
}

export function useVipGuard() {
    return {check, open, close}
}
