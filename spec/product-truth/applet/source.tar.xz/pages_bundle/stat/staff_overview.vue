<template>
    <view class="stat-filter">
        <view class="stat-date-filter">
            <text class="stat-filter-item" :class="{active:options.timeType === 'today'}"
                  @click="onChangeTimeRange('today')">今天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'yesterday'}"
                  @click="onChangeTimeRange('yesterday')">昨天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'month'}"
                  @click="onChangeTimeRange('month')">本月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'lastMonth'}"
                  @click="onChangeTimeRange('lastMonth')">上月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'cumulative'}"
                  @click="onChangeTimeRange('cumulative')">累计
            </text>
        </view>
    </view>
    <view class="container">
        <view class="section mt-3">
            <view class="section-header bottom-line">
                <view class="section-title">我的发放业绩</view>
            </view>
            <view class="section-body">
                <view class="overview-grid">
                    <view class="ov-item">
                        <view class="ov-label">领取券包个数</view>
                        <view class="ov-value">{{ staffOverview.receiveCount || 0 }}</view>
                        <view class="ov-extra">核销率
                            <text class="text-success">{{ staffOverview.receiveVerifyRate || 0 }}%</text>
                        </view>
                    </view>
                    <view class="ov-item">
                        <view class="ov-label">发出券张数</view>
                        <view class="ov-value">{{ staffOverview.couponReceiveCount || 0 }}</view>
                    </view>
                    <view class="ov-item">
                        <view class="ov-label">发放被核销张数</view>
                        <view class="ov-value">{{ staffOverview.couponVerifyCount || 0 }}</view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {ref} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import request from "@/hooks/request";

const bundleId = ref()

const options = ref({
    timeType: 'cumulative',
})

const staffOverview = ref({});
const getStaffOverview = () => {
    request.get('/seller/bundle/stat/staff-overview', {
        bundleId: bundleId.value,
        ...options.value,
    }).then(res => {
        staffOverview.value = res.data
    })
}

const onChangeTimeRange = (timeType) => {
    options.value.timeType = timeType
    getStaffOverview()
}

onLoad((e) => {
    bundleId.value = e.bundleId
    getStaffOverview()
})
</script>

<style scoped>
.overview-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20rpx;
}

.ov-item {
    background: #f9fafb;
    border-radius: 16rpx;
    padding: 20rpx;
}

.ov-label {
    font-size: 22rpx;
    color: #6b7280;
}

.ov-value {
    font-size: 44rpx;
    font-weight: 700;
    color: #0f172a;
    margin-top: 8rpx;
}

.ov-extra {
    font-size: 20rpx;
    color: #94a3b8;
    margin-top: 4rpx;
}
</style>
