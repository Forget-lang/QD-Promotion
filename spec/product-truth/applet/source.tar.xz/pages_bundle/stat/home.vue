<template>
    <t-cell-group t-class="mt-2" theme="card">
        <t-cell title="我的业绩" arrow
                :url="'/pages_bundle/stat/staff_overview?bundleId=' + bundleId"/>
        <t-cell v-if="checkPermission(PERM_BUNDLE.STAT_CHANNEL_RANK)" title="发放渠道统计" arrow
                :url="'/pages_bundle/stat/channel_issue_rank?bundleId=' + bundleId"/>
        <t-cell v-if="checkPermission(PERM_BUNDLE.STAT_STORE_RANK)" title="门店发放统计" arrow
                :url="'/pages_bundle/stat/store_issue_rank?bundleId=' + bundleId"/>
        <t-cell v-if="checkPermission(PERM_BUNDLE.STAT_STORE_RANK)" title="门店核销统计" arrow
                :url="'/pages_bundle/stat/store_verify_rank?bundleId=' + bundleId"/>
        <t-cell v-if="checkPermission(PERM_BUNDLE.STAT_STAFF_RANK)" title="员工发放统计" arrow
                :url="'/pages_bundle/stat/staff_issue_rank?bundleId=' + bundleId"/>
        <t-cell v-if="checkPermission(PERM_BUNDLE.STAT_STAFF_RANK)" title="员工核销统计" arrow
                :url="'/pages_bundle/stat/staff_verify_rank?bundleId=' + bundleId"/>
    </t-cell-group>
</template>

<script setup>
import {ref} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import {useAuth} from "@/hooks/useAuth.js";
import {PERM_BUNDLE} from "@/constants/permission.js";

const {checkPermission} = useAuth();
const bundleId = ref();
onLoad((e) => {
    bundleId.value = e.bundleId
})
</script>

<style scoped>

</style>
