<template>
    <m-result v-if="showSuccess" type="success" title="调整成功" back></m-result>
    <view v-if="!showSuccess">
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="当前库存" :note="currentStock + ' 个'"/>
            <t-input label="增加库存" placeholder="只能增加，不能减少" type="number" align="right"
                     v-model:value="adjustStock" suffix="个"></t-input>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" v-if="adjustStock > 0">
            <t-cell title="调整后库存">
                <template #note>
                    <view class="after-stock">
                        <text class="original-stock">{{ currentStock }}</text>
                        <text class="arrow ml-1 mr-1">+</text>
                        <text class="adjust-num">{{ adjustStock }}</text>
                        <text class="equal ml-1 mr-1">=</text>
                        <text class="text-success">{{ afterStock }}</text>
                        <text class="unit ml-1">个</text>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>

        <m-submit :loading="loading" :disabled="loading || adjustStock <= 0" @click="onSubmit">确认调整库存</m-submit>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request.js'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink.js'

const {back} = useLink()

const bundleId = ref('')
const currentStock = ref(0)
const adjustStock = ref()
const loading = ref(false)
const showSuccess = ref(false)

const afterStock = computed(() => {
    return currentStock.value + parseInt(adjustStock.value || 0)
})

const getBundleInfo = () => {
    request.get('/seller/bundle/get/detail', {id: bundleId.value}).then((res) => {
        currentStock.value = res.data.totalStock || 0
    })
}

const onSubmit = () => {
    if (adjustStock.value <= 0) {
        utils.toast('请输入要增加的库存数量')
        return
    }

    loading.value = true
    request.post('/seller/bundle/update-stock', {
        id: bundleId.value,
        addStock: parseInt(adjustStock.value),
    }).then(() => {
        showSuccess.value = true
        currentStock.value = afterStock.value
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    if (!e.bundleId) {
        utils.toast('缺少券包ID')
        setTimeout(() => {
            back()
        }, 1500)
        return
    }
    bundleId.value = e.bundleId
    getBundleInfo()
})
</script>

<style scoped></style>
