<template>
    <m-result
        v-if="isSuccess"
        type="success"
        title="修改成功"
        description="券包信息已更新"
        confirmText="查看详情"
        cancelText="返回"
        @confirm="replace('/pages_bundle/bundle/detail?bundleId=' + bundleId)"
        @cancel="back()"
    ></m-result>

    <m-loading v-else-if="bundle === undefined"></m-loading>
    <m-empty v-else-if="bundle === null">券包不存在</m-empty>

    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view>封面图片</view>
                <view class="text-small text-success">推荐尺寸：5:4</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="form.coverImages"
                    :max="1"
                    :cropperWidth="300"
                    :cropperHeight="240"
                    emitName="bundleCover"
                ></m-cover-uploader>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-input
                placeholder="最多18个字，支持表情符号"
                align="right"
                :maxlength="18"
                v-model:value="form.name"
            >
                <template #label>
                    <view class="input-custom-label-required">券包名称</view>
                </template>
            </t-input>
            <t-cell
                title="制作数量"
                :note="form.totalStock + '个'"
                description="库存请到详情页通过「调整库存」修改"
            ></t-cell>
            <t-input
                v-if="canEditReceiveRule"
                placeholder="最少1个，最多100个"
                type="number"
                align="right"
                v-model:value="form.userLimit"
                suffix="个"
            >
                <template #label>
                    <view class="input-custom-label-required">每人限领</view>
                </template>
            </t-input>
            <t-cell v-else title="每人限领" :note="form.userLimit + '个'"
                    description="已有领取记录，限领个数不支持修改"></t-cell>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-select
                v-if="canEditReceiveRule"
                required
                title="领取方式"
                v-model:value="form.receiveType"
                :options="receiveTypeOptions"
            ></m-select>
            <t-cell v-else title="领取方式" :note="receiveTypeLabel"></t-cell>
            <view class="cell-helper" v-if="canEditReceiveRule && form.receiveType > 0">
                <text v-if="form.receiveType === BUNDLE_RECEIVE_TYPE.ALL" class="lh-25 text-success">
                    一键全部领取：顾客一次领取包内所有优惠券，每种券按设置数量发放。
                </text>
                <text v-if="form.receiveType === BUNDLE_RECEIVE_TYPE.RANDOM" class="lh-25 text-success">
                    随机领取一种：顾客领取时随机获得包内一种优惠券，适合抽奖玩法。
                </text>
                <text v-if="form.receiveType === BUNDLE_RECEIVE_TYPE.CHOOSE" class="lh-25 text-success">
                    自选一种：顾客从包内券列表中自选一种后再领取。
                </text>
            </view>
        </t-cell-group>

        <view class="mt-2">
            <m-theme-select v-model:value="form.theme"/>
        </view>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-staff-select
                required
                title="发券员工"
                :multiple="true"
                :show-disabled="true"
                v-model:value="form.staffIds"
            ></m-staff-select>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-bundle-coupon-select
                required
                title="券包内容"
                tip="仅可选择「券包」类型的有效优惠券；修改后仅影响之后领取，已领取记录不变"
                v-model:value="form.coupons"
                :beforeAdd="onBeforeCouponAdd"
            ></m-bundle-coupon-select>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea
                label="使用须知"
                v-model:value="form.content"
                :maxlength="500"
                :indicator="true"
                placeholder="请输入使用须知"
            ></t-textarea>
            <view class="usage-toolbar">
                <view class="usage-toolbar-tip">
                    <t-icon name="lightbulb" size="28rpx" color="var(--td-brand-color)"/>
                    <text class="usage-toolbar-tip-text">不会写？一键套用模版</text>
                </view>
                <view class="usage-toolbar-actions">
                    <t-button theme="primary" variant="text" size="small" @click="onUseContentTemplate(1)">通用模版</t-button>
                    <t-button t-class="ml-2" theme="default" variant="text" size="small" :disabled="!form.content"
                              custom-style="background-color: transparent;" @click="onClearContent">清空
                    </t-button>
                </view>
            </view>
        </t-cell-group>

        <t-cell-group t-title-class="mt-2" title="领券顾客信息" theme="card" :bordered="false">
            <t-cell>
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>填写手机号</text>
                        <m-edition-badge :feature="EDITION_FEATURES.GET_MOBILE" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isGetMobile" :default-value="false" @change="onGetMobileChange"/>
                </template>
            </t-cell>
            <t-cell :bordered="false" description="该商户下从未领过优惠券、券包、次卡的顾客才可领取">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>仅新客户可领</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_NEW_CUSTOMER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyNewCustomer" :default-value="false"
                              @change="onOnlyNewCustomerChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" :disabled="loading" @click="onSubmit">
                保存修改
            </t-button>
        </view>

        <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import {BUNDLE_RECEIVE_TYPE} from '@/constants/bundle'
import {EDITION_FEATURES, getQuotaOverflow} from '@/constants/edition'
import { RESPONSE_CODE } from '@/constants/code'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth.js'
import {useVipGuard} from '@/hooks/useVipGuard'

const {replace, back} = useLink()
const {getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()

const loading = ref(false)
const isSuccess = ref(false)
const bundleId = ref('')
const bundle = ref()

const receiveTypeOptions = [
    {label: '一键全部领取', value: BUNDLE_RECEIVE_TYPE.ALL},
    {label: '随机领取一种', value: BUNDLE_RECEIVE_TYPE.RANDOM},
    {label: '自选一种', value: BUNDLE_RECEIVE_TYPE.CHOOSE},
]

const receiveTypeLabelMap = {
    [BUNDLE_RECEIVE_TYPE.ALL]: '一键全部领取',
    [BUNDLE_RECEIVE_TYPE.RANDOM]: '随机领取一种',
    [BUNDLE_RECEIVE_TYPE.CHOOSE]: '自选一种',
}

const form = ref({
    coverImages: [],
    theme: 1,
    name: '',
    userLimit: undefined,
    totalStock: undefined,
    receiveType: BUNDLE_RECEIVE_TYPE.ALL,
    coupons: [],
    content: '',
    staffIds: [],
    isGetMobile: false,
    isOnlyNewCustomer: false,
    isShare: false,
    shareTitle: '',
    shareCover: '',
})

const canEditReceiveRule = computed(() => !bundle.value?.receiveCount)
const receiveTypeLabel = computed(() => receiveTypeLabelMap[form.value.receiveType] || '')

const shareCover = computed(() => {
    if (form.value?.coverImages?.length > 0) {
        form.value.shareCover = form.value.coverImages[0]
        return form.value.coverImages[0]
    }
    return form.value.shareCover || ''
})

// 点击添加包内优惠券：免费/标准版不支持券包，专业/企业达到档位上限时提示升级
const onBeforeCouponAdd = () => {
    const overflow = getQuotaOverflow(EDITION_FEATURES.BUNDLE_ISSUE, staffSession.value?.editionId, (form.value.coupons || []).length)
    if (overflow) {
        check(overflow)
        return false
    }
    return true
}

// 开启填写手机号：标准版及以上支持，受限则回退开关
const onGetMobileChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.GET_MOBILE).then((allowed) => {
        if (!allowed) form.value.isGetMobile = false
    })
}

// 开启仅新客户可领：标准版及以上支持，受限则回退开关
const onOnlyNewCustomerChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_NEW_CUSTOMER).then((allowed) => {
        if (!allowed) form.value.isOnlyNewCustomer = false
    })
}

// 每次进入页面刷新员工会话，保证版本档位预检数据最新
onShow(() => {
    getSession()
})

const onUseContentTemplate = (templateId) => {
    if (templateId === 1) {
        form.value.content = `● 遗失处理：券包仅限本人使用，请勿转借他人。因手机丢失、账号泄露等原因导致券包被他人使用，责任由用户自行承担。
● 使用方式：到店消费时，请在结账前主动出示券包中的优惠券电子码，由店员扫码/核销后使用对应优惠券。
● 领取规则：根据券包设置的领取方式（一键全部领取/随机领取一种/自选一种），领取相应的优惠券。
● 找零兑现：券包中的优惠券不兑现、不找零，每单限用一张优惠券。
● 核销说明：逾期未核销的优惠券将自动作废，不支持延期或补发；若遇门店临时停业（如装修、节假日调整），有效期不顺延。
● 适用范围：特价商品、团购套餐、礼品卡充值等特殊项目不适用（具体以门店公示为准）。
● 特别说明：严禁通过虚假交易等违规方式使用本券包，一经发现，门店有权取消核销资格并追回优惠金额。
● 最终解释权：在法律允许范围内，本店拥有本次活动最终解释权。如有疑问可联系门店客服。`
    }
}

// 一键清空使用须知（二次确认防止误触）
const onClearContent = () => {
    uni.showModal({
        title: '提示',
        content: '确定清空使用须知吗？',
        success: (res) => {
            if (res.confirm) {
                form.value.content = ''
            }
        }
    })
}

const getDetail = () => {
    request.get('/seller/bundle/get/detail', {
        id: bundleId.value,
    }).then(res => {
        bundle.value = res.data
        form.value = {
            coverImages: res.data.cover ? [res.data.cover] : [],
            theme: res.data.theme || 1,
            name: res.data.name,
            userLimit: res.data.userLimit,
            totalStock: res.data.totalStock,
            receiveType: res.data.receiveType,
            coupons: res.data.coupons || [],
            content: res.data.content,
            staffIds: res.data.staffIds || [],
            isGetMobile: res.data.isGetMobile || false,
            isOnlyNewCustomer: res.data.isOnlyNewCustomer || false,
            isShare: res.data.isShare,
            shareTitle: res.data.shareTitle || '',
            shareCover: res.data.shareCover || '',
        }
        uni.setNavigationBarTitle({title: '修改券包'})
    }).catch(err => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            bundle.value = null
        }
    })
}

const onSubmit = utils.throttle(() => {
    loading.value = true
    const {coverImages, totalStock, ...rest} = form.value
    const submitData = {
        id: bundleId.value,
        ...rest,
        cover: coverImages?.[0] || '',
    }
    request.post('/seller/bundle/update', submitData).then(() => {
        return request.get('/seller/bundle/get/detail', {id: bundleId.value})
    }).then(res => {
        res.data = {
            ...res.data,
            unitCount: res.data.coupons?.length || 0,
        }
        uni.$emit('onBundleUpdate', res.data)
        isSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}, 800)

onLoad((e) => {
    if (!e.bundleId) {
        utils.toast('缺少券包ID')
        setTimeout(() => back(), 1500)
        return
    }
    bundleId.value = e.bundleId
    getDetail()
})
</script>

<style>
/*
 * 自定义样式原因：使用须知工具栏为「灯泡图标引导 + 文字按钮」单行内联组合，
 * app.css 的 .tips-card 是整块提示卡（含标题/多行），不适合单行工具条；TDesign 亦无对应组件。
 * 替代方案：白底融入卡片、细分隔线区隔内容，图标色取 --td-brand-color，仅补缺位视觉层。
 */
.usage-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16rpx 16rpx 16rpx 32rpx;
    background-color: #FFFFFF;
    border-top: 1rpx solid #F0F0F0;
}

.usage-toolbar-tip {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 16rpx;
}

.usage-toolbar-tip-text {
    font-size: 24rpx;
    color: #666;
    margin-left: 8rpx;
}

.usage-toolbar-actions {
    display: flex;
    align-items: center;
    flex-shrink: 0;
}
</style>
