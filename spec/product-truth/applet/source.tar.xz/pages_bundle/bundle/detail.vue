<template>
    <m-loading v-if="bundle === undefined"></m-loading>
    <m-empty v-else-if="bundle === null">券包不存在</m-empty>
    <view class="container-safety" v-else>
        <view class="detail-header">
            <view class="container">
                <view class="bundle-card">
                    <view class="bundle-body">
                        <view class="bundle-content">
                            <view class="bundle-head">
                                <image v-if="bundle.cover" class="bundle-cover" :src="bundle.cover" mode="aspectFill"/>
                                <view v-else class="bundle-cover bundle-cover-empty">
                                    <t-icon name="gift-filled" size="40rpx" color="#e84c59"/>
                                </view>
                                <view class="bundle-info">
                                    <view class="bundle-name text-ellipsis-break">{{ bundle.name }}</view>
                                    <view class="bundle-issue">{{ bundle.receiveTypeLabel }}</view>
                                </view>
                            </view>
                        </view>
                        <view class="bundle-value">
                            <view class="bundle-metric">
                                <text class="bundle-metric-num">{{ unitCount }}</text>
                                <text class="bundle-metric-unit">种券</text>
                            </view>
                            <text class="bundle-metric-sep">·</text>
                            <view class="bundle-metric">
                                <text class="bundle-metric-num">{{ bundle.itemCount || 0 }}</text>
                                <text class="bundle-metric-unit">张</text>
                            </view>
                        </view>
                    </view>
                    <view class="coupon-line bundle-coupon-line"></view>
                    <view class="bundle-tags">
                        <t-tag :theme="statusTagTheme(bundle.status)" variant="light-outline" size="small">
                            {{ bundle.statusLabel }}
                        </t-tag>
                        <t-tag v-if="bundle.auditStatus !== BUNDLE_AUDIT_STATUS.PASSED" theme="warning" variant="light-outline" size="small">
                            {{ bundle.auditStatusLabel }}
                        </t-tag>
                        <t-tag theme="default" variant="outline" size="small">
                            {{ bundle.isShare ? '可分享' : '不可分享' }}
                        </t-tag>
                        <t-tag v-if="bundle.themeLabel" theme="default" variant="outline" size="small">
                            {{ bundle.themeLabel }}
                        </t-tag>
                        <view class="bundle-limit">
                            <t-icon name="user" size="24rpx" color="#e84c59" custom-style="margin-right: 6rpx;"/>
                            <text>每人限领</text>
                            <text class="bundle-limit-num">{{ bundle.userLimit || 0 }}</text>
                            <text>个</text>
                        </view>
                    </view>
                </view>

                <view class="section">
                    <view class="row col-3 mt-3">
                        <view class="stat">
                            <view class="stat-value">{{ bundle.receiveCount || 0 }}</view>
                            <view class="stat-label">领取总数</view>
                        </view>
                        <view class="stat">
                            <view class="stat-value">{{ bundle.todayReceiveCount || 0 }}</view>
                            <view class="stat-label">今日领取</view>
                        </view>
                        <view class="stat">
                            <view class="stat-value">{{ bundle.yesterdayReceiveCount || 0 }}</view>
                            <view class="stat-label">昨日领取</view>
                        </view>
                    </view>

                    <t-divider/>

                    <view class="container">
                        <view class="stock-panel">
                            <view class="d-flex justify-content-between align-items-center">
                                <view>
                                    <view class="text-muted text-small mb-2">剩余库存</view>
                                    <view>
                                        <text class="stock-remain">{{ bundle.remainStock || 0 }}</text>
                                        <text class="text-muted"> 个 / {{ bundle.totalStock }} 个</text>
                                    </view>
                                </view>
                                <view v-if="checkPermission(PERM_BUNDLE.UPDATE) && bundle.status !== BUNDLE_STATUS.DISCARDED" class="button-gold"
                                      @click="push('/pages_bundle/bundle/update_stock?bundleId=' + bundleId)">调整库存
                                </view>
                            </view>
                            <t-progress :percentage="Number(remainPercent)" :show-info="false" :stroke-width="6"
                                        color="#e84c59"/>
                        </view>
                    </view>

                    <t-divider/>

                    <t-grid :column="4">
                        <t-grid-item v-if="checkPermission(PERM_BUNDLE.RECEIVE_LIST)" text="领取明细" icon="task"
                                     :url="'/pages_bundle/receive/list?bundleId=' + bundleId"/>
                        <t-grid-item text="数据统计" icon="chart-analytics"
                                     :url="'/pages_bundle/stat/home?bundleId=' + bundleId"/>
                        <t-grid-item text="包含优惠券" icon="layers" @click="showCouponPopup = true"/>
                        <t-grid-item text="券包须知" icon="file-1" @click="showContentPopup = true"/>
                    </t-grid>
                </view>
            </view>
        </view>

        <t-cell-group title="操作设置" t-title-class="mt-2" theme="card">
            <t-grid :column="4">
                <t-grid-item v-if="checkPermission(PERM_BUNDLE.UPDATE) && bundle.status !== BUNDLE_STATUS.DISCARDED" text="修改券包" icon="edit-2"
                             @click="checkPermission(PERM_BUNDLE.UPDATE) && push('/pages_bundle/bundle/update?bundleId=' + bundleId)"/>
                <t-grid-item v-if="checkPermission(PERM_BUNDLE.UPDATE) && bundle.status === BUNDLE_STATUS.ISSUING" text="暂停发放" icon="pause-circle-stroke"
                             @click="pauseVisible = true"/>
                <t-grid-item v-if="checkPermission(PERM_BUNDLE.UPDATE) && bundle.status === BUNDLE_STATUS.PAUSED" text="恢复发放" icon="play-circle-stroke"
                             @click="startVisible = true"/>
                <t-grid-item v-if="checkPermission(PERM_BUNDLE.DISCARD) && bundle.status !== BUNDLE_STATUS.DISCARDED" text="作废券包" icon="delete-time"
                             @click="push('/pages_bundle/bundle/discard?bundleId=' + bundleId)"/>
                <t-grid-item v-if="checkPermission(PERM_BUNDLE.DELETE)" text="删除券包" icon="delete" @click="push('/pages_bundle/bundle/delete?bundleId=' + bundleId)"/>
                <t-grid-item v-if="checkPermission(PERM_BUNDLE.UPDATE)" text="发券员工" icon="user-setting"
                             :url="'/pages_bundle/issue/staff?bundleId=' + bundleId + '&status=' + bundle.status"/>
            </t-grid>
        </t-cell-group>

    </view>

    <m-submit v-if="bundle && bundle.hasIssuePermission && checkPermission(PERM_BUNDLE.ISSUE)" :disabled="bundle.status !== BUNDLE_STATUS.ISSUING"
              @click="issuePopupVisible = true">发放券包
        <template v-if="bundle.status === BUNDLE_STATUS.PAUSED"> [已暂停]</template>
    </m-submit>
    <m-submit v-else-if="bundle" :disabled="true">您没有发券权限</m-submit>

    <t-popup placement="bottom" v-model:visible="issuePopupVisible">
        <view class="popup-header">
            <view class="popup-header-title">私密发放</view>
            <view class="popup-header-close">
                <t-icon name="close" @click="issuePopupVisible = false" :size="20"></t-icon>
            </view>
        </view>
        <view class="text-center text-muted text-small">适合一对一/储值回馈/消费奖励/给指定客户</view>
        <t-divider/>
        <t-grid :column="4">
            <t-grid-item text="微信好友/群"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2nl4lbp0mqcs77du0.png"
                         @click="goPrivateConfig(CHANNEL_TYPE.PRIVATE_WECHAT)"/>
            <t-grid-item text="二维码"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2o2slbp0mqcs77dug.png"
                         @click="goPrivateConfig(CHANNEL_TYPE.PRIVATE_QRCODE)"/>
            <t-grid-item v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" text="企微加好友发券"
                         image="https://cdn.lenmy.com/quandao/2026/06/24/d8thsq5b4ek0dhdbngc0.png"
                         @click="goPrivateConfig(CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT)"/>
        </t-grid>
        <view class="popup-bottom-cancel mt-5" @click="issuePopupVisible = false">取消</view>
    </t-popup>

    <t-action-sheet :visible="pauseVisible" :items="[{ label: '确定暂停发放' }]" @selected="onPauseSelected"
                    @cancel="pauseVisible = false"></t-action-sheet>
    <t-action-sheet :visible="startVisible" :items="[{ label: '确定恢复发放' }]" @selected="onStartSelected"
                    @cancel="startVisible = false"></t-action-sheet>

    <t-popup v-model:visible="showCouponPopup" placement="bottom">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-title">包含优惠券</view>
                <view class="popup-header-close">
                    <t-icon t-class="mr-2" name="close" size="50rpx" @click="showCouponPopup = false"/>
                </view>
            </view>
            <scroll-view class="popup-body coupon-list" scroll-y :show-scrollbar="true">
                <view v-if="bundle" class="container">
                    <view class="coupon" v-for="item in bundle.coupons" :key="item.couponId"
                          @tap="push('/pages_coupon/coupon/detail?couponId=' + item.couponId)">
                        <view class="coupon-body">
                            <view class="coupon-content">
                                <view class="coupon-name text-ellipsis-break">{{ item.couponName }}</view>
                                <view class="coupon-tag">
                                    <t-tag theme="danger" size="small">{{ item.couponTypeLabel }}</t-tag>
                                    <t-tag theme="danger" variant="light-outline" size="small" v-if="item.isAppt">
                                        需预约
                                    </t-tag>
                                    <t-tag theme="danger" variant="light-outline" size="small" v-if="item.isTransfer">
                                        可转赠
                                    </t-tag>
                                </view>
                                <view class="coupon-valid">{{ item.validLabel }}</view>
                            </view>
                            <view class="coupon-value">
                                <!-- 代金券、套餐券 -->
                                <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.CASH || item.couponType === COUPON_TYPE.PACKAGE">
                                    <text class="coupon-face-unit">￥</text>
                                    <text class="coupon-face-money">{{ item.faceAmount }}</text>
                                </view>
                                <!-- 满减券 -->
                                <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.REDUCE">
                                    <text class="coupon-face-unit">￥</text>
                                    <text class="coupon-face-money">{{ item.reduceAmount }}</text>
                                </view>
                                <!-- 折扣券 -->
                                <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                    <text class="coupon-face-money">{{ item.discountAmount }}</text>
                                    <text class="coupon-face-font">折</text>
                                </view>
                                <!-- 兑换券 -->
                                <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                    <t-icon name="gift-filled" color="e84c59" size="64rpx"></t-icon>
                                </view>
                                <!-- 手气券 -->
                                <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.RANDOM">
                                    <text class="coupon-face-unit">￥</text>
                                    <text class="coupon-face-money">{{ item.randomMinAmount }}~{{
                                            item.randomMaxAmount
                                        }}
                                    </text>
                                </view>
                                <view class="coupon-threshold">{{ item.threshold }}</view>
                            </view>
                        </view>
                        <view class="coupon-line"></view>
                        <view class="coupon-footer">
                            <view class="coupon-footer-left">
                                <t-tag theme="danger" variant="light-outline" size="small">{{
                                        item.issueTypeLabel
                                    }}
                                </t-tag>
                                <view class="coupon-stats">
                                    <text>每包 {{ item.issueCount }} 张</text>
                                    <text>/</text>
                                    <text>库存 {{ item.remainStock }} 张</text>
                                </view>
                            </view>
                            <t-tag :theme="couponStatusTheme(item.status)" variant="light-outline" size="small">
                                {{ item.statusLabel }}
                            </t-tag>
                        </view>
                    </view>
                </view>
            </scroll-view>
        </view>
    </t-popup>

    <t-popup v-model:visible="showContentPopup" placement="bottom">
        <view class="popup-header">
            <view class="popup-header-title">券包须知</view>
            <view class="popup-header-close">
                <t-icon name="close" size="50rpx" @click="showContentPopup = false"/>
            </view>
        </view>
        <scroll-view class="popup-body popup-body-scroll" scroll-y :show-scrollbar="true">
            <view class="popup-card">
                <view v-if="bundle"  class="item-text">{{ bundle.content }}</view>
            </view>
        </scroll-view>
    </t-popup>
</template>

<script setup>
import {onLoad, onShow, onUnload, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request'
import { RESPONSE_CODE } from '@/constants/code'
import { COUPON_TYPE, COUPON_STATUS } from '@/constants/coupon'
import { BUNDLE_STATUS, BUNDLE_AUDIT_STATUS } from '@/constants/bundle'
import { CHANNEL_TYPE } from '@/constants/common'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_BUNDLE, PERM_WECOM} from '@/constants/permission.js'

const {push} = useLink()
const {checkPermission} = useAuth()

const bundleId = ref('')
const bundle = ref()
const showCouponPopup = ref(false)
const showContentPopup = ref(false)
const issuePopupVisible = ref(false)
const pauseVisible = ref(false)
const startVisible = ref(false)

const unitCount = computed(() => bundle.value?.coupons?.length || 0)

const remainPercent = computed(() => {
    if (!bundle.value?.totalStock) return 0
    return utils.formatPercent(bundle.value.remainStock / bundle.value.totalStock)
})

// 券包状态标签主题（按 BundleStatus：1 发放中 / 2 已暂停）
const statusTagTheme = (status) => {
    if (status === BUNDLE_STATUS.ISSUING) return 'success'
    if (status === BUNDLE_STATUS.PAUSED) return 'warning'
    return 'default'
}

// 优惠券状态标签主题（按 CouponStatus：1 有效中 / 2 已暂停 / 3 已作废 / 4 已过期 / 5 已冻结）
const couponStatusTheme = (status) => {
    if (status === COUPON_STATUS.ISSUING) return 'success'
    if (status === COUPON_STATUS.PAUSED) return 'warning'
    if (status === COUPON_STATUS.DISCARDED) return 'danger'
    if (status === COUPON_STATUS.FROZEN) return 'primary'
    return 'default'
}

const getDetail = () => {
    request.get('/seller/bundle/get/detail', {
        id: bundleId.value,
    }).then(res => {
        bundle.value = res.data
        uni.setNavigationBarTitle({title: res.data.name})
    }).catch(err => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            bundle.value = null
        }
    }).finally(() => {
        setTimeout(() => {
            uni.stopPullDownRefresh()
        }, 300)
    })
}

const goPrivateConfig = (channelType) => {
    issuePopupVisible.value = false
    const shareTitle = bundle.value.shareTitle || bundle.value.name
    const cover = bundle.value.shareCover || bundle.value.cover || ''
    if (channelType === CHANNEL_TYPE.PRIVATE_WECHAT || channelType === CHANNEL_TYPE.PRIVATE_QRCODE) {
        push('/pages_bundle/issue/private?bundleId=' + bundleId.value + '&shareTitle=' + shareTitle + '&cover=' + cover + '&channelType=' + channelType)
    } else if (channelType === CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT) {
        push('/pages_wecom/staff/list?productType=2&productId=' + bundleId.value)
    }
}

const onPauseSelected = () => {
    request.post('/seller/bundle/pause', {id: bundleId.value}).then(() => {
        utils.toast('券包已暂停')
        pauseVisible.value = false
        getDetail()
    }).catch(err => {
        utils.toast(err.message)
    })
}

const onStartSelected = () => {
    request.post('/seller/bundle/start', {id: bundleId.value}).then(() => {
        utils.toast('券包已恢复')
        startVisible.value = false
        getDetail()
    }).catch(err => {
        utils.toast(err.message)
    })
}

// 是否已删除（收到删除通知后标记，避免 onShow 再次请求）
const isDeleted = ref(false)

// 券包删除事件回调：标记已删除，导航由 delete.vue 统一处理
const onBundleDelete = (e) => {
    if (e?.id && e.id === bundleId.value) {
        isDeleted.value = true
    }
}


onLoad((e) => {
    bundleId.value = e.bundleId
    uni.$on('onBundleDelete', onBundleDelete)
})

onUnload(() => {
    uni.$off('onBundleDelete', onBundleDelete)
})

onShow(() => {
    // 已删除的券包不再请求，避免报"券包不存在"
    if (isDeleted.value) return
    if (bundleId.value) {
        getDetail()
    }
})

onPullDownRefresh(() => {
    // 已删除的券包不再请求
    if (isDeleted.value) {
        uni.stopPullDownRefresh()
        return
    }
    getDetail()
})
</script>

<style scoped>
.detail-header {
    padding-top: 20rpx;
    min-height: 400px;
    background: url("https://cdn.lenmy.com/quanketuan/2024/09/23/crodj1ide1heuifummd0.png") repeat-x;
}

.detail-header :deep(.bundle-coupon-line)::before,
.detail-header :deep(.bundle-coupon-line)::after {
    background-color: #e2453d;
    background-image: url("https://cdn.lenmy.com/quanketuan/2024/09/23/crodj1ide1heuifummd0.png");
    background-repeat: repeat-x;
    background-position: center top;
    background-size: auto 400px;
}

.bundle-card {
    margin-bottom: 30rpx;
    background: #fff;
    border-radius: 20rpx;
    overflow: hidden;
}

.bundle-body {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 32rpx 32rpx 10rpx;
}

.bundle-content {
    flex: 1;
    min-width: 0;
    padding-right: 20rpx;
}

.bundle-head {
    display: flex;
    align-items: flex-start;
    gap: 20rpx;
}

.bundle-cover {
    width: 96rpx;
    height: 96rpx;
    border-radius: 12rpx;
    flex-shrink: 0;
    display: block;
    background: #fafafa;
}

.bundle-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    background: #fff5f5;
}

.bundle-info {
    flex: 1;
    min-width: 0;
}

.bundle-name {
    font-weight: 600;
    font-size: 32rpx;
    color: #1a1a1a;
    line-height: 1.4;
    margin-bottom: 6rpx;
}

.bundle-issue {
    font-size: 26rpx;
    color: #666;
    line-height: 1.4;
    margin-bottom: 6rpx;
}

.bundle-limit {
    display: inline-flex;
    align-items: center;
    margin-left: auto;
    padding: 4rpx 16rpx;
    border-radius: 20rpx;
    background: #fff5f5;
    font-size: 22rpx;
    color: #e84c59;
    line-height: 1.6;
}

.bundle-limit-num {
    font-size: 26rpx;
    font-weight: 700;
    margin: 0 4rpx;
}

.bundle-value {
    display: flex;
    align-items: baseline;
    justify-content: flex-end;
    flex-shrink: 0;
    gap: 6rpx;
}

.bundle-metric {
    display: flex;
    align-items: baseline;
    color: #e84c59;
}

.bundle-metric-num {
    font-weight: 700;
    font-size: 44rpx;
    line-height: 1;
}

.bundle-metric-unit {
    font-weight: 600;
    font-size: 24rpx;
    margin-left: 2rpx;
}

.bundle-metric-sep {
    font-size: 26rpx;
    color: #e84c59;
    opacity: 0.45;
    padding: 0 4rpx;
}

.bundle-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 12rpx;
    padding: 8rpx 32rpx 24rpx;
}

.stock-panel {
    padding-bottom: 8rpx;
}

.stock-panel :deep(.t-progress) {
    margin-top: 16rpx;
}

.stock-remain {
    font-size: 42rpx;
    font-weight: 700;
    color: #1a1a1a;
}

.common-popup {
    background: #f5f5f5;
    border-radius: 24rpx 24rpx 0 0;
    max-height: 70vh;
}

.popup-card {
    background: #fff;
    padding: 32rpx;
    border-radius: 16rpx;
}

.item-text {
    font-size: 28rpx;
    color: #666;
    line-height: 1.8;
    white-space: pre-wrap;
}

.valid-tag {
    font-size: 24rpx;
    color: #ccc;
}

/* 包含优惠券弹层 - 卡片样式（对齐商户端优惠券列表） */
.coupon-list .coupon {
    margin-bottom: 20rpx;
    position: relative;
    background: #fff;
    border-radius: 20rpx;
}

.coupon-list .coupon-body {
    padding: 32rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.coupon-list .coupon-content {
    flex: 1;
    min-width: 0;
    padding-right: 16rpx;
}

.coupon-list .coupon-name {
    font-weight: 600;
    font-size: 32rpx;
    color: #181818;
    margin-bottom: 12rpx;
}

.coupon-list .coupon-tag {
    display: flex;
    flex-wrap: wrap;
    gap: 8rpx;
    margin-bottom: 10rpx;
}

.coupon-list .coupon-valid {
    color: #666;
    font-size: 28rpx;
    margin-top: 10rpx;
}

.coupon-list .coupon-value {
    max-width: 260rpx;
    flex-shrink: 0;
    overflow: hidden;
    text-align: right;
}

.coupon-list .coupon-face {
    color: #e84c59;
    position: relative;
    display: flex;
    align-items: start;
    justify-content: flex-end;
}

.coupon-list .coupon-face-unit {
    font-weight: 600;
    font-size: 28rpx;
    margin-right: 2rpx;
    margin-top: 6rpx;
}

.coupon-list .coupon-face-font {
    margin-top: 6rpx;
    margin-left: 4rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-list .coupon-face-money {
    font-weight: bold;
    font-size: 56rpx;
}

.coupon-list .coupon-threshold {
    color: #e84c59;
    font-size: 28rpx;
    margin-top: 8rpx;
}

.coupon-list .coupon-footer {
    padding: 0 32rpx 32rpx 32rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 24rpx;
    color: #666;
}

.coupon-list .coupon-footer-left {
    display: flex;
    align-items: center;
    gap: 16rpx;
    flex: 1;
    min-width: 0;
}

.coupon-list .coupon-stats {
    display: flex;
    align-items: center;
    gap: 12rpx;
    color: #999;
    font-size: 24rpx;
}

.popup-bottom-cancel {
    padding: 32rpx;
    text-align: center;
    font-size: 32rpx;
    color: #666;
    background: #fff;
    border-top: 1px solid #f5f5f5;
}
</style>
