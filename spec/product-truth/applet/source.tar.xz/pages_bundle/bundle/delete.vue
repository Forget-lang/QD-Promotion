<template>
    <m-loading v-if="bundle === undefined"></m-loading>
    <template v-else>
        <m-empty v-if="bundle === null">券包不存在</m-empty>
        <template v-else>
            <m-result type="info" v-if="bundle.status !== BUNDLE_STATUS.DISCARDED && bundle.status !== BUNDLE_STATUS.EXPIRED" title="删除条件不足"
                      description="仅已作废和已过期的券包可以删除">
                <template #action>
                    <t-button @click="back()" theme="primary">
                        返回作废券包
                    </t-button>
                </template>
            </m-result>
            <view v-if="bundle.status === BUNDLE_STATUS.DISCARDED || bundle.status === BUNDLE_STATUS.EXPIRED">
                <t-cell-group theme="card" t-class="mt-2">
                    <t-checkbox-group v-model:value="checks">
                        <t-checkbox
                            :value="1"
                            label="你需确认删除后不可恢复，关联的发券员工将一并解除。"
                        />
                        <t-checkbox
                            :value="2"
                            label="你需确认删除后券包与包内优惠券的关联将自动解除（不影响优惠券本身）。"
                        />
                        <t-checkbox
                            :value="3"
                            label="你需确认若当前券包配置了企业微信发券，将自动解除绑定。"
                        />
                        <t-checkbox
                            :value="4"
                            label="你需确认客户已领取的券包将一并删除。"
                        />
                    </t-checkbox-group>
                </t-cell-group>

            </view>
            <m-submit v-if="checkPermission('BundleDelete')" @click="onDelete" :disabled="checks.length !== 4">
                删除券包
            </m-submit>
            <m-submit v-else :disabled="true">您没有删除权限</m-submit>
        </template>
    </template>
</template>

<script setup>
import {onLoad, onShow} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request'
import { RESPONSE_CODE } from '@/constants/code'
import { BUNDLE_STATUS } from '@/constants/bundle'
import utils from '@/utils/utils'
import MResult from '@/components/m/m-result/m-result.vue'
import MSubmit from '@/components/m/m-submit/m-submit.vue'
import {useLink} from '@/hooks/useLink'
import {useAuth} from "@/hooks/useAuth";

const {push, back} = useLink()
const {checkPermission} = useAuth()
const bundleId = ref('')
const bundle = ref()
const checks = ref([])

const getDetail = () => {
    request.get('/seller/bundle/get/detail', {id: bundleId.value}).then(res => {
        bundle.value = res.data
    }).catch(err => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            bundle.value = null
        } else {
            utils.toast(err.message)
        }
    })
}

const onDelete = () => {
    if ((bundle.value.status === BUNDLE_STATUS.DISCARDED || bundle.value.status === BUNDLE_STATUS.EXPIRED) && checks.value.length !== 4) {
        utils.toast('请确认所有选项')
        return
    }
    request.post('/seller/bundle/delete', {id: bundleId.value}).then(() => {
        uni.$emit('onBundleDelete', {id: bundleId.value})
        utils.alert('删除成功', () => {
            back(2)
        })
    }).catch(() => {
    })
}

onLoad((e) => {
    bundleId.value = e.bundleId
})

onShow(() => {
    getDetail()
})
</script>
