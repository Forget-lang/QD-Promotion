<template>
    <t-tabs v-model:value="currentTab" bottom-line-mode="auto" @change="onTabChange">
        <t-tab-panel label="可用券包" :value="1"></t-tab-panel>
        <t-tab-panel label="失效券包" :value="2"></t-tab-panel>
    </t-tabs>

    <view class="container mt-2 container-safety">
        <view class="list-summary" v-if="items && items.length > 0">
            <text>共 {{ total }} 个券包</text>
            <text v-if="!isCompleted" class="list-summary-hint">已加载 {{ items.length }} 个</text>
        </view>

        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">
                {{ currentTab === 1 ? '暂无可用券包，点击下方制作' : '暂无失效券包' }}
            </m-empty>
            <template v-else>
                <view
                    class="bundle"
                    v-for="item in items"
                    :key="item.id"
                    :style="getThemeStyle(item.theme)"
                    :class="{'is-inactive': currentTab === 2}"
                    @tap="push('/pages_bundle/bundle/detail?bundleId=' + item.id)"
                >
                    <view class="bundle-header">
                        <view class="bundle-name text-ellipsis-2">{{ item.name }}</view>
                        <view class="bundle-header-right">
                            <text class="bundle-status">{{ item.statusLabel }}</text>
                            <text v-if="item.auditStatus !== BUNDLE_AUDIT_STATUS.PASSED" class="bundle-audit text-ellipsis">{{
                                    item.auditStatusLabel
                                }}
                            </text>
                        </view>
                    </view>
                    <view class="bundle-body">
                        <view class="bundle-count">
                            <text class="bundle-count-num">{{ item.unitCount || 0 }}</text>
                            <text class="bundle-count-unit">种券</text>
                            <text class="bundle-count-sep">·共</text>
                            <text class="bundle-count-num">{{ item.itemCount || 0 }}</text>
                            <text class="bundle-count-unit">张</text>
                        </view>
                        <image v-if="item.cover" class="bundle-cover" :src="item.cover" mode="aspectFill"/>
                        <view v-else class="bundle-cover bundle-cover-empty">
                            <t-icon name="gift-filled" size="36rpx" color="rgba(255,255,255,0.6)"/>
                        </view>
                    </view>
                    <view class="bundle-footer">
                        <view class="bundle-tag">{{ item.receiveTypeLabel }}</view>
                        <view class="bundle-stats">
                            <text>总 {{ item.totalStock }}个</text>
                            <text class="bundle-stats-sep">/</text>
                            <text>剩 {{ item.remainStock }}个</text>
                            <text class="bundle-stats-sep">/</text>
                            <text>领 {{ item.receiveCount }}个</text>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
    <m-submit v-if="checkPermission(PERM_BUNDLE.CREATE)" @click="push('/pages_bundle/bundle/create')">制作券包</m-submit>
</template>

<script setup>
import {onLoad, onUnload, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {BUNDLE_AUDIT_STATUS} from '@/constants/bundle'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_BUNDLE} from '@/constants/permission.js'
import {getThemeStyle} from '@/utils/theme'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()
// 当前 Tab（1可用/2失效）
const currentTab = ref(1)
// 列表查询筛选参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: 1,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 券包总数
const total = ref(0)
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取券包列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/bundle/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 刷新列表（事件监听复用）
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

const onTabChange = (e) => {
    search.value.status = e.value
    items.value = undefined
    onRefresh()
}

const registerEvent = () => {
    uni.$on('onBundleDelete', (e) => {
        if (!e?.id || !items.value?.length) return
        const deleteIndex = items.value.findIndex(item => item.id === e.id)
        if (deleteIndex >= 0) {
            items.value.splice(deleteIndex, 1)
        }
    })
    uni.$on('onBundleDiscard', (e) => {
        if (!e?.id || !items.value?.length) return
        if (currentTab.value !== 1) return
        const index = items.value.findIndex(item => item.id === e.id)
        if (index >= 0) {
            items.value.splice(index, 1)
            if (total.value > 0) total.value--
        }
    })
    uni.$on('onBundleUpdate', (e) => {
        if (!e?.id || !items.value?.length) return
        const editIndex = items.value.findIndex(item => item.id === e.id)
        if (editIndex >= 0) {
            items.value.splice(editIndex, 1, e)
        }
    })
    uni.$on('onBundleCreate', () => {
        if (currentTab.value !== 1) return
        onRefresh()
    })
}

onLoad(() => {
    registerEvent()
    getItems()
})

onUnload(() => {
    uni.$off('onBundleDelete')
    uni.$off('onBundleDiscard')
    uni.$off('onBundleUpdate')
    uni.$off('onBundleCreate')
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.list-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 8rpx 20rpx;
    font-size: 24rpx;
    color: #999;
}

.list-summary-hint {
    color: #ccc;
}

.bundle {
    position: relative;
    margin-bottom: 24rpx;
    border-radius: 24rpx;
    padding: 28rpx 28rpx 24rpx;
    overflow: hidden;
    box-shadow: 0 6rpx 24rpx rgba(0, 0, 0, 0.08);
}

.bundle.is-inactive {
    opacity: 0.82;
}

.bundle-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16rpx;
}

.bundle-name {
    flex: 1;
    min-width: 0;
    font-size: 34rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.35;
}

.bundle-header-right {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 12rpx;
}

.bundle-status {
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.82);
}

.bundle-audit {
    font-size: 22rpx;
    color: #ffd666;
    white-space: nowrap;
}

.bundle-body {
    margin-top: 20rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20rpx;
}

.bundle-count {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: baseline;
    line-height: 1;
}

.bundle-count-num {
    font-size: 44rpx;
    font-weight: 700;
    color: #fff;
}

.bundle-count-unit {
    margin-left: 4rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.82);
}

.bundle-count-sep {
    margin: 0 8rpx 0 10rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.62);
}

.bundle-cover {
    width: 140rpx;
    height: 100rpx;
    border-radius: 12rpx;
    flex-shrink: 0;
    display: block;
    background: rgba(255, 255, 255, 0.12);
}

.bundle-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
}

.bundle-footer {
    margin-top: 22rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.bundle-tag {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.92);
    padding: 4rpx 14rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.4);
    border-radius: 8rpx;
    background: rgba(255, 255, 255, 0.12);
}

.bundle-stats {
    display: flex;
    align-items: center;
    gap: 8rpx;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.62);
}

.bundle-stats-sep {
    color: rgba(255, 255, 255, 0.35);
}

.text-ellipsis-2 {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}
</style>
