<template>
    <m-result v-if="showSuccess" title="作废成功" description="客户已领取的券包及领包后发出的未核销券已一并作废。"
              back></m-result>
    <template v-else>
        <view class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="h4">作废须知：</view>
                <view class="mt-1 text-small">1. 所有
                    <text class="text-danger">客户已领取的券包也会一并作废</text>
                    ，请谨慎操作！
                </view>
                <view class="mt-1 text-small">2. 领包后发出的
                    <text class="text-danger">未核销优惠券也将一并作废</text>
                    ，已核销的不受影响。
                </view>
                <view class="mt-1 text-small">3. 作废后券包
                    <text class="text-danger">不可继续发放、领取</text>
                    ；券包内挂载的优惠券模版本身不会作废。
                </view>
                <view class="mt-1 text-small">4. 作废后券包不可恢复；作废后可进行删除操作。</view>
            </view>
        </view>
        <t-cell-group t-class="mt-2" theme="card">
            <t-textarea required label="作废原因" v-model:value="form.reason" :maxlength="32" :indicator="true"
                        placeholder="请输入作废原因"></t-textarea>
        </t-cell-group>
        <view class="mt-3">
            <t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless icon="circle"
                        relation-key="-1" custom-style="background-color: transparent;">
                <template #label>
                    <view class="agreement">
                        我已阅读并知晓：作废后
                        <text class="text-danger">所有客户已领取的券包及领包后发出的未核销券将一并作废</text>
                        ，确认要作废该券包。
                    </view>
                </template>
            </t-checkbox>
        </view>
        <m-submit :loading="loading" :disabled="loading || !allowAgreement" @click="onSubmit">确认作废</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request.js'
import MResult from '@/components/m/m-result/m-result.vue'
import utils from '@/utils/utils'

const bundleId = ref()
const allowAgreement = ref(false)
const loading = ref(false)
const form = ref({
    reason: ''
})
const showSuccess = ref(false)

const onSubmit = () => {
    if (!form.value.reason) {
        utils.toast('请输入作废原因')
        return
    }
    loading.value = true
    request.post('/seller/bundle/discard', {id: bundleId.value, reason: form.value.reason}).then(() => {
        uni.$emit('onBundleDiscard', {id: bundleId.value})
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    }).catch((err) => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    bundleId.value = e.bundleId
})
</script>

<style scoped>

</style>
