<template>
    <m-loading v-if="detail === undefined"></m-loading>
    <m-empty v-else-if="detail === null">领取记录不存在</m-empty>
    <view class="container-safety" v-else>
        <view class="container mt-3">
            <view class="summary-card">
                <view class="summary-head">
                    <view class="user-avatar">
                        <image v-if="detail.avatar" :src="detail.avatar" mode="aspectFill"/>
                        <text v-else>{{ displayName.charAt(0) }}</text>
                    </view>
                    <view class="summary-info">
                        <view class="summary-name">{{ displayName }}</view>
                        <view class="summary-mobile" v-if="detail.mobile">
                            {{ detail.mobile }}
                            <text class="copy-btn text-wechat" @click="utils.copyClipboard(detail.mobile)">复制</text>
                        </view>
                        <view class="summary-time">领取于 {{ detail.receivedAt }}</view>
                    </view>
                </view>

                <view class="summary-metrics">
                    <view class="metric-item">
                        <view class="metric-num metric-unused">{{ detail.unusedCount || 0 }}</view>
                        <view class="metric-label">未使用</view>
                    </view>
                    <view class="metric-divider"></view>
                    <view class="metric-item">
                        <view class="metric-num metric-used">{{ detail.usedCount || 0 }}</view>
                        <view class="metric-label">已核销</view>
                    </view>
                    <view class="metric-divider"></view>
                    <view class="metric-item">
                        <view class="metric-num metric-discarded">{{ detail.discardedCount || 0 }}</view>
                        <view class="metric-label">已作废</view>
                    </view>
                    <view class="metric-divider"></view>
                    <view class="metric-item">
                        <view class="metric-num metric-expired">{{ detail.expiredCount || 0 }}</view>
                        <view class="metric-label">已过期</view>
                    </view>
                </view>
            </view>
        </view>

        <view class="container mt-2">
            <view class="panel-card">
                <view class="panel-title">券包信息</view>
                <view class="panel-row">
                    <text class="panel-label">券包名称</text>
                    <text class="panel-value">{{ detail.bundleName }}</text>
                </view>
                <view class="panel-row">
                    <text class="panel-label">实发张数</text>
                    <text class="panel-value">{{ detail.couponCount || 0 }}张</text>
                </view>
                <view class="panel-row" v-if="detail.chosenCouponName">
                    <text class="panel-label">自选券种</text>
                    <text class="panel-value">{{ detail.chosenCouponName }}</text>
                </view>
            </view>
        </view>

        <view class="container mt-2">
            <view class="panel-card">
                <view class="panel-title">发放信息</view>
                <view class="issue-grid">
                    <view class="issue-grid-item">
                        <view class="issue-grid-icon issue-icon-type">
                            <t-icon name="layers" size="32rpx" color="#07c160"/>
                        </view>
                        <text class="issue-grid-label">领取方式</text>
                        <text class="issue-grid-value">{{ detail.receiveTypeLabel }}</text>
                    </view>
                    <view class="issue-grid-item">
                        <view class="issue-grid-icon issue-icon-channel">
                            <t-icon name="share-1" size="32rpx" color="#1989fa"/>
                        </view>
                        <text class="issue-grid-label">发放渠道</text>
                        <text class="issue-grid-value">{{ detail.channelTypeLabel }}</text>
                    </view>
                    <view class="issue-grid-item">
                        <view class="issue-grid-icon issue-icon-store">
                            <t-icon name="shop" size="32rpx" color="#e84c59"/>
                        </view>
                        <text class="issue-grid-label">发券门店</text>
                        <text class="issue-grid-value">{{ detail.issueStoreName || '-' }}</text>
                    </view>
                    <view class="issue-grid-item">
                        <view class="issue-grid-icon issue-icon-staff">
                            <t-icon name="user" size="32rpx" color="#9b59b6"/>
                        </view>
                        <text class="issue-grid-label">发券人</text>
                        <text class="issue-grid-value">{{ detail.issueStaffName || '-' }}</text>
                    </view>
                </view>

                <view class="issue-remark">
                    <view class="issue-remark-head">
                        <t-icon name="chat" size="28rpx" color="#b8860b"/>
                        <text class="issue-remark-label">发放备注</text>
                    </view>
                    <text class="issue-remark-value">{{ detail.issueRemark || '无' }}</text>
                </view>
            </view>
        </view>

        <view class="container mt-2">
            <view class="section-title">包含优惠券</view>
            <view class="coupon-container">
                <view
                    v-for="item in detail.coupons"
                    :key="item.id"
                    class="receive coupon-wrap"
                    @click="goCouponDetail(item.id)"
                >
                    <view class="coupon" :class="{ 'coupon-disabled': item.status !== RECEIVE_STATUS.UNUSED }">
                        <view class="coupon-header">
                            <image class="coupon-thumb" :src="item.cover" mode="scaleToFill"/>
                        </view>
                        <view class="coupon-body">
                            <view class="coupon-content">
                                <view class="coupon-content-info">
                                    <view class="coupon-content-name text-ellipsis-break">{{ item.couponName }}</view>
                                    <view class="coupon-content-value">
                                        <template v-if="isAmountFace(item.couponType)">
                                            <view class="coupon-content-amount">
                                                <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                <view class="coupon-amount-discount">元券</view>
                                            </view>
                                        </template>
                                        <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                            <view class="coupon-content-amount">
                                                <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                <view class="coupon-amount-discount">折券</view>
                                            </view>
                                        </template>
                                        <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                            <view class="coupon-amount">
                                                <image class="exchange-icon" src="/static/img/exchange.png"
                                                       mode="aspectFit"/>
                                            </view>
                                        </template>
                                        <view class="coupon-threshold">{{ item.threshold }}</view>
                                    </view>
                                    <view class="coupon-content-valid text-ellipsis">{{ item.validLabel }}</view>
                                </view>
                                <view v-if="item.status === RECEIVE_STATUS.UNUSED" class="coupon-content-action">
                                    <view class="button-gold">查看</view>
                                </view>
                            </view>
                        </view>
                    </view>

                    <image
                        v-if="couponStampMap[item.status]"
                        class="coupon-stamp"
                        :src="couponStampMap[item.status]"
                        mode="aspectFit"
                    />
                </view>
                <m-empty v-if="!detail.coupons?.length" :height="200">暂无优惠券</m-empty>
            </view>
        </view>
    </view>

    <m-submit
        v-if="detail && detail.unusedCount > 0 && checkPermission(PERM_BUNDLE.RECEIVE_DISCARD)"
        @click="discardVisible = true"
    >作废所有待使用优惠券
    </m-submit>

    <t-popup placement="bottom" :visible="discardVisible" @visible-change="onDiscardPopupChange">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-title">作废所有待使用优惠券</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="24px" @click="discardVisible = false"/>
                </view>
            </view>
            <view class="popup-body">
                <view class="textarea-wrapper">
                    <t-textarea
                        label="作废原因"
                        v-model:value="discardForm.reason"
                        :custom-style="textareaStyle"
                        :maxlength="32"
                        :indicator="true"
                        :cursor-spacing="120"
                        placeholder="请输入作废原因"
                    />
                </view>
            </view>
            <view class="popup-footer">
                <t-button theme="primary" size="large" block @click="onConfirmDiscardUnused">确认作废</t-button>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import { RESPONSE_CODE } from '@/constants/code'
import { COUPON_TYPE, RECEIVE_STATUS, isAmountFace } from '@/constants/coupon'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {PERM_BUNDLE} from '@/constants/permission'

const {push} = useLink()
const {checkPermission} = useAuth()

const bundleReceiveId = ref('')
const detail = ref()
const loading = ref(false)
const discardVisible = ref(false)
const discardForm = ref({reason: ''})
const textareaStyle = 'height: 360rpx'

const displayName = computed(() => detail.value?.realName || detail.value?.nickname || '微信用户')

const couponStampMap = {
    2: '/static/img/coupon-used.png',
    3: '/static/img/coupon-discard.png',
    4: '/static/img/coupon-invalid.png',
}

const getDetail = () => {
    request.get('/seller/bundle/receive/detail', {
        id: bundleReceiveId.value,
    }).then(res => {
        detail.value = res.data
        uni.setNavigationBarTitle({title: '领取详情'})
    }).catch(err => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            detail.value = null
        }
    })
}

const goCouponDetail = (couponReceiveId) => {
    push('/pages_coupon/receive/detail?couponReceiveId=' + couponReceiveId)
}

const onDiscardPopupChange = (val) => {
    if (!val) {
        discardForm.value = {reason: ''}
    }
}

const onConfirmDiscardUnused = () => {
    if (!discardForm.value.reason) {
        utils.toast('请输入作废原因')
        return
    }
    loading.value = true
    request.post('/seller/bundle/receive/discard-unused', {
        id: bundleReceiveId.value,
        reason: discardForm.value.reason,
    }).then(() => {
        utils.toast('作废成功')
        discardVisible.value = false
        getDetail()
    }).catch(err => {
        utils.toast(err.message || '作废失败')
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    if (!e.bundleReceiveId) {
        utils.toast('缺少领取记录ID')
        setTimeout(() => uni.navigateBack(), 1500)
        return
    }
    bundleReceiveId.value = e.bundleReceiveId
    getDetail()
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 300)
})
</script>

<style scoped>
.summary-card {
    background: #fff;
    border-radius: 16rpx;
    padding: 28rpx;
}

.summary-head {
    display: flex;
    align-items: flex-start;
    gap: 16rpx;
}

.user-avatar {
    width: 88rpx;
    height: 88rpx;
    border-radius: 50%;
    background: #e8f4ff;
    color: #3b82f6;
    font-size: 32rpx;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    overflow: hidden;
}

.user-avatar image {
    width: 100%;
    height: 100%;
}

.summary-info {
    flex: 1;
    min-width: 0;
}

.summary-name {
    font-size: 32rpx;
    font-weight: 700;
    color: #333;
}

.summary-mobile {
    margin-top: 8rpx;
    font-size: 26rpx;
    color: #666;
}

.summary-time {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.summary-metrics {
    display: flex;
    align-items: center;
    margin-top: 28rpx;
    padding-top: 24rpx;
    border-top: 1rpx solid #f5f5f5;
}

.metric-item {
    flex: 1;
    text-align: center;
}

.metric-divider {
    width: 1rpx;
    height: 56rpx;
    background: #eee;
    flex-shrink: 0;
}

.metric-num {
    font-size: 40rpx;
    font-weight: 700;
    color: #333;
}

.metric-used {
    color: #1989fa;
}

.metric-unused {
    color: #07c160;
}

.metric-discarded {
    color: #e84c59;
}

.metric-expired {
    color: #999;
}

.metric-label {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.panel-card {
    background: #fff;
    border-radius: 16rpx;
    padding: 28rpx 24rpx;
}

.panel-title {
    font-size: 28rpx;
    font-weight: 700;
    color: #333;
    margin-bottom: 20rpx;
}

.panel-row {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 24rpx;
    padding: 16rpx 0;
    border-bottom: 1rpx solid #f5f5f5;
}

.panel-row:last-child {
    border-bottom: none;
    padding-bottom: 0;
}

.panel-label {
    font-size: 26rpx;
    color: #999;
    flex-shrink: 0;
}

.panel-value {
    font-size: 26rpx;
    color: #333;
    text-align: right;
    line-height: 1.5;
}

.issue-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16rpx;
}

.issue-grid-item {
    background: #fafafa;
    border-radius: 16rpx;
    padding: 20rpx;
}

.issue-grid-icon {
    width: 56rpx;
    height: 56rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 12rpx;
}

.issue-icon-type {
    background: rgba(7, 193, 96, 0.12);
}

.issue-icon-channel {
    background: rgba(25, 137, 250, 0.12);
}

.issue-icon-store {
    background: rgba(232, 76, 89, 0.12);
}

.issue-icon-staff {
    background: rgba(155, 89, 182, 0.12);
}

.issue-grid-label {
    display: block;
    font-size: 22rpx;
    color: #999;
    margin-bottom: 6rpx;
}

.issue-grid-value {
    display: block;
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
    word-break: break-all;
}

.issue-remark {
    margin-top: 20rpx;
    padding: 24rpx;
    background: #fff8e6;
    border-radius: 16rpx;
    border-left: 6rpx solid #f5a623;
}

.issue-remark-head {
    display: flex;
    align-items: center;
    gap: 8rpx;
    margin-bottom: 12rpx;
}

.issue-remark-label {
    font-size: 24rpx;
    font-weight: 600;
    color: #b8860b;
}

.issue-remark-value {
    display: block;
    font-size: 28rpx;
    color: #5c4a1f;
    line-height: 1.7;
    word-break: break-all;
}

.section-title {
    font-size: 28rpx;
    font-weight: 700;
    color: #333;
    margin-bottom: 16rpx;
    padding: 0 8rpx;
}

.coupon-container {
    padding-bottom: 8rpx;
}

.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.receive + .receive {
    margin-top: 20rpx;
}

.coupon-wrap {
    position: relative;
}

.coupon {
    padding: 32rpx;
    display: flex;
    align-items: center;
}

.coupon.coupon-disabled {
    filter: grayscale(1);
}

.coupon-header {
    margin-right: 30rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #181818;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    margin-top: 8rpx;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

.coupon-stamp {
    position: absolute;
    right: 30rpx;
    top: 0;
    bottom: 0;
    margin: auto 0;
    width: 160rpx;
    height: 160rpx;
    z-index: 10;
    pointer-events: none;
}

.popup-body {
    height: 400rpx;
}

.textarea-wrapper {
    border-radius: 16rpx;
    border: 1px solid #f0f0f0;
    margin: 0 24rpx;
}

.popup-footer {
    display: flex;
    padding: 24rpx 32rpx;
    gap: 24rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
}

.popup-footer .t-button {
    border-radius: 40rpx;
}
</style>
