<template>
    <view class="filter-bar">
        <view class="filter-bar-left">
            <view class="filter-bar-item" @tap="showOrderPicker = true">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.sorter === 'desc' }">
                    {{ search.sorter === 'desc' ? '最新' : '最早' }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.sorter === 'desc' ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showTimePicker = true">
                <text class="filter-bar-label filter-bar-time"
                      :class="{ 'filter-bar-active': search.startTime && search.endTime }">
                    {{ search.startTime && search.endTime ? search.startTime + '~' + search.endTime : '时间' }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.startTime && search.endTime ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showChannelPicker = true">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.channelType }">
                    {{ getChannelLabel(search.channelType) || '渠道' }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.channelType ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="storeSelectRef?.onOpen">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.issueStoreId }">
                    {{ storeLabel || '门店' }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.issueStoreId ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="staffSelectRef?.onOpen">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.issueStaffId }">
                    {{ staffLabel || '员工' }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.issueStaffId ? 'var(--td-brand-color)' : '#999'"/>
            </view>
        </view>
        <view class="filter-bar-right" @tap="onResetFilter">
            <text class="filter-bar-action">重置</text>
        </view>
    </view>

    <view class="summary-bar" v-if="items && total > 0">
        <text>共 {{ total }} 条领取记录</text>
    </view>

    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无领取记录</m-empty>
            <template v-else>
                <view
                    class="record-item"
                    v-for="item in items"
                    :key="item.id"
                    @tap="goDetail(item.id)"
                >
                    <view class="record-header">
                        <view class="record-user">
                            <view class="user-avatar">
                                <image v-if="item.avatar" :src="item.avatar" mode="aspectFill"></image>
                                <text v-else>{{ displayName(item).charAt(0) }}</text>
                            </view>
                            <view class="user-info">
                                <view class="user-name-row">
                                    <text class="user-name">{{ displayName(item) }}</text>
                                </view>
                                <view class="user-time">{{ item.receivedAt }}</view>
                            </view>
                        </view>
                        <t-icon name="chevron-right" size="32rpx" color="#ddd"/>
                    </view>

                    <view class="bundle-name-row" v-if="!search.bundleId && item.bundleName">
                        <t-icon name="gift" size="28rpx" color="#e84c59"/>
                        <text class="bundle-name">{{ item.bundleName }}</text>
                    </view>

                    <view class="issue-grid">
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">发放渠道</text>
                            <text class="issue-grid-value">{{ item.channelTypeLabel }}</text>
                        </view>
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">发券门店</text>
                            <text class="issue-grid-value text-ellipsis">{{ item.issueStoreName || '-' }}</text>
                        </view>
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">发券人</text>
                            <text class="issue-grid-value text-ellipsis">{{ item.issueStaffName || '-' }}</text>
                        </view>
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">发放备注</text>
                            <text class="issue-grid-value text-ellipsis">{{ item.issueRemark || '无' }}</text>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
    <m-submit v-if="checkPermission('BundleExport')" @click="onExportList">导出领取记录</m-submit>

    <t-popup placement="bottom" v-model:visible="showTimePicker" @visible-change="onTimePickerChange" :z-index="10000"
             :overlay-props="{ zIndex: 9999 }">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-cancel" @tap="showTimePicker = false">取消</view>
                <view class="popup-header-title">选择时间</view>
                <view class="popup-header-confirm" @tap="onClearTime">清空</view>
            </view>
            <view class="popup-body" style="height: 600rpx;">
                <t-cell-group theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.startTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="开始时间"
                        placeholder="请选择开始时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <t-cell-group t-class="mt-2" theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.endTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="结束时间"
                        placeholder="请选择结束时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <view class="popup-footer mt-5">
                    <t-button theme="danger" size="large" block @click="onConfirmTime">确认</t-button>
                </view>
            </view>
        </view>
    </t-popup>

    <t-action-sheet :visible="showChannelPicker" :items="channelActionItems" @selected="onSelectChannel"
                    @cancel="showChannelPicker = false"/>
    <t-action-sheet :visible="showOrderPicker" :items="orderItems" @selected="onSelectOrder"
                    @cancel="showOrderPicker = false"/>

    <m-store-select
        ref="storeSelectRef"
        v-model:value="search.issueStoreId"
        title="发放门店"
        placeholder="请选择发放门店"
        :multiple="false"
        :hidden="true"
        @label-change="onStoreLabelChange"
    />
    <m-staff-select
        ref="staffSelectRef"
        v-model:value="search.issueStaffId"
        title="发放员工"
        placeholder="请选择发放员工"
        :multiple="false"
        :hidden="true"
        @label-change="onStaffLabelChange"
    />

    <!-- VIP 升级抽屉：承接导出接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {saveBase64Excel} from '@/hooks/useFile'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

// ========== 列表查询 ==========
const search = ref({
    page: 1,
    pageSize: 20,
    bundleId: undefined,
    channelType: undefined,
    sorter: 'desc',
    startTime: undefined,
    endTime: undefined,
    issueStoreId: undefined,
    issueStaffId: undefined,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 领取记录总数
const total = ref(0)
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// ========== 筛选相关 ==========
const showTimePicker = ref(false)
const showOrderPicker = ref(false)
const showChannelPicker = ref(false)
const storeSelectRef = ref()
const storeLabel = ref()
const staffSelectRef = ref()
const staffLabel = ref()
const tempTime = ref({
    startTime: '',
    endTime: '',
})
const orderItems = [
    {label: '最新', value: 'desc'},
    {label: '最早', value: 'asc'},
]
const channelOptions = [
    {label: '私密微信好友', value: 11},
    {label: '私密二维码', value: 12},
]
const channelActionItems = channelOptions.map(o => ({label: o.label, value: o.value}))

// 展示客户名称：优先真实姓名，其次昵称
const displayName = (item) => item.realName || item.nickname || '微信用户'

// 根据渠道值取筛选项文案
const getChannelLabel = (val) => {
    const item = channelOptions.find(o => o.value === val)
    return item ? item.label : ''
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取领取记录列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/bundle/receive/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 下拉刷新：重置到第一页
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 进入领取详情
const goDetail = (id) => {
    push('/pages_bundle/receive/detail?bundleReceiveId=' + id)
}

// 按当前筛选条件导出领取记录
const onExportList = async () => {
    utils.showLoading()
    try {
        const res = await request.post('/seller/bundle/receive/export', search.value)
        await saveBase64Excel(res.data.file, '券包领取记录')
    } catch (err) {
        // ignore
    } finally {
        utils.hideLoading()
    }
}

// 门店选择标签变更后刷新列表
const onStoreLabelChange = (label) => {
    storeLabel.value = label
    applyFilterAndRefresh()
}

// 员工选择标签变更后刷新列表
const onStaffLabelChange = (label) => {
    staffLabel.value = label
    applyFilterAndRefresh()
}

// 时间弹框显隐；打开时回填已选时间
const onTimePickerChange = (visible) => {
    showTimePicker.value = visible
    if (visible) {
        tempTime.value.startTime = search.value.startTime || ''
        tempTime.value.endTime = search.value.endTime || ''
    }
}

// 确认时间筛选
const onConfirmTime = () => {
    search.value.startTime = tempTime.value.startTime || undefined
    search.value.endTime = tempTime.value.endTime || undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

// 清空时间筛选
const onClearTime = () => {
    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    search.value.startTime = undefined
    search.value.endTime = undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

// 选择排序方式
const onSelectOrder = (e) => {
    search.value.sorter = e.selected.value
    showOrderPicker.value = false
    applyFilterAndRefresh()
}

// 选择发放渠道
const onSelectChannel = (e) => {
    search.value.channelType = e.selected.value
    showChannelPicker.value = false
    applyFilterAndRefresh()
}

// 应用筛选条件并重新加载第一页
const applyFilterAndRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 重置筛选（保留从详情页带入的 bundleId）
const onResetFilter = () => {
    const bundleId = search.value.bundleId
    search.value.startTime = undefined
    search.value.endTime = undefined
    search.value.sorter = 'desc'
    search.value.channelType = undefined
    search.value.issueStoreId = undefined
    search.value.issueStaffId = undefined
    search.value.bundleId = bundleId

    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    staffLabel.value = ''
    storeLabel.value = ''

    applyFilterAndRefresh()
}

onLoad((e) => {
    if (e.bundleId) {
        search.value.bundleId = e.bundleId
        uni.setNavigationBarTitle({title: '券包领取记录'})
    }
    getItems()
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.filter-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20rpx 32rpx;
    background: #fff;
    border-bottom: 1rpx solid #eee;
}

.filter-bar-left {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 24rpx 32rpx;
    flex: 1;
}

.filter-bar-item {
    display: flex;
    align-items: center;
    gap: 6rpx;
    padding: 8rpx 0;
}

.filter-bar-label {
    font-size: 28rpx;
    color: #666;
    max-width: 84rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.filter-bar-time {
    max-width: 180rpx;
}

.filter-bar-active {
    color: var(--td-brand-color) !important;
}

.filter-bar-right {
    flex-shrink: 0;
    margin-left: 16rpx;
}

.filter-bar-action {
    font-size: 28rpx;
    color: var(--td-brand-color);
}

.summary-bar {
    padding: 16rpx 32rpx 0;
    font-size: 24rpx;
    color: #999;
}

.popup-footer {
    display: flex;
    padding: 24rpx 32rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
}

.record-item {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
    margin-bottom: 20rpx;
}

.record-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20rpx;
}

.record-user {
    display: flex;
    align-items: flex-start;
    flex: 1;
    min-width: 0;
}

.user-avatar {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    background: #e8f4ff;
    color: #3b82f6;
    font-size: 28rpx;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
    overflow: hidden;
}

.user-avatar image {
    width: 100%;
    height: 100%;
}

.user-info {
    flex: 1;
    min-width: 0;
}

.user-name-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 8rpx;
}

.user-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    margin-right: 12rpx;
}

.user-mobile {
    font-size: 26rpx;
    color: #333;
    margin-right: 12rpx;
}

.user-time {
    font-size: 24rpx;
    color: #999;
}

.bundle-name-row {
    display: flex;
    align-items: center;
    gap: 8rpx;
    margin-bottom: 16rpx;
    padding-bottom: 16rpx;
    border-bottom: 1rpx solid #f5f5f5;
}

.bundle-name {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.issue-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16rpx;
}

.issue-grid-item {
    background: #fafafa;
    border-radius: 12rpx;
    padding: 16rpx 20rpx;
    /* grid 子项默认最小宽度为 auto，会导致内部 text-ellipsis 失效而撑开格子，置 0 让省略生效 */
    min-width: 0;
}

.issue-grid-label {
    display: block;
    font-size: 22rpx;
    color: #999;
    margin-bottom: 8rpx;
}

.issue-grid-value {
    display: block;
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
}
</style>
