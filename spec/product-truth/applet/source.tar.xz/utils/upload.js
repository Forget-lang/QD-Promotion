import config from '@/config.js'
import {useSessionStore} from '@/stores/session'

/**
 * 上传请求头：每次调用读取最新 token / merchantId，避免 setup 顶层快照。
 * @param {{ withMerchant?: boolean }} [options] 用户端上传可传 withMerchant: false
 */
export function getUploadHeader(options = {}) {
    const {withMerchant = true} = options
    const session = useSessionStore()
    const header = {
        'Content-Type': 'application/json;charset=utf-8;',
        'Authorization': session.token || '',
        'App-Name': 'applet',
        'Version': config.version,
    }
    if (withMerchant) {
        header['Merchant-Id'] = session.merchantId || ''
    }
    return header
}
