import {getTheme, themes} from '@/utils/theme.js'

// 商家主页默认墨玉绿，色板与券包/次卡 themes 一致
export const defaultHomeTheme = 4

export const getHomeTheme = (theme) => {
    const value = Number(theme)
    return themes.find((item) => item.value === value) || getTheme(defaultHomeTheme)
}

const mixHex = (hex, target, ratio) => {
    const n = parseInt(String(hex).replace('#', ''), 16)
    const r = (n >> 16) & 255
    const g = (n >> 8) & 255
    const b = n & 255
    const tr = (target >> 16) & 255
    const tg = (target >> 8) & 255
    const tb = target & 255
    const to = (c, t) => Math.round(c + (t - c) * ratio)
    return '#' + [to(r, tr), to(g, tg), to(b, tb)].map((c) => c.toString(16).padStart(2, '0')).join('')
}

// 会员卡渐变：真机 Tab 页不吃父节点 CSS 变量，必须内联 background
export const getHomeThemeStyle = (theme) => {
    const color = getHomeTheme(theme).color
    const light = mixHex(color, 0xffffff, 0.18)
    const dark = mixHex(color, 0x000000, 0.32)
    return {
        background: `linear-gradient(160deg, ${light} 0%, ${color} 48%, ${dark} 100%)`,
    }
}

export const getHomeThemeColorStyle = (theme) => {
    return {
        background: getHomeTheme(theme).color,
    }
}

/** 浅色页面底：主题色极淡化，适合列表页 */
export const getHomeThemePageStyle = (theme) => {
    const color = getHomeTheme(theme).color
    const pageBg = mixHex(color, 0xffffff, 0.94)
    return {
        background: pageBg,
        '--theme-color': color,
        '--theme-soft': mixHex(color, 0xffffff, 0.88),
        '--theme-soft-bg': mixHex(color, 0xffffff, 0.9),
        '--page-bg': pageBg,
    }
}

export const getHomeThemeAccent = (theme) => getHomeTheme(theme).color

export const applyHomeThemeBackground = (theme) => {
    const color = getHomeTheme(theme).color
    uni.setBackgroundColor({
        backgroundColorTop: color,
        backgroundColor: color,
    })
}

/** 列表类页：导航栏与页面浅底同色 */
export const applyHomeThemePageChrome = (theme) => {
    const pageBg = mixHex(getHomeTheme(theme).color, 0xffffff, 0.94)
    uni.setNavigationBarColor({
        frontColor: '#000000',
        backgroundColor: pageBg,
    })
    uni.setBackgroundColor({
        backgroundColorTop: pageBg,
        backgroundColor: pageBg,
        backgroundColorBottom: pageBg,
    })
}
