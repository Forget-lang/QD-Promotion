// 券包/次卡共用主题色：与 server model.BundleTheme 取值一致（会员卡深色系）
export const themes = [{value: 1, label: '尊享红', color: '#8B1A32', desc: '经典贵宾礼遇，适合高端会所'},
    {value: 2, label: '酒窖红', color: '#6A2432', desc: '复古质感，适合精品餐饮'},
    {value: 3, label: '鎏金黄', color: '#786018', desc: '低调奢华，适合 SPA 美业'},
    {value: 4, label: '墨玉绿', color: '#0C453D', desc: '沉稳内敛，适合茶咖养生'},
    {value: 5, label: '午夜蓝', color: '#212F99', desc: '商务信赖，适合轻奢服务'},
    {value: 6, label: '赤铜棕', color: '#6B3A2A', desc: '温暖质感，适合沙龙理疗'},
    {value: 7, label: '曜石黑', color: '#121216', desc: '黑金格调，适合私享定制'},
    {value: 8, label: '御紫', color: '#3E2060', desc: '神秘尊贵，适合奢华美业'},
    {value: 9, label: '深海蓝', color: '#123448', desc: '宁静高级，适合酒店旅拍'},
]

// 默认主题色 ID（尊享红）
export const defaultTheme = 1

// 根据主题 ID 获取主题配置，无效值回落默认色
export const getTheme = (theme) => {
    const value = Number(theme) || defaultTheme
    return themes.find(item => item.value === value) || themes[0]
}

// 页面/组件根节点样式：背景色 + CSS 变量供子元素伪类使用
export const getThemeStyle = (theme) => {
    const color = getTheme(theme).color
    return {
        background: color,
        '--theme-color': color,
    }
}

// Tab 主题：背景与页面一致，激活文字/滑块为黑色
export const tabsThemeBlack = {
    '--td-tab-nav-bg-color': '#f6f6f6',
    '--td-tab-item-active-color': '#000000',
    '--td-tab-track-color': '#000000',
    '--td-badge-content-text-color': '#999999',
}
