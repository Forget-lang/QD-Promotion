// utils/monitor.js
import config from "../config";
import utils from "./utils";

const monitor = {
	// 初始化：只注册全局监听
	init() {
		console.log('🛡️ QuanDao Monitor Init');

		// 1. 监听 JS 语法/逻辑错误
		wx.onError((err) => {
			console.log('📹 监控到异常抛出，上报错误：', err.message)
			wx.reportEvent('wxonerror', {
				message: err.message,
				stack: err.stack,
			})
		})


		// 2. 监听 Promise 未捕获异常
		wx.onUnhandledRejection((res) => {
			const reason = res.reason
			const msg = reason?.errMsg ?? reason?.message ?? String(reason ?? 'unknown')
			console.log('📹 监控到异常抛出，上报错误：', msg)
			wx.reportEvent('rejecterror', {
				error: msg
			})
		})

		// 3. 监听页面不存在
		wx.onPageNotFound((res) => {

		})

		// 4. 监听内存告警
		uni.onMemoryWarning((res) => {

		})
	}
};

export default monitor;