import dayjs from "dayjs";
import CryptoJS from 'crypto-js';
import config from "@/config.js"
import {RECOMMEND_TYPE} from "@/constants/common.js"
import {showLoading as globalShowLoading, hideLoading as globalHideLoading} from './loading'

export default {
    /**
     * @method 弹窗提示
     * @desc 显示只有「确定」按钮的模态弹窗，可选回调
     * @param message 弹窗内容
     * @param func 点击确定后的回调函数
     */
    alert: function (message, func) {
        uni.showModal({
            showCancel: false,
            content: message,
            success(res) {
                if (res.confirm) {
                    if (func) {
                        func()
                    }
                }
            }
        })
    },

    /**
     * @method 判断分页数据是否可以追加
     * @desc 通过对比上一页最后一条与新一页第一条的 key 值，判断是否有重复数据
     * @param pageData 已有分页数据
     * @param newPageData 新一页数据
     * @param key 用于对比的唯一字段
     * @returns 是否可追加
     */
    checkLoadMoreData: function (pageData, newPageData, key) {
        let preLastItem = {}
        let newFirstItem = {}
        if (pageData.length > 0) {
            preLastItem = pageData[pageData.length - 1]
        }
        if (newPageData.length > 0) {
            newFirstItem = newPageData[0]
        }
        if (preLastItem[key] === newFirstItem[key]) {
            return false
        }
        return true
    },

    /**
     * @method 检测小程序版本更新
     * @desc 检测当前小程序是否为最新版本，提示用户下载或更新
     */
    checkUpdateVersion: function () {
        let updateManager = uni.getUpdateManager();
        if (!updateManager) {
            return;
        }
        if (uni.canIUse("getUpdateManager")) {
            updateManager.onCheckForUpdate(function (res) {
                if (res.hasUpdate) {
                    updateManager.onUpdateReady(function () {
                        uni.showModal({
                            title: "更新提示",
                            content: "已有新的版本，点击确定升级",
                            showCancel: false,
                            success: function (res) {
                                if (res.confirm) {
                                    updateManager.applyUpdate();
                                }
                            },
                        });
                    });
                    updateManager.onUpdateFailed(function () {
                        uni.showModal({
                            title: "更新提示",
                            content: "自动升级失败，请您删除当前小程序，重新d打开小程序升级新版本。",
                        });
                    });
                }
            });
        } else {
            uni.showModal({
                title: "溫馨提示",
                content: "当前微信版本过低，部分功能无法使用，请升级到最新微信版本后重试。",
            });
        }
    },

    /**
     * @method 复制内容到剪切板
     * @desc 将内容写入系统剪切板，可自定义提示
     * @param content 要复制的内容
     * @param alertTips 自定义提示文案，传空则使用系统默认提示
     */
    copyClipboard(content, alertTips = '') {
        uni.setClipboardData({
            data: content,
            showToast: alertTips ? false : true,
        })
    },

    /**
     * @method 拨打电话
     * @desc 调用 uni.makePhoneCall 拨号；空号时 toast 提示，传空字符串 emptyTip 则静默
     * @param phone 电话号码
     * @param emptyTip 空号提示文案，默认「尚未设置客服电话」；传空字符串则不提示
     */
    makePhoneCall(phone, emptyTip = '尚未设置客服电话') {
        if (phone === undefined || phone === null || String(phone).trim() === '') {
            if (emptyTip) {
                this.toast(emptyTip)
            }
            return
        }
        uni.makePhoneCall({
            phoneNumber: String(phone),
        })
    },

    /**
     * @method 函数防抖
     * @desc 短时间内多次触发同一事件，只执行最后一次，或者只执行最开始的一次，中间的不执行
     * @param func 目标函数
     * @param wait 延迟执行毫秒数
     * @param immediate true - 立即执行，false - 延迟执行
     */
    debounce: function (func, wait = 1000, immediate = true) {
        let timer;
        return function () {
            let context = this,
                args = arguments;
            if (timer) clearTimeout(timer);
            if (immediate) {
                let callNow = !timer;
                timer = setTimeout(() => {
                    timer = null;
                }, wait);
                if (callNow) func.apply(context, args);
            } else {
                timer = setTimeout(() => {
                    func.apply(context, args);
                }, wait)
            }
        }
    },

    /**
     * @method 格式化百分比
     * @desc 将小数转为百分比，保留一位小数，末位为 0 则不保留
     * @param n 小数（如 0.856 → 85.6%）
     * @returns 格式化后的百分比数字字符串
     */
    formatPercent: function (n) {
        let num = Math.floor((n * 100) * 10) / 10
        let str = num.toString()
        return str.replace(/\.0$/, '')
    },

    formatRichText(html) {
        let newContent = html.replace(/<img[^>]*>/gi, function (match, capture) {
            match = match.replace(/style="[^"]+"/gi, '').replace(/style='[^']+'/gi, '');
            match = match.replace(/width="[^"]+"/gi, '').replace(/width='[^']+'/gi, '');
            match = match.replace(/height="[^"]+"/gi, '').replace(/height='[^']+'/gi, '');
            return match;
        });
        newContent = newContent.replace(/style="[^"]+"/gi, function (match, capture) {
            match = match.replace(/width:[^;]+;/gi, 'max-width:100%;').replace(/width:[^;]+;/gi,
                'max-width:100%;');
            return match;
        });
        newContent = newContent.replace(/\<p/gi, '<p class="line"');
        newContent = newContent.replace(/\<h1/gi, '<h1 class="h1"');
        newContent = newContent.replace(/\<h2/gi, '<h2 class="h2"');
        newContent = newContent.replace(/\<h3/gi, '<h3 class="h3"');
        newContent = newContent.replace(/\<strong/gi, '<strong class="strong"');
        newContent = newContent.replace(/<br[^>]*\/>/gi, '');
        newContent = newContent.replace(/<p[^>]*\/>/gi, '');
        newContent = newContent.replace(/\<img/gi, '<img style="max-width:100%" class="img"');
        return newContent;
    },

    /**
     * @method 数字分隔符格式化
     * @desc 将数字每 4 位插入指定分隔符
     * @param num 待格式化的数字
     * @param separator 分隔符
     * @returns 格式化后的字符串
     */
    formatSeparator: function (num, separator) {
        const numStr = num.toString();
        return numStr.replace(/(\d{4})(?=\d)/g, `$1${separator}`);
    },

    /**
     * @method 获取设备信息
     * @desc 返回设备 ID、型号、品牌、平台、系统版本、微信版本等
     * @returns 设备信息对象
     */
    getDeviceInfo: function () {
        let info = uni.getDeviceInfo()
        let appInfo = uni.getAppBaseInfo()
        return {
            deviceId: info.deviceId, // 设备 ID，由 uni-app 框架生成并存储，清空 Storage 会导致改变
            deviceModel: info.deviceModel, // 设备型号
            deviceType: info.deviceType, // 设备类型 phone、pad、pc
            deviceBrand: info.deviceBrand, // 设备品牌，如 apple、huawei、Redmi
            platform: info.platform, // android / ios / harmonyos
            os: info.system, // 操作系统及版本
            sdkVersion: appInfo.SDKVersion, // 客户端基础库版本
            wechatVersion: appInfo.version, // 微信版本号
        }
    },

    /**
     * @method 获取图片信息
     * @desc 通过 uni.getImageInfo 获取图片的类型、宽高、路径
     * @param tempFilePath 图片临时路径
     * @returns 图片信息对象 { type, height, width, path }
     */
    async getImgInfo(tempFilePath) {
        try {
            let image = await new Promise((resolve, reject) => {
                uni.getImageInfo({
                    src: tempFilePath,
                    success(res) {
                        let imgInfo = {
                            type: res.type,
                            height: res.height,
                            width: res.width,
                            path: res.path
                        }
                        resolve(imgInfo)
                    },
                    fail(err) {
                        reject(err)
                    }
                })
            })
            return image
        } catch (err) {
            console.log('检测图片信息报错：', err)
        }
    },

    /**
     * @method 获取导航栏高度
     * @desc 通过胶囊按钮位置计算自定义导航栏的总高度
     * @returns 导航栏高度（px）
     */
    getNavBarHeight: function () {
        const menuButtonInfo = wx.getMenuButtonBoundingClientRect();
        const capsuleTop = menuButtonInfo.top;
        const capsuleHeight = menuButtonInfo.height;
        let systemInfo = uni.getWindowInfo()
        return capsuleTop + capsuleHeight + (capsuleTop - systemInfo.statusBarHeight)
    },

    /**
     * @method 日期转时间戳
     * @desc 将日期字符串转为 Unix 时间戳（秒）
     * @param dateStr 日期字符串
     * @returns Unix 时间戳
     */
    getUnixTime: function (dateStr) {
        return dayjs(dateStr).unix()
    },

    /**
     * @method 隐藏加载提示
     * @desc 隐藏全局 Loading
     */
    hideLoading: function () {
        globalHideLoading()
    },

    /**
     * @method 判断值是否在数组中
     * @desc 遍历数组，判断目标值是否存在
     * @param t 目标值
     * @param arr 待查找的数组
     * @returns 是否存在
     */
    inArray: function (t, arr) {
        for (let i in arr) {
            if (arr[i] === t) {
                return true
            }
        }
        return false
    },

    /**
     * @method 判断对象是否为空
     * @desc 遍历对象属性，无任何属性则返回 true
     * @param obj 待判断的对象
     * @returns 是否为空对象
     */
    isEmptyObject: function (obj) {
        for (var key in obj) {
            return false;
        }
        return true;
    },

    /**
     * @method 判断是否为纯数字
     * @desc 通过正则校验值是否全为数字
     * @param val 待校验的值
     * @returns 是否为纯数字
     */
    isNumeric(val) {
        return /^\d+$/.test(val)
    },

    /**
     * @method 打开企业微信客服
     * @desc 调用 wx.openCustomerServiceChat 打开客服聊天
     */
    openCustomerService: function () {
        const self = this;
        wx.openCustomerServiceChat({
            extInfo: {url: config.customerService.url},
            corpId: config.customerService.appId,
            success(res) {

            },
            fail(err) {
                console.log('客服打开失败：', err)
                self.toast('客服打开失败，请稍后再试')
            }
        })
    },

    /**
     * @method 生成随机数
     * @desc 生成从 minNum 到 maxNum 的随机整数
     * @param minNum 最小值（传一个参数时为最大值）
     * @param maxNum 最大值
     * @returns 随机整数
     */
    randomNum(minNum, maxNum) {
        switch (arguments.length) {
            case 1:
                return parseInt(Math.random() * minNum + 1, 10);
            case 2:
                return parseInt(Math.random() * (maxNum - minNum + 1) + minNum, 10);
            default:
                return 0;
        }
    },

    /**
     * @method 显示加载提示
     * @desc 显示全局 Loading 遮罩，默认文案「加载中」
     * @param msg 加载提示文案
     */
    showLoading(msg) {
        globalShowLoading(msg || '加载中')
    },

    /**
     * @method 接口签名
     * @desc 将参数按 key 排序拼接，首尾加 secret，MD5 生成签名
     * @param params 请求参数对象
     * @param secret 签名密钥
     * @param timestamp 时间戳
     * @returns MD5 签名字符串
     */
    signParam: function (params, secret, timestamp) {
        const keys = Object.keys(params).sort()
        let paramStr = secret
        keys.forEach(k => {
            let value = params[k]
            let type = typeof value
            if (type === 'string' || type === 'boolean' || type === 'number') {
                paramStr += k + value
            }
        })
        paramStr += timestamp
        paramStr += secret
        let sign = CryptoJS.MD5(paramStr).toString()
        return sign
    },

    /**
     * @method 函数节流
     * @desc 连续触发事件，但在 n 秒内只执行一次函数，会稀释函数的执行频率
     * @param func 目标函数
     * @param wait 延迟执行毫秒数
     * @param type 1 - 在时间段开始的时候触发，2 - 在时间段结束的时候触发
     */
    throttle: function (func, wait = 1000, type = 1) {
        let previous = 0;
        let timeout;
        return function () {
            let context = this;
            let args = arguments;
            if (type === 1) {
                let now = Date.now();
                if (now - previous > wait) {
                    func.apply(context, args);
                    previous = now;
                }
            } else if (type === 2) {
                if (!timeout) {
                    timeout = setTimeout(() => {
                        timeout = null;
                        func.apply(context, args)
                    }, wait)
                }
            }
        }
    },

    /**
     * @method 轻提示
     * @desc 显示 Toast 提示，延迟 100ms 确保 Loading 彻底消失后再显示
     * @param title 提示文案
     */
    toast: function (title) {
        setTimeout(() => {
            wx.showToast({
                title: title,
                icon: 'none',
                duration: 2000
            });
        }, 100);
    },

    /**
     * @method 验证手机号
     * @desc 校验手机号是否为 11 位，不合法时弹出 Toast 提示
     * @param mobile 手机号
     * @returns 是否合法
     */
    validateMobile(mobile) {
        let validateMobile = mobile + ''
        console.log('mobile:', mobile, '   validateMobile:', validateMobile, ' -- :', validateMobile.length)
        if (this.isEmptyObject(validateMobile) || validateMobile.length == 0) {
            this.toast('请输入手机号码')
            return false
        }
        if (validateMobile.length != 11) {
            this.toast('请输入正确手机号码')
            return false
        }
        return true
    },
    /**
     * @method 打开推荐位链接
     * @param item 推荐位数据
     * @param item.recommendType 推荐位类型
     * @param item.url 推荐位链接
     * **/
    openPosition(item){
        if (!item.url) return
        if (item.recommendType === RECOMMEND_TYPE.VIDEO_CHANNEL) {//视频号
            wx.openChannelsActivity({
                finderUserName: 'sphRmlgGSY5YIIu',
                feedId: item.url,//视频号 视频ID
                success(res) {
                    console.log('打开视频号成功',)
                },
                fail(err) {
                    console.log('打开视频号失败', err)
                    utils.toast('打开视频号失败:' + err.errMsg)
                },
                complete(res) {
                    console.log('打开视频号结束', res)
                }
            })
        } else if (item.recommendType === RECOMMEND_TYPE.OFFICIAL_ACCOUNT) {//公众号链接
            uni.navigateTo({url: '/pages_assist/help/article?url=' + encodeURIComponent(item.url) + '&title=' + encodeURIComponent(item.title || '')})
        } else if (item.recommendType === RECOMMEND_TYPE.MINI_PROGRAM_PAGE) {//小程序内页面路径
            uni.navigateTo({url: item.url})
        }
    }
}
