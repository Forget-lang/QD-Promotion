/** 全局 Loading 引用计数，request 与 utils 共用，避免互相 hide 掉对方的 loading */
let loadingCount = 0
let loadingTimer = null

export function showLoading(title = '加载中...') {
    if (loadingCount === 0) {
        loadingTimer = setTimeout(() => {
            uni.showLoading({title, mask: true})
        }, 300)
    }
    loadingCount++
}

export function hideLoading() {
    loadingCount--
    if (loadingCount <= 0) {
        loadingCount = 0
        if (loadingTimer) {
            clearTimeout(loadingTimer)
            loadingTimer = null
        }
        uni.hideLoading()
    }
}
