<template>
    <m-result v-if="showSuccess" type="success" title="注销成功" description="个人账号已成功注销"
              confirmText="返回" @confirm="onSuccessBack"></m-result>
    <template v-else>
        <view class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="h4">注销须知：</view>
                <view class="mt-1 text-small">1. 注销后，
                    <text class="text-danger">账号相关数据将被清除且无法恢复</text>
                    ，请谨慎操作！
                </view>
                <view class="mt-1 text-small">2. 注销后将无法使用该账号登录，卡包内优惠券、券包、次卡等将无法继续使用。
                </view>
                <view class="mt-1 text-small">3. 若您已加入商家门店，请先联系商家管理员退出所有门店后再注销。</view>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card">
            <t-textarea label="注销原因" v-model:value="reason" placeholder="请填写注销原因" maxlength="200"/>
        </t-cell-group>

        <view class="mt-3">
            <t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless icon="circle"
                        relation-key="-1" custom-style="background-color: transparent;">
                <template #label>
                    <view class="agreement">
                        我已阅读并知晓注销个人账号的风险，确认要注销账号及所有数据。
                    </view>
                </template>
            </t-checkbox>
        </view>

        <m-submit :loading="loading" :disabled="loading || !allowAgreement" @click="onSubmit">确认注销</m-submit>
    </template>
</template>

<script setup>
import {ref} from 'vue'
import request from '@/hooks/request'
import {useSessionStore} from '@/stores/session'
import {useLink} from '@/hooks/useLink'
import utils from '@/utils/utils'

const sessionStore = useSessionStore()
const {reLaunch} = useLink()
const allowAgreement = ref(false)
const loading = ref(false)
const showSuccess = ref(false)
const reason = ref('')

const onSubmit = () => {
    if (!reason.value.trim()) {
        utils.toast('请填写注销原因')
        return
    }
    uni.showModal({
        title: '确认注销',
        content: '注销后账号数据将被清除且无法恢复，确认要注销吗？',
        confirmColor: '#E3302D',
        success(res) {
            if (!res.confirm) return
            loading.value = true
            request.post('/user/user/delete', {reason: reason.value.trim()}).then(() => {
                sessionStore.logout()
                showSuccess.value = true
            }).catch(err => {
                utils.toast(err.message || '注销失败')
            }).finally(() => {
                loading.value = false
            })
        }
    })
}

const onSuccessBack = () => {
    reLaunch('/pages/index/index')
}
</script>
