<template>
    <t-cell-group t-class="mt-2" theme="card">
        <get-user-info @success="onUpdateUserInfo">
            <t-cell arrow title="修改个人信息" hover></t-cell>
        </get-user-info>
        <t-cell arrow title="增加订阅次数" hover @click="onSubscribeMessage"></t-cell>
        <t-cell arrow title="我的反馈" hover url="/pages_user/feedback/list"></t-cell>
    </t-cell-group>
    <t-cell-group t-class="mt-2" theme="card">
        <t-cell arrow title="退出登录" hover @click="onShowSheet"></t-cell>
    </t-cell-group>
    <t-cell-group t-class="mt-2" theme="card">
        <t-cell arrow title="注销账号" hover url="/pages_user/setting/cancel"></t-cell>
    </t-cell-group>

    <m-footer :system-id="3"></m-footer>

    <!-- 订阅消息引导 -->
    <m-subscribe-message-guide v-model:visible="showSubscribeGuide"/>

    <t-action-sheet ref="sheetRef" @selected="onSheetAction"></t-action-sheet>
</template>

<script setup>
import {ref} from 'vue'
import request from '@/hooks/request'
import {useSessionStore} from '@/stores/session'
import utils from '@/utils/utils'
import config from '@/config'
import {useAuth} from '@/hooks/useAuth'
import {ActionSheetPlugin, ActionSheetTheme} from '@/uni_modules/tdesign-uniapp/components/index';
import MFooter from '@/components/m/m-footer/m-footer.vue'

const {logout} = useAuth()
const sessionStore = useSessionStore()
const showSubscribeGuide = ref(false)

// 修改个人信息：授权后更新头像昵称
const onUpdateUserInfo = (e) => {
    const nickname = e.detail?.userInfo?.nickName
    const avatar = e.detail?.userInfo?.avatarUrl
    if (!nickname || !avatar) {
        utils.toast('获取用户信息失败')
        return
    }
    request.post('/user/user/update', {nickname, avatar}).then(() => {
        sessionStore.setAccount({nickname, avatar})
        utils.toast('修改成功')
    })
}

// 增加订阅次数
const onSubscribeMessage = utils.debounce(async () => {
    const tmplIds = config.subscribeMessage.couponReceive
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds,
        success(result) {
            utils.hideLoading()
            const hasReject = tmplIds.some(id => result[id] === 'reject')
            if (hasReject) {
                showSubscribeGuide.value = true
            } else {
                utils.toast('订阅成功')
            }
        },
        fail() {
            utils.hideLoading()
            showSubscribeGuide.value = true
        }
    })
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const settings = res.subscriptionsSetting || {}
            const allAccepted = tmplIds.every(id => settings[id] === 'accept')
            if (!allAccepted) {
                showSubscribeGuide.value = true
            }
        },
    })
})

const onShowSheet = () => {
    ActionSheetPlugin.show({
        theme: ActionSheetTheme.List,
        selector: '#sheetRef',
        context: this,
        description: '退出登录会清除您的登录信息，确认退出吗？',
        items: [
            {
                label: '退出登录',
                color: '#E3302D',
            },
        ],
    })
}

const onSheetAction = (e) => {
    if (e.index === 0) {
        logout()
    }
}
</script>
