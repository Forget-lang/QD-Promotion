<template>
    <m-loading v-if="data === undefined"/>
    <m-empty v-else-if="!data">暂无数据</m-empty>
    <template v-else>
        <view class="container-safety">
            <!-- 磁卡卡面 -->
            <view class="container mt-2">
                <m-card-magnetic-face
                    :theme="Number(data.card.theme) || 1"
                    :merchant-name="merchant.name"
                    :cover="data.card.cover"
                    :title="data.card.name"
                    :card-type="data.card.cardType"
                    :total-times="data.receive.totalTimes"
                    :remain-times="data.receive.remainCount"
                    :valid-label="data.receive.validLabel"
                    :status="data.receive.status"
                    :status-label="data.receive.statusLabel"
                />
            </view>

            <!-- 次卡内容 -->
            <view class="container mt-2">
                <view class="section pb-3">
                    <view class="section-header">
                        <view class="section-title">次卡内容</view>
                        <view class="benefit-badge" v-if="data.card.cardType === CARD_TYPE.BENEFIT">
                            {{ data.card.items.length }} 项权益
                        </view>
                    </view>
                    <view class="card-benefit-body" v-if="data.card.cardType === CARD_TYPE.BENEFIT">
                        <m-card-benefit-list
                            :items="data.card.items"
                            :theme="data.card.theme"
                            :show-status="false"
                        />
                    </view>
                    <view class="card-benefit-body" v-else>
                        <view class="benefit-content">
                            <view class="benefit-content-text">{{ data.card.benefitContent }}</view>
                        </view>
                    </view>
                </view>
            </view>

            <!-- 适用门店 -->
            <view class="container mt-2">
                <view class="section">
                    <view class="section-header">
                        <view class="section-title">适用门店</view>
                    </view>
                    <m-card-stores :card-id="cardId" v-model:stores="stores" theme="list"/>
                </view>
            </view>

            <!-- 使用须知 -->
            <view class="container mt-2">
                <view class="section">
                    <view class="section-header">
                        <view class="section-title">使用须知</view>
                    </view>

                    <view class="explain-row" v-if="data.card.userLimit">
                        <text class="explain-label">领取限制：</text>
                        <text class="explain-value">每人限领{{ data.card.userLimit }}张</text>
                    </view>

                    <view class="usage-info" v-if="data.card.isVerifyInterval || data.card.isTransfer || data.card.content || data.card.productImages?.length > 0">
                        <view class="explain-row" v-if="data.card.isVerifyInterval">
                            <text class="explain-label">使用间隔：</text>
                            <text class="explain-value">{{
                                    Number(data.card.verifyIntervalDay) === 0 ? '每天可使用 1 次' : ('间隔 ' + data.card.verifyIntervalDay + ' 天可使用 1 次')
                                }}</text>
                        </view>

                        <view class="explain-row" v-if="data.card.isTransfer">
                            <text class="explain-label">支持转赠：</text>
                            <text class="explain-value">领后支持转赠送给好友使用</text>
                        </view>

                        <view class="explain-row" v-if="data.card.content">
                            <view class="explain-label">使用说明：</view>
                            <text class="explain-value">{{data.card.content}}</text>
                        </view>
                    </view>

                    <!-- 说明图片 -->
                    <view class="product-images" v-if="data.card.productImages?.length">
                        <image
                            v-for="(img, index) in data.card.productImages"
                            :key="index"
                            class="product-image"
                            :src="img"
                            mode="widthFix"
                        />
                    </view>
                </view>
            </view>
            <m-footer></m-footer>

            <!-- 底部留出安全区域的距离 -->
            <view style="height: 60rpx;"></view>
        </view>

        <view class="notice-floating" v-if="data.transfer && !data.transfer.isValid">
            <t-notice-bar :content="data.transfer.invalidReason" theme="error" :prefix-icon="true"/>
        </view>

        <!-- 底部操作栏 -->
        <view class="card-footer" :style="{ '--theme-color': themeColor }">
            <view class="p-3">
                <view class="card-receive-button primary" v-if="data.transfer.isValid" @click="onSubscribeMessage">
                    领取次卡
                </view>
            </view>
        </view>

        <!-- 领取前完善信息弹窗 -->
        <m-coupon-receive-profile
            v-model:visible="showProfile"
            :merchant="merchant"
            :profile-option="profileOption"
            :on-receive="onReceiveCard"
        />

    </template>

    <!-- 订阅消息提示动图 -->
    <view class="subscribe-gif-wrap" v-if="showSubscribeGif" @click="showSubscribeGif = false">
        <image class="subscribe-gif" src="https://cdn.lenmy.com/quandao/img/subscribe_message.gif" mode="widthFix"/>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import {CARD_TYPE} from '@/constants/card'
import utils from '@/utils/utils'
import config from '@/config'
import {getTheme} from '@/utils/theme.js'
import {useSessionStore} from '@/stores/session'

const session = useSessionStore()

const shareKey = ref('')
const data = ref()
const cardId = ref()
const stores = ref([])
const merchant = ref({})

const showProfile = ref(false)
const showSubscribeGif = ref(false)
const profileOption = ref({
    isGetMobile: false,
    registerType: 1
})

// 主题色
const themeColor = computed(() => getTheme(data.value?.card?.theme).color)

const getDetail = () => {
    request.get('/card/transfer', {shareKey: shareKey.value}, {showLoading: false}).then(res => {
        // 数据类型安全处理
        res.data.card.productImages = Array.isArray(res.data.card.productImages) ? res.data.card.productImages : []
        data.value = res.data
        merchant.value = res.data.merchant
        cardId.value = res.data.card.id
        // 根据商家设置项配置授权登录
        profileOption.value = {
            isGetMobile: res.data.card.isGetMobile,
            registerType: res.data.merchant.registerType || 1
        }
    }).catch(() => {
        data.value = null
    })
}

// 检查领券订阅消息是否会弹出订阅弹框
const willShowSubscribePopup = () => {
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const itemSettings = res.subscriptionsSetting
            const hasUndecided = config.subscribeMessage.couponReceive.some(
                tmplId => itemSettings[tmplId] !== 'accept' && itemSettings[tmplId] !== 'reject'
            )
            showSubscribeGif.value = hasUndecided
        },
        fail() {
            // 静默失败
        }
    })
}

// 点击领取按钮订阅消息
const onSubscribeMessage = utils.debounce(async () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        },
        fail() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        }
    })
    willShowSubscribePopup()
})

// 领取次卡请求
const onReceiveCard = (profileData) => {
    return new Promise((resolve, reject) => {
        const randomDelay = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        const params = {
            shareKey: shareKey.value,
            mobile: profileData.mobile,
            scene: session.appletScene,
            os: session.getDeviceInfo('os'),
            device: session.getDeviceInfo('device')
        }
        request.post('/user/card/transfer/receive', params, {
            showLoading: true,
            disableErrorToast: true,
        }).then((res) => {
            data.value.transfer.isValid = false
            data.value.transfer.invalidReason = '已领取'
            setTimeout(() => resolve(res), randomDelay)
        }).catch((err) => {
            setTimeout(() => reject(err), randomDelay)
        })
    })
}

onLoad((e) => {
    shareKey.value = e.shareKey || ''
    if (shareKey.value) getDetail()

    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true,
    })
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

</script>

<style scoped>
/* ===== 次数统计 ===== */
.summary-card {
    background: #fff;
    border-radius: 20rpx;
    padding: 32rpx;
}

.summary-metrics {
    display: flex;
    align-items: center;
    justify-content: space-around;
}

.metric-item {
    text-align: center;
}

.metric-num {
    font-size: 44rpx;
    font-weight: 700;
}

.metric-used {
    color: #e84c59;
}

.metric-remain {
    color: #07c160;
}

.metric-label {
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #999;
}

.metric-divider {
    width: 1rpx;
    height: 60rpx;
    background: #eee;
}

/* ===== 次卡内容 ===== */
.benefit-badge {
    font-size: 22rpx;
    color: var(--theme-color);
    padding: 6rpx 18rpx;
    background: #f5f5f5;
    border-radius: 20rpx;
    font-weight: 500;
}

.benefit-content {
    padding: 24rpx 0;
}

.benefit-content-text {
    font-size: 28rpx;
    color: #1a1a1a;
    line-height: 44rpx;
    white-space: pre-line;
}

.card-benefit-body {
    padding: 0 32rpx;
}

/* ===== 使用说明区块===== */
.usage-info {
    padding: 0 32rpx 32rpx;
}

.explain-row {
    font-size: 28rpx;
    margin-top: 20rpx;
}

.explain-label {
    margin-bottom: 16rpx;
    color: #78797f;
}
.explain-value{
    line-height: 50rpx;
}

/* 说明图片 */
.product-images {
    background: #fff;
}

.product-image {
    display: block;
    width: 100%;
}

/* 浮动通知 — 定位于底部操作栏上方，z-index 须高于 card-footer */
.notice-floating {
    position: fixed;
    bottom: calc(170rpx + constant(safe-area-inset-bottom));
    bottom: calc(170rpx + env(safe-area-inset-bottom));
    left: 0;
    right: 0;
    z-index: 101;
    padding: 0 24rpx;
    background: transparent;
    transition: all 0.3s ease;
}

/* ===== 底部操作栏 ===== */
.card-footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 100;
    background: #fff !important;
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
    box-shadow: 0 -2rpx 16rpx rgba(0, 0, 0, 0.06);
}

.card-receive-button {
    display: block;
    text-align: center;
    padding: 30rpx 48rpx;
    border-radius: 44rpx;
    font-size: 30rpx;
    font-weight: 500;
    transition: all 0.2s ease;
}

.card-receive-button.primary {
    background: var(--theme-color);
    color: #fff;
    border: none;
}

.card-receive-button.primary:active {
    opacity: 0.85;
}

.card-receive-button.disable {
    background: #f7f7f7;
    color: #ccc;
    border: none;
}

/* ===== 订阅消息动图 ===== */
.subscribe-gif-wrap {
    position: fixed;
    top: 25vh;
    right: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.subscribe-gif {
    width: 600rpx;
    border-radius: 16rpx;
}
</style>
