<template>
    <t-tabs
        v-model:value="currentTab"
        bottom-line-mode="auto"
        :custom-style="tabsThemeBlack"
        @change="onTabChange"
    >
        <t-tab-panel label="有效中" :value="1"></t-tab-panel>
        <t-tab-panel label="已失效" :value="2"></t-tab-panel>
    </t-tabs>

    <view class="container mt-2 pb-4">
        <m-loading v-if="items === undefined"/>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">{{ currentTab === 1 ? '暂无可用次卡' : '暂无失效次卡' }}</m-empty>
            <template v-else>
                <view
                    v-for="item in items"
                    :key="item.id"
                    class="mb-2"
                    @tap="goDetail(item.id)"
                >
                    <m-card-magnetic-face
                        :theme="Number(item.theme) || 1"
                        :merchant-name="item.merchantName"
                        :cover="item.cover"
                        :title="item.cardName"
                        :card-type="item.cardType"
                        :total-times="item.totalTimes"
                        :remain-times="currentTab === 2 ? null : item.remainCount"
                        :valid-label="item.validLabel"
                        :status="item.status"
                        :status-label="item.statusLabel"
                    />
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onShow, onReachBottom, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import {tabsThemeBlack} from "@/utils/theme";
import utils from '@/utils/utils'
import to from '@/hooks/to'

const {push} = useLink()
// 当前商家（从卡包首页带入）
const merchantId = ref('')
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: 1,
    merchantId: undefined,
})
// 当前 Tab：1 可用 2 失效
const currentTab = ref(1)
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取次卡列表数据
const getItems = () => {
    if (!merchantId.value) return
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/user/card/receive/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 切换 Tab 筛选
const onTabChange = (e) => {
    currentTab.value = e.value
    search.value.status = e.value
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 跳转次卡详情
const goDetail = (id) => {
    push('/pages_user/card/detail?id=' + id)
}

onLoad((e) => {
    if (!e.merchantId) {
        utils.toast('缺少商家')
        return
    }
    merchantId.value = e.merchantId
    search.value.merchantId = e.merchantId
    currentTab.value = to.Int(e.status) || 1
    search.value.status = currentTab.value
})

onShow(() => {
    if (!merchantId.value) return
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>

</style>
