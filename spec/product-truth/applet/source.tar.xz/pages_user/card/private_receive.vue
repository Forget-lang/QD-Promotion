<template>
    <m-loading v-if="card === undefined"></m-loading>
    <m-empty :height="800" v-else-if="!card">暂无数据</m-empty>

    <template v-else>
        <view class="container-safety">
            <!-- 磁卡卡面 -->
            <view class="container mt-2">
                <m-card-magnetic-face
                    :theme="card.theme"
                    :merchant-name="merchant?.name"
                    :cover="card.cover"
                    :title="card.name"
                    :card-type="card.cardType"
                    :total-times="card.totalTimes"
                    :valid-label="card.validLabel"
                    :status="card.status"
                    :status-label="card.statusLabel"
                />
            </view>

            <!-- 次卡内容 -->
            <view class="container mt-2">
                <view class="section pb-3">
                    <view class="section-header">
                        <view class="section-title">次卡内容</view>
                        <view class="benefit-badge" v-if="card.cardType === CARD_TYPE.BENEFIT">{{ card.items.length }}
                            项权益
                        </view>
                    </view>
                    <!-- 权益卡：次卡权益项 -->
                    <view class="card-benefit-body" v-if="card.cardType === CARD_TYPE.BENEFIT">
                        <m-card-benefit-list
                            :items="card.items"
                            :theme="card.theme"
                            :show-status="false"
                        />
                    </view>
                    <!-- 通卡/次卡：文本优惠内容 -->
                    <view class="card-benefit-body" v-else>
                        <view class="benefit-content">
                            <view class="benefit-content-text">{{ card.benefitContent }}</view>
                        </view>
                    </view>
                </view>
            </view>

            <!-- 适用门店 -->
            <view class="container mt-2">
                <view class="section">
                    <view class="section-header">
                        <view class="section-title">适用门店</view>
                    </view>
                    <m-card-stores :card-id="cardId" v-model:stores="stores" theme="list"/>
                </view>
            </view>

            <!-- 使用须知 -->
            <view class="container mt-2"
                  v-if="card.userLimit || card.isOnlyNewCustomer || card.isVerifyInterval || card.isTransfer || card.content || card.productImages?.length > 0">
                <view class="section">
                    <view class="section-header">
                        <view class="section-title">使用须知</view>
                    </view>
                    <view class="usage-info">
                        <!-- 每人限领 -->
                        <view class="explain-row" v-if="card.userLimit">
                            <text class="explain-label">领取限制：</text>
                            <text class="explain-value">每人限领{{ card.userLimit }}张</text>
                        </view>

                        <view class="explain-row" v-if="card.isOnlyNewCustomer">
                            <text class="explain-label">领取对象：</text>
                            <text class="explain-value">仅新客户可领</text>
                        </view>

                        <view class="explain-row" v-if="card.isVerifyInterval">
                            <text class="explain-label">使用间隔：</text>
                            <text class="explain-value">{{
                                    Number(card.verifyIntervalDay) === 0 ? '每天可使用 1 次' : ('间隔 ' + card.verifyIntervalDay + ' 天可使用 1 次')
                                }}</text>
                        </view>

                        <view class="explain-row" v-if="card.isTransfer">
                            <text class="explain-label">支持转赠：</text>
                            <text class="explain-value">领后支持转赠送给好友使用</text>
                        </view>

                        <view class="explain-row" v-if="card.content">
                            <view class="explain-label">使用说明：</view>
                            <text class="explain-value">{{card.content}}</text>
                        </view>
                    </view>

                    <!-- 说明图片 -->
                    <view class="product-images" v-if="card.productImages?.length > 0">
                        <image
                            v-for="(img, index) in card.productImages"
                            :key="index"
                            class="product-image"
                            :src="img"
                            mode="widthFix"
                        />
                    </view>
                </view>
            </view>
            <m-footer></m-footer>

            <!-- 底部留出安全区域的距离 -->
            <view style="height: 60rpx;"></view>
        </view>

        <!-- 底部操作栏 -->
        <view class="card-footer" :style="themeStyle">
            <view class="p-3">
                <view class="card-receive-button disable" v-if="isReceiveEnded">领取已超时</view>
                <view class="card-receive-button primary" v-else-if="issue.status === ISSUE_PRIVATE_STATUS.RECEIVED"
                      @click="reLaunch('/pages/index/index')">查看已领的卡券
                </view>
                <view class="button-receive disable" v-else-if="issue.status === ISSUE_PRIVATE_STATUS.EXPIRED">领取已超时</view>
                <view class="card-receive-button disable" v-else-if="card.status === CARD_STATUS.PAUSED">活动已停止</view>
                <view class="card-receive-button disable" v-else-if="card.status === CARD_STATUS.DISCARDED">次卡已作废</view>
                <view class="card-receive-button disable" v-else-if="card.status === CARD_STATUS.EXPIRED">活动已结束</view>
                <view class="card-receive-button disable" v-else-if="card.remainStock <= 0">已抢光</view>
                <view class="card-receive-button primary" @click="onSubscribeMessage" v-else>
                    {{ card.cardType === CARD_TYPE.UNLIMITED ? '领取次卡' : `领取次卡 · ${card.totalTimes} 次` }}
                </view>
            </view>
            <!-- 领取倒计时 -->
            <view v-if="issue.status === ISSUE_PRIVATE_STATUS.VALID && endCountdown > 0"
                  class="card-footer-remark">
                <t-count-down
                    :custom-style="{fontSize:'28rpx',fontWeight:'500'}"
                    :time="endCountdown * 1000"
                    :format="endCountdownFormat"
                    :split-with-unit="endCountdownHasDays"
                    content="default" theme="square"
                    @finish="onEndCountDownFinish"
                />
                <text class="card-footer-remark-text">后领取链接失效，请尽快领取</text>
            </view>
        </view>
    </template>

    <!-- 领取前授权登录弹窗 -->
    <m-coupon-receive-profile v-model:visible="showProfile" :merchant="merchant" :profile-option="profileOption" :on-receive="onReceiveCard" />

    <!-- 订阅消息提示动图 -->
    <view class="subscribe-gif-wrap" v-if="showSubscribeGif" @click="showSubscribeGif = false">
        <image class="subscribe-gif" src="https://cdn.lenmy.com/quandao/img/subscribe_message.gif" mode="widthFix" />
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import {CARD_STATUS, CARD_TYPE, ISSUE_PRIVATE_STATUS} from '@/constants/card'
import utils from '@/utils/utils'
import config from '@/config'
import {useLink} from '@/hooks/useLink.js'
import {getThemeStyle, getTheme} from '@/utils/theme.js'
import {useSessionStore} from "@/stores/session"

const {reLaunch, push} = useLink()
const session = useSessionStore()

const endCountdown = ref(0)
const isReceiveEnded = ref(false)
const showProfile = ref(false)
const profileOption = ref({
    isGetMobile: false,
    registerType: 1
})
const showSubscribeGif = ref(false)

const cardId = ref()
const cardIssueId = ref()
const inviterId = ref()
const card = ref()
const merchant = ref()
const issue = ref({})
const stores = ref([])

// 主题色
const themeStyle = computed(() => getThemeStyle(card.value?.theme))
const themeColor = computed(() => getTheme(card.value?.theme).color)
// 领取倒计时是否超过 24 小时
const endCountdownHasDays = computed(() => endCountdown.value >= 86400)
// 领取倒计时格式（超过 24 小时显示天数）
const endCountdownFormat = computed(() => endCountdownHasDays.value ? 'DD:HH:mm:ss' : 'HH:mm:ss')

const initCountdown = () => {
    if (issue.value.expireMinute > 0 && issue.value.status === ISSUE_PRIVATE_STATUS.VALID && card.value.status === CARD_STATUS.ISSUING) {
        endCountdown.value = issue.value.expireCountdownTime ?? 0
        isReceiveEnded.value = endCountdown.value <= 0
    }
}

const goMerchant = () => {
    if (!merchant.value?.id) return
    push('/pages_user/merchant/home?merchantId=' + merchant.value.id)
}

const onEndCountDownFinish = () => {
    endCountdown.value = 0
    isReceiveEnded.value = true
}

const getDetail = () => {
    request.get('/card/private/issue/detail', {
        cardId: cardId.value,
        cardIssueId: cardIssueId.value,
    }, {showLoading: false}).then(res => {
        //数据类型安全处理
        res.data.card.productImages = Array.isArray(res.data.card.productImages) ? res.data.card.productImages : []
        cardId.value = res.data.card.id
        card.value = res.data.card
        merchant.value = res.data.merchant
        issue.value = res.data.issue
        // 根据商家设置项配置授权登录
        profileOption.value = {
            isGetMobile: card.value.isGetMobile,
            registerType: merchant.value.registerType
        }
        initCountdown()
    }).catch(() => {
        card.value = null
        merchant.value = null
    })
}

// 检查领券订阅消息是否会弹出订阅弹框
const willShowSubscribePopup = () => {
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const itemSettings = res.subscriptionsSetting
            const hasUndecided = config.subscribeMessage.couponReceive.some(
                tmplId => itemSettings[tmplId] !== 'accept' && itemSettings[tmplId] !== 'reject'
            )
            showSubscribeGif.value = hasUndecided
        },
        fail() {
            // 静默失败
        }
    })
}

// 点击领取按钮订阅消息
const onSubscribeMessage = utils.debounce(async () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        },
        fail() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        }
    })
    willShowSubscribePopup()
})

// 领取次卡请求
const onReceiveCard = (profileData) => {
    return new Promise((resolve, reject) => {
        const randomDelay = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        const params = {
            merchantId: merchant.value.id,
            cardId: cardId.value,
            cardIssueId: cardIssueId.value,
            inviterId: inviterId.value || null,
            mobile: profileData.mobile,
            scene: session.appletScene,
            os: session.getDeviceInfo('os'),
            device: session.getDeviceInfo('device')
        }
        request.post('/user/card/private/receive', params, {
            showLoading: true,
            disableErrorToast: true,
        }).then((res) => {
            issue.value.status = ISSUE_PRIVATE_STATUS.RECEIVED
            endCountdown.value = 0
            isReceiveEnded.value = false
            setTimeout(() => resolve(res), randomDelay)
        }).catch((err) => {
            setTimeout(() => reject(err), randomDelay)
        })
    })
}

onLoad((e) => {
    if (e.i) cardIssueId.value = e.i
    if (e.inviterId) inviterId.value = e.inviterId
    if (e.scene) cardIssueId.value = decodeURIComponent(e.scene)

    if (cardIssueId.value) {
        getDetail()
    } else {
        // 缺少发放 ID，直接展示无数据态，避免长期加载中
        card.value = null
    }

    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true,
    })
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

</script>

<style scoped>

/* ===== 次卡内容 ===== */
.benefit-badge {
    font-size: 22rpx;
    color: var(--theme-color);
    padding: 6rpx 18rpx;
    background: #f5f5f5;
    border-radius: 20rpx;
    font-weight: 500;
}

.card-benefit-body {
    padding: 0 32rpx;
}

.benefit-content {
    padding: 24rpx 0;
}

.benefit-content-text {
    font-size: 28rpx;
    color: #1a1a1a;
    line-height: 44rpx;
    white-space: pre-line;
}

/* ===== 使用说明区块===== */
.usage-info {
    padding: 0 32rpx 32rpx;
}

.explain-row {
    font-size: 28rpx;
    margin-top: 20rpx;
}

.explain-label {
    margin-bottom: 16rpx;
    color: #78797f;
}
.explain-value{
    line-height: 50rpx;
}

/* 说明图片 */
.product-images {

}

.product-image {
    display: block;
    width: 100%;
}

/* ===== 底部操作栏 ===== */
.card-footer {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 100;
    background: #fff !important;
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
    box-shadow: 0 -2rpx 16rpx rgba(0, 0, 0, 0.06);
}

.card-receive-button {
    display: block;
    text-align: center;
    padding: 30rpx 48rpx;
    border-radius: 44rpx;
    font-size: 30rpx;
    font-weight: 500;
    transition: all 0.2s ease;
}

.card-receive-button.primary {
    background: var(--theme-color);
    color: #fff;
    border: none;
}

.card-receive-button.primary:active {
    opacity: 0.85;
}

.card-receive-button.disable {
    background: #f7f7f7;
    color: #ccc;
    border: none;
}

.card-footer-remark {
    text-align: center;
    padding: 8rpx 24rpx 16rpx;
    font-size: 24rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4rpx 0;
}

.card-footer-remark-text {
    color: #999;
}

/* 订阅消息动图 */
.subscribe-gif-wrap {
    position: fixed;
    top: 25vh;
    right: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.subscribe-gif {
    width: 600rpx;
    border-radius: 16rpx;
}
</style>
