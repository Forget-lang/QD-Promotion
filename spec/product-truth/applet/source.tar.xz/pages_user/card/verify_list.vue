<template>
    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"/>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无使用记录</m-empty>
            <template v-else>
                <view class="record-item" v-for="item in items" :key="item.id">
                    <view class="record-head">
                        <text class="record-title">第 {{ item.useSort }} 次</text>
                        <t-tag
                            :theme="item.status === VERIFY_STATUS.SUCCESS ? 'success' : 'danger'"
                            variant="light" size="small">
                            {{ item.statusLabel }}
                        </t-tag>
                    </view>
                    <view class="record-sub" v-if="item.benefitLabel">{{ item.benefitLabel }}</view>
                    <view class="record-meta">
                        <view>核销门店：{{ item.verifyStoreName || '-' }}</view>
                        <view>核销时间：{{ item.verifiedAt }}</view>
                        <view v-if="item.status === VERIFY_STATUS.DISCARD && item.verifyRemark">
                            作废原因：{{ item.verifyRemark }}
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {VERIFY_STATUS} from '@/constants/card'
import to from '@/hooks/to'

// 次卡领取记录 ID
const id = ref('')
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
})
// 核销明细列表
const items = ref()
// 列表总数
const total = ref(0)
// 是否已加载完
const isCompleted = ref(false)
// 是否正在加载更多
const loadingMore = ref(false)

// 获取核销明细
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/user/card/receive/verify/list', {
        ...search.value,
        cardReceiveId: id.value,
    }).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

onLoad((e) => {
    if (e.id) {
        id.value = e.id
        getItems()
    } else {
        items.value = null
    }
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.record-item {
    background: #fff;
    border-radius: 16rpx;
    padding: 28rpx;
    margin-bottom: 20rpx;
}

.record-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.record-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
}

.record-sub {
    margin-top: 8rpx;
    font-size: 28rpx;
    color: #333;
    line-height: 42rpx;
}

.record-meta {
    margin-top: 12rpx;
    line-height: 40rpx;
}
</style>
