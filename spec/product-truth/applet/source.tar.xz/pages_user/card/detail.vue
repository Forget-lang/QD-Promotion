<template>
    <m-result v-if="errMessage !== ''"
              type="danger"
              :title="errMessage"
              back
    >
    </m-result>
    <m-loading v-else-if="detail === undefined"/>
    <m-empty v-else-if="detail === null">次卡不存在</m-empty>

    <view v-else class="card-detail-page mt-2">
        <!-- 磁卡卡面 -->
        <view class="container">
            <m-card-magnetic-face
                :theme="Number(detail.theme) || 1"
                :merchant-name="detail.merchantName"
                :cover="detail.cover"
                :title="detail.cardName"
                :card-type="detail.cardType"
                :total-times="detail.totalTimes"
                :remain-times="detail.remainCount"
                :used-times="detail.verifyCount"
                :valid-label="detail.validLabel"
                :status="detail.status"
                :status-label="detail.statusLabel"
            />
        </view>

        <!-- 广告位 -->
        <view class="section container mt-2" v-if="adUnitCardDetail">
            <ad-custom :unit-id="adUnitCardDetail"></ad-custom>
        </view>

        <!-- 使用方式 -->
        <view class="container mt-2">
            <view class="section">
                <view class="section-header">
                    <view class="section-title">核销码</view>
                </view>
                <view class="usage-body">
                    <!-- 核销码 -->
                    <view class="usage-code mt-2" v-if="detail.status === RECEIVE_STATUS.VALID && !detail.transferLock">
                        <view class="usage-qrcode">
                            <view class="usage-qrcode-wrap">
                                <image v-if="qrcodeUrl" class="usage-qrcode-image" :src="qrcodeUrl" mode="aspectFit"/>
                                <m-loading v-else-if="qrcodeLoading"/>
                            </view>
                            <view class="usage-qrcode-tip text-muted text-small">向店员出示此码完成核销</view>
                        </view>
                    </view>

                    <!-- 卡号 -->
                    <view class="usage-code mt-3">
                        <view class="usage-card-no">
                            <text class="usage-card-no-text">No.{{ utils.formatSeparator(detail.id, ' ') }}</text>
                        </view>
                        <view class="usage-code-actions">
                            <view class="usage-code-action" @click="onCopyCode(detail.id)">
                                <t-icon name="copy" size="32rpx" color="#595959"/>
                                <text class="usage-code-action-text">复制卡号</text>
                            </view>
                            <view class="usage-code-action-divider"></view>
                            <view class="usage-code-action" @click="onContactMerchant">
                                <t-icon name="shop-1" size="32rpx" color="#595959"/>
                                <text class="usage-code-action-text">联系商家</text>
                            </view>
                        </view>

                        <!-- 已用次数（通卡/次卡，点击看使用记录；次数 = 核销 + 作废） -->
                        <view class="usage-count mt-3" v-if="detail.cardType !== CARD_TYPE.BENEFIT"
                              @click="onViewVerifyList">
                            <text class="text-wechat">已用 {{ (detail.verifyCount || 0) + (detail.discardCount || 0) }}
                                次
                            </text>
                            <t-icon name="chevron-right" size="28rpx" color="#576b95" custom-style="margin-left: 4rpx; vertical-align: middle;"/>
                        </view>
                    </view>

                    <!-- 次卡权益项内容（权益卡） -->
                    <view class="mt-5" v-if="detail.cardType === CARD_TYPE.BENEFIT">
                        <m-card-benefit-list
                            :items="detail.items"
                            :theme="detail.theme"
                        />
                    </view>

                    <!-- 转赠中 -->
                    <view v-if="detail.isTransfer && detail.transferLock" class="usage-card-action">
                        <t-button theme="default" size="medium" block disabled custom-style="width: 400rpx">转赠中
                        </t-button>
                        <text class="text-danger mt-1 text-center" @click="onCancelTransfer">取消转赠</text>
                    </view>


                    <!-- 非可用状态 -->
                    <view v-else-if="detail.status !== RECEIVE_STATUS.VALID" class="usage-card-action">
                        <t-button theme="default" size="medium" block disabled custom-style="width: 400rpx">
                            {{ detail.statusLabel }}
                        </t-button>
                    </view>
                </view>

                <!-- 适用门店 -->
                <view class="usage-stores top-line" :class="{ 'pb-3': stores.length === 1, 'bottom-line': (detail.isTransfer && detail.status === RECEIVE_STATUS.VALID) && stores.length === 1 }">
                    <m-card-stores :cardId="detail.cardId" v-model:stores="stores" theme="cell"/>
                </view>
                <!--转赠-->
                <template v-if="detail.isTransfer && detail.status === RECEIVE_STATUS.VALID">
                    <t-cell v-if="!detail.transferLock" title="转赠给好友" arrow :bordered="false" @click="onSubscribeMessage"></t-cell>
                    <t-cell v-else-if="detail.transferLock" title="转赠给好友" note="转赠中，可取消转赠" arrow :bordered="false" @click="onCancelTransfer"></t-cell>
                </template>
            </view>
        </view>

        <!-- 优惠内容（通卡/次卡） -->
        <view class="container mt-2" v-if="detail.cardType !== CARD_TYPE.BENEFIT && detail.benefitContent">
            <view class="section">
                <view class="section-header">
                    <view class="section-title">优惠内容</view>
                </view>
                <view class="benefit-content">
                    <view class="benefit-content-text">{{ detail.benefitContent }}</view>
                </view>
            </view>
        </view>

        <!-- 使用须知-->
        <view class="container mt-2" v-if="detail.isVerifyInterval || detail.isTransfer || detail.content || detail.productImages?.length > 0">
            <view class="section">
                <view class="section-header">
                    <view class="section-title">使用须知</view>
                </view>
                <view class="usage-info">

                    <view class="explain-row" v-if="detail.userLimit">
                        <text class="explain-label">领取限制：</text>
                        <text class="explain-value">每人限领{{ detail.userLimit }}张</text>
                    </view>

                    <!-- 核销时间间隔 -->
                    <view class="explain-row" v-if="detail.isVerifyInterval">
                        <text class="explain-label">使用间隔：</text>
                        <text class="explain-value">{{
                                Number(detail.verifyIntervalDay) === 0 ? '每天可使用 1 次' : ('间隔 ' + detail.verifyIntervalDay + ' 天可使用 1 次')
                            }}
                        </text>
                    </view>
                    <view class="explain-row" v-if="detail.isTransfer">
                        <text class="explain-label">支持转赠：</text>
                        <text class="explain-value">领后支持转赠送给好友使用</text>
                    </view>
                    <!-- 使用说明文字 -->
                    <view class="explain-row" v-if="detail.content">
                        <view class="explain-label">使用说明：</view>
                        <text class="explain-value">{{detail.content}}</text>
                    </view>
                </view>

                <!-- 说明图片 -->
                <view class="product-images" v-if="detail.productImages?.length > 0">
                    <image
                        v-for="(img, index) in detail.productImages"
                        :key="index"
                        class="product-image"
                        :src="img"
                        mode="widthFix"
                    />
                </view>
            </view>
        </view>

        <!-- 底部 -->
        <m-footer></m-footer>
    </view>

    <!-- 转赠弹窗 -->
    <t-popup placement="bottom" v-model:visible="showTransfer" :z-index="99999">
        <view class="card-detail-popup" style="width: 100%">
            <view class="popup-header">
                <view class="popup-header-title">转赠给好友</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="24px" @click="showTransfer = false"/>
                </view>
            </view>
            <view class="popup-transfer-body">
                <t-textarea v-if="!transferShareKey"
                    custom-style="height: 300rpx; margin-bottom: 32rpx;background-color: #f7f7f7;border-radius: 12rpx;"
                    label="转赠备注" v-model:value="transferRemark" :maxlength="32" :cursor-spacing="120" :indicator="true"
                    placeholder="请输入转赠备注"></t-textarea>
                <!-- 转赠成功态：图标 + 标题 + 提示，填充与输入态一致的固定高度 -->
                <view v-else class="transfer-success">
                    <t-icon name="check-circle-filled" size="80rpx" color="#07C160"/>
                    <view class="transfer-success-title">转赠设置成功</view>
                    <view class="transfer-success-tip">好友领取前可多次分享，仅首位领取好友可获得本次卡</view>
                </view>
            </view>
            <view class="popup-bottom-action">
                <t-button v-if="!transferShareKey" theme="primary" size="large" block @click="onLockTransfer">确认转赠
                </t-button>
                <t-button v-else theme="primary" size="large" block open-type="share" @click="onTransferShare">
                    <view class="d-flex align-items-center">
                        <t-icon t-class="mr-1" name="share-1" size="20px"/>
                        分享给微信好友
                    </view>
                </t-button>
            </view>
            <view class="text-muted mt-1 text-center" @click="showTransfer = false">取消</view>
        </view>
    </t-popup>
</template>

<script setup>
import {onLoad, onShow, onHide, onPullDownRefresh, onShareAppMessage, onShareTimeline} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request'
import {CARD_TYPE, RECEIVE_STATUS} from '@/constants/card'
import utils from '@/utils/utils'
import config from '@/config'
import {getTheme} from '@/utils/theme'

// 次卡领取记录 ID
const id = ref('')
// 次卡详情
const detail = ref()
// 适用门店
const stores = ref([])
// 核销码
const qrcodeUrl = ref('')
const qrcodeLoading = ref(false)
// 转赠
const showTransfer = ref(false)
const transferRemark = ref('')
const transferShareKey = ref('')
const errMessage = ref('')

// 主题色
const themeColor = computed(() => {
    return getTheme(Number(detail.value?.theme) || 1).color
})

// 次卡详情页广告位 unit-id
const adUnitCardDetail = computed(() => {
    if (config.adUnit?.cardDetail && detail.value?.allowAd) {
        return config.adUnit?.cardDetail
    }
    return ''
})

// 查看该次卡的全部核销明细
const onViewVerifyList = () => {
    if (!detail.value?.id) return
    uni.navigateTo({url: '/pages_user/card/verify_list?id=' + detail.value.id})
}

//复制卡券编号
const onCopyCode = (code) => {
    uni.setClipboardData({
        data: code,
        showToast: false,
        success: function() {
            utils.toast('卡号已复制到剪切板')
        },
        fail: () => {

        }
    });
}

//联系商家：拨打电话联系商家
const onContactMerchant = () => {
    utils.makePhoneCall(detail.value.servicePhone)
}

// 自动加载核销码
const loadQrcode = () => {
    qrcodeUrl.value = ''
    qrcodeLoading.value = true
    request.get('/user/card/receive/verify-qrcode', {
        id: id.value
    }, {
        disableErrorToast: true
    }).then(res => {
        qrcodeUrl.value = res.data.qrcode || ''
    }).catch((err) => {
        errMessage.value = err.message || ''
    }).finally(() => {
        qrcodeLoading.value = false
    })
}

// 转赠前订阅消息
const onSubscribeMessage = () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showTransfer.value = true
        },
        fail() {
            utils.hideLoading()
            showTransfer.value = true
        }
    })
}

// 锁定转赠
const onLockTransfer = utils.debounce(() => {
    request.post('/user/card/receive/lock-transfer', {
        cardReceiveId: id.value,
        remark: transferRemark.value
    }, {showLoading: true}).then(res => {
        transferShareKey.value = res.data.shareKey
        detail.value.transferLock = true
    }).catch(() => {
    })
})

// 分享转赠
const onTransferShare = () => {
    showTransfer.value = false
}

// 取消转赠
const onCancelTransfer = () => {
    uni.showModal({
        title: '提示',
        content: '确定取消转赠吗？',
        success: (res) => {
            if (!res.confirm) return
            request.post('/user/card/receive/unlock-transfer', {
                cardReceiveId: id.value
            }, {
                disableErrorToast: true
            }).then(() => {
                detail.value.transferLock = false
                transferShareKey.value = ''
                utils.toast('已取消转赠')
                loadQrcode()
            }).catch((err) => {
                errMessage.value = err.message || ''
            })
        }
    })
}

// 获取次卡详情
const getDetail = () => {
    request.get('/user/card/receive/detail', {id: id.value}).then(res => {
        //数据类型安全处理
        res.data.productImages = Array.isArray(res.data.productImages) ? res.data.productImages : []
        detail.value = res.data
        // 可用时自动加载核销码
        if (res.data.status === RECEIVE_STATUS.VALID && !res.data.transferLock) {
            loadQrcode()
        }
    }).catch(() => {
        detail.value = null
    })
}

onLoad((e) => {
    if (e.id) {
        id.value = e.id
        getDetail()
    }
    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true,
    })
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

// 截图监听：截屏时立即刷新核销码，防止截屏盗用
const onScreenCapture = () => {
    if (detail.value?.status === RECEIVE_STATUS.VALID && !detail.value?.transferLock) {
        loadQrcode()
    }
}

onShow(() => {
    uni.onUserCaptureScreen(onScreenCapture)
})

onHide(() => {
    uni.offUserCaptureScreen(onScreenCapture)
})

onShareAppMessage(() => ({
    title: transferRemark.value || `送你一张次卡：${detail.value?.cardName || ''}`,
    imageUrl: detail.value?.cover || '',
    path: '/pages_user/card/transfer_receive?shareKey=' + transferShareKey.value,
}))

onShareTimeline(() => ({
    title: transferRemark.value || `送你一张次卡：${detail.value?.cardName || ''}`,
    imageUrl: detail.value?.cover || '',
    path: '/pages_user/card/transfer_receive?shareKey=' + transferShareKey.value,
}))

</script>

<style scoped>
.card-detail-page {
    min-height: 100vh;
}

/* 使用方式 */
.usage-body {
    padding: 0 32rpx;
}

/* 使用方式 */
.usage-card-action {
    width: 100%;
    margin-top: 96rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.usage-stores {
    margin-top: 78rpx;
}

.usage-code {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.usage-card-no {
    margin-top: 8rpx;
}

.usage-card-no-text {
    font-size: 34rpx;
    font-weight: 700;
    color: #1a1a1a;
    letter-spacing: 4rpx;
}

.usage-code-actions {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 10rpx;
}

.usage-code-action {
    display: flex;
    align-items: center;
    padding: 12rpx 28rpx;
}

.usage-code-action-text {
    margin-left: 8rpx;
    font-size: 26rpx;
    color: #595959;
}

.usage-code-action-divider {
    width: 1rpx;
    height: 28rpx;
    background: #e7e7e7;
}

/* 已使用次数 */
.usage-count {
    display: flex;
    align-items: center;
    justify-content: center;
}

.usage-qrcode {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.usage-qrcode-wrap {
    width: 360rpx;
    height: 360rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.usage-qrcode-image {
    width: 360rpx;
    height: 360rpx;
}

.usage-qrcode-tip {
    margin-top: 8rpx;
}

.cell-title {
    color: #202020;
    font-size: 30rpx;
    font-weight: 600;
    flex-shrink: 0;
}

.cell-note {
    color: #1c1c1c;
    font-size: 30rpx;
    font-weight: 600;
}

/* 说明图片 */
.product-images {
    background: #fff;
}

.product-image {
    display: block;
    width: 100%;
}

/* 通卡/次卡 文本优惠内容 */
.benefit-content {
    padding: 24rpx 32rpx;
}

.benefit-content-text {
    font-size: 28rpx;
    color: #1a1a1a;
    line-height: 44rpx;
    white-space: pre-line;
}

.benefit-content-count {
    margin-top: 16rpx;
    font-size: 26rpx;
    color: #78797f;
}

/* ===== 使用说明区块===== */
.usage-info {
    padding: 0 32rpx 32rpx;
}

.explain-row {
    font-size: 28rpx;
    margin-top: 20rpx;
}

.explain-label {
    margin-bottom: 16rpx;
    color: #78797f;
}
.explain-value{
    line-height: 50rpx;
}

/* 转赠弹窗 */
.card-detail-popup {
    width: 600rpx;
    background: #fff;
    border-radius: 24rpx;
    padding: 0 32rpx 32rpx;
    box-sizing: border-box;
}

/* 固定高度：textarea 300rpx + 间距 32rpx，切换提示语时保持弹框高度一致 */
.popup-transfer-body {
    height: 332rpx;
}

/* 转赠成功态：居中布局填满与输入态一致的固定高度，避免中部空白 */
.transfer-success {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
}

.transfer-success-title {
    margin-top: 16rpx;
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.transfer-success-tip {
    margin-top: 16rpx;
    font-size: 24rpx;
    color: #999;
    text-align: center;
}

</style>
