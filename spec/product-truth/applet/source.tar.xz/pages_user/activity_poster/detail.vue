<template>
    <m-navigation-bar :scrollY="scrollY" :threshHeight="coverHeight" :hasCover="!!detail">
        <template #title>
            <view class="nav-title" :class="{ scrolled: scrollY >= coverHeight * 0.6 }">
                {{ detail?.name || '活动海报' }}
            </view>
        </template>
    </m-navigation-bar>

    <m-loading v-if="detail === undefined"></m-loading>
    <m-empty :height="800" v-else-if="detail === null">活动不存在或已下架</m-empty>

    <view v-else class="page-body">
        <!-- 封面：通栏无圆角 -->
        <image
            class="cover"
            :src="detail.cover"
            mode="aspectFill"
            :style="{ height: coverHeight + 'px' }"
        />

        <!-- 主题内容区：商家信息 + 优惠券列表 + 活动须知 -->
        <view class="theme-panel container">
            <view class="merchant-panel" v-if="detail.merchant" @click="goMerchant">
                <image class="merchant-panel-logo" :src="detail.merchant.logo" mode="aspectFill"/>
                <view class="merchant-panel-info">
                    <view class="merchant-panel-name-row">
                        <view class="merchant-panel-name text-ellipsis">{{ detail.merchant.name }}</view>
                        <view
                            class="merchant-auth-tag"
                            :class="isMerchantVerified ? 'merchant-auth-tag--verified' : 'merchant-auth-tag--unverified'"
                        >
                            {{ isMerchantVerified ? '已认证' : '未认证' }}
                        </view>
                    </view>
                    <view class="merchant-panel-industry text-ellipsis" v-if="detail.merchant.industry">
                        {{ detail.merchant.industry }}
                    </view>
                </view>
                <t-icon name="chevron-right" size="28rpx" color="#999"/>
            </view>

            <view class="coupon-list mt-2" v-if="detail.coupons?.length">
                <view
                    class="receive mb-2"
                    v-for="item in detail.coupons"
                    :key="item.couponId"
                    @click="onCouponClick(item)"
                >
                    <view class="coupon-top">
                        <view class="coupon-top-type">{{ item.couponTypeLabel }}</view>
                    </view>
                    <view class="coupon-line"></view>
                    <view class="coupon">
                        <view class="coupon-header">
                            <image class="coupon-thumb" :src="item.cover" mode="aspectFill"/>
                        </view>
                        <view class="coupon-body">
                            <view class="coupon-content">
                                <view class="coupon-content-info">
                                    <view class="coupon-content-name text-ellipsis-break">{{ item.couponName }}</view>
                                    <view class="coupon-content-value">
                                        <template v-if="isAmountFace(item.couponType)">
                                            <view class="coupon-content-amount">
                                                <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                <view class="coupon-amount-discount">元券</view>
                                            </view>
                                        </template>
                                        <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                            <view class="coupon-content-amount">
                                                <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                <view class="coupon-amount-discount">折券</view>
                                            </view>
                                        </template>
                                        <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                            <view class="coupon-amount">
                                                <image class="exchange-icon" src="/static/img/exchange.png"
                                                       mode="aspectFit"/>
                                            </view>
                                        </template>
                                        <view class="coupon-threshold">{{ item.threshold }}</view>
                                    </view>
                                    <view class="coupon-content-valid text-ellipsis">{{ item.validLabel }}</view>
                                </view>
                                <view class="coupon-content-action">
                                    <view class="button-gold">领取</view>
                                </view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
            <m-empty v-else>暂无可领优惠券</m-empty>

            <view class="section mt-2" v-if="detail.notice">
                <view class="section-header">
                    <view class="section-title">活动须知</view>
                </view>
                <view class="section-body">
                    <text class="notice">{{ detail.notice }}</text>
                </view>
            </view>
        </view>
    </view>

    <!-- 浮动分享按钮（允许分享时显示） -->
    <view v-if="detail?.isShare" class="share-fab">
        <t-button
            theme="primary"
            shape="circle"
            variant="base"
            size="large"
            open-type="share"
            icon="share-1"
            aria-label="分享活动"
            :custom-style="{ width: '96rpx', padding: '0' }"
        />
    </view>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onPageScroll, onShareAppMessage} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {AUTH_STATUS} from '@/constants/merchant'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink.js'

const {push} = useLink()
const detail = ref()
const activityId = ref('')
const scrollY = ref(0)
const coverHeight = uni.getWindowInfo().screenWidth * 4 / 5

// 商户是否已认证通过
const isMerchantVerified = computed(() => detail.value?.merchant?.authStatus === AUTH_STATUS.SUCCESS)

const loadDetail = () => {
    request.get('/activity-poster/detail', {id: activityId.value}).then(res => {
        detail.value = res.data
        if (detail.value?.isShare) {
            uni.updateShareMenu({
                withShareTicket: false,
                isPrivateMessage: false,
            })
        } else {
            uni.hideShareMenu()
            uni.updateShareMenu({
                withShareTicket: true,
                isPrivateMessage: true,
            })
        }
    }).catch(err => {
        detail.value = null
        utils.toast(err.message || '加载失败')
    })
}

const goMerchant = () => {
    const merchantId = detail.value?.merchant?.id
    if (!merchantId) return
    push('/pages_user/merchant/home?merchantId=' + merchantId)
}

const onCouponClick = (item) => {
    if (!item.appletPath) {
        return utils.toast('领券链接无效')
    }
    push(item.appletPath)
}

onLoad((options) => {
    if (options.scene) {
        activityId.value = decodeURIComponent(options.scene)
    } else if (options.id) {
        activityId.value = options.id
    }
    if (activityId.value) {
        loadDetail()
    } else {
        detail.value = null
    }
})

onPageScroll((e) => {
    if (e.scrollTop < coverHeight + 100) {
        scrollY.value = e.scrollTop
    }
})

onShareAppMessage(() => {
    return {
        title: detail.value?.name || '活动海报',
        imageUrl: detail.value?.cover || '',
        path: '/pages_user/activity_poster/detail?id=' + activityId.value,
    }
})
</script>

<style scoped>
.nav-title {
    max-width: 360rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    font-size: 30rpx;
    font-weight: 600;
    color: #fff;
}

.nav-title.scrolled {
    color: #333;
}

.cover {
    width: 100%;
    display: block;
    background: #f5f5f5;
}

.theme-panel {
    padding-top: 24rpx;
    padding-bottom: 48rpx;
}

.merchant-panel {
    margin-top: -60rpx;
    display: flex;
    align-items: center;
    gap: 16rpx;
    padding: 24rpx;
    background: #fff;
    border-radius: 24rpx;
}

.merchant-panel-logo {
    width: 88rpx;
    height: 88rpx;
    border-radius: 50%;
    flex-shrink: 0;
    background: #f5f5f5;
}

.merchant-panel-info {
    flex: 1;
    min-width: 0;
}

.merchant-panel-name-row {
    display: flex;
    align-items: center;
    gap: 12rpx;
    min-width: 0;
}

.merchant-panel-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    min-width: 0;
}

.merchant-auth-tag {
    flex-shrink: 0;
    padding: 2rpx 10rpx;
    font-size: 20rpx;
    line-height: 1.4;
    border-radius: 999px;
    white-space: nowrap;
}

.merchant-auth-tag--verified {
    color: #1a9f5c;
    background: rgba(26, 159, 92, 0.12);
}

.merchant-auth-tag--unverified {
    color: #999;
    background: #f5f5f5;
}

.merchant-panel-industry {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.notice {
    font-size: 26rpx;
    color: #666;
    line-height: 1.7;
    white-space: pre-wrap;
}

.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.coupon-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 24rpx 32rpx 8rpx;
}

.coupon-top-type {
    font-size: 26rpx;
    font-weight: 600;
    color: #373737;
}

.coupon {
    padding: 10rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon-header {
    margin-right: 24rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
    background: #f5f5f5;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

/*
 * 自定义样式原因：浮动分享按钮需 fixed 定位与圆形阴影，
 * TDesign t-button 不提供外层定位能力，用 view 承载定位与阴影。
 */
.share-fab {
    position: fixed;
    right: 32rpx;
    bottom: calc(48rpx + constant(safe-area-inset-bottom));
    bottom: calc(48rpx + env(safe-area-inset-bottom));
    z-index: 100;
    width: 96rpx;
    height: 96rpx;
    border-radius: 50%;
    box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.2);
}
</style>
