<template>
    <view class="page" :style="pageStyle">
        <!-- 当前积分头部：主题色会员卡同款渐变 -->
        <view class="hero" :style="heroStyle">
            <view class="hero-main">
                <view class="hero-left">
                    <text class="hero-label">当前积分</text>
                    <text class="hero-value">{{ pointBalance }}</text>
                    <text class="hero-slogan">每一次消费 · 都更值得</text>
                </view>
                <image class="hero-cover" :src="heroCover" mode="aspectFill"/>
            </view>
        </view>

        <!-- 明细列表 -->
        <view class="list-section">
            <view class="list-head">
                <text class="list-title">积分明细</text>
                <view class="list-filter" @tap="showFilter = true">
                    <text>{{ filterLabel }}</text>
                    <t-icon name="chevron-down" size="28rpx" :color="themeColor"/>
                </view>
            </view>

            <m-loading v-if="items === undefined && page === 1"></m-loading>
            <m-empty v-else-if="items !== undefined && items.length === 0">暂无积分记录</m-empty>
            <template v-else-if="items">
                <view class="log-card" v-for="item in items" :key="item.id">
                    <view
                        class="log-icon"
                        :class="item.changeValue > 0 ? 'plus' : 'minus'"
                    >
                        <t-icon
                            :name="item.changeValue > 0 ? 'gift' : 'shop'"
                            size="36rpx"
                            :color="item.changeValue > 0 ? '#e2453d' : '#07c160'"
                        />
                    </view>
                    <view class="log-main">
                        <text class="log-name">{{ item.pointTypeName || '积分变动' }}</text>
                        <text v-if="item.customerRemark" class="log-remark">{{ item.customerRemark }}</text>
                        <text v-if="item.storeName" class="log-store">{{ item.storeName }}</text>
                        <text class="log-time">{{ formatTime(item.createdAt) }}</text>
                    </view>
                    <view class="log-right">
                        <text
                            class="log-amount"
                            :class="item.changeValue > 0 ? 'plus' : 'minus'"
                        >
                            {{ item.changeValue > 0 ? '+' : '' }}{{ item.changeValue }}
                        </text>
                        <text class="log-balance">余额 {{ item.balanceAfter }}</text>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <view v-else-if="isCompleted" class="nomore">—— 没有更多了 ——</view>
            </template>
        </view>
    </view>

    <t-action-sheet
        v-model:visible="showFilter"
        :items="filterItems"
        @selected="onFilterSelect"
        @cancel="showFilter = false"
    />
</template>

<script setup>
import {computed, ref, watch} from 'vue'
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import dayjs from 'dayjs'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import to from '@/hooks/to'
import config from '@/config.js'
import {
    applyHomeThemePageChrome,
    defaultHomeTheme,
    getHomeThemeAccent,
    getHomeThemePageStyle,
    getHomeThemeStyle,
} from '@/utils/homeTheme'

const merchantId = ref('')
const merchantCover = ref('')
const homeTheme = ref(defaultHomeTheme)
const pointBalance = ref(0)
const direction = ref(0)
const page = ref(1)
const pageSize = 20
const items = ref()
const isCompleted = ref(false)
const loadingMore = ref(false)
const showFilter = ref(false)

const heroCover = computed(() => merchantCover.value || config.default.cover)
const themeColor = computed(() => getHomeThemeAccent(homeTheme.value))
const heroStyle = computed(() => getHomeThemeStyle(homeTheme.value))
const pageStyle = computed(() => getHomeThemePageStyle(homeTheme.value))

const filterItems = [
    {label: '全部类型', value: 0},
    {label: '奖励', value: 1},
    {label: '消费', value: 2},
]

const filterLabel = computed(() => {
    return filterItems.find(i => i.value === direction.value)?.label || '全部类型'
})

const formatTime = (t) => t ? dayjs(t).format('YYYY-MM-DD HH:mm') : ''

const loadMerchant = () => {
    if (!merchantId.value) return
    request.get('/user/merchant/detail', {id: merchantId.value}).then(res => {
        merchantCover.value = res.data?.cover || ''
        homeTheme.value = Number(res.data?.homeTheme) || defaultHomeTheme
    }).catch(() => {
        merchantCover.value = ''
        homeTheme.value = defaultHomeTheme
    })
}

const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/user/point/log/list', {
        merchantId: merchantId.value,
        direction: direction.value,
        page: page.value,
        pageSize,
    }).then(res => {
        pointBalance.value = res.data.pointBalance || 0
        if (page.value === 1) items.value = []
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(err => {
        utils.toast(err.message)
        if (page.value === 1) items.value = []
    }).finally(() => {
        loadingMore.value = false
        uni.stopPullDownRefresh()
    })
}

const reload = () => {
    page.value = 1
    isCompleted.value = false
    getItems()
}

const onFilterSelect = (e) => {
    const val = e?.selected?.value
    if (val === undefined || val === null) return
    direction.value = Number(val)
    showFilter.value = false
    reload()
}

watch(homeTheme, (theme) => {
    applyHomeThemePageChrome(theme)
}, {immediate: true})

onLoad((e) => {
    if (!e.merchantId) {
        utils.toast('缺少商家')
        return
    }
    merchantId.value = e.merchantId
    loadMerchant()
    getItems()
})

onPullDownRefresh(() => {
    reload()
})

onReachBottom(() => {
    if (isCompleted.value || loadingMore.value) return
    page.value++
    getItems()
})
</script>

<style scoped>
.page {
    min-height: 100vh;
    padding-bottom: 48rpx;
    box-sizing: border-box;
}

.hero {
    margin: 24rpx 24rpx 0;
    padding: 36rpx 32rpx 40rpx;
    border-radius: 24rpx;
    overflow: hidden;
    position: relative;
}

.hero-main {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
}

.hero-left {
    flex: 1;
    min-width: 0;
    padding-right: 16rpx;
}

.hero-label {
    font-size: 26rpx;
    color: rgba(255, 255, 255, 0.78);
}

.hero-value {
    display: block;
    margin-top: 8rpx;
    font-size: 72rpx;
    font-weight: 800;
    color: #fff;
    line-height: 1.05;
    letter-spacing: 1rpx;
}

.hero-avail {
    margin-top: 12rpx;
    display: inline-flex;
    align-items: center;
    gap: 6rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.72);
}

.hero-slogan {
    display: block;
    margin-top: 28rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.55);
    letter-spacing: 2rpx;
}

.hero-cover {
    width: 200rpx;
    height: 134rpx;
    flex-shrink: 0;
    border-radius: 16rpx;
    background: rgba(255, 255, 255, 0.18);
    border: 2rpx solid rgba(255, 255, 255, 0.28);
    align-self: center;
}

.list-section {
    margin-top: 32rpx;
    padding: 0 24rpx;
}

.list-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20rpx;
    padding: 0 4rpx;
}

.list-title {
    font-size: 32rpx;
    font-weight: 700;
    color: #222;
}

.list-filter {
    display: flex;
    align-items: center;
    gap: 4rpx;
    font-size: 24rpx;
    color: #666;
}

.log-card {
    background: #fff;
    border-radius: 20rpx;
    padding: 28rpx 24rpx;
    margin-bottom: 20rpx;
    display: flex;
    align-items: flex-start;
    gap: 20rpx;
}

.log-icon {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.log-icon.plus {
    background: #fdeceb;
}

.log-icon.minus {
    background: #e8f8ef;
}

.log-main {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    gap: 6rpx;
}

.log-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #222;
}

.log-remark {
    font-size: 24rpx;
    color: #666;
    margin-top: 2rpx;
}

.log-store,
.log-time {
    font-size: 22rpx;
    color: #999;
}

.log-right {
    flex-shrink: 0;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    gap: 6rpx;
    padding-top: 4rpx;
}

.log-amount {
    font-size: 36rpx;
    font-weight: 700;
    font-variant-numeric: tabular-nums;
}

.log-amount.plus {
    color: #e2453d;
}

.log-amount.minus {
    color: #07c160;
}

.log-balance {
    font-size: 22rpx;
    color: #999;
}

.nomore {
    padding: 24rpx 0 8rpx;
    text-align: center;
    font-size: 22rpx;
    color: #bbb;
}
</style>
