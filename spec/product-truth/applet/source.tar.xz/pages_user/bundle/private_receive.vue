<template>
    <m-navigation-bar :scrollY="scrollY" :threshHeight="swiperHeight" :hasCover="!!bundle">
        <template #title>
            <view class="merchant-info" v-if="merchant" :class="{ 'scrolled': scrollY >= swiperHeight }"
                  @click="goMerchant">
                <image class="merchant-logo" :src="merchant.logo" mode="aspectFill"/>
                <text class="merchant-name">{{ merchant.name }}</text>
                <t-icon name="chevron-right" size="28rpx" :color="scrollY >= swiperHeight ? '#333' : '#fff'"/>
            </view>
        </template>
    </m-navigation-bar>

    <m-loading v-if="bundle === undefined"></m-loading>
    <m-empty :height="800" v-else-if="!bundle">暂无数据</m-empty>

    <template v-else>
        <view class="container-safety">
            <view class="bundle-cover">
                <image class="cover-image" :src="bundle.cover" mode="aspectFill" :style="{ height: swiperHeight + 'px' }"/>
            </view>

            <view class="container">
                <!-- 商户信息 -->
                <view class="merchant-panel" v-if="merchant" @click="goMerchant">
                    <image class="merchant-panel-logo" :src="merchant.logo" mode="aspectFill"/>
                    <view class="merchant-panel-info">
                        <view class="merchant-panel-name">{{ merchant.name }}</view>
                        <view class="merchant-panel-extra text-ellipsis">
                            {{ merchant.name || merchant.address }}
                        </view>
                    </view>
                    <t-icon name="chevron-right" size="28rpx" color="#999"/>
                </view>
                <!-- /商户信息 -->

                <!-- 券包 -->
                <view class="bundle mt-2" :style="themeStyle">
                    <view class="bundle-title">{{ bundle.name }}</view>
                    <view class="bundle-subtitle">
                        {{ bundle.receiveTypeLabel }} · {{ bundle.itemCount }}张专属优惠券
                    </view>

                    <view class="choose-tip" v-if="bundle.receiveType === BUNDLE_RECEIVE_TYPE.CHOOSE">请选择一种优惠券领取</view>

                    <view class="bundle-body">
                        <!-- 优惠券列表 -->
                        <view class="coupon-list" v-if="bundle.coupons?.length">
                            <view
                                v-for="item in bundle.coupons"
                                :key="item.couponId"
                                class="coupon-item bundle-coupon-ticket"
                                @click="onShowCouponDetail(item)"
                            >
                                <view class="coupon">
                                    <view class="coupon-header">
                                        <image v-if="item.cover" class="coupon-thumb" :src="item.cover"
                                               mode="scaleToFill"/>
                                        <view v-else class="coupon-thumb coupon-thumb-empty">
                                            <text>{{ item.couponTypeLabel }}</text>
                                        </view>
                                    </view>
                                    <view class="coupon-body">
                                        <view class="coupon-content">
                                            <view class="coupon-content-info">
                                                <view class="coupon-content-name text-ellipsis-break">
                                                    {{ item.couponName }}
                                                </view>
                                                <view class="coupon-content-value">
                                                    <template v-if="isAmountFace(item.couponType)">
                                                        <view class="coupon-content-amount text-ellipsis">
                                                            <view class="coupon-amount-money">
                                                                {{ item.couponAmount }}
                                                            </view>
                                                            <view class="coupon-amount-discount">元券</view>
                                                        </view>
                                                    </template>
                                                    <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                                        <view class="coupon-content-amount">
                                                            <view class="coupon-amount-money">
                                                                {{ item.couponAmount }}
                                                            </view>
                                                            <view class="coupon-amount-discount">折券</view>
                                                        </view>
                                                    </template>
                                                    <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                                        <view class="coupon-amount">
                                                            <image class="exchange-icon" src="/static/img/exchange.png"
                                                                   mode="aspectFit"/>
                                                        </view>
                                                    </template>
                                                    <view class="coupon-threshold">{{ item.threshold }}</view>
                                                </view>
                                                <view class="coupon-content-valid text-ellipsis">
                                                    {{ item.validLabel }}
                                                </view>
                                            </view>
                                            <view class="coupon-content-action">
                                                <view class="button-gold">x{{ item.issueCount }}张</view>
                                            </view>
                                        </view>
                                    </view>
                                </view>
                            </view>
                        </view>
                        <!-- /优惠券列表 -->

                        <!-- 券包须知 -->
                        <view class="bundle-content mt-5">
                            <view class="h3">使用须知</view>
                            <!-- 每人限领 -->
                            <view class="bundle-text mt-3" v-if="bundle.userLimit">
                                <text class="bundle-label">领取限制：</text>
                                <text>每人限领{{ bundle.userLimit }}个</text>
                            </view>
                            <view class="bundle-text mt-3" v-if="bundle.isOnlyNewCustomer">
                                <text class="bundle-label">领取对象：</text>
                                <text>仅新客户可领</text>
                            </view>
                            <!-- 使用说明 -->
                            <template v-if="bundle.content">
                                <view class="bundle-text mt-2">
                                    <text class="bundle-label">使用说明：</text>
                                </view>
                                <view class="bundle-text">{{ bundle.content }}</view>
                            </template>
                        </view>
                        <!-- /券包须知 -->
                    </view>
                </view>
                <m-footer></m-footer>

                <!-- 底部留出安全区域的距离 -->
                <view style="height: 60rpx;"></view>
            </view>

            <!-- 券包底部 - 固定在页面底部 -->
            <view class="bundle-footer" :style="themeStyle">
                <view class="p-3">
                    <view class="bundle-receive-button disable" v-if="isReceiveEnded">领取已超时</view>
                    <view class="bundle-receive-button primary" v-else-if="issue.status === ISSUE_PRIVATE_STATUS.RECEIVED"
                          @click="reLaunch('/pages/index/index')">查看已领的卡券
                    </view>
                    <view class="button-receive disable" v-else-if="issue.status === ISSUE_PRIVATE_STATUS.EXPIRED">领取已超时</view>
                    <view class="bundle-receive-button disable" v-else-if="bundle.status === BUNDLE_STATUS.PAUSED">活动已停止
                    </view>
                    <view class="bundle-receive-button disable" v-else-if="bundle.status === BUNDLE_STATUS.DISCARDED">券包已作废
                    </view>
                    <view class="bundle-receive-button disable" v-else-if="bundle.status === BUNDLE_STATUS.EXPIRED">活动已结束
                    </view>
                    <view class="bundle-receive-button disable" v-else-if="bundle.remainStock <= 0">已抢光
                    </view>
                    <view class="bundle-receive-button primary" v-else-if="bundle.receiveType === BUNDLE_RECEIVE_TYPE.ALL"
                          @click="onSubscribeMessage">领取券包 · {{ bundle.itemCount }}张
                    </view>
                    <view class="bundle-receive-button primary" v-else-if="bundle.receiveType === BUNDLE_RECEIVE_TYPE.RANDOM"
                          @click="onSubscribeMessage">领取券包 · 随机一种领取
                    </view>
                    <view class="bundle-receive-button primary" v-else-if="bundle.receiveType === BUNDLE_RECEIVE_TYPE.CHOOSE"
                          @click="onSubscribeMessage">领取券包 · 选择一种领取
                    </view>
                </view>
                <!-- 领取倒计时 -->
                <view v-if="issue.status === ISSUE_PRIVATE_STATUS.VALID && endCountdown > 0" class="bundle-footer-remark">
                    <t-count-down :custom-style="{fontSize:'28rpx',fontWeight:'500'}"
                                  :time="endCountdown * 1000"
                                  :format="endCountdownFormat"
                                  :split-with-unit="endCountdownHasDays"
                                  content="default" theme="square"
                                  @finish="onEndCountDownFinish"/>
                    <text class="bundle-footer-remark-text">后领取链接失效，请尽快领取</text>
                </view>
                <!-- /领取倒计时 -->
            </view>
            <!-- /券包底部 -->
        </view>
    </template>

    <!-- 选择卡券弹框（自选一种时使用） -->
    <t-popup v-model:visible="showCouponSelectPopup" placement="bottom" :round="true">
        <view class="coupon-select-popup popup-container" :style="{ '--theme-color': themeColor }">
            <view class="popup-header">
                <view class="popup-header-title">请选择一种优惠券领取</view>
                <view class="popup-header-close" @click="showCouponSelectPopup = false">
                    <t-icon name="close" size="24px" color="#999"/>
                </view>
            </view>
            <scroll-view scroll-y class="flex-fill coupon-view-scroll-body" :show-scrollbar="false">
                <view class="popup-coupon-list">
                    <view
                        v-for="item in bundle.coupons"
                        :key="item.couponId"
                        class="popup-coupon-item"
                        :class="{ 'is-selected': chosenCouponId === item.couponId }"
                        @click="onCouponItemClick(item.couponId)"
                    >
                        <view class="popup-coupon-cover">
                            <image v-if="item.cover" :src="item.cover" mode="scaleToFill"/>
                            <view v-else class="popup-coupon-cover-empty">
                                <text>{{ item.couponTypeLabel }}</text>
                            </view>
                        </view>
                        <view class="popup-coupon-info">
                            <view class="popup-coupon-name text-ellipsis-break">{{ item.couponName }}</view>
                            <view class="popup-coupon-value">
                                <template v-if="isAmountFace(item.couponType)">
                                    <text class="popup-coupon-amount">{{ item.couponAmount }}</text>
                                    <text class="popup-coupon-unit">元券</text>
                                </template>
                                <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                    <text class="popup-coupon-amount">{{ item.couponAmount }}</text>
                                    <text class="popup-coupon-unit">折券</text>
                                </template>
                                <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                    <image class="popup-exchange-icon" src="/static/img/exchange.png" mode="aspectFit"/>
                                </template>
                                <text class="popup-coupon-threshold">{{ item.threshold }}</text>
                            </view>
                            <view class="popup-coupon-valid text-ellipsis">{{ item.validLabel }}</view>
                        </view>
                        <view class="popup-coupon-check">
                            <t-icon v-if="chosenCouponId === item.couponId" name="check-circle-filled" size="44rpx"
                                    :color="themeColor"/>
                            <view v-else class="popup-coupon-check-empty"/>
                        </view>
                    </view>
                </view>
            </scroll-view>
            <view class="popup-footer">
                <t-button theme="primary" block size="large" :disabled="!chosenCouponId"
                          @click="onConfirmSelectCoupon">确认选择
                </t-button>
            </view>
        </view>
    </t-popup>

    <!-- 优惠券详情弹框 -->
    <t-popup v-model:visible="showCouponDetailPopup" placement="bottom" :round="true">
        <view class="popup-container coupon-select-popup">
            <view class="popup-header">
                <view class="popup-header-title">优惠券详情</view>
                <view class="popup-header-close" @click="showCouponDetailPopup = false">
                    <t-icon name="close" size="24px" color="#999"/>
                </view>
            </view>
            <!-- 加载状态 -->
            <m-loading v-if="selectedCouponData === undefined"></m-loading>
            <!-- 空状态 -->
            <m-empty :height="800" v-else-if="!selectedCouponData">暂无数据</m-empty>
            <scroll-view scroll-y class="flex-fill coupon-view-scroll-body" :show-scrollbar="false" v-else>
                <!-- 封面图 -->
                <view class="coupon-covers">
                    <t-swiper :list="selectedCouponData.coverImages" :height="swiperHeight" :navigation="selectedCouponData.coverImages.length > 1" :autoplay="selectedCouponData.coverImages.length > 1" :loop="selectedCouponData.coverImages.length > 1"/>
                </view>
                <!-- /封面图 -->
                <!-- 快闪框 -->
                <m-coupon-flash :coupon="selectedCouponData" />
                <!-- /快闪框 -->
                <view class="container">
                    <!-- 优惠券卡片 -->
                    <view class="mt-2">
                        <m-coupon-tpl :coupon="selectedCouponData" :receive-count="selectedCouponData.publicIssueCount" />
                    </view>
                    <!-- / 优惠券卡片 -->

                    <!-- 详情 -->
                    <m-coupon-usage :coupon="selectedCouponData" />

                    <!-- 适用门店列表 -->
                    <view class="section mt-2">
                        <view class="section-header">
                            <view class="section-title">适用门店</view>
                        </view>
                        <m-usage-stores :stores="selectedCouponStores"/>
                    </view>
                </view>
            </scroll-view>
        </view>
    </t-popup>

    <!-- 领券前完善信息弹窗 -->
    <m-coupon-receive-profile v-model:visible="showProfile" :merchant="merchant" :profile-option="profileOption" :on-receive="onReceiveCoupon" />
    <!-- 订阅消息提示动图 -->
    <view class="subscribe-gif-wrap" v-if="showSubscribeGif" @click="showSubscribeGif = false">
        <image class="subscribe-gif" src="https://cdn.lenmy.com/quandao/img/subscribe_message.gif" mode="widthFix" />
    </view>
</template>


<script setup>
import {onLoad, onPullDownRefresh, onPageScroll} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {BUNDLE_STATUS, BUNDLE_RECEIVE_TYPE, ISSUE_PRIVATE_STATUS} from '@/constants/bundle'
import utils from '@/utils/utils'
import config from '@/config'
import {useLink} from '@/hooks/useLink.js'
import {getThemeStyle, getTheme} from '@/utils/theme.js'
import {useSessionStore} from '@/stores/session'

const {reLaunch, push} = useLink()
const session = useSessionStore()

// 页面滚动距离（导航栏渐变用）
const scrollY = ref(0)
// 封面区域高度
const swiperHeight = uni.getWindowInfo().screenWidth * 4 / 5

// 领取倒计时剩余秒数
const endCountdown = ref(0)
// 领取是否已超时
const isReceiveEnded = ref(false)

const bundleId = ref()
const bundleIssueId = ref()
const inviterId = ref()
// 券包详情
const bundle = ref()
// 商户信息
const merchant = ref()
// 私密发放记录
const issue = ref({})
// 自选玩法的优惠券 ID
const chosenCouponId = ref()
// 选择卡券弹框（自选一种玩法时使用）
const showCouponSelectPopup = ref(false)
// 完善信息弹框
const showProfile = ref(false)
// 完善信息配置
const profileOption = ref({
    isGetMobile: false,
    registerType: 1
})
// 订阅消息动图
const showSubscribeGif = ref(false)
// 优惠券详情弹框
const showCouponDetailPopup = ref(false)
const selectedCouponData = ref(undefined)
const selectedCouponStores = ref([])


// 券包区域主题样式（背景色 + CSS 变量）
const themeStyle = computed(() => getThemeStyle(bundle.value?.theme))
const themeColor = computed(() => getTheme(bundle.value?.theme).color)
// 领取倒计时是否超过 24 小时
const endCountdownHasDays = computed(() => endCountdown.value >= 86400)
// 领取倒计时格式（超过 24 小时显示天数）
const endCountdownFormat = computed(() => endCountdownHasDays.value ? 'DD:HH:mm:ss' : 'HH:mm:ss')


// 初始化倒计时
const initCountdown = () => {
    if (issue.value.expireMinute > 0 && issue.value.status === ISSUE_PRIVATE_STATUS.VALID && bundle.value.status === BUNDLE_STATUS.ISSUING) {
        endCountdown.value = issue.value.expireCountdownTime ?? 0
        isReceiveEnded.value = endCountdown.value <= 0
    }
}

// 跳转 merchant 首页
const goMerchant = () => {
    if (!merchant.value?.id) return
    push('/pages_user/merchant/home?merchantId=' + merchant.value.id)
}

// 结束倒计时结束
const onEndCountDownFinish = () => {
    isReceiveEnded.value = true
}

// 检查领券订阅消息是否会弹出订阅弹框
const willShowSubscribePopup = () => {
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const itemSettings = res.subscriptionsSetting
            const hasUndecided = config.subscribeMessage.couponReceive.some(
                tmplId => itemSettings[tmplId] !== 'accept' && itemSettings[tmplId] !== 'reject'
            )
            showSubscribeGif.value = hasUndecided
        },
        fail() {
            // 静默失败
        }
    })
}

// 点击领券按钮 - 订阅消息
const onSubscribeMessage = utils.debounce(async () => {
    // 自选一种玩法时，先弹出选择卡券弹框
    if (bundle.value.receiveType === BUNDLE_RECEIVE_TYPE.CHOOSE) {
        chosenCouponId.value = ''
        showCouponSelectPopup.value = true
        return
    }
    // 非自选玩法直接进入订阅消息流程
    doSubscribeMessage()
}, 800)

// 执行订阅消息流程
const doSubscribeMessage = () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        },
        fail() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        }
    })
    willShowSubscribePopup()
}

// 确认选择卡券后，进入订阅消息流程
const onConfirmSelectCoupon = () => {
    if (!chosenCouponId.value) return
    showCouponSelectPopup.value = false
    doSubscribeMessage()
}

// 点击卡券项选中
const onCouponItemClick = (couponId) => {
    chosenCouponId.value = couponId
}

// 显示优惠券详情弹框
const onShowCouponDetail = (item) => {
    getCouponView(item)
    getCouponStores(item)
    showCouponDetailPopup.value = true
}

const getCouponView = (coupon) => {
    request.get('/coupon/detail', {
        couponId: coupon.couponId,
        merchantId: merchant.value.id
    }).then(res => {
        selectedCouponData.value = res.data.coupon
    }).catch(err => {
        selectedCouponData.value = null
    })
}

const getCouponStores = (coupon) => {
    request.get('/coupon/stores', {
        couponId: coupon.couponId
    }).then(res => {
        selectedCouponStores.value = res.data.items
    }).catch(err => {
        selectedCouponStores.value = []
    })
}

// 领取券包请求
const onReceiveCoupon = (profileData) => {
    return new Promise((resolve, reject) => {
        const randomDelay = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        const params = {
            merchantId: merchant.value.id,
            bundleId: bundleId.value,
            bundleIssueId: bundleIssueId.value,
            chosenCouponId: chosenCouponId.value || null,
            mobile: profileData?.mobile,
            inviterId: inviterId.value || null,
            scene: session.appletScene, // 小程序场景值
            os: session.getDeviceInfo('os'),
            device: session.getDeviceInfo('device')

        }
        request.post('/user/bundle/private/receive', params, {
            disableErrorToast: true
        }).then(res => {
            issue.value.status = ISSUE_PRIVATE_STATUS.RECEIVED
            endCountdown.value = 0
            isReceiveEnded.value = false
            setTimeout(() => resolve(res), randomDelay)
        }).catch(err => {
            setTimeout(() => reject(err), randomDelay)
        })
    })
}

// 获取券包详情
const getDetail = () => {
    request.get('/bundle/private/issue/detail', {
        bundleIssueId: bundleIssueId.value,
    }, {showLoading: false}).then(res => {
        bundleId.value = res.data.bundle.id
        bundle.value = res.data.bundle
        merchant.value = res.data.merchant
        issue.value = res.data.issue
        initCountdown()
        // 获取领券信息设置项
        profileOption.value = {
            isGetMobile: res.data.bundle.isGetMobile,
            registerType: res.data.merchant.registerType
        }
    }).catch(() => {
        bundle.value = null
        merchant.value = null
    })
}

onLoad((e) => {
    if (e.i) bundleIssueId.value = e.i
    if (e.inviterId) inviterId.value = e.inviterId
    if (e.scene) bundleIssueId.value = e.scene

    if (bundleIssueId.value) {
        getDetail()
    } else {
        // 缺少发放 ID，直接展示无数据态，避免长期加载中
        bundle.value = null
    }

    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true,
    })
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

// 监听页面滚动
onPageScroll((e) => {
    if (e.scrollTop < 360) {
        scrollY.value = e.scrollTop
    }
})

</script>

<style scoped>

.bundle-container {
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
}

/* ===== 商户信息 - 导航栏滚动过渡 ===== */
.merchant-info {
    display: flex;
    align-items: center;
    gap: 8rpx;
    color: #fff;
    padding: 8rpx 16rpx;
    border-radius: 32rpx;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    margin: 0 10rpx;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
}

.merchant-info.scrolled {
    background: rgba(255, 255, 255, 0.95);
    color: #333;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.1);
    transform: scale(0.96);
}

.merchant-logo {
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.merchant-info.scrolled .merchant-logo {
    transform: scale(0.9);
}

.merchant-name {
    font-size: 28rpx;
    font-weight: 500;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    transition: font-weight 0.3s ease;
}

.merchant-info.scrolled .merchant-name {
    font-weight: 600;
}

.bundle-cover {
    width: 100%;
    overflow: hidden;
}

.cover-image {
    width: 100%;
}

.merchant-panel {
    position: relative;
    z-index: 2;
    margin-top: -60rpx;
    background: #fff;
    display: flex;
    align-items: center;
    gap: 16rpx;
    padding: 32rpx 32rpx;
    border-radius: 24rpx;
    box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.08);
}

.merchant-panel-info {
    flex: 1;
    min-width: 0;
}

.merchant-panel-extra {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.merchant-panel-logo {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    flex-shrink: 0;
}

.merchant-panel-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.bundle {
    padding: 32rpx;
    border-radius: 24rpx;
    position: relative;
}

.bundle-title {
    font-size: 36rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.4;
}

.bundle-subtitle {
    margin-top: 12rpx;
    font-size: 26rpx;
    color: rgba(255, 255, 255, 0.85);
}

.choose-tip {
    margin-top: 24rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.75);
}

.bundle-body {

}

.coupon-list {
    margin-top: 24rpx;
}

.coupon-item {
    position: relative;
    margin-bottom: 20rpx;
    border-radius: 24rpx;
    background: #fff;
    overflow: visible;
}

.coupon-item-selected {
    box-shadow: 0 0 0 4rpx #ffd666;
}

/* 券包领取页：两侧凹槽（无虚线） */
.bundle-coupon-ticket::before,
.bundle-coupon-ticket::after {
    content: '';
    position: absolute;
    top: 50%;
    width: 24rpx;
    height: 24rpx;
    border-radius: 50%;
    transform: translateY(-50%);
    z-index: 1;
    pointer-events: none;
    background: var(--theme-color);
}

.bundle-coupon-ticket::before {
    left: -12rpx;
}

.bundle-coupon-ticket::after {
    right: -12rpx;
}

.bundle .coupon {
    padding: 32rpx;
    display: flex;
    align-items: center;
}

.bundle .coupon-header {
    margin-right: 30rpx;
}

.bundle .coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
    background: #f5f5f5;
}

.bundle .coupon-thumb-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 12rpx;
    font-size: 22rpx;
    color: #07c160;
    text-align: center;
    box-sizing: border-box;
}

.bundle .coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.bundle .coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.bundle .coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.bundle .coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #1a1a1a;
}

.bundle .coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.bundle .coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.bundle .coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.bundle .coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.bundle .coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.bundle .exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.bundle .coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.bundle .coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

.bundle-content .h3 {
    font-size: 32rpx;
    font-weight: 600;
    color: rgba(255, 255, 255, 0.68);
}

.bundle-text {
    font-size: 28rpx;
    line-height: 2;
    color: rgba(255, 255, 255, 0.68);
    white-space: pre-wrap;
}

.bundle-label {
    color: rgba(255, 255, 255, 0.85);
    font-weight: 500;
}

/* ===== 底部操作栏 - 简约风格 ===== */
.bundle-footer {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 100;
    /* 保持白色背景，覆盖 themeStyle 的主题色背景 */
    background: #fff !important;
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
    box-shadow: 0 -2rpx 16rpx rgba(0, 0, 0, 0.06);
}

.bundle-receive-button {
    display: block;
    text-align: center;
    padding: 30rpx 48rpx;
    border-radius: 44rpx;
    font-size: 30rpx;
    font-weight: 500;
    transition: all 0.2s ease;
}

/* 主按钮 - 主题色填充风格 */
.bundle-receive-button.primary {
    background: var(--theme-color);
    color: #fff;
    border: none;
}

.bundle-receive-button.primary:active {
    opacity: 0.85;
}

/* 禁用按钮 - 浅灰色 */
.bundle-receive-button.disable {
    background: #f7f7f7;
    color: #ccc;
    border: none;
}

.bundle-footer-remark {
    text-align: center;
    padding: 8rpx 24rpx 16rpx;
    font-size: 24rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 4rpx 0;
}

.bundle-footer-remark-text {
    color: #999;
}

/* ===== 选择卡券弹框 ===== */
.coupon-select-popup {
    display: flex;
    flex-direction: column;
    height: 85vh;
}

.popup-coupon-list {
    flex: 1;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    padding: 8rpx 24rpx 16rpx;
}

.popup-coupon-item {
    display: flex;
    align-items: center;
    margin-bottom: 16rpx;
    padding: 24rpx;
    background: #fff;
    border-radius: 20rpx;
    border: 2rpx solid transparent;
    transition: all 0.2s ease;
}

.popup-coupon-item.is-selected {
    border-color: var(--theme-color, #07c160);
    box-shadow: 0 0 0 1rpx var(--theme-color, #07c160);
}

.popup-coupon-cover {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    overflow: hidden;
    margin-right: 24rpx;
    background: #f5f5f5;
}

.popup-coupon-cover image {
    width: 100%;
    height: 100%;
}

.popup-coupon-cover-empty {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 12rpx;
    font-size: 22rpx;
    color: #07c160;
    text-align: center;
    box-sizing: border-box;
}

.popup-coupon-info {
    flex: 1;
    min-width: 0;
}

.popup-coupon-name {
    font-size: 30rpx;
    font-weight: 500;
    color: #222;
    line-height: 1.4;
}

.popup-coupon-value {
    display: flex;
    align-items: baseline;
    margin-top: 10rpx;
}

.popup-coupon-amount {
    font-size: 44rpx;
    font-weight: 700;
    color: #e84c59;
    line-height: 1;
}

.popup-coupon-unit {
    font-size: 26rpx;
    font-weight: 600;
    color: #e84c59;
    margin-left: 6rpx;
}

.popup-exchange-icon {
    width: 56rpx;
    height: 56rpx;
}

.popup-coupon-threshold {
    margin-left: 12rpx;
    font-size: 24rpx;
    color: #b6b6b6;
}

.popup-coupon-valid {
    font-size: 24rpx;
    color: #b6b6b6;
    margin-top: 10rpx;
}

.popup-coupon-check {
    flex-shrink: 0;
    margin-left: 16rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.popup-coupon-check-empty {
    width: 40rpx;
    height: 40rpx;
    border-radius: 50%;
    border: 2rpx solid #ddd;
    box-sizing: border-box;
}

.popup-footer {
    --td-button-primary-bg-color: var(--theme-color, #07c160);
    --td-button-primary-active-bg-color: var(--theme-color, #07c160);
    --td-button-primary-border-color: var(--theme-color, #07c160);
    --td-button-primary-disabled-bg: #e8e8e8;
    --td-button-primary-disabled-border-color: #e8e8e8;
    --td-button-primary-disabled-color: #bbb;
    padding: 16rpx 24rpx 24rpx;
}
.subscribe-gif-wrap {
    position: fixed;
    top: 25vh;
    right: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.subscribe-gif {
    width: 600rpx;
    border-radius: 16rpx;
}

.coupon-covers {
    width: 100%;
    overflow: hidden;
}

:deep(.coupon-covers .t-swiper) {
    --td-swiper-radius: 0;
    border-radius: 0 !important;
}

:deep(.coupon-covers .t-swiper-nav--bottom) {
    bottom: 45rpx !important;
}

.coupon-view-scroll-body {
    height: 0; /* 配合 flex: 1 在 flex 容器中正确计算高度 */
}

</style>
