<template>
    <view class="container mt-2 pb-4 container-safety">
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无券包</m-empty>
            <template v-else>
                <view
                    class="bundle"
                    v-for="(item, index) in items"
                    :key="item.id || index"
                    :style="getThemeStyle(item.theme)"
                    @tap="goDetail(item.id)"
                >
                    <view class="bundle-header">
                        <view class="bundle-name text-ellipsis-2">{{ item.bundleName }}</view>
                        <text class="bundle-merchant-name text-ellipsis">{{ item.merchantName }}</text>
                    </view>
                    <view class="bundle-body">
                        <view class="bundle-count">
                            <text class="bundle-count-num">{{ item.couponKindCount }}</text>
                            <text class="bundle-count-unit">种券</text>
                            <text class="bundle-count-sep">·共</text>
                            <text class="bundle-count-num">{{ item.itemCount }}</text>
                            <text class="bundle-count-unit">张</text>
                        </view>
                        <image v-if="item.cover" class="bundle-cover" :src="item.cover" mode="aspectFill"/>
                        <view v-else class="bundle-cover bundle-cover-empty">
                            <t-icon name="gift-filled" size="36rpx" color="rgba(255,255,255,0.6)"/>
                        </view>
                    </view>
                    <view class="bundle-footer">
                        <view class="bundle-tags">
                            <view class="bundle-tag">券包</view>
                        </view>
                        <text class="bundle-time">领取于 {{ formatTime(item.receivedAt) }}</text>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import dayjs from 'dayjs'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import {getThemeStyle} from '@/utils/theme'
import utils from '@/utils/utils'
import to from '@/hooks/to'

const {push} = useLink()
// 当前商家（从卡包首页带入）
const merchantId = ref('')
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    merchantId: undefined,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 格式化领取时间
const formatTime = (t) => {
    if (!t) return ''
    return dayjs(t).format('YYYY-MM-DD HH:mm')
}

// 跳转券包详情
const goDetail = (id) => {
    push('/pages_user/bundle/detail?id=' + id)
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取券包列表数据
const getItems = () => {
    if (!merchantId.value) return
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/user/bundle/receive/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

onLoad((e) => {
    if (!e.merchantId) {
        utils.toast('缺少商家')
        return
    }
    merchantId.value = e.merchantId
    search.value.merchantId = e.merchantId
})

onShow(() => {
    if (!merchantId.value) return
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.bundle {
    position: relative;
    margin-bottom: 24rpx;
    border-radius: 24rpx;
    padding: 28rpx 28rpx 24rpx;
    overflow: hidden;
    box-shadow: 0 6rpx 24rpx rgba(0, 0, 0, 0.08);
}

.bundle-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16rpx;
}

.bundle-name {
    flex: 1;
    min-width: 0;
    font-size: 34rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.35;
}

.bundle-merchant-name {
    flex-shrink: 0;
    max-width: 240rpx;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.62);
    white-space: nowrap;
    padding-top: 6rpx;
}

.bundle-body {
    margin-top: 20rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20rpx;
}

.bundle-count {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: baseline;
    line-height: 1;
}

.bundle-count-num {
    font-size: 44rpx;
    font-weight: 700;
    color: #fff;
}

.bundle-count-unit {
    margin-left: 4rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.82);
}

.bundle-count-sep {
    margin: 0 8rpx 0 10rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.62);
}

.bundle-cover {
    width: 140rpx;
    height: 100rpx;
    border-radius: 12rpx;
    flex-shrink: 0;
    display: block;
    background: rgba(255, 255, 255, 0.12);
}

.bundle-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
}

.bundle-footer {
    margin-top: 22rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.bundle-tags {
    display: flex;
    align-items: center;
    gap: 12rpx;
    flex-shrink: 0;
}

.bundle-tag {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.92);
    padding: 4rpx 14rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.4);
    border-radius: 8rpx;
    background: rgba(255, 255, 255, 0.12);
}

.bundle-time {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.62);
}

.text-ellipsis-2 {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}
</style>
