<template>
    <m-navigation-bar :scrollY="scrollY" :threshHeight="swiperHeight" :hasCover="!!detail">
        <template #title>
            <view class="merchant-info" v-if="detail" :class="{ 'scrolled': scrollY >= swiperHeight }"
                  @click="goMerchant">
                <image class="merchant-logo" :src="detail.merchantLogo" mode="aspectFill"/>
                <text class="merchant-name">{{ detail.merchantName }}</text>
                <t-icon name="chevron-right" size="28rpx" :color="scrollY >= swiperHeight ? '#333' : '#fff'"/>
            </view>
        </template>
    </m-navigation-bar>

    <m-loading v-if="detail === undefined"></m-loading>
    <m-empty v-else-if="detail === null" :height="400">券包不存在</m-empty>

    <template v-else>
        <view class="container-safety">
            <view class="bundle-cover" :style="!detail.cover ? themeStyle : null">
                <image v-if="detail.cover" class="cover-image" :src="detail.cover" mode="aspectFill"
                       :style="{ height: swiperHeight + 'px' }"/>
                <view v-else class="cover-fallback" :style="{ height: swiperHeight + 'px' }">
                    <t-icon name="gift-filled" size="80rpx" color="rgba(255,255,255,0.5)"/>
                </view>
            </view>

            <view class="container">
                <!-- 商户信息 -->
                <view class="merchant-panel" @click="goMerchant">
                    <image class="merchant-panel-logo" :src="detail.merchantLogo" mode="aspectFill"/>
                    <view class="merchant-panel-info">
                        <view class="merchant-panel-name text-ellipsis">{{ detail.merchantName }}</view>
                        <view class="merchant-panel-extra text-ellipsis">领取于 {{
                                formatTime(detail.receivedAt)
                            }}
                        </view>
                    </view>
                    <t-icon name="chevron-right" size="28rpx" color="#999"/>
                </view>
                <!-- /商户信息 -->

                <!-- 券包 -->
                <view class="bundle mt-2" :style="themeStyle">
                    <view class="bundle-title-row">
                        <view class="bundle-title">{{ detail.bundleName }}</view>
                    </view>
                    <view class="bundle-subtitle">
                        {{ detail.couponKindCount }}种券 · 共{{ detail.itemCount }}张
                    </view>

                    <view class="bundle-body">
                        <!-- 优惠券列表 -->
                        <view class="coupon-list" v-if="detail.coupons?.length">
                            <view
                                v-for="coupon in detail.coupons"
                                :key="coupon.id"
                                class="coupon-item bundle-coupon-ticket"
                                @tap="goCouponDetail(coupon.id)"
                            >
                                <view class="coupon">
                                    <view class="coupon-header">
                                        <image v-if="coupon.cover" class="coupon-thumb" :src="coupon.cover"
                                               mode="scaleToFill"/>
                                        <view v-else class="coupon-thumb coupon-thumb-empty">
                                            <text>{{ coupon.couponTypeLabel }}</text>
                                        </view>
                                    </view>
                                    <view class="coupon-body">
                                        <view class="coupon-content">
                                            <view class="coupon-content-info">
                                                <view class="coupon-content-name text-ellipsis-break">
                                                    {{ coupon.couponName }}
                                                </view>
                                                <view class="coupon-content-value">
                                                    <template v-if="isAmountFace(coupon.couponType)">
                                                        <view class="coupon-content-amount">
                                                            <view class="coupon-amount-money">{{
                                                                    coupon.couponAmount
                                                                }}
                                                            </view>
                                                            <view class="coupon-amount-discount">元券</view>
                                                        </view>
                                                    </template>
                                                    <template v-else-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                                                        <view class="coupon-content-amount">
                                                            <view class="coupon-amount-money">{{
                                                                    coupon.couponAmount
                                                                }}
                                                            </view>
                                                            <view class="coupon-amount-discount">折券</view>
                                                        </view>
                                                    </template>
                                                    <template v-else-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                                                        <view class="coupon-amount">
                                                            <image class="exchange-icon"
                                                                   src="/static/img/exchange.png"
                                                                   mode="aspectFit"/>
                                                        </view>
                                                    </template>
                                                    <view class="coupon-threshold">{{ coupon.threshold }}</view>
                                                </view>
                                                <view class="coupon-content-valid text-ellipsis">
                                                    {{ coupon.validLabel }}
                                                </view>
                                            </view>
                                            <view class="coupon-content-action">
                                                <view class="coupon-status">{{ coupon.statusLabel }}</view>
                                            </view>
                                        </view>
                                    </view>
                                </view>
                            </view>
                        </view>
                        <view v-else class="coupon-list-empty">暂无优惠券</view>
                        <!-- /优惠券列表 -->

                        <!-- 券包须知 -->
                        <view class="bundle-content mt-2" v-if="detail.content">
                            <view class="h3">券包须知</view>
                            <!-- 每人限领 -->
                            <view class="bundle-text mt-3" v-if="detail.userLimit">
                                <text class="bundle-label">领取限制：</text>
                                <text>每人限领{{ detail.userLimit }}个</text>
                            </view>
                            <view class="bundle-text">{{ detail.content }}</view>
                        </view>
                        <!-- /券包须知 -->
                    </view>
                </view>
            </view>
        </view>
    </template>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onPageScroll} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import dayjs from 'dayjs'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {useLink} from '@/hooks/useLink'
import {getThemeStyle} from '@/utils/theme'

const {push} = useLink()

const scrollY = ref(0)
const swiperHeight = uni.getWindowInfo().screenWidth * 4 / 5

const receiveId = ref('')
const detail = ref()

const themeStyle = computed(() => getThemeStyle(detail.value?.theme))

const formatTime = (t) => {
    if (!t) return ''
    return dayjs(t).format('YYYY-MM-DD HH:mm')
}

const goMerchant = () => {
    if (!detail.value?.merchantId) return
    push('/pages_user/merchant/home?merchantId=' + detail.value.merchantId)
}

const goCouponDetail = (id) => {
    push('/pages_user/coupon/detail?id=' + id)
}

const getDetail = () => {
    detail.value = undefined
    request.get('/user/bundle/receive/get', {id: receiveId.value}).then(res => {
        detail.value = res.data
    }).catch(() => {
        detail.value = null
    })
}

onLoad((e) => {
    if (e.id) {
        receiveId.value = e.id
        getDetail()
    } else {
        detail.value = null
    }
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

onPageScroll((e) => {
    if (e.scrollTop < 360) {
        scrollY.value = e.scrollTop
    }
})
</script>

<style scoped>
/* ===== 导航栏滚动过渡 ===== */
.merchant-info {
    display: flex;
    align-items: center;
    gap: 8rpx;
    color: #fff;
    padding: 8rpx 16rpx;
    border-radius: 32rpx;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    margin: 0 10rpx;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
}

.merchant-info.scrolled {
    background: rgba(255, 255, 255, 0.95);
    color: #333;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.1);
    transform: scale(0.96);
}

.merchant-logo {
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.merchant-info.scrolled .merchant-logo {
    transform: scale(0.9);
}

.merchant-name {
    font-size: 28rpx;
    font-weight: 500;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    transition: font-weight 0.3s ease;
}

.merchant-info.scrolled .merchant-name {
    font-weight: 600;
}

/* ===== 封面 ===== */
.bundle-cover {
    width: 100%;
    overflow: hidden;
}

.cover-image {
    width: 100%;
}

.cover-fallback {
    width: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
}

/* ===== 商户信息面板 ===== */
.merchant-panel {
    position: relative;
    z-index: 2;
    margin-top: -60rpx;
    background: #fff;
    display: flex;
    align-items: center;
    gap: 16rpx;
    padding: 32rpx;
    border-radius: 24rpx;
    box-shadow: 0 8rpx 24rpx rgba(0, 0, 0, 0.08);
}

.merchant-panel-info {
    flex: 1;
    min-width: 0;
}

.merchant-panel-extra {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.merchant-panel-logo {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    flex-shrink: 0;
}

.merchant-panel-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

/* ===== 券包主题卡片 ===== */
.bundle {
    padding: 32rpx;
    border-radius: 24rpx;
    position: relative;
}

.bundle-title-row {
    display: flex;
    align-items: center;
    gap: 16rpx;
}

.bundle-title {
    font-size: 36rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.4;
}

.bundle-subtitle {
    margin-top: 12rpx;
    font-size: 26rpx;
    color: rgba(255, 255, 255, 0.85);
}

.coupon-list {
    margin-top: 24rpx;
}

.coupon-list-empty {
    margin-top: 24rpx;
    text-align: center;
    font-size: 26rpx;
    color: rgba(255, 255, 255, 0.7);
    padding: 40rpx 0;
}

.coupon-item {
    position: relative;
    margin-bottom: 20rpx;
    border-radius: 24rpx;
    background: #fff;
    overflow: visible;
}

/* 两侧凹槽（与领取页一致） */
.bundle-coupon-ticket::before,
.bundle-coupon-ticket::after {
    content: '';
    position: absolute;
    top: 50%;
    width: 24rpx;
    height: 24rpx;
    border-radius: 50%;
    transform: translateY(-50%);
    z-index: 1;
    pointer-events: none;
    background: var(--theme-color);
}

.bundle-coupon-ticket::before {
    left: -12rpx;
}

.bundle-coupon-ticket::after {
    right: -12rpx;
}

.bundle .coupon {
    padding: 32rpx;
    display: flex;
    align-items: center;
}

.bundle .coupon-header {
    margin-right: 30rpx;
}

.bundle .coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
    background: #f5f5f5;
}

.bundle .coupon-thumb-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 12rpx;
    font-size: 22rpx;
    color: #07c160;
    text-align: center;
    box-sizing: border-box;
}

.bundle .coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.bundle .coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.bundle .coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.bundle .coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #1a1a1a;
}

.bundle .coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    margin-top: 8rpx;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.bundle .coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.bundle .coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.bundle .coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.bundle .coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.bundle .exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.bundle .coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.bundle .coupon-content-valid {
    font-size: 26rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

/* 券状态徽章（统一白色，不随状态切换） */
.coupon-status {
    display: inline-block;
    font-size: 22rpx;
    color: #666;
    padding: 6rpx 16rpx;
    border-radius: 8rpx;
    background: #fff;
    border: 1rpx solid #e8e8e8;
}

/* ===== 券包须知 ===== */
.bundle-content .h3 {
    color: rgba(255, 255, 255, 0.68);
    font-size: 32rpx;
    font-weight: 600;
}

.bundle-label {
    color: rgba(255, 255, 255, 0.85);
    font-weight: 500;
}

.bundle-text {
    margin-top: 16rpx;
    font-size: 26rpx;
    line-height: 2;
    color: rgba(255, 255, 255, 0.68);
    white-space: pre-wrap;
}
</style>
