<template>
    <m-loading v-if="loading"></m-loading>
    <view v-else class="page" :style="pageStyle">
        <view class="header" :style="headerStyle">
            <view class="header-deco">
                <view class="header-glow"></view>
                <text class="header-vip">VIP</text>
            </view>

            <view class="nav" :style="{height: navHeight}">
                <view class="nav-back" @tap="onBack">
                    <t-icon name="chevron-left" size="44rpx" color="#fff"/>
                </view>
                <text class="nav-title">会员权益</text>
                <view class="nav-placeholder"></view>
            </view>

            <view class="profile">
                <image class="profile-avatar" :src="displayAvatar" mode="aspectFill"/>
                <view class="profile-main">
                    <text class="profile-name text-ellipsis">{{ displayNickname }}</text>
                    <text class="profile-greet text-ellipsis">{{ greetText }}</text>
                    <m-member-level-badge
                        v-if="memberLevel"
                        class="profile-badge"
                        :name="memberLevel.name"
                        :icon-key="memberLevel.iconKey"
                        :color="memberLevel.color"
                    />
                    <text v-else class="profile-level-empty">暂未设置会员等级</text>
                </view>
            </view>
        </view>

        <view class="sheet">
            <view v-if="posterUrl" class="poster-wrap" @tap="onPreview">
                <image class="poster" :src="posterUrl" mode="widthFix"/>
            </view>
            <view v-else class="poster-empty">
                <m-empty :height="520">商家尚未上传会员权益海报</m-empty>
            </view>
        </view>
    </view>
</template>

<script setup>
import {onLoad, onShow, onShareAppMessage, onShareTimeline} from '@dcloudio/uni-app'
import {computed, ref, watch} from 'vue'
import request from '@/hooks/request'
import {useAuth} from '@/hooks/useAuth'
import {useLink} from '@/hooks/useLink'
import config from '@/config'
import utils from '@/utils/utils'
import {
    applyHomeThemeBackground,
    getHomeThemeAccent,
    getHomeThemeStyle,
} from '@/utils/homeTheme'
import {useSessionStore} from '@/stores/session'

const {back} = useLink()
const {avatar, nickname} = useAuth()
const session = useSessionStore()

const loading = ref(true)
const merchantId = ref('')
const merchantName = ref('')
const posterUrl = ref('')
const memberLevel = ref(null)
const homeTheme = ref(null)
const navPadTop = ref('48px')
const navHeight = ref('32px')

const pageStyle = computed(() => ({
    background: getHomeThemeAccent(homeTheme.value),
}))

const headerStyle = computed(() => ({
    ...getHomeThemeStyle(homeTheme.value),
    paddingTop: navPadTop.value,
}))

const displayAvatar = computed(() => avatar.value || config.default.avatar)
const displayNickname = computed(() => nickname.value || '微信用户')
const greetText = computed(() => {
    const name = (merchantName.value || '').trim()
    return name ? `感谢你与${name}相遇` : '感谢你与本店相遇'
})

const buildSharePath = () => {
    let path = '/pages_user/merchant/member-benefit?merchantId=' + merchantId.value
    if (session.userId) {
        path += '&inviterId=' + session.userId
    }
    return path
}

const buildShareTitle = () => {
    const name = (merchantName.value || '').trim()
    return name ? name + '会员权益' : '会员权益'
}

const enableShareMenu = () => {
    uni.showShareMenu({
        withShareTicket: false,
        menus: ['shareAppMessage', 'shareTimeline'],
    })
}

watch(homeTheme, (theme) => {
    applyHomeThemeBackground(theme)
}, {immediate: true})

const initNavStyle = () => {
    try {
        const menu = wx.getMenuButtonBoundingClientRect()
        navPadTop.value = menu.top + 'px'
        navHeight.value = menu.height + 'px'
    } catch (e) {
        navPadTop.value = '48px'
        navHeight.value = '32px'
    }
}

const loadData = () => {
    loading.value = true
    request.get('/user/merchant/member-benefit', {merchantId: merchantId.value}).then((res) => {
        posterUrl.value = res.data.memberBenefitImage || ''
        memberLevel.value = res.data.memberLevel || null
        homeTheme.value = res.data.homeTheme
        merchantName.value = res.data.merchantName || ''
    }).catch(() => {
        utils.toast('加载失败')
    }).finally(() => {
        loading.value = false
    })
}

const onBack = () => back()

const onPreview = () => {
    if (!posterUrl.value) return
    uni.previewImage({
        urls: [posterUrl.value],
        current: posterUrl.value,
    })
}

onLoad((options) => {
    initNavStyle()
    enableShareMenu()
    merchantId.value = options.merchantId || options.id || ''
    if (!merchantId.value) {
        utils.toast('缺少商家信息')
        return
    }
    loadData()
})

onShow(() => {
    enableShareMenu()
})

onShareAppMessage(() => {
    return {
        title: buildShareTitle(),
        imageUrl: posterUrl.value || config.default.cover,
        path: buildSharePath(),
    }
})

onShareTimeline(() => {
    return {
        title: buildShareTitle(),
        imageUrl: posterUrl.value || config.default.cover,
        query: 'merchantId=' + merchantId.value,
    }
})
</script>

<style scoped>
.page {
    min-height: 100vh;
    box-sizing: border-box;
}

.header {
    position: relative;
    min-height: calc(520rpx + 50px);
    padding-left: 40rpx;
    padding-right: 40rpx;
    box-sizing: border-box;
    overflow: hidden;
}

.header-deco {
    position: absolute;
    inset: 0;
    overflow: hidden;
    pointer-events: none;
}

.header-glow {
    position: absolute;
    inset: 0;
    background: radial-gradient(ellipse 90% 70% at 100% 0%, rgba(255, 255, 255, 0.18) 0%, transparent 52%),
    radial-gradient(ellipse 70% 55% at 0% 100%, rgba(255, 255, 255, 0.08) 0%, transparent 48%);
}

.header-vip {
    position: absolute;
    right: -8rpx;
    top: 48%;
    transform: translateY(-40%);
    font-size: 160rpx;
    font-weight: 700;
    letter-spacing: 4rpx;
    color: rgba(255, 255, 255, 0.12);
    line-height: 1;
    font-style: italic;
}

.nav,
.profile {
    position: relative;
    z-index: 1;
}

.nav {
    display: flex;
    align-items: center;
    justify-content: space-between;
    box-sizing: content-box;
    margin-bottom: 56rpx;
}

.nav-back,
.nav-placeholder {
    width: 64rpx;
    height: 64rpx;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    flex-shrink: 0;
}

.nav-title {
    flex: 1;
    text-align: center;
    font-size: 34rpx;
    font-weight: 600;
    color: #fff;
    line-height: 1.2;
}

.profile {
    display: flex;
    align-items: flex-start;
    gap: 24rpx;
    max-width: 78%;
    padding-top: 16rpx;
    padding-bottom: calc(24rpx + 50px);
    box-sizing: border-box;
}

.profile-avatar {
    width: 140rpx;
    height: 140rpx !important;
    border-radius: 50%;
    flex-shrink: 0;
    border: 4rpx solid rgba(255, 255, 255, 0.85);
    background: rgba(255, 255, 255, 0.16);
    box-sizing: border-box;
}

.profile-main {
    flex: 1;
    min-width: 0;
    padding-top: 4rpx;
}

.profile-name {
    display: block;
    font-size: 40rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.25;
}

.profile-greet {
    display: block;
    margin-top: 14rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.82);
    line-height: 1.35;
}

.profile-badge {
    display: inline-flex;
    margin-top: 24rpx;
}

.profile-level-empty {
    display: block;
    margin-top: 22rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.72);
}

.sheet {
    position: relative;
    z-index: 2;
    margin-top: -120rpx;
    min-height: calc(100vh - 220rpx);
    padding: 0;
    background: #fff;
    border-radius: 40rpx 40rpx 0 0;
    box-sizing: border-box;
    overflow: hidden;
}

.poster-wrap {
    overflow: hidden;
    background: #fff;
}

.poster {
    width: 100%;
    display: block;
}

.poster-empty {
    padding: 80rpx 28rpx 48rpx;
}
</style>
