<template>
    <view class="container pb-4 container-safety">
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0" :height="400">暂无商家</m-empty>
            <template v-else>
                <view
                    class="merchant"
                    v-for="item in items"
                    :key="item.id"
                    @tap="goDetail(item.id)"
                >
                    <view class="merchant-cover-wrap">
                        <image v-if="item.cover" class="merchant-cover" :src="item.cover" mode="aspectFill"/>
                        <view v-else class="merchant-cover merchant-cover-empty">
                            <t-icon name="shop-1" size="56rpx" color="#ccc"/>
                        </view>
                    </view>
                    <view class="merchant-body">
                        <view class="merchant-head">
                            <view class="merchant-name text-ellipsis">{{ item.name }}</view>
                            <view
                                class="merchant-auth"
                                :class="item.authStatus === AUTH_STATUS.SUCCESS ? 'is-verified' : 'is-unverified'"
                                v-if="item.authStatus != null"
                            >
                                <t-icon name="verified-filled" size="28rpx"/>
                                <text class="merchant-auth-text">{{ item.authStatus === AUTH_STATUS.SUCCESS ? '已认证' : '未认证' }}</text>
                            </view>
                        </view>
                        <view class="merchant-tags" v-if="item.industry">
                            <view class="merchant-tag">
                                <view class="merchant-tag-dot"></view>
                                <text>{{ item.industry }}</text>
                            </view>
                        </view>
                        <view class="merchant-address" v-if="item.address">
                            <t-icon name="location" size="22rpx" color="#b6b6b6"/>
                            <text class="text-ellipsis">{{ item.address }}</text>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
</template>

<script setup>
import {onShow, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {AUTH_STATUS} from '@/constants/merchant'
import {useLink} from '@/hooks/useLink'
import to from '@/hooks/to'

const {push} = useLink()
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 跳转商家主页
const goDetail = (id) => {
    push('/pages_user/merchant/home?id=' + id)
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取商家列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/user/merchant/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

onShow(() => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.merchant {
    margin-bottom: 24rpx;
    background: #fff;
    border-radius: 24rpx;
    overflow: hidden;
}

.merchant-cover-wrap {
    position: relative;
    width: 100%;
}

.merchant-cover {
    width: 100%;
    height: 220rpx;
    display: block;
    background: #f2f2f2;
}

.merchant-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #fafafa 0%, #f0f0f0 100%);
}

.merchant-body {
    padding: 28rpx 32rpx 40rpx;
}

.merchant-head {
    display: flex;
    align-items: center;
    gap: 12rpx;
}

.merchant-name {
    flex: 1;
    min-width: 0;
    font-size: 32rpx;
    font-weight: 600;
    color: #181818;
    line-height: 1.4;
}

/* 认证标记 */
.merchant-auth {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 4rpx;
    font-size: 22rpx;
    line-height: 1;
}

.merchant-auth.is-verified {
    color: #07c160;
}

.merchant-auth.is-unverified {
    color: #b6b6b6;
}

/* 行业标签 */
.merchant-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 12rpx;
    margin-top: 16rpx;
}

.merchant-tag {
    display: inline-flex;
    align-items: center;
    gap: 10rpx;
    padding: 6rpx 18rpx 6rpx 14rpx;
    border-radius: 8rpx;
    background: rgba(232, 76, 89, 0.06);
    color: #e84c59;
    font-size: 22rpx;
    line-height: 1.5;
}

.merchant-tag-dot {
    width: 8rpx;
    height: 8rpx;
    border-radius: 50%;
    background: #e84c59;
    box-shadow: 0 0 0 3rpx rgba(232, 76, 89, 0.12);
}

.merchant-address {
    display: flex;
    align-items: center;
    margin-top: 18rpx;
    font-size: 24rpx;
    color: #999;
}

.merchant-address text {
    margin-left: 8rpx;
}
</style>
