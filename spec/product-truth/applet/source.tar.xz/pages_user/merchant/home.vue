<template>
    <view class="home-page">
        <view class="hero">
            <image class="hero-cover" :src="heroCover" mode="scaleToFill"/>
            <view class="hero-mask"></view>
            <m-navigation-bar :scrollY="scrollY" :threshHeight="swiperHeight">

            </m-navigation-bar>

            <view class="hero-info" v-if="detail">
                <view class="hero-name-row">
                    <view class="hero-name text-ellipsis">{{ detail.name }}</view>
                    <view v-if="isMerchantVerified" class="member-badge" :style="memberBadgeStyle">
                        <image class="member-badge-icon" src="/static/img/home-badge-crown.png" mode="aspectFit"/>
                        <text>已认证</text>
                    </view>
                </view>
                <view v-if="detail.address" class="hero-address" @tap="onOpenLocation">
                    <t-icon name="location" size="24rpx" color="rgba(255,255,255,0.88)"/>
                    <text class="text-ellipsis">{{ detail.address }}</text>
                </view>
                <view class="hero-tags">
                    <view class="hero-tag" @tap="onGoCouponCenter">
                        <t-icon name="gift" size="26rpx" color="#fff"/>
                        <text>领券中心</text>
                    </view>
                    <view class="hero-tag" @tap="onGoMemberBenefit">
                        <t-icon name="usergroup" size="26rpx" color="#fff"/>
                        <text>会员权益</text>
                    </view>
                    <view class="hero-tag" @tap="onCallPhone">
                        <t-icon name="call" size="26rpx" color="#fff"/>
                        <text>客服电话</text>
                    </view>
                </view>
            </view>
        </view>

        <!-- 本店卡包：积分 / 优惠券 / 次卡 -->
        <view v-if="detail !== null" class="member-card" :style="memberCardStyle">
            <view class="member-card-deco">
                <view class="member-card-glow"></view>
                <view class="member-card-orb"></view>
            </view>
            <view class="user-row">
                <template v-if="!isLoggedIn">
                    <get-user-info @success="onGetUserInfoSuccess">
                        <image class="user-avatar" :src="cardAvatar" mode="aspectFill"/>
                    </get-user-info>
                </template>
                <image v-else class="user-avatar" :src="cardAvatar" mode="aspectFill"/>
                <view class="user-main">
                    <view class="user-name-row">
                        <template v-if="!isLoggedIn">
                            <get-user-info @success="onGetUserInfoSuccess">
                                <view class="user-name">登录</view>
                            </get-user-info>
                        </template>
                        <view v-else-if="!isCustomer" class="user-name" @tap="onJoin">加入</view>
                        <template v-else>
                            <view class="user-name text-ellipsis">{{ cardNickname }}</view>
                            <m-member-level-badge
                                v-if="memberLevel"
                                class="user-level-badge"
                                :name="memberLevel.name"
                                :icon-key="memberLevel.iconKey"
                                :color="memberLevel.color"
                                @click="onGoMemberBenefit"
                            />
                        </template>
                    </view>
                    <view class="user-sub">
                        <template v-if="!isLoggedIn">登录后查看会员信息</template>
                        <template v-else-if="!isCustomer">加入本店后查看会员信息</template>
                        <template v-else>累计积分 {{ pointBalance }}</template>
                    </view>
                </view>
                <view class="user-code" @tap="onMemberQrcode">
                    <t-icon name="qrcode" size="48rpx" color="#fff"/>
                </view>
            </view>
            <view class="stats-row">
                <view class="stat" @tap="onPointTap">
                    <view class="stat-head">
                        <image class="stat-icon" src="/static/img/home-point.png" mode="aspectFit"/>
                        <view class="stat-num">{{ pointBalance }}</view>
                    </view>
                    <view class="stat-label">积分</view>
                    <view class="stat-link">
                        <text>查看我的积分</text>
                        <t-icon name="chevron-right" size="22rpx" color="rgba(255,255,255,0.55)"/>
                    </view>
                </view>
                <view class="stat-divider"></view>
                <view class="stat" @tap="onStatTap('/pages_user/coupon/index')">
                    <view class="stat-head">
                        <image class="stat-icon" src="/static/img/home-stat-ticket.png" mode="aspectFit"/>
                        <view class="stat-num">{{ couponCount }}
                            <text class="stat-unit">张</text>
                        </view>
                    </view>
                    <view class="stat-label">优惠券</view>
                    <view class="stat-link">
                        <text>查看可用优惠券</text>
                        <t-icon name="chevron-right" size="22rpx" color="rgba(255,255,255,0.55)"/>
                    </view>
                </view>
                <view class="stat-divider"></view>
                <view class="stat" @tap="onStatTap('/pages_user/card/index')">
                    <view class="stat-head">
                        <image class="stat-icon" src="/static/img/home-card.png" mode="aspectFit"/>
                        <view class="stat-num">{{ cardCount }}
                            <text class="stat-unit">张</text>
                        </view>
                    </view>
                    <view class="stat-label">次卡</view>
                    <view class="stat-link">
                        <text>查看我的次卡</text>
                        <t-icon name="chevron-right" size="22rpx" color="rgba(255,255,255,0.55)"/>
                    </view>
                </view>
            </view>
            <image class="member-wave" src="/static/img/home-card-wave.png" mode="scaleToFill"/>
        </view>

        <!-- 活动海报：开启「展示到商家主页」的上架海报；多张轮播，空则不展示 -->
        <view v-if="posterCovers.length" class="poster-section">
            <t-swiper
                :list="posterCovers"
                :height="posterSwiperHeight"
                :navigation="posterCovers.length > 1"
                :autoplay="posterCovers.length > 1"
                :loop="posterCovers.length > 1"
                :interval="4000"
                @click="onPosterClick"
            />
        </view>

        <m-loading v-if="detail === undefined"></m-loading>
        <m-empty v-else-if="detail === null" :height="240">商家不存在</m-empty>
        <view v-else id="coupon-center" class="coupon-section">
            <!-- 广告位-->
            <view class="section" v-if="adUnitMerchantHome">
                <ad-custom :unit-id="adUnitMerchantHome"></ad-custom>
            </view>

            <view class="section-header">
                <view class="section-title">领券中心</view>
            </view>
            <m-loading v-if="coupons === undefined"></m-loading>
            <m-empty v-else-if="coupons.length === 0" :height="240">暂无可领优惠券</m-empty>
            <view
                v-else
                class="receive mb-2"
                v-for="item in coupons"
                :key="item.id"
                @click="onCouponClick(item)"
            >
                <view class="coupon-top">
                    <view class="coupon-top-type">{{ item.couponTypeLabel }}</view>
                </view>
                <view class="coupon-line"></view>
                <view class="coupon">
                    <view class="coupon-header">
                        <image class="coupon-thumb" :src="item.cover" mode="aspectFill"/>
                    </view>
                    <view class="coupon-body">
                        <view class="coupon-content">
                            <view class="coupon-content-info">
                                <view class="coupon-content-name text-ellipsis-break">{{ item.couponName }}</view>
                                <view class="coupon-content-value">
                                    <template v-if="isAmountFace(item.couponType)">
                                        <view class="coupon-content-amount">
                                            <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                            <view class="coupon-amount-discount">元券</view>
                                        </view>
                                    </template>
                                    <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                        <view class="coupon-content-amount">
                                            <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                            <view class="coupon-amount-discount">折券</view>
                                        </view>
                                    </template>
                                    <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                        <view class="coupon-amount">
                                            <image class="exchange-icon" src="/static/img/exchange.png"
                                                   mode="aspectFit"/>
                                        </view>
                                    </template>
                                    <view class="coupon-threshold">{{ item.threshold }}</view>
                                </view>
                                <view class="coupon-content-valid text-ellipsis">{{ item.validLabel }}</view>
                            </view>
                            <view class="coupon-content-action">
                                <view class="button-gold">领取</view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </view>

        <t-popup placement="center" :visible="memberQrcodeVisible" @visible-change="onMemberQrcodePopupChange">
            <view class="member-qrcode-popup">
                <view class="member-qrcode-popup-header">
                    <text class="member-qrcode-popup-title">客户码</text>
                    <t-icon name="close" size="44rpx" color="#999" @click="memberQrcodeVisible = false"/>
                </view>
                <view class="member-qrcode-popup-body">
                    <m-loading v-if="memberQrcodeLoading"></m-loading>
                    <template v-else-if="memberQrcode">
                        <image
                            class="member-qrcode-image"
                            :src="memberQrcode"
                            mode="aspectFit"
                            show-menu-by-longpress
                        />
                        <view v-if="memberUserId" class="member-qrcode-userid text-muted text-small"
                              @click="onCopyUserId">
                            客户编码：{{ memberUserId }}
                            <t-icon name="copy" size="32rpx" color="#999"
                                    custom-style="margin-left: 8rpx; vertical-align: middle;"/>
                        </view>
                    </template>
                    <m-empty v-else :height="320">暂无客户码</m-empty>
                </view>
                <view class="member-qrcode-popup-tip text-muted text-small">向商家出示此码识别客户身份</view>
            </view>
        </t-popup>
    </view>
</template>

<script setup>
import {onLoad, onShareAppMessage, onPageScroll} from '@dcloudio/uni-app'
import {computed, ref, watch} from 'vue'
import request from '@/hooks/request'
import {useAuth} from '@/hooks/useAuth'
import {useLink} from '@/hooks/useLink'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {AUTH_STATUS} from '@/constants/merchant'
import config from '@/config'
import to from '@/hooks/to'
import utils from '@/utils/utils'
import {applyHomeThemeBackground, getHomeThemeColorStyle, getHomeThemeStyle} from '@/utils/homeTheme'
import {useSessionStore} from '@/stores/session'

const {login, isLoggedIn, avatar, nickname} = useAuth()
const {push} = useLink()
const session = useSessionStore()


const scrollY = ref(0)
const swiperHeight = uni.getWindowInfo().screenWidth * 4 / 5

// 当前商家 ID
const merchantId = ref('')
// 打开主页时的邀请人（分享带入）
const inviterId = ref('')
// 商家公开信息
const detail = ref()
// 领券中心列表
const coupons = ref()
// 商家主页活动海报（开启展示且上架）
const posters = ref([])
// 海报轮播图 URL 列表
const posterCovers = computed(() => posters.value.map((p) => p.cover).filter(Boolean))
// 海报轮播高度：内容区宽约屏宽-48rpx，按 3:2
const posterSwiperHeight = Math.round((uni.getWindowInfo().windowWidth - uni.upx2px(48)) * 2 / 3)
// 本店顾客态（登录后拉取）
const customer = ref(null)
// 加入本店请求中
const joining = ref(false)
// 客户码弹层
const memberQrcodeVisible = ref(false)
// 客户码图片
const memberQrcode = ref('')
// 客户编码
const memberUserId = ref('')
// 客户码加载中
const memberQrcodeLoading = ref(false)

// 会员卡主题样式
const memberCardStyle = computed(() => getHomeThemeStyle(detail.value?.homeTheme))

// 认证徽章主题色
const memberBadgeStyle = computed(() => getHomeThemeColorStyle(detail.value?.homeTheme))

// 监听主题色变化，同步页面背景
watch(() => detail.value?.homeTheme, (theme) => {
    applyHomeThemeBackground(theme)
}, {immediate: true})

// 门头封面
const heroCover = computed(() => detail.value?.cover || config.default.cover)

// 商家主页广告位 unit-id
const adUnitMerchantHome = computed(() => {
    if (config.adUnit?.merchantHome && detail.value?.allowAd) {
        return config.adUnit.merchantHome
    }
    return ''
})

// 当前商家是否已认证
const isMerchantVerified = computed(() => detail.value?.authStatus === AUTH_STATUS.SUCCESS)

// 是否已是本店顾客
const isCustomer = computed(() => !!customer.value?.isCustomer)

// 会员卡头像
const cardAvatar = computed(() => customer.value?.avatar || avatar.value || config.default.avatar)

// 会员卡昵称
const cardNickname = computed(() => customer.value?.nickname || nickname.value || '微信用户')

// 会员等级
const memberLevel = computed(() => (isCustomer.value ? customer.value?.memberLevel : null) || null)

// 本店可用优惠券张数（非顾客为 0）
const couponCount = computed(() => isCustomer.value ? to.Int(customer.value?.couponCount) : 0)

// 本店积分余额（非顾客为 0）
const pointBalance = computed(() => isCustomer.value ? to.Int(customer.value?.pointBalance) : 0)

// 本店可用次卡张数（非顾客为 0）
const cardCount = computed(() => isCustomer.value ? to.Int(customer.value?.cardCount) : 0)

// 从 scene / id / merchantId 解析商家 ID
const resolveMerchantId = (e) => {
    if (e.scene) return decodeURIComponent(e.scene)
    if (e.id) return e.id
    if (e.merchantId) return e.merchantId
    return ''
}

// 拉取公开商家信息、领券列表、主页活动海报
const loadPublicHome = () => {
    detail.value = undefined
    coupons.value = undefined
    posters.value = []
    const id = merchantId.value
    return Promise.all([
        request.get('/merchant/home', {merchantId: id}, {showLoading: false}),
        request.get('/merchant/home/coupon/list', {merchantId: id}, {showLoading: false}),
        request.get('/activity-poster/home-list', {merchantId: id}, {showLoading: false}).catch(() => ({data: {items: []}})),
    ]).then(([detailRes, listRes, posterRes]) => {
        detail.value = detailRes.data
        coupons.value = to.Array(listRes.data.items)
        posters.value = to.Array(posterRes.data?.items)
    }).catch(() => {
        detail.value = null
        coupons.value = []
        posters.value = []
    })
}

// 点击活动海报进入公开详情
const onPosterClick = (e) => {
    const index = e?.index ?? e?.detail?.index
    const item = posters.value[index]
    if (!item?.id) return
    push(`/pages_user/activity_poster/detail?id=${item.id}`)
}

// 拉取本店顾客态（需登录）
const loadCustomer = () => {
    if (!isLoggedIn.value || !merchantId.value) {
        customer.value = null
        return Promise.resolve()
    }
    return request.get('/user/merchant/home/customer', {merchantId: merchantId.value}, {showLoading: false}).then((res) => {
        customer.value = res.data
    }).catch(() => {
        customer.value = null
    })
}

// 刷新主页：公开数据 +（已登录则）顾客态
const refreshHome = () => {
    return loadPublicHome().then(() => loadCustomer())
}

// 授权登录并成为本店顾客，再刷新
const onGetUserInfoSuccess = (e) => {
    login({
        nickname: e.detail.userInfo.nickName,
        avatar: e.detail.userInfo.avatarUrl,
        merchantId: merchantId.value,
    }).then(() => {
        if (merchantId.value) {
            refreshHome()
        }
    })
}

// 已登录用户加入本店
const onJoin = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    if (!merchantId.value || joining.value) return
    joining.value = true
    request.post('/user/merchant/home/join', {merchantId: merchantId.value}).then((res) => {
        customer.value = res.data
        utils.toast('已加入本店')
    }).catch((err) => {
        utils.toast(err.message || '加入失败')
    }).finally(() => {
        joining.value = false
    })
}

// 跳转本店卡包对应列表
const onStatTap = (path) => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    if (!isCustomer.value) {
        utils.toast('请先加入本店')
        return
    }
    if (!merchantId.value) {
        utils.toast('缺少商家')
        return
    }
    const sep = path.includes('?') ? '&' : '?'
    push(path + sep + 'merchantId=' + merchantId.value)
}

// 进入积分明细
const onPointTap = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    if (!isCustomer.value) {
        utils.toast('请先加入本店')
        return
    }
    if (!merchantId.value) {
        utils.toast('缺少商家')
        return
    }
    push('/pages_user/point/list?merchantId=' + merchantId.value)
}

// 拉取会员码与客户编码并打开弹层
const loadMemberQrcode = () => {
    memberQrcodeVisible.value = true
    memberQrcode.value = ''
    memberUserId.value = ''
    memberQrcodeLoading.value = true
    request.get('/user/user/qrcode').then((res) => {
        memberQrcode.value = res.data.qrcode || ''
        memberUserId.value = res.data.userId || ''
    }).catch(() => {
        memberQrcodeVisible.value = false
    }).finally(() => {
        memberQrcodeLoading.value = false
    })
}

// 打开客户码
const onMemberQrcode = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    if (!isCustomer.value) {
        utils.toast('请先加入本店')
        return
    }
    const tmplIds = (config.subscribeMessage.pointChange || []).filter(Boolean)
    if (!tmplIds.length) {
        loadMemberQrcode()
        return
    }
    uni.requestSubscribeMessage({
        tmplIds,
        success() {
            loadMemberQrcode()
        },
        fail() {
            loadMemberQrcode()
        },
    })
}

// 关闭客户码弹层时清空图片
const onMemberQrcodePopupChange = (e) => {
    const visible = e && typeof e === 'object' ? e.visible : !!e
    memberQrcodeVisible.value = visible
    if (!visible) {
        memberQrcode.value = ''
        memberUserId.value = ''
    }
}

// 复制客户编码
const onCopyUserId = () => {
    if (!memberUserId.value) return
    utils.copyClipboard(memberUserId.value, '客户编码已复制')
}

// 滚动到领券中心
const onGoCouponCenter = () => {
    uni.pageScrollTo({selector: '#coupon-center', duration: 200})
}

// 进入会员权益页
const onGoMemberBenefit = () => {
    const id = detail.value?.id
    if (!id) {
        utils.toast('商家不存在')
        return
    }
    push('/pages_user/merchant/member-benefit?merchantId=' + id)
}

// 打开商家地图位置
const onOpenLocation = () => {
    const d = detail.value
    if (!d) return
    if (d.lat > 0 && d.lng > 0) {
        uni.openLocation({
            latitude: d.lat,
            longitude: d.lng,
            scale: 18,
            name: d.name,
            address: d.address,
            fail: () => {
                uni.showToast({icon: 'none', title: '打开地图失败'})
            },
        })
        return
    }
    uni.showToast({icon: 'none', title: '商家尚未设置地图位置'})
}

// 拨打客服电话
const onCallPhone = () => {
    utils.makePhoneCall(detail.value?.servicePhone, '尚未设置客服电话')
}

// 去领券中心对应公开领取页（优先分享带来的邀请人，否则当前登录用户）
const onCouponClick = (item) => {
    if (!item.couponIssueId) {
        utils.toast('领券链接无效')
        return
    }
    let href = '/pages_user/coupon/public_receive?i=' + item.couponIssueId
    const invite = inviterId.value || session.userId
    if (invite) {
        href += '&inviterId=' + invite
    }
    push(href)
}

onPageScroll((e) => {
    if (e.scrollTop < 360) {
        scrollY.value = e.scrollTop
    }
})

// 页面加载：解析商家并拉公开数据；已登录再拉顾客态
onLoad((e) => {
    const query = e || {}
    merchantId.value = resolveMerchantId(query)
    if (query.inviterId) {
        inviterId.value = query.inviterId
    }
    if (!merchantId.value) {
        detail.value = null
        coupons.value = []
        return
    }
    refreshHome()
})

// 分享给好友
onShareAppMessage(() => {
    let path = '/pages_user/merchant/home?id=' + merchantId.value
    if (session.userId) {
        path += '&inviterId=' + session.userId
    }
    return {
        title: detail.value?.homeShareTitle || detail.value?.name || '商家主页',
        imageUrl: detail.value?.cover || config.default.cover,
        path,
    }
})
</script>

<style scoped>
.home-page {
    min-height: 100vh;
    background: #f6f6f6;
    padding-bottom: 48rpx;
}

.hero {
    position: relative;
    width: 100%;
    height: 0;
    /* 门头固定 3:2（宽:高），与顾客首页 pages/index 保持一致；*/
    padding-top: 66.666%;
    overflow: hidden;
}

.hero-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: block;
    background: #1a3d32;
}

.hero-mask {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.42);
}

.hero-nav {
    position: absolute;
    left: 24rpx;
    right: 0;
    z-index: 3;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    box-sizing: content-box;
}

.hero-pill {
    display: flex;
    align-items: center;
    gap: 6rpx;
    height: 56rpx;
    padding: 0 18rpx;
    border-radius: 28rpx;
    background: rgba(0, 0, 0, 0.38);
    color: #fff;
    font-size: 24rpx;
    line-height: 1;
}

.hero-info {
    position: absolute;
    left: 32rpx;
    right: 32rpx;
    bottom: 120rpx;
    z-index: 3;
    color: #fff;
}

.hero-name-row {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 15px;
    margin-bottom: 24rpx;
}

.hero-name {
    flex: 0 1 auto;
    min-width: 0;
    max-width: 70%;
    font-size: 40rpx;
    font-weight: 700;
    line-height: 1.35;
}

.member-badge {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    gap: 6rpx;
    height: 36rpx;
    padding: 0 14rpx;
    border-radius: 36rpx;
    background: #0C453D;
    color: #fff;
    font-size: 20rpx;
    line-height: 1;
}

.member-badge-icon {
    width: 22rpx;
    height: 22rpx !important;
    display: block;
}

.hero-address {
    display: flex;
    align-items: center;
    gap: 8rpx;
    margin-bottom: 28rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.88);
}

.hero-address text {
    min-width: 0;
}

.hero-tags {
    display: flex;
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    gap: 16rpx;
}

.hero-tag {
    display: inline-flex;
    align-items: center;
    gap: 8rpx;
    height: 52rpx;
    padding: 0 20rpx;
    border-radius: 26rpx;
    background: rgba(255, 255, 255, 0.2);
    border: 1rpx solid rgba(255, 255, 255, 0.28);
    color: #fff;
    font-size: 24rpx;
    line-height: 1;
}

.coupon-section {
    margin: 8rpx 24rpx 0;
}

.poster-section {
    margin: 16rpx 24rpx 0;
    border-radius: 20rpx;
    overflow: hidden;
    background: #fff;
}

.coupon-section .section-header {
    padding: 20rpx 0;
}

.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.coupon-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 24rpx 32rpx 8rpx;
}

.coupon-top-type {
    font-size: 26rpx;
    font-weight: 600;
    color: #373737;
}

.coupon {
    padding: 10rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon-header {
    margin-right: 24rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
    background: #f5f5f5;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    min-width: 0;
}

.coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

.member-card {
    position: relative;
    z-index: 4;
    margin: -72rpx 24rpx 8rpx;
    padding: 40rpx 28rpx 0;
    background: linear-gradient(160deg, #0d6754 0%, #0C453D 48%, #04362d 100%);
    border-radius: 24rpx 24rpx 0 0;
    box-sizing: border-box;
}

.member-card-deco {
    position: absolute;
    inset: 0;
    overflow: hidden;
    pointer-events: none;
    border-radius: 24rpx 24rpx 0 0;
}

.member-card-glow {
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(ellipse 90% 70% at 100% 0%, rgba(255, 255, 255, 0.16) 0%, transparent 52%),
    radial-gradient(ellipse 70% 55% at 0% 100%, rgba(232, 194, 122, 0.1) 0%, transparent 48%);
}

.member-card-orb {
    position: absolute;
    top: -80rpx;
    right: -40rpx;
    width: 220rpx;
    height: 220rpx;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.05);
    pointer-events: none;
}

.user-row,
.stats-row,
.member-wave {
    position: relative;
    z-index: 1;
}

.user-row {
    display: flex;
    align-items: flex-start;
    gap: 16rpx;
}

.user-avatar {
    width: 96rpx;
    height: 96rpx !important;
    border-radius: 50%;
    flex-shrink: 0;
    background: rgba(255, 255, 255, 0.16);
}

.user-main {
    flex: 1;
    min-width: 0;
    padding-top: 6rpx;
}

.user-name-row {
    display: flex;
    align-items: center;
    min-width: 0;
    gap: 12rpx;
}

.user-level-badge {
    flex-shrink: 0;
}

.user-name {
    font-size: 36rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.25;
}

.user-sub {
    margin-top: 10rpx;
    font-size: 24rpx;
    color: #fff;
    line-height: 1.2;
}

.user-code {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding-top: 8rpx;
}

.stats-row {
    display: flex;
    align-items: stretch;
    margin-top: 40rpx;
    padding-bottom: 12rpx;
}

.stat {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

.stat-head {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8rpx;
}

.stat-icon {
    width: 44rpx;
    height: 44rpx !important;
    display: block;
    flex-shrink: 0;
}

.stat-num {
    font-size: 48rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1;
}

.stat-unit {
    font-size: 28rpx;
    font-weight: 400;
}

.stat-label {
    margin-top: 10rpx;
    font-size: 30rpx;
    color: #fff;
    line-height: 1.2;
}

.stat-link {
    margin-top: 22rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 2rpx;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.55);
    line-height: 1.2;
}

.stat-divider {
    width: 1rpx;
    margin: 16rpx 0 20rpx;
    background: rgba(255, 255, 255, 0.12);
    flex-shrink: 0;
}

.member-wave {
    display: block;
    width: calc(100% + 56rpx);
    height: 72rpx !important;
    margin: 20rpx -28rpx 0;
}

.member-qrcode-popup {
    width: 600rpx;
    background: #fff;
    border-radius: 24rpx;
    padding: 32rpx;
    box-sizing: border-box;
}

.member-qrcode-popup-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24rpx;
}

.member-qrcode-popup-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.member-qrcode-popup-body {
    min-height: 400rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.member-qrcode-image {
    width: 400rpx;
    height: 400rpx;
}

.member-qrcode-userid {
    margin-top: 24rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.member-qrcode-popup-tip {
    text-align: center;
    margin-top: 24rpx;
}
</style>
