<template>
    <m-loading v-if="item === undefined"></m-loading>
    <view v-else-if="item">
        <t-cell-group theme="card" t-class="mt-2">
            <t-cell title="反馈类型" :note="item.feedbackTypeLabel"/>
            <t-cell title="处理状态" :note="item.statusLabel"/>
            <t-cell title="联系方式" :note="item.mobile || '-'"/>
            <t-cell title="提交时间" :note="item.createdAt"/>
        </t-cell-group>
        <t-cell-group theme="card" t-class="mt-2" v-if="item.voucherId && item.voucherId !== '0'">
            <t-cell title="卡券编号" :note="item.voucherId"/>
            <t-cell title="卡券" :note="item.voucherName || '-'"/>
            <t-cell title="商家" :note="item.merchantName || '-'"/>
        </t-cell-group>
        <view class="container mt-2">
            <view class="section">
                <view class="section-header">
                    <text class="section-title">反馈内容</text>
                </view>
                <view class="section-body">
                    {{ item.content }}
                </view>
                <t-divider/>
                <view class="p-3" v-if="imageList.length">
                    <image
                        v-for="(url, idx) in imageList"
                        :key="idx"
                        :src="url"
                        mode="aspectFill"
                        class="feedback-image"
                        @click="preview(idx)"
                    />
                </view>
            </view>
            <view class="section mt-2">
                <view class="section-header">
                    <text class="section-title">平台回复</text>
                    <text class="section-more">{{ item.replyAt }}</text>
                </view>
                <view class="section-body">
                    {{ item.replyContent }}
                </view>
            </view>
        </view>
        <t-cell-group theme="card" t-class="mt-2" v-if="item.status === 1">
            <t-cell title="处理结果" note="待处理，请耐心等待"/>
        </t-cell-group>
    </view>
    <m-empty v-else>反馈记录不存在</m-empty>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad} from '@dcloudio/uni-app'
import request from '@/hooks/request.js'
import MLoading from '@/components/m/m-loading/m-loading.vue'

const item = ref()
const feedbackId = ref('')

const imageList = computed(() => {
    const files = item.value?.files
    if (!files) return []
    if (Array.isArray(files)) {
        return files.map(v => (typeof v === 'string' ? v : v?.url)).filter(Boolean)
    }
    return []
})

const preview = (idx) => {
    uni.previewImage({
        current: idx,
        urls: imageList.value,
    })
}

const getItem = () => {
    request.get('/user/feedback/detail', {id: feedbackId.value}).then((res) => {
        item.value = res.data
    }).catch(() => {
        // 加载失败展示不存在态，避免长期加载中
        item.value = null
    })
}

onLoad((e) => {
    if (e.id) {
        feedbackId.value = e.id
        getItem()
    } else {
        // 缺少反馈 ID，直接展示不存在态
        item.value = null
    }
})
</script>

<style scoped>
.feedback-image {
    width: 160rpx;
    height: 160rpx;
    border-radius: 12rpx;
    margin: 0 16rpx 16rpx 0;
}

.reply-box {
    padding: 24rpx;
    background: #fff;
    color: #333;
    font-size: 28rpx;
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-all;
}
</style>
