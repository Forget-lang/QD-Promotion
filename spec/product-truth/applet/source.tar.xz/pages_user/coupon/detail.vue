<template>
    <m-result v-if="errMessage !== ''"
              type="danger"
              :title="errMessage"
              back
    >
    </m-result>
    <m-loading v-else-if="coupon === undefined"></m-loading>
    <m-empty v-else-if="coupon === null">优惠券不存在</m-empty>
    <view v-else class="coupon-detail-page mt-2">
        <!-- 优惠券-内容 -->
        <view class="container">
            <view class="receive mb-3">
                <!-- 商户 -->
                <view class="merchant">
                    <image class="merchant-logo" :src="coupon.merchantLogo" mode="aspectFill"/>
                    <view class="merchant-header">
                        <view class="merchant-header-title">
                            <view class="d-flex align-items-center">
                                <text class="text-ellipsis">{{ coupon.merchantName }}</text>
                            </view>
                        </view>
                        <view class="merchant-header-extra">
                            <view class="coupon-type">{{ coupon.couponTypeLabel }}</view>
                        </view>
                    </view>
                </view>
                <view class="coupon-line"></view>
                <!-- /优惠券-商户 -->
                <view class="coupon" :class="{ 'used': coupon.status === RECEIVE_STATUS.USED, 'discard': coupon.status === RECEIVE_STATUS.DISCARDED, 'invalid': coupon.status === RECEIVE_STATUS.EXPIRED }">
                    <!-- 优惠券-内容 -->
                    <view class="coupon-header">
                        <image class="coupon-thumb" :src="coupon.cover" mode="scaleToFill"/>
                    </view>
                    <view class="coupon-body">
                        <view class="coupon-content">
                            <view class="coupon-content-info">
                                <view class="coupon-content-name text-ellipsis-break">{{ coupon.couponName }}
                                </view>
                                <view class="coupon-content-value">
                                    <template v-if="isAmountFace(coupon.couponType)">
                                        <view class="coupon-content-amount">
                                            <view class="coupon-amount-money">{{ coupon.couponAmount }}</view>
                                            <view class="coupon-amount-discount">元券</view>
                                        </view>
                                    </template>
                                    <template v-else-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                                        <view class="coupon-content-amount">
                                            <view class="coupon-amount-money">{{ coupon.couponAmount }}</view>
                                            <view class="coupon-amount-discount">折券</view>
                                        </view>
                                    </template>
                                    <template v-else-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                                        <view class="coupon-amount">
                                            <img class="exchange-icon" src="/static/img/exchange.png" alt="">
                                        </view>
                                    </template>
                                    <view class="coupon-threshold">{{ coupon.threshold }}</view>
                                </view>
                                <view class="coupon-content-valid text-ellipsis">{{ coupon.validLabel }}</view>
                            </view>
                        </view>
                    </view>
                    <!-- /优惠券-内容 -->
                </view>
                <!-- / 优惠券 -->
            </view>

            <!-- 广告位 -->
            <view class="section mt-2" v-if="adUnitCouponDetail">
                <ad-custom :unit-id="adUnitCouponDetail"></ad-custom>
            </view>

            <!-- 使用方式 -->
            <view class="section mt-2 usage-container">
                <view class="section-header">
                    <view class="section-title">核销码</view>
                </view>
                <view class="usage-body">
                    <view class="usage-card-tip text-muted">可用时间：{{ coupon.validTimeLabel }}</view>

                    <!-- 核销码 -->
                    <view class="usage-code mt-2" v-if="coupon.status === RECEIVE_STATUS.UNUSED && !coupon.transferLock">
                        <view class="usage-qrcode">
                            <view class="usage-qrcode-wrap">
                                <image v-if="qrcodeUrl" class="usage-qrcode-image" :src="qrcodeUrl" mode="aspectFit"></image>
                                <m-loading v-else-if="qrcodeLoading"></m-loading>
                            </view>
                            <view class="usage-qrcode-tip text-muted text-small">向店员出示此码完成核销</view>
                        </view>
                    </view>

                    <!-- 卡号 -->
                    <view class="usage-code mt-3">
                        <view class="usage-card-no">
                            <text class="usage-card-no-text">No.{{ utils.formatSeparator(coupon.id, ' ') }}</text>
                        </view>
                        <view class="usage-code-actions">
                            <view class="usage-code-action" @click="onCopyCode(coupon.id)">
                                <t-icon name="copy" size="32rpx" color="#595959"/>
                                <text class="usage-code-action-text">复制卡号</text>
                            </view>
                            <view class="usage-code-action-divider"></view>
                            <view class="usage-code-action" @click="onContactMerchant">
                                <t-icon name="shop-1" size="32rpx" color="#595959"/>
                                <text class="usage-code-action-text">联系商家</text>
                            </view>
                        </view>
                    </view>

                    <!-- 转赠状态 -->
                    <view v-if="coupon.isTransfer && coupon.transferLock" class="usage-card-action">
                        <t-button theme="default" size="medium" block disabled custom-style="width: 400rpx">转赠中</t-button>
                        <text class="text-danger mt-1 text-center" @click="onCancelTransfer">取消转赠</text>
                    </view>

                    <!-- 非可用状态：展示状态文案 -->
                    <view v-else-if="coupon.status !== RECEIVE_STATUS.UNUSED" class="usage-card-action">
                        <t-button theme="default" size="medium" block disabled custom-style="width: 400rpx">{{ coupon.statusLabel }}</t-button>
                    </view>

                    <!-- 同步微信卡包 -->
                    <view
                        v-if="coupon.status === RECEIVE_STATUS.UNUSED && coupon.isAllowWecard && !coupon.isAddWecard && signInfo && signInfo.isAllowWecard"
                        class="usage-card-action mt-2"
                    >
                        <send-coupon
                            @sendcoupon="onSendCoupon"
                            @userconfirm="onWecardConfirm"
                            :suggest_immediate_use="true"
                            :send_coupon_params="signInfo.sendCouponParams"
                            :sign="signInfo.sign"
                            :send_coupon_merchant="signInfo.sendCouponMerchant"
                        >
                            <button class="wecard-button" type="default">同步至微信卡包</button>
                        </send-coupon>
                    </view>

                </view>
                <view class="usage-stores top-line" :class="{ 'bottom-line': (coupon.isAppt || coupon.isVerifyReward || coupon.isTransferReward || (coupon.isTransfer && coupon.status === RECEIVE_STATUS.UNUSED)) && stores.length === 1, 'usage-stores-bottom': stores.length === 1 }">
                    <!--适用门店-->
                    <m-coupon-stores :couponId="coupon.couponId" v-model:stores="stores" theme="cell" />
                </view>
                <t-cell v-if="coupon.isAppt" :note="coupon.apptDesc" :bordered="coupon.isVerifyReward">
                    <template #title>
                        <text class="flex-shrink mr-2">提前预约</text>
                    </template>
                </t-cell>
                <t-cell v-if="coupon.isVerifyReward" title="核销奖励" note="到店核销后可再得本券一张" :bordered="coupon.isTransferReward"></t-cell>
                <t-cell v-if="coupon.isTransferReward" title="转赠奖励" note="转赠并核销后可获得奖励" :bordered="coupon.isTransfer && coupon.status === RECEIVE_STATUS.UNUSED"></t-cell>
                <!--转赠-->
                <template v-if="coupon.isTransfer && coupon.status === RECEIVE_STATUS.UNUSED">
                    <t-cell v-if="!coupon.transferLock" title="转赠给好友" arrow :bordered="false" @click="onSubscribeMessage"></t-cell>
                    <t-cell v-else-if="coupon.transferLock" title="转赠给好友" note="转赠中，可取消转赠" arrow :bordered="false" @click="onCancelTransfer"></t-cell>
                </template>
            </view>

            <!-- 详情、使用须知 -->
            <m-coupon-usage :coupon="coupon"></m-coupon-usage>

            <m-footer></m-footer>

        </view>

        <!-- 优惠券-转赠 -->
        <t-popup placement="bottom" v-model:visible="showTransfer" :z-index="99999">
            <view class="popup-header">
                <view class="popup-header-title">转赠给好友</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="24px" @click="showTransfer = false"/>
                </view>
            </view>
            <view class="popup-share-body">
                <t-textarea v-if="!transferShareKey" custom-style="height: 300rpx; margin-bottom: 32rpx;background-color: #f7f7f7;border-radius: 12rpx;" label="转赠备注" v-model:value="transferRemark" :maxlength="32" :cursor-spacing="120" :indicator="true" placeholder="请输入转赠备注"></t-textarea>
                <!-- 转赠成功态：图标 + 标题 + 提示，填充与输入态一致的固定高度 -->
                <view v-else class="transfer-success">
                    <t-icon name="check-circle-filled" size="80rpx" color="#07C160"/>
                    <view class="transfer-success-title">转赠设置成功</view>
                    <view class="transfer-success-tip">好友领取前可多次分享，仅首位领取好友可获得本券</view>
                </view>
            </view>
            <view class="popup-bottom-action">
                <t-button v-if="!transferShareKey" theme="primary" size="large" block @click="onLockTransfer">确认转赠</t-button>
                <t-button v-else theme="primary" size="large" block open-type="share" @click="onTransferShare">
                    <view class="d-flex align-items-center">
                        <t-icon t-class="mr-1" name="share-1" size="20px"/>
                        分享给微信好友
                    </view>
                </t-button>
            </view>
            <view class="text-muted mt-1 text-center" @click="showTransfer = false">取消</view>
        </t-popup>

    </view>
</template>

<script setup>
import { onLoad, onShow, onHide, onPullDownRefresh, onShareAppMessage, onShareTimeline } from '@dcloudio/uni-app'
import { ref, computed } from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE, RECEIVE_STATUS, isAmountFace} from '@/constants/coupon'
import {RESPONSE_CODE} from '@/constants/code'
import utils from '@/utils/utils'
import dayjs from "dayjs";
import config from "@/config";
import {useLink} from "@/hooks/useLink.js"

const {back} = useLink()

const receiveId = ref('')
const coupon = ref()
const stores = ref([])
const qrcodeUrl = ref('')
const qrcodeLoading = ref(false)
const showTransfer = ref(false)
const transferRemark = ref('')
const transferShareKey = ref()
const errMessage = ref('')
const signInfo = ref(null)

// 优惠券详情页广告位 unit-id
const adUnitCouponDetail = computed(() => {
    if (config.adUnit?.couponDetail && coupon.value?.allowAd) {
        return config.adUnit.couponDetail
    }
    return ''
})

//加载核销码（卡券可用时自动调用）
const loadQrcode = () => {
    qrcodeUrl.value = ''
    errMessage.value = ''
    qrcodeLoading.value = true
    request.get('/user/coupon/receive/verify-qrcode', { id: receiveId.value }, {
        disableErrorToast: true
    }).then((res) => {
        qrcodeUrl.value = res.data.qrcode || ''
    }).catch((err) => {
        errMessage.value = err.message || ''
    }).finally(() => {
        qrcodeLoading.value = false
    })
}

//刷新核销码
const onRefreshQrcode = () => {
    loadQrcode()
}

//转赠时订阅消息提醒
const onSubscribeMessage = () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showTransfer.value = true
        },
        fail() {
            utils.hideLoading()
            showTransfer.value = true
        }
    })
}

//锁定转赠
const onLockTransfer = utils.debounce(() => {
    request.post('/user/coupon/receive/lock-transfer', {
        couponReceiveId: receiveId.value,
        remark: transferRemark.value
    }, { showLoading: true }).then((res) => {
        transferShareKey.value = res.data.shareKey
        coupon.value.transferLock = true

    }).catch(() => {

    })
})

//转赠分享时处理
const onTransferShare = () => {
    showTransfer.value = false
}

//取消转赠
const onCancelTransfer = () => {
    uni.showModal({
        title: '提示',
        content: '确定取消转赠吗？',
        success: (res) => {
            if (res.confirm) {
                request.post('/user/coupon/receive/unlock-transfer', {
                    couponReceiveId :receiveId.value
                }, {
                    disableErrorToast: true
                }).then(res => {
                    coupon.value.transferLock = false
                    transferShareKey.value = ''
                    utils.toast('已取消转赠')
                    loadQrcode()
                }).catch((err) => {
                    errMessage.value = err.message || ''
                })
            }
        }
    })
}


//复制卡券编号
const onCopyCode = (code) => {
    uni.setClipboardData({
        data: code,
        showToast: false,
        success: function() {
            utils.toast('卡券编号已复制到剪切板')
        },
        fail: () => {

        }
    });
}

//联系商家：拨打商家电话
const onContactMerchant = () => {
    utils.makePhoneCall(coupon.value.servicePhone)
}

const getDetail = (params = {}) => {
    const query = {
        id: receiveId.value || undefined,
        ...params,
    }
    request.get('/user/coupon/receive/detail', query).then(res => {
        res.data.validLabel = `${dayjs(res.data.validStartTime).format('YYYY/MM/DD')} 至 ${dayjs(res.data.validEndTime).format('YYYY/MM/DD')}`
        coupon.value = res.data
        receiveId.value = res.data.id || receiveId.value
        signInfo.value = res.data.signInfo || null
        // 卡券可用时自动加载核销码
        if (res.data.status === RECEIVE_STATUS.UNUSED && !res.data.transferLock) {
            loadQrcode()
        }
    }).catch(() => {
        coupon.value = null
        signInfo.value = null
    })
}

const onSendCoupon = (e) => {
    const list = e?.detail?.send_coupon_result || []
    const ok = list.some((item) => item.code === 'SUCCESS' || item.code === 'DUPREQUEST')
    if (ok) {
        request.post('/user/coupon/receive/wecard', {ids: [receiveId.value]}).catch(() => {
        })
        coupon.value.isAddWecard = true
        if (signInfo.value) {
            signInfo.value = {...signInfo.value, isAllowWecard: false}
        }
    }
}

const onWecardConfirm = () => {
    request.post('/user/coupon/receive/wecard', {ids: [receiveId.value]}).catch(() => {
    })
    coupon.value.isAddWecard = true
    if (signInfo.value) {
        signInfo.value = {...signInfo.value, isAllowWecard: false}
    }
}

// 截图监听：截屏时立即刷新核销码，防止截屏盗用
const onScreenCapture = () => {
    if (coupon.value?.status === RECEIVE_STATUS.UNUSED && !coupon.value?.transferLock && coupon.value.isVerifySign) {
        loadQrcode()
    }
}

onLoad((e) => {
    const query = e || {}
    if (query.id) {
        receiveId.value = query.id
        getDetail()
    } else if (query.ciphertext) {
        // 微信卡包「立即使用」：无本地 id，透传加密参数由服务端解密
        getDetail({
            ciphertext: query.ciphertext,
            nonce: query.nonce,
            associate: query.associate,
            stockId: query.stockId,
            openId: query.openId,
        })
    } else {
        coupon.value = null
    }
    uni.onUserCaptureScreen(onScreenCapture)
    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true,
    })
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

onShow(() => {

})

onHide(() => {
    uni.offUserCaptureScreen(onScreenCapture)
})

onShareAppMessage(() => {
    let href = '/pages_user/coupon/transfer_receive?shareKey=' + transferShareKey.value
    return {
        title: transferRemark.value || '领取好友转赠的优惠券',
        imageUrl: coupon.value?.cover,
        desc: transferRemark.value || '',
        path: href
    }
})

onShareTimeline(() => {
    let href = '/pages_user/coupon/transfer_receive?shareKey=' + transferShareKey.value
    return {
        title: transferRemark.value || '领取好友转赠的优惠券',
        imageUrl: coupon.value?.cover,
        desc: transferRemark.value || '',
        path: href
    }
})

</script>

<style scoped>
.coupon-detail-page {
    position: relative;
    min-height: 100vh;
    overflow: hidden;
}

/* 优惠券 */
.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative; /* 【关键】作为内部绝对定位元素的参照物 */
    overflow: hidden; /* 防止内部内容超出圆角 */
}

.merchant {
    display: flex;
    align-items: center;
    margin-bottom: 10rpx;
    padding: 32rpx 32rpx 10rpx 32rpx;
}

.merchant-logo {
    width: 50rpx;
    height: 50rpx;
    border-radius: 50%;
    margin-right: 10rpx;
    flex-shrink: 0;
}

.merchant-header {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.merchant-header-title {
    flex: 1;
    font-size: 28rpx;
    font-weight: 600;
    color: #373737;
}

.coupon {
    position: relative;
    padding: 10rpx 32rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon + .coupon {
    margin-top: 20rpx;
}

.coupon-header {
    margin-right: 30rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
}

.coupon-body {
    position: relative;
    flex: 1;
    /* 金额较长时让 body 可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
}

.coupon-type {
    color: #999;
    font-size: 20rpx;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}
/* /优惠券 */

/* 使用方式卡片 */
.usage-container {

}

.usage-body {
    padding: 0 32rpx;
}

.usage-card-tip {
    font-size: 26rpx;
    margin-bottom: 32rpx;
    color: #777777;
}

.usage-card-action {
    width: 100%;
    margin-top: 96rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.wecard-button {
    width: 400rpx;
    height: 80rpx;
    line-height: 80rpx;
    padding: 0;
    margin: 0;
    border: none;
    border-radius: 12rpx;
    background: #07C160;
    color: #fff;
    font-size: 28rpx;
}

.wecard-button::after {
    border: none;
}

.usage-stores {
    margin-top: 78rpx;
}

.usage-stores-bottom {
    padding-bottom: 32rpx;
}


.cell-title {
    color: #202020;
    font-size: 30rpx;
    font-weight: 600;
    flex-shrink: 0;
}

.cell-note {
    color: #1c1c1c;
    font-size: 30rpx;
    font-weight: 600;
}

.popup-share-body {
    width: 100%;
    background: #fff;
    border-radius: 24rpx;
    padding: 0 32rpx 32rpx;
    box-sizing: border-box;
    /* 固定高度：textarea 300rpx + 间距 32rpx + 底部内边距 32rpx，切换提示语时保持弹框高度一致 */
    height: 364rpx;
}

/* 转赠成功态：居中布局填满与输入态一致的固定高度，避免中部空白 */
.transfer-success {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
}

.transfer-success-title {
    margin-top: 16rpx;
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.transfer-success-tip {
    margin-top: 24rpx;
    font-size: 24rpx;
    color: #999;
    text-align: center;
}

/* 使用方式-条形码+核销码 */
.usage-code {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.usage-card-no {
    margin-top: 8rpx;
}

.usage-card-no-text {
    font-size: 34rpx;
    font-weight: 700;
    color: #1a1a1a;
    letter-spacing: 4rpx;
}

.usage-code-actions {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 10rpx;
}

.usage-code-action {
    display: flex;
    align-items: center;
    padding: 12rpx 28rpx;
}

.usage-code-action-text {
    margin-left: 8rpx;
    font-size: 26rpx;
    color: #595959;
}

.usage-code-action-divider {
    width: 1rpx;
    height: 28rpx;
    background: #e7e7e7;
}

.usage-qrcode {
    display: flex;
    flex-direction: column;
    align-items: center;
}

.usage-qrcode-wrap {
    width: 360rpx;
    height: 360rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.usage-qrcode-image {
    width: 360rpx;
    height: 360rpx;
}

.usage-qrcode-tip {
    margin-top: 8rpx;
}


.coupon.used::after {
    content: " ";
    display: block;
    width: 160rpx;
    height: 160rpx;
    position: absolute;
    top: 0;
    right: 60rpx;
    z-index: 22;
    background: url("/static/img/coupon-used.png") no-repeat center center;
    background-size: contain
}

.coupon.invalid::after {
    content: " ";
    display: block;
    width: 160rpx;
    height: 160rpx;
    position: absolute;
    top: 0;
    right: 60rpx;
    z-index: 22;
    background: url("/static/img/coupon-invalid.png") no-repeat center center;
    background-size: contain
}

.coupon.discard::after {
    content: " ";
    display: block;
    width: 160rpx;
    height: 160rpx;
    position: absolute;
    top: 0;
    right: 60rpx;
    z-index: 22;
    background: url("/static/img/coupon-discard.png") no-repeat center center;
    background-size: contain
}

</style>
