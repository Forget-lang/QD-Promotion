<template>
    <t-tabs v-model:value="currentTab" bottom-line-mode="auto" @change="onTabChange">
        <t-tab-panel label="未使用" :value="1"></t-tab-panel>
        <t-tab-panel label="已使用" :value="2"></t-tab-panel>
        <t-tab-panel label="已作废" :value="3"></t-tab-panel>
        <t-tab-panel label="已过期" :value="4"></t-tab-panel>
    </t-tabs>
    <m-loading v-if="items === undefined"></m-loading>
    <m-empty v-else-if="items === null">
        <view>加载失败</view>
        <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
    </m-empty>
    <view class="container" v-else>
        <view class="paragraph d-flex justify-content-between align-items-baseline" @tap="push('/pages_user/coupon/transfer_list')">
            <view>共 {{ total }} 张优惠券</view>
            <view class="d-flex align-items-center text-success">
                <text class="text-small mr-1">转赠记录</text>
                <t-icon name="chevron-right" size="24rpx" color="currentColor"></t-icon>
            </view>
        </view>
        <m-empty v-if="items.length === 0">暂无优惠券</m-empty>
        <template v-else>
            <view
                v-for="item in items"
                :key="item.id"
                class="receive coupon-wrap"
            >
                <!-- 商户 -->
                <view class="merchant">
                    <image class="merchant-logo" :src="item.merchantLogo" mode="aspectFill"/>
                    <view class="merchant-header">
                        <view class="merchant-header-title">
                            <view class="d-flex align-items-center">
                                <text class="text-ellipsis">{{ item.merchantName }}</text>
                            </view>
                        </view>
                        <view class="merchant-header-extra">
                            <view class="coupon-type">{{ item.couponTypeLabel }}</view>
                        </view>
                    </view>
                </view>
                <view class="coupon-line"></view>

                <!-- 优惠券 -->
                <view
                    class="coupon"
                    :class="{ 'coupon-disabled': currentTab > 1 }"
                    @tap="push('/pages_user/coupon/detail?id=' + item.id)"
                >
                    <view class="coupon-header">
                        <image class="coupon-thumb" :src="item.cover" mode="scaleToFill"/>
                    </view>
                    <view class="coupon-body">
                        <view class="coupon-content">
                            <view class="coupon-content-info">
                                <view class="coupon-content-name text-ellipsis-break">
                                    {{ item.couponName }}
                                </view>
                                <view class="coupon-content-value">
                                    <template v-if="isAmountFace(item.couponType)">
                                        <view class="coupon-content-amount">
                                            <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                            <view class="coupon-amount-discount">元券</view>
                                        </view>
                                    </template>
                                    <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                        <view class="coupon-content-amount">
                                            <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                            <view class="coupon-amount-discount">折券</view>
                                        </view>
                                    </template>
                                    <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                        <view class="coupon-amount">
                                            <image class="exchange-icon" src="/static/img/exchange.png" mode="aspectFit"/>
                                        </view>
                                    </template>
                                    <view class="coupon-threshold">{{ item.threshold }}</view>
                                </view>
                                <view class="coupon-content-valid text-ellipsis">
                                    {{ item.validLabel }}
                                </view>
                            </view>
                            <view v-if="currentTab === 1" class="coupon-content-action">
                                <view class="button-gold">使用</view>
                            </view>
                        </view>
                    </view>
                </view>

                <!-- 印戳 -->
                <image
                    v-if="currentTab > 1"
                    class="coupon-stamp"
                    :src="stampMap[currentTab]"
                    mode="aspectFit"
                />
            </view>
            <m-loading v-if="loadingMore" text="正在加载..."/>
            <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils'
import to from "@/hooks/to";

const {push} = useLink()
// 当前商家（从卡包首页带入）
const merchantId = ref('')
// 当前激活的 Tab（1未使用/2已使用/3已作废/4已过期）
const currentTab = ref(1)
// 列表查询筛选参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: 1,
    merchantId: undefined,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)
// 优惠券总数量
const total = ref(0)
// 印戳图片映射（按 Tab 值）
const stampMap = {
    2: '/static/img/coupon-used.png',
    3: '/static/img/coupon-discard.png',
    4: '/static/img/coupon-invalid.png'
}

// 切换 Tab 筛选
const onTabChange = (e) => {
    search.value.status = e.value
    items.value = undefined
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取优惠券列表数据
const getItems = () => {
    if (!merchantId.value) return
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/user/coupon/receive/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            //只有首次加载失败（请求超时等情况），页面显示网络错误样式，可重试请求
            items.value = null
        } else {
            // 加载失败，页码减一（因为onReachBottom已触发page+1，需要减掉）
            search.value.page--
        }
    }).finally(() => {
         setTimeout(() => {
             loadingMore.value = false
             uni.stopPullDownRefresh()
         }, 500)
    })
}

onLoad((e) => {
    if (!e.merchantId) {
        utils.toast('缺少商家')
        return
    }
    merchantId.value = e.merchantId
    search.value.merchantId = e.merchantId
})

onShow(() => {
    if (!merchantId.value) return
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.receive + .receive {
    margin-top: 20rpx;
}

.coupon-wrap {
    position: relative;
}

.merchant {
    display: flex;
    align-items: center;
    margin-bottom: 10rpx;
    padding: 32rpx 32rpx 10rpx 32rpx;
}

.merchant-logo {
    width: 50rpx;
    height: 50rpx;
    border-radius: 50%;
    margin-right: 10rpx;
    flex-shrink: 0;
}

.merchant-header {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-width: 0;
}

.merchant-header-title {
    flex: 1;
    min-width: 0;
    font-size: 28rpx;
    font-weight: 600;
    color: #373737;
}

.merchant-header-extra {
    flex-shrink: 0;
    margin-left: 16rpx;
}

.coupon-type {
    color: #999;
    font-size: 20rpx;
}

.coupon {
    padding: 10rpx 32rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon.coupon-disabled {
    filter: grayscale(1);
}

.coupon-header {
    margin-right: 30rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #181818;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    margin-top: 8rpx;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

.coupon-stamp {
    position: absolute;
    right: 30rpx;
    top: 0;
    bottom: 0;
    margin: auto 0;
    width: 160rpx;
    height: 160rpx;
    z-index: 10;
    pointer-events: none;
}
</style>
