<template>
    <m-navigation-bar :scrollY="scrollY" :threshHeight="swiperHeight" :hasCover="!!coupon">
        <template #title>
            <view class="merchant-info" v-if="merchant" :class="{ 'scrolled': scrollY >= swiperHeight }" @click="goMerchant">
                <image class="merchant-logo" :src="merchant.logo" mode="aspectFill" />
                <text class="merchant-name">{{ merchant.name }}</text>
                <t-icon name="chevron-right" size="28rpx" :color="scrollY >= swiperHeight ? '#333' : '#fff'" />
            </view>
        </template>
    </m-navigation-bar>

    <!-- 加载状态 -->
    <m-loading v-if="coupon === undefined"></m-loading>

    <!-- 空状态 -->
    <m-empty :height="800" v-else-if="!coupon">暂无数据</m-empty>

    <template v-else>
        <view class="container-safety">
            <!-- 封面图 -->
            <view class="coupon-covers">
                <t-swiper :list="coupon.coverImages" :height="swiperHeight" :navigation="coupon.coverImages.length > 1" :autoplay="true" :loop="true"/>
            </view>
            <!-- /封面图 -->

            <!-- 快闪框 -->
            <m-coupon-flash :coupon="coupon" />
            <!-- /快闪框 -->

            <!-- 领券结束倒计时-->
            <view class="container mt-2" v-if="endCountdown > 0">
                <view class="countdown countdown-end">
                    <view class="countdown-glow"></view>
                    <view class="countdown-content">
                        <view class="countdown-label countdown-label-urgent">距离领取结束时间还有</view>
                        <view class="d-flex justify-content-center">
                            <t-count-down :time="endCountdown * 1000"
                                          :format="endCountdownFormat"
                                          :split-with-unit="endCountdownHasDays"
                                          content="default" theme="square"
                                          @finish="onEndCountDownFinish"/>
                        </view>
                    </view>
                </view>
            </view>
            <!-- / 领券结束倒计时 -->

            <!-- 内容区域 -->
            <view class="container">
                <!-- 优惠券卡片 -->
                <view class="mt-2">
                    <m-coupon-tpl :coupon="coupon" :receive-count="issue.issueCount"/>
                </view>

                <!-- 广告位-->
                <view class="section mt-2" v-if="adUnitCouponReceivePrivate">
                    <ad-custom :unit-id="adUnitCouponReceivePrivate"></ad-custom>
                </view>

                <view class="section mt-2">
                    <!--适用门店-->
                    <m-coupon-stores :couponId="couponId" v-model:stores="stores" />
                    <!--使用须知-->
                    <m-coupon-intro :coupon="coupon" />
                </view>

                <!-- 详情 -->
                <m-coupon-usage :coupon="coupon" />

                <!-- 适用门店列表 -->
                <view class="section mt-2" v-if="stores.length > 1">
                    <view class="section-header">
                        <view class="section-title">适用门店</view>
                    </view>
                    <m-usage-stores :stores="stores"/>
                </view>

                <!-- 商家门头 -->
                <view class="section mt-2">
                    <image style="width:100%;height:auto;display:block;border-radius: 20rpx" :src="merchant.cover" mode="widthFix" />
                </view>
            </view>

            <m-footer></m-footer>

            <!-- 底部留出安全区域的距离 -->
            <view style="height: 90rpx;"></view>
        </view>

        <!-- 底部固定区域  -->
        <view class="bottom-fixed-bar">
            <view class="bottom-fixed-body">
                <view class="bottom-left" @click="goMerchant">
                    <image class="bottom-merchant-logo" :src="merchant.logo" mode="aspectFill" />
                    <view class="bottom-merchant-info">
                        <view class="bottom-merchant-name text-center text-ellipsis-break">{{ merchant.name }}</view>
                    </view>
                </view>
                <view class="bottom-right">
                    <view class="button-receive disable" v-if="isReceiveEnded">领取已超时</view>
                    <!-- 已被领取  -->
                    <view class="button-receive primary" v-else-if="issue.status === ISSUE_PRIVATE_STATUS.RECEIVED" @click="reLaunch('/pages/index/index')">查看已领的卡券</view>
                    <view class="button-receive disable" v-else-if="issue.status === ISSUE_PRIVATE_STATUS.EXPIRED">领取已超时</view>
                    <!-- 暂停发放  -->
                    <view class="button-receive disable" v-else-if="coupon.status === COUPON_STATUS.PAUSED">活动已停止</view>
                    <!-- 卡券已作废  -->
                    <view class="button-receive disable" v-else-if="coupon.status === COUPON_STATUS.DISCARDED">卡券已作废</view>
                    <!-- 卡券已过期 -->
                    <view class="button-receive disable" v-else-if="coupon.status === COUPON_STATUS.EXPIRED">活动已结束</view>
                    <view class="button-receive flex-column primary" @click="onSubscribeMessage" v-else>
                        领取卡券
                        <view class="button-receive-remark">{{ coupon.couponTypeLabel }} *
                            {{ issue.issueCount }}张
                        </view>
                    </view>
                </view>
            </view>
        </view>

        <!-- 领券前完善信息弹窗 -->
        <m-coupon-receive-profile v-model:visible="showProfile" :merchant="merchant" :profile-option="profileOption" :on-receive="onReceiveCoupon" />
    </template>

    <!-- 订阅消息提示动图 -->
    <view class="subscribe-gif-wrap" v-if="showSubscribeGif" @click="showSubscribeGif = false">
        <image class="subscribe-gif" src="https://cdn.lenmy.com/quandao/img/subscribe_message.gif" mode="widthFix" />
    </view>
</template>

<script setup>
import { onLoad, onPullDownRefresh, onPageScroll } from '@dcloudio/uni-app'
import {computed, ref} from "vue";
import request from "@/hooks/request";
import {COUPON_STATUS, ISSUE_PRIVATE_STATUS} from "@/constants/coupon";
import utils from "@/utils/utils";
import config from "@/config";
import {useLink} from "@/hooks/useLink.js"

import {useSessionStore} from "@/stores/session";
const {reLaunch, push} = useLink()

const session = useSessionStore()

const couponId = ref()
const merchantId = ref()
const couponIssueId = ref()
const inviterId = ref()
const coupon = ref()
const merchant = ref()
const issue = ref()
const stores = ref([])
const scrollY = ref(0)
const swiperHeight = uni.getWindowInfo().screenWidth * 4 / 5
const showProfile = ref(false)
const profileOption = ref({
    isGetMobile: false,
    registerType: 1
})
const endCountdown = ref(0)
const isReceiveEnded = ref(false)
const showSubscribeGif = ref(false)
// 领取倒计时是否超过 24 小时
const endCountdownHasDays = computed(() => endCountdown.value >= 86400)
// 领取倒计时格式（超过 24 小时显示天数）
const endCountdownFormat = computed(() => endCountdownHasDays.value ? 'DD:HH:mm:ss' : 'HH:mm:ss')

// 私密领券页广告位 unit-id
const adUnitCouponReceivePrivate = computed(() => {
    if (config.adUnit?.couponReceivePrivate && merchant.value?.allowAd) {
        return config.adUnit.couponReceivePrivate
    }
    return ''
})

// 检查领券订阅消息是否会弹出订阅弹框
const willShowSubscribePopup = () => {
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const itemSettings = res.subscriptionsSetting
            const hasUndecided = config.subscribeMessage.couponReceive.some(
                tmplId => itemSettings[tmplId] !== 'accept' && itemSettings[tmplId] !== 'reject'
            )
            showSubscribeGif.value = hasUndecided
        },
        fail() {
            // 静默失败
        }
    })
}

// 点击领券按钮订阅消息
const onSubscribeMessage = utils.debounce(async () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        },
        fail() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        }
    })
    willShowSubscribePopup()
})

// 领券请求
const onReceiveCoupon = (profileData) => {
    return new Promise((resolve, reject) => {
        const randomDelay = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        const params = {
            couponId: couponId.value,
            couponIssueId: couponIssueId.value,
            merchantId: merchantId.value,
            mobile: profileData.mobile,
            cipherCode: profileData.cipherCode,
            inviterId: inviterId.value,
            scene: session.appletScene, // 小程序场景值
            os: session.getDeviceInfo('os'),
            device: session.getDeviceInfo('device')
        }
        request.post('/user/coupon/private/receive', params, {
            disableErrorToast: true
        }).then(res => {
            issue.value.status = ISSUE_PRIVATE_STATUS.RECEIVED
            endCountdown.value = 0
            isReceiveEnded.value = false
            setTimeout(() => resolve(res), randomDelay)
        }).catch((err) => {
            setTimeout(() => reject(err), randomDelay)
        })
    })
}

// 结束倒计时结束
const onEndCountDownFinish = () => {
    endCountdown.value = 0
    isReceiveEnded.value = true
}

// 跳转商家主页
const goMerchant = () => {
    push('/pages_user/merchant/home?merchantId=' + merchant.value.id)
}

// 有领取过期时间时：初始化倒计时
const initCountdown = () => {
    if (issue.value.expireMinute > 0 && issue.value.status === ISSUE_PRIVATE_STATUS.VALID && coupon.value.status === COUPON_STATUS.ISSUING) {
        endCountdown.value = issue.value.expireCountdownTime ?? 0
        isReceiveEnded.value = endCountdown.value <= 0
    }
}

// 优惠券详情
const getCoupon = () => {
    request.get('/coupon/private/issue/detail', {
        couponId: couponId.value,
        couponIssueId: couponIssueId.value
    }, { showLoading: false }).then(res => {
        couponId.value = res.data.coupon.id
        merchantId.value = res.data.merchant.id
        coupon.value = res.data.coupon
        merchant.value = res.data.merchant
        issue.value = res.data.issue
        //初始化倒计时
        initCountdown()
        //获取领券信息设置项
        profileOption.value = {
            isGetMobile: coupon.value.isGetMobile,
            isMobileLimit: coupon.value.isMobileLimit,
            registerType: merchant.value.registerType,
            cipherType: coupon.value.cipherType || 0,
        }

    }).catch(() => {
        coupon.value = null
        merchant.value = null
    })
}

onLoad((e) => {
    if (e.i) couponIssueId.value = e.i
    if (e.inviterId) inviterId.value = e.inviterId
    if (e.scene) couponIssueId.value = decodeURIComponent(e.scene)

    if (couponIssueId.value) {
        getCoupon()
    } else {
        // 缺少发放 ID，直接展示无数据态，避免长期加载中
        coupon.value = null
    }

    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true
    })
})

onPullDownRefresh(() => {
    getCoupon()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

onPageScroll((e) => {
    if (e.scrollTop < 360) {
        scrollY.value = e.scrollTop
    }
})

</script>

<style scoped>

.coupon-covers {
    width: 100%;
    overflow: hidden;
}

:deep(.coupon-covers .t-swiper) {
    --td-swiper-radius: 0;
    border-radius: 0 !important;
}

:deep(.coupon-covers .t-swiper-nav--bottom) {
    bottom: 45rpx !important;
}

/* 商户信息 - 滚动过渡优化 */
.merchant-info {
    display: flex;
    align-items: center;
    gap: 8rpx;
    color: #fff;
    padding: 8rpx 16rpx;
    border-radius: 32rpx;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    margin: 0 10rpx;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
}

.merchant-info.scrolled {
    background: rgba(255, 255, 255, 0.98);
    color: #333;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.1);
    transform: scale(0.96);
}

.merchant-logo {
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.merchant-info.scrolled .merchant-logo {
    transform: scale(0.9);
}

.merchant-name {
    font-size: 28rpx;
    font-weight: 500;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    transition: font-weight 0.3s ease;
}

.merchant-info.scrolled .merchant-name {
    font-weight: 600;
}

/* 倒计时 - 增强视觉层次 */
.countdown {
    position: relative;
    overflow: hidden;
    font-size: 28rpx;
    background: #fff;
    text-align: center;
    padding: 24rpx 32rpx;
    border-radius: 20rpx;
    box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.04);
}

/* 发光动画效果 */
.countdown-glow {
    position: absolute;
    top: -50%;
    left: -50%;
    width: 200%;
    height: 200%;
    background: radial-gradient(circle, rgba(246, 56, 11, 0.06) 0%, transparent 70%);
    animation: glow-pulse 3s ease-in-out infinite;
    pointer-events: none;
}

@keyframes glow-pulse {
    0%, 100% { opacity: 0.5; transform: scale(1); }
    50% { opacity: 1; transform: scale(1.05); }
}

/* 结束倒计时 - 红色紧迫感 */
.countdown-end {
    border: 2px solid #f6380b;
    background: linear-gradient(135deg, #fff 0%, #fff5f0 100%);
}

.countdown-content {
    position: relative;
    z-index: 1;
}

.countdown-label {
    margin-bottom: 12rpx;
    color: #666;
    font-size: 26rpx;
}

.countdown-label-urgent {
    color: #f6380b;
    font-weight: 600;
}

/* 底部固定栏 - 视觉层次优化 */
.bottom-fixed-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #f2f2f2;
    padding-bottom: env(safe-area-inset-bottom);
}

.bottom-fixed-body {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 24rpx;
    padding: 20rpx 32rpx;
}

.bottom-left {
    display: flex;
    align-items: center;
    background-color: #fff;
    height: 100rpx;
    width: 260rpx;
    border-radius: 999px;
    padding: 0 26rpx;
}

.bottom-right {
    flex: 1;
}

.bottom-merchant-logo {
    width: 64rpx;
    height: 64rpx;
    border-radius: 50%;
    flex-shrink: 0;
    margin-right: 16rpx;
}

.bottom-merchant-info {
    flex: 1;
    overflow: hidden;
}

.bottom-merchant-name {
    font-size: 28rpx;
    font-weight: bold;
    color: #1a1a1a;
    overflow: hidden;
    margin-bottom: 4rpx;
}

/* 订阅消息动图 */
.subscribe-gif-wrap {
    position: fixed;
    top: 25vh;
    right: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.subscribe-gif {
    width: 600rpx;
    border-radius: 16rpx;
}

</style>
