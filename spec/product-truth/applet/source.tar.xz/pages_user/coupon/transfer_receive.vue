<template>
    <m-navigation-bar :scrollY="scrollY" :threshHeight="swiperHeight" :hasCover="!!coupon">
        <template #title>
            <view class="merchant-info" v-if="merchant" :class="{ 'scrolled': scrollY >= swiperHeight }" @click="goMerchant">
                <image class="merchant-logo" :src="merchant.logo" mode="aspectFill" />
                <text class="merchant-name">{{ merchant.name }}</text>
                <t-icon name="chevron-right" size="28rpx" :color="scrollY >= swiperHeight ? '#333' : '#fff'" />
            </view>
        </template>
    </m-navigation-bar>

    <!-- 加载状态 -->
    <m-loading v-if="coupon === undefined"></m-loading>

    <!-- 空状态 -->
    <m-empty :height="800" v-else-if="!coupon">暂无数据</m-empty>

    <template v-else>
        <view class="container-safety">
            <!-- 封面图 -->
            <view class="coupon-covers">
                <t-swiper :list="coupon.coverImages" :height="swiperHeight" :navigation="coupon.coverImages.length > 1" :autoplay="coupon.coverImages.length > 1" :loop="coupon.coverImages.length > 1"/>
            </view>
            <!-- /封面图 -->

            <!-- 快闪框 -->
            <view class="coupon-flash">
                <view class="coupon-flash-price">
                    <!-- 代金券 -->
                    <template v-if="coupon.couponType === COUPON_TYPE.CASH">
                        <view class="coupon-flash-unit">￥</view>
                        <view class="coupon-flash-money">{{ coupon.couponAmount }}</view>
                        <view class="coupon-flash-delete">抵用￥{{coupon.originalPrice }}</view>
                    </template>
                    <!-- 套餐券 -->
                    <template v-if="coupon.couponType === COUPON_TYPE.PACKAGE">
                        <view class="coupon-flash-unit">￥</view>
                        <view class="coupon-flash-money">{{ coupon.couponAmount }}</view>
                        <view class="coupon-flash-delete text-decoration">原价￥{{coupon.originalPrice }}</view>
                    </template>
                    <!-- 满减券 -->
                    <template v-if="coupon.couponType === COUPON_TYPE.REDUCE">
                        <view class="coupon-flash-unit">￥</view>
                        <view class="coupon-flash-money">{{ coupon.couponAmount }}</view>
                        <view class="coupon-flash-delete">{{ coupon.threshold }}</view>
                    </template>
                    <!-- 折扣券 -->
                    <template v-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                        <view class="coupon-flash-money">{{ coupon.couponAmount }}</view>
                        <view class="coupon-flash-unit ml-1" style="font-size: 32rpx;">折</view>
                        <view class="coupon-flash-delete">{{ coupon.threshold }}</view>
                    </template>
                    <!-- 兑换券 -->
                    <template v-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                        <view class="coupon-flash-money text-ellipsis-break" style="max-width: 320rpx;font-size: 36rpx">{{ coupon.couponAmount }}</view>
                    </template>
                    <!-- 手气券 -->
                    <template v-if="coupon.couponType === COUPON_TYPE.RANDOM">
                        <view class="coupon-flash-unit">￥</view>
                        <view class="coupon-flash-money">{{ coupon.couponAmount }}</view>
                        <view class="coupon-flash-delete">{{ coupon.threshold }}</view>
                    </template>
                    <view class="coupon-flash-type">
                        <t-icon name="gift-filled" color="#ff3a0b" size="30rpx"></t-icon>
                        <text class="ml-1">{{coupon.couponTypeLabel}}</text>
                    </view>
                </view>
                <view class="coupon-flash-meta">
                    <view class="coupon-flash-tag">{{coupon.isAppt?'需预约':'无需预约'}}</view>
                    <view class="coupon-flash-tag ml-1">{{coupon.isTransfer?'可转赠':'不可转赠'}}</view>
                    <view class="coupon-flash-tag ml-1" v-if="coupon.isVerifyReward">核销有奖</view>
                    <view class="coupon-flash-tag ml-1" v-if="coupon.isTransferReward">转赠有奖</view>
                </view>
            </view>
            <!-- /快闪框 -->

            <!-- 内容区域 -->
            <view class="container">
                <!-- 优惠券卡片 -->
                <view class="mt-2">
                    <view class="coupon">
                        <!-- 内容 -->
                        <view class="coupon-body">
                            <view class="coupon-name">
                                <view class="text-ellipsis-break">{{ coupon.name }}</view>
                            </view>
                            <view v-if="coupon.couponType === COUPON_TYPE.EXCHANGE" class="coupon-exchange text-ellipsis-break">{{
                                    coupon.couponAmount
                                }}
                            </view>
                            <view v-else class="coupon-valid text-ellipsis-break">{{ coupon.validLabel }}</view>
                        </view>

                        <!-- 金额 -->
                        <view class="coupon-fee">
                            <!-- 代金券\套餐券\满减券\手气券 -->
                            <template v-if="isAmountFace(coupon.couponType)">
                                <view class="coupon-amount">
                                    <text class="coupon-amount-unit">¥</text>
                                    <text class="coupon-amount-money">{{ coupon.couponAmount }}</text>
                                </view>
                            </template>

                            <!-- 折扣券 -->
                            <template v-else-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                                <view class="coupon-amount">
                                    <text class="coupon-amount-money">{{ coupon.couponAmount }}</text>
                                    <text class="coupon-amount-discount">折</text>
                                </view>
                            </template>

                            <!-- 兑换券 -->
                            <template v-else-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                                <view class="coupon-amount">
                                    <img class="exchange-icon" src="/static/img/exchange.png" alt="">
                                </view>
                            </template>

                            <view class="coupon-threshold">{{ coupon.threshold }}</view>
                        </view>
                    </view>
                </view>

                <view class="section mt-2">
                    <!--适用门店-->
                    <m-coupon-stores :couponId="coupon.id" v-model:stores="stores" />
                    <!--使用须知-->
                    <m-coupon-intro :coupon="coupon" />
                </view>

                <!-- 详情 -->
                <m-coupon-usage :coupon="coupon" />

                <!-- 适用门店列表 -->
                <view class="section mt-2" v-if="stores.length > 1">
                    <view class="section-header">
                        <view class="section-title">适用门店</view>
                    </view>
                    <m-usage-stores :stores="stores"/>
                </view>

                <!-- 商家门头 -->
                <view class="section mt-2">
                    <image style="width:100%;height:auto;display:block;border-radius: 20rpx" :src="merchant.cover" mode="widthFix" />
                </view>

            </view>

            <m-footer></m-footer>

            <!-- 底部留出安全区域的距离 -->
            <view style="height: 90rpx;"></view>
        </view>

        <!-- 转赠领取不能被领取提示 -->
        <view class="floating-notification" v-if="showNotice">
            <t-notice-bar :content="transfer.invalidReason" theme="error" :prefixIcon="true" :suffixIcon="'close'" :visible="true" @click="showNotice = false" />
        </view>

        <!-- 底部固定区域  -->
        <view class="bottom-fixed-bar">
            <view class="bottom-fixed-body">
                <view class="bottom-left" @click="goMerchant">
                    <image class="bottom-merchant-logo" :src="merchant.logo" mode="aspectFill" />
                    <view class="bottom-merchant-info">
                        <view class="bottom-merchant-name text-center text-ellipsis-break">{{ merchant.name }}</view>
                    </view>
                </view>
                <view class="bottom-right">
                    <view v-if="transfer.isValid" class="button-receive flex-column primary" @click="onSubscribeMessage">领取转赠的卡券</view>
                    <view v-else class="button-receive flex-column disable">领取转赠的卡券</view>
                </view>
            </view>
        </view>

        <!-- 领券前完善信息弹窗 -->
        <m-coupon-receive-profile v-model:visible="showProfile" :merchant="merchant" :profile-option="profileOption" :on-receive="onReceiveCoupon" />
    </template>

    <!-- 订阅消息提示动图 -->
    <view class="subscribe-gif-wrap" v-if="showSubscribeGif" @click="showSubscribeGif = false">
        <image class="subscribe-gif" src="https://cdn.lenmy.com/quandao/img/subscribe_message.gif" mode="widthFix" />
    </view>
</template>

<script setup>
import { onLoad, onPullDownRefresh, onPageScroll } from '@dcloudio/uni-app'
import {ref} from "vue";
import request from "@/hooks/request";
import {COUPON_TYPE, isAmountFace} from "@/constants/coupon";
import utils from "@/utils/utils";
import config from "@/config";
import dayjs from "dayjs";
import {useLink} from "@/hooks/useLink.js"
import {useSessionStore} from "@/stores/session";
const {push} = useLink()

const session = useSessionStore()

const shareKey = ref()
const coupon = ref()
const transfer = ref()
const merchant = ref()
const stores = ref([])
const scrollY = ref(0)
const swiperHeight = uni.getWindowInfo().screenWidth * 4 / 5
const showProfile = ref(false)
const profileOption = ref({
    isGetMobile: false,
    registerType: 1
})
const showSubscribeGif = ref(false)
const showNotice = ref(false)

// 检查领券订阅消息是否会弹出订阅弹框
const willShowSubscribePopup = () => {
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const itemSettings = res.subscriptionsSetting
            const hasUndecided = config.subscribeMessage.couponReceive.some(
                tmplId => itemSettings[tmplId] !== 'accept' && itemSettings[tmplId] !== 'reject'
            )
            showSubscribeGif.value = hasUndecided
        },
        fail() {
            // 静默失败
        }
    })
}

// 点击领券按钮订阅消息
const onSubscribeMessage = utils.debounce(async () => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        success() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        },
        fail() {
            utils.hideLoading()
            showProfile.value = true
            showSubscribeGif.value = false
        }
    })
    willShowSubscribePopup()
})

// 领券请求
const onReceiveCoupon = (profileData) => {
    return new Promise((resolve, reject) => {
        const randomDelay = Math.floor(Math.random() * (2000 - 1000 + 1)) + 1000
        request.post('/user/coupon/transfer/receive', {
            shareKey: shareKey.value,
            mobile: profileData.mobile,
            scene: session.appletScene, // 小程序场景值
            os: session.getDeviceInfo('os'),
            device: session.getDeviceInfo('device')
        }, {
            disableErrorToast: true
        }).then(res => {
            setTimeout(() => resolve(res), randomDelay)
        }).catch((err) => {
            setTimeout(() => reject(err), randomDelay)
        })
    })
}

// 优惠券详情
const getCoupon = () => {
    request.get('/coupon/transfer', {
        shareKey: shareKey.value,
    }, { showLoading: false }).then(res => {
        res.data.coupon.couponAmount = res.data.receive.couponAmount
        res.data.coupon.originalPrice = res.data.receive.originalPrice
        res.data.coupon.validLabel = `${dayjs(res.data.receive.validStartTime).format('YYYY.MM.DD')} ~ ${dayjs(res.data.receive.validEndTime).format('YYYY.MM.DD')}`
        coupon.value = res.data.coupon
        merchant.value = res.data.merchant
        transfer.value = res.data.transfer
        showNotice.value = !res.data.transfer.isValid

        //获取领券信息设置项
        profileOption.value = {
            isGetMobile: coupon.value.isGetMobile,
            registerType: merchant.value.registerType,
        }

        uni.hideShareMenu()
        uni.updateShareMenu({
            withShareTicket: true,
            isPrivateMessage: true
        })

    }).catch(() => {
        coupon.value = null
        merchant.value = null
    })
}

// 跳转商家主页
const goMerchant = () => {
    push('/pages_user/merchant/home?merchantId=' + merchant.value.id)
}

onLoad((e) => {
    if (e.shareKey) shareKey.value = e.shareKey

    if (shareKey.value) {
        getCoupon()
    }
})

onPullDownRefresh(() => {
    getCoupon()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

onPageScroll((e) => {
    if (e.scrollTop < 360) {
        scrollY.value = e.scrollTop
    }
})

</script>

<style scoped>

.coupon-covers {
    width: 100%;
    overflow: hidden;
}

:deep(.coupon-covers .t-swiper) {
    --td-swiper-radius: 0;
    border-radius: 0 !important;
}

:deep(.coupon-covers .t-swiper-nav--bottom) {
    bottom: 45rpx !important;
}

/* 商户信息 - 滚动过渡优化 */
.merchant-info {
    display: flex;
    align-items: center;
    gap: 8rpx;
    color: #fff;
    padding: 8rpx 16rpx;
    border-radius: 32rpx;
    transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
    margin: 0 10rpx;
    backdrop-filter: blur(8px);
    -webkit-backdrop-filter: blur(8px);
}

.merchant-info.scrolled {
    background: rgba(255, 255, 255, 0.98);
    color: #333;
    box-shadow: 0 4rpx 12rpx rgba(0, 0, 0, 0.1);
    transform: scale(0.96);
}

.merchant-logo {
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    flex-shrink: 0;
    transition: transform 0.3s ease;
}

.merchant-info.scrolled .merchant-logo {
    transform: scale(0.9);
}

.merchant-name {
    font-size: 28rpx;
    font-weight: 500;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    transition: font-weight 0.3s ease;
}

.merchant-info.scrolled .merchant-name {
    font-weight: 600;
}

/* 浮动通知 */
.floating-notification {
    position: fixed;
    bottom: calc(150rpx + constant(safe-area-inset-bottom));
    bottom: calc(150rpx + env(safe-area-inset-bottom));
    left: 0;
    right: 0;
    z-index: 100;
    background: transparent;
    transition: all 0.3s ease;
}

/* 底部固定栏 - 视觉层次优化 */
.bottom-fixed-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #f2f2f2;
    padding-bottom: env(safe-area-inset-bottom);
}

.bottom-fixed-body {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 24rpx;
    padding: 20rpx 32rpx;
}

.bottom-left {
    display: flex;
    align-items: center;
    background-color: #fff;
    height: 100rpx;
    width: 260rpx;
    border-radius: 999px;
    padding: 0 26rpx;
}

.bottom-right {
    flex: 1;
}

.bottom-merchant-logo {
    width: 64rpx;
    height: 64rpx;
    border-radius: 50%;
    flex-shrink: 0;
    margin-right: 16rpx;
}

.bottom-merchant-info {
    flex: 1;
    overflow: hidden;
}

.bottom-merchant-name {
    font-size: 28rpx;
    font-weight: bold;
    color: #1a1a1a;
    overflow: hidden;
    margin-bottom: 4rpx;
}

/* 订阅消息动图 */
.subscribe-gif-wrap {
    position: fixed;
    top: 25vh;
    right: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.subscribe-gif {
    width: 600rpx;
    border-radius: 16rpx;
}

/* 快闪框样式 */
.coupon-flash {
    border-radius: 32rpx 32rpx 0 0;
    margin-top: -30rpx;
    padding: 32rpx;
    background: #ff3a0b url("https://cdn.lenmy.com/quandao/2026/05/21/d87cnr4lbp0t6seglksg.png") no-repeat right bottom;
    background-size: 50%;
    position: relative;
    color: #fff;
}

.coupon-flash-price {
    display: flex;
    align-items: center;
}

.coupon-flash-unit {
    font-size: 48rpx;
}

.coupon-flash-money {
    font-size: 64rpx;
    font-weight: 600;
}
.coupon-flash-delete {
    color: rgba(255,255,255,0.8);
    margin-left: 20rpx;
    font-size: 24rpx;
}
.coupon-flash-type {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    margin-left: 20rpx;
    background: #fff;
    font-size:22rpx;
    border-radius: 8rpx;
    padding:5rpx 16rpx;
    color:#ff3a0b;
    font-weight: 600;
}
.coupon-flash-meta{
    margin-top:10rpx;
    display: flex;
    align-items: center;
}
.coupon-flash-tag{
    font-size:24rpx;
    color:#fff;
    background: rgba(255,255,255,0.3);
    border-radius: 8rpx;
    padding:5rpx 16rpx;
}

/* 优惠券卡片样式 */
.coupon {
    position: relative;
    background: #fff;
    border-radius: 20rpx;
    padding: 32rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.coupon-fee {
    max-width: 230rpx;
    text-align: right;
}

.coupon-amount {
    display: flex;
    align-items: flex-start;
    justify-content: flex-end;
    color: #f14752;
    gap: 5rpx;
}

.coupon-amount-money {
    font-size: 64rpx;
    font-weight: 600;
}

.coupon-amount-unit {
    font-size: 28rpx;
    font-weight: 600;
    margin-right: 4rpx;
    margin-top: 12rpx;
}

.coupon-amount-discount {
    margin-left: 4rpx;
    font-size: 28rpx;
    font-weight: 600;
    line-height: 30rpx;
    margin-top: 12rpx;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    font-size: 24rpx;
    color: #e2443d;
    margin-top: 6rpx;
}

.coupon-body {
    flex: 1;
    padding-right: 48rpx;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin-top: 8rpx;
}

.coupon-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #272727;
    margin-bottom: 28rpx;
    display: flex;
    align-items: center;
    gap: 10rpx;
}

.coupon-count {
    width: 58rpx;
    flex-shrink: 0;
    font-size: 20rpx;
    background: #e2443d;
    color: #fff;
    border-radius: 10rpx;
    padding: 4rpx 0;
    text-align: center;
    font-weight: normal;
}

.coupon-valid {
    color: #78797f;
}

.coupon-exchange {
    color: #78797f;
    margin-bottom: 10rpx;
}

</style>
