<template>
    <view class="page">
        <t-tabs v-model:value="currentTab" bottom-line-mode="auto" @change="onTabChange">
            <t-tab-panel label="全部" :value="0"></t-tab-panel>
            <t-tab-panel label="转赠中" :value="1"></t-tab-panel>
            <t-tab-panel label="已成功" :value="3"></t-tab-panel>
            <t-tab-panel label="已取消" :value="2"></t-tab-panel>
        </t-tabs>

        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <view class="container mt-2" v-else>
            <m-empty v-if="items.length === 0">暂无转赠记录</m-empty>
            <template v-else>
                <view
                    v-for="item in items"
                    :key="item.id"
                    class="receive"
                >
                    <!-- 商户 -->
                    <view class="merchant">
                        <image class="merchant-logo" :src="item.merchantLogo" mode="aspectFill"/>
                        <view class="merchant-header">
                            <view class="merchant-header-title">
                                <view class="d-flex align-items-center">
                                    <text class="text-ellipsis">{{ item.merchantName }}</text>
                                </view>
                            </view>
                            <view class="merchant-header-extra">
                                <view class="transfer-status" :class="'transfer-status-' + item.status">
                                    {{ item.statusLabel }}
                                </view>
                            </view>
                        </view>
                    </view>
                    <view class="coupon-line"></view>

                    <!-- 优惠券 -->
                    <view
                        class="coupon"
                        :class="{ 'coupon--clickable': item.status !== TRANSFER_STATUS.RECEIVED }"
                        @tap="onItemTap(item)"
                    >
                        <view class="coupon-header">
                            <image class="coupon-thumb" :src="item.cover" mode="scaleToFill"/>
                        </view>
                        <view class="coupon-body">
                            <view class="coupon-content">
                                <view class="coupon-content-info">
                                    <view class="coupon-content-name text-ellipsis-break">
                                        {{ item.couponName }}
                                    </view>
                                    <view class="coupon-content-value">
                                        <template v-if="isAmountFace(item.couponType)">
                                            <view class="coupon-content-amount">
                                                <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                <view class="coupon-amount-discount">元券</view>
                                            </view>
                                        </template>
                                        <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                            <view class="coupon-content-amount">
                                                <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                <view class="coupon-amount-discount">折券</view>
                                            </view>
                                        </template>
                                        <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                            <view class="coupon-amount">
                                                <img class="exchange-icon" src="/static/img/exchange.png" alt="">
                                            </view>
                                        </template>
                                        <view class="coupon-threshold">{{ item.threshold }}</view>
                                    </view>
                                    <view class="coupon-content-valid text-ellipsis">
                                        {{ item.validLabel }}
                                    </view>
                                </view>
                                <view class="coupon-content-action">
                                    <view v-if="item.status === TRANSFER_STATUS.TRANSFERRING" class="button-gold">查看</view>
                                    <view v-else-if="item.status === TRANSFER_STATUS.RECEIVED" class="button-gold button-gold--muted">
                                        已领取
                                    </view>
                                    <view v-else-if="item.status === TRANSFER_STATUS.CANCELED" class="button-gold button-gold--muted">
                                        已取消
                                    </view>
                                </view>
                            </view>
                        </view>
                    </view>

                    <view class="coupon-line"></view>

                    <!-- 转赠信息 -->
                    <view class="transfer-info">
                        <view v-if="item.remark" class="transfer-info-remark">
                            <t-icon name="chat" size="28rpx" color="#b6b6b6"/>
                            <text class="transfer-info-remark-text">{{ item.remark }}</text>
                        </view>
                        <view class="transfer-info-row">
                            <text class="transfer-info-label">发起时间</text>
                            <text class="transfer-info-value">{{ formatTime(item.sharedAt) }}</text>
                        </view>
                        <view v-if="item.status === TRANSFER_STATUS.RECEIVED && item.receiverNickname" class="transfer-info-row">
                            <text class="transfer-info-label">领取好友</text>
                            <view class="transfer-info-value transfer-info-value--receiver">
                                <image class="receiver-avatar" :src="item.receiverAvatar" mode="aspectFill"/>
                                <text>{{ item.receiverNickname }}</text>
                            </view>
                        </view>
                        <view v-if="item.status === TRANSFER_STATUS.RECEIVED && item.receivedAt" class="transfer-info-row">
                            <text class="transfer-info-label">领取时间</text>
                            <text class="transfer-info-value">{{ formatTime(item.receivedAt) }}</text>
                        </view>
                        <view v-if="item.status === TRANSFER_STATUS.CANCELED && item.canceledAt" class="transfer-info-row">
                            <text class="transfer-info-label">取消时间</text>
                            <text class="transfer-info-value">{{ formatTime(item.canceledAt) }}</text>
                        </view>
                    </view>

                    <!-- 转赠中操作 -->
                    <view v-if="item.status === TRANSFER_STATUS.TRANSFERRING" class="transfer-actions">
                        <button class="share-btn button-gold" @tap="onShareTap(item)">
                            再次分享
                        </button>
                        <view v-if="item.canCancel" class="cancel-btn" @tap.stop="onCancelTransfer(item)">
                            取消转赠
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </view>

        <!-- 再次分享弹框 -->
        <t-popup placement="bottom" v-model:visible="showShare" :z-index="99999">
            <view class="popup-header">
                <view class="popup-header-title">转赠给好友</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="24px" @click="showShare = false"/>
                </view>
            </view>
            <view class="popup-share-body">
                <!-- 转赠成功态：图标 + 标题 + 提示，填充固定高度避免中部空白 -->
                <view class="transfer-success">
                    <t-icon name="check-circle-filled" size="80rpx" color="#07C160"/>
                    <view class="transfer-success-title">转赠设置成功</view>
                    <view class="transfer-success-tip">好友领取前可多次分享，仅首位领取好友可获得本券</view>
                </view>
            </view>
            <view class="popup-bottom-action">
                <t-button theme="primary" size="large" block open-type="share" @click="onShareConfirm">
                    <view class="d-flex align-items-center">
                        <t-icon t-class="mr-1" name="share-1" size="20px"/>
                        分享给微信好友
                    </view>
                </t-button>
            </view>
            <view class="text-muted mt-1 text-center" @click="showShare = false">取消</view>
        </t-popup>
    </view>
</template>

<script setup>
import { onLoad, onShow, onPullDownRefresh, onReachBottom, onShareAppMessage} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace, TRANSFER_STATUS} from '@/constants/coupon'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils'
import to from '@/hooks/to'

const {push} = useLink()
// 当前 Tab（0全部/1转赠中/2已取消/3已成功）
const currentTab = ref(0)
// 列表查询筛选参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: undefined
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)
// 当前分享的转赠项
const shareItem = ref()
// 分享弹框显示
const showShare = ref(false)

// 格式化时间显示
const formatTime = (t) => {
    if (!t) return ''
    return String(t).replace('T', ' ').slice(0, 16)
}

// 切换 Tab 筛选
const onTabChange = (e) => {
    const val = e.detail?.value ?? e.value ?? e
    currentTab.value = Number(val)
    search.value.status = currentTab.value === 0 ? undefined : currentTab.value
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取转赠记录列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    const params = {
        page: search.value.page,
        pageSize: search.value.pageSize
    }
    if (search.value.status) {
        params.status = search.value.status
    }
    request.get('/user/coupon/transfer/list', params).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 点击转赠项跳转券详情
const onItemTap = (item) => {
    if (item.status === TRANSFER_STATUS.RECEIVED) return
    push('/pages_user/coupon/detail?id=' + item.couponReceiveId)
}

// 点击再次分享：获取shareKey后弹出分享弹框
const onShareTap = (item) => {
    shareItem.value = item
    showShare.value = true
}

// 点击分享按钮触发转发后关闭弹框
const onShareConfirm = () => {
    showShare.value = false
}

// 取消转赠
const onCancelTransfer = (item) => {
    uni.showModal({
        title: '提示',
        content: '确定取消转赠吗？',
        success: (res) => {
            if (res.confirm) {
                request.post('/user/coupon/receive/unlock-transfer', {
                    couponReceiveId: item.couponReceiveId
                }).then(() => {
                    utils.toast('已取消转赠')
                    search.value.page = 1
                    items.value = undefined
                    getItems()
                }).catch(() => {
                })
            }
        }
    })
}

onLoad(() => {
    uni.hideShareMenu()
    uni.updateShareMenu({
        withShareTicket: true,
        isPrivateMessage: true,
    })
})

onShow(() => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (isCompleted.value || loadingMore.value) return
    search.value.page += 1
    getItems()
})

onShareAppMessage(() => {
    return {
        title: shareItem.value?.remark || '领取好友转赠的优惠券',
        imageUrl: shareItem.value?.cover,
        path: '/pages_user/coupon/transfer_receive?shareKey=' + shareItem.value?.shareKey
    }
})

</script>

<style scoped>
.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.receive + .receive {
    margin-top: 20rpx;
}

.merchant {
    display: flex;
    align-items: center;
    margin-bottom: 10rpx;
    padding: 32rpx 32rpx 10rpx 32rpx;
}

.merchant-logo {
    width: 50rpx;
    height: 50rpx;
    border-radius: 50%;
    margin-right: 10rpx;
    flex-shrink: 0;
}

.merchant-header {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    min-width: 0;
}

.merchant-header-title {
    flex: 1;
    min-width: 0;
    font-size: 28rpx;
    font-weight: 600;
    color: #373737;
}

.merchant-header-extra {
    flex-shrink: 0;
    margin-left: 16rpx;
}

.transfer-status {
    font-size: 24rpx;
    font-weight: 500;
}

.transfer-status-1 {
    color: #07c160;
}

.transfer-status-3 {
    color: #576b95;
}

.transfer-status-2 {
    color: #999;
}

.coupon {
    padding: 10rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon--clickable {
    cursor: pointer;
}

.coupon-header {
    margin-right: 30rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #181818;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    margin-top: 8rpx;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

.button-gold--muted {
    background-color: #f5f5f5;
    color: #999;
}

.transfer-info {
    padding: 10rpx 32rpx 24rpx 32rpx;
}

.transfer-info-remark {
    display: flex;
    align-items: flex-start;
    gap: 12rpx;
    padding: 16rpx 20rpx;
    margin-bottom: 16rpx;
    background: #fafafa;
    border-radius: 12rpx;
}

.transfer-info-remark-text {
    flex: 1;
    font-size: 26rpx;
    color: #666;
    line-height: 1.5;
}

.transfer-info-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-top: 16rpx;
}

.transfer-info-row:first-child {
    margin-top: 0;
}

.transfer-info-label {
    flex-shrink: 0;
    font-size: 26rpx;
    color: #999;
}

.transfer-info-value {
    flex: 1;
    min-width: 0;
    margin-left: 24rpx;
    font-size: 26rpx;
    color: #666;
    text-align: right;
}

.transfer-info-value--receiver {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 12rpx;
}

.receiver-avatar {
    width: 40rpx;
    height: 40rpx;
    border-radius: 50%;
    flex-shrink: 0;
}

.transfer-actions {
    display: flex;
    align-items: center;
    justify-content: flex-end;
    gap: 32rpx;
    padding: 0 32rpx 32rpx;
}

.share-btn {
    margin: 0;
    padding: 10rpx 32rpx;
    height: auto;
    line-height: normal;
    border: none;
    font-size: 24rpx;
}

.share-btn::after {
    border: none;
}

.cancel-btn {
    font-size: 26rpx;
    color: #e84c59;
}

.popup-share-body {
    width: 100%;
    background: #fff;
    box-sizing: border-box;
    height: 300rpx;
}

/* 转赠成功态：居中布局填满固定高度，避免中部空白 */
.transfer-success {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    height: 100%;
}

.transfer-success-title {
    margin-top: 16rpx;
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.transfer-success-tip {
    margin-top: 16rpx;
    font-size: 24rpx;
    color: #999;
    text-align: center;
}

</style>
