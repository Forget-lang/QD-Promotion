import {
	defineStore
} from 'pinia';
import {
	computed,
	ref
} from 'vue';
import config from '../config';
import to from '../hooks/to';

export const useSessionStore = defineStore('session', () => {
	const token = ref(uni.getStorageSync('token') ? uni.getStorageSync('token') : ''); // 用户登录TOKEN
	const nickname = ref(uni.getStorageSync('nickname') ? uni.getStorageSync('nickname') : '')
	const avatar = ref(uni.getStorageSync('avatar') ? uni.getStorageSync('avatar') : config.default.avatar)
	const userId = ref(uni.getStorageSync('userId') ? uni.getStorageSync('userId') : '')
	const merchantId = ref(uni.getStorageSync('merchantId') ? uni.getStorageSync('merchantId') : '') // 商户ID，如果用户加入了商户，需要赋值
	const merchantName = ref(uni.getStorageSync('merchantName') ? uni.getStorageSync('merchantName') : '') // 商户名称，如果用户加入了商户，需要赋值
	const merchantLogo = ref(uni.getStorageSync('merchantLogo') ? uni.getStorageSync('merchantLogo') : '') // 商户logo，如果用户加入了商户，需要赋值
	const permissions = ref(uni.getStorageSync('permissions') ? uni.getStorageSync('permissions') : []) // 用户在当前商家所拥有的权限
	const tempCoupon = ref(uni.getStorageSync('tempCoupon') ? uni.getStorageSync('tempCoupon') : '')//保存制作卡券的草稿
	const appletScene = ref(0)//小程序场景值
	const deviceInfo = ref()

	// 设置用户Token，用于登录
	function login(info) {
		token.value = info.token;
		nickname.value = info.nickname
		avatar.value = info.avatar
		userId.value = info.userId

		uni.setStorageSync('token', info.token);
		uni.setStorageSync('nickname', info.nickname)
		uni.setStorageSync('avatar', info.avatar)
		uni.setStorageSync('userId', info.userId)
	}

	const logout = () => {
		token.value = ''
		nickname.value = ''
		avatar.value = config.default.avatar
		userId.value = ''

		uni.removeStorageSync('token')
		uni.removeStorageSync('nickname')
		uni.removeStorageSync('avatar')
        uni.removeStorageSync('userId')
		uni.removeStorageSync('userHomeMerchantId')
		exitMerchant()
		clearTempCoupon()
	}

	const setAccount = (info) => {
		nickname.value = info.nickname
		avatar.value = info.avatar
		uni.setStorageSync('nickname', info.nickname)
		uni.setStorageSync('avatar', info.avatar)
	}

	const setMerchant = (info) => {
		merchantId.value = info.merchantId
		merchantName.value = info.merchantName
		merchantLogo.value = info.merchantLogo
		permissions.value = info.permissions
		uni.setStorageSync('merchantId', info.merchantId)
		uni.setStorageSync('merchantName', info.merchantName)
		uni.setStorageSync('merchantLogo', info.merchantLogo)
		uni.setStorageSync('permissions', info.permissions)
	}

	//单独更新当前商户的权限列表
	const setPermissions = (data) => {
		permissions.value = to.Array(data)
		uni.setStorageSync('permissions', permissions.value)
	}

	//退出当前门店，如果还有门店，需要重新选择
	const exitMerchant = () => {
		merchantId.value = ''
		merchantName.value = ''
		merchantLogo.value = ''
		permissions.value = []
		uni.removeStorageSync('merchantId')
		uni.removeStorageSync('merchantName')
		uni.removeStorageSync('merchantLogo')
		uni.removeStorageSync('permissions')
		clearTempCoupon()
	}

	//保存制作卡券的草稿
	const setTempCoupon = (data) => {
		tempCoupon.value = data
		uni.setStorageSync('tempCoupon', data)
	}
	//清除制作卡券的草稿
	const clearTempCoupon = () => {
		tempCoupon.value = ''
		uni.removeStorageSync('tempCoupon')
	}

	// 设置小程序场景
	const setAppletScene = (value) => {
		appletScene.value = value
	}

	// 获取设备信息(操作系统、设备型号)
	const getDeviceInfo = (field) => {
		if (!deviceInfo.value) {
			deviceInfo.value = uni.getDeviceInfo()
		}
		if (field === 'os') {
			return deviceInfo.value['system']
		}
		if (field === 'device') {
			return deviceInfo.value['platform']
		}
		return deviceInfo.value[field]
	}

	return {
		token,
		avatar,
		nickname,
		userId,
		appletScene,
		login,
		logout,
		merchantId,
		merchantName,
		merchantLogo,
		setAccount,
		setMerchant,
		setPermissions,
		exitMerchant,
		permissions,
		tempCoupon,
		setTempCoupon,
		clearTempCoupon,
		setAppletScene,
		getDeviceInfo
	};
});