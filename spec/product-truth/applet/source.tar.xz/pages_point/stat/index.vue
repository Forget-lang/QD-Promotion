<template>
    <m-loading v-if="stat === undefined"></m-loading>
    <view v-else class="container-safety">
        <view class="section mt-3 p-3">
            <view class="row col-2">
                <view class="stat">
                    <view class="stat-value">{{ stat.monthIncrease }}</view>
                    <view class="stat-label">本月发放</view>
                </view>
                <view class="stat">
                    <view class="stat-value">{{ stat.monthDecrease }}</view>
                    <view class="stat-label">本月消耗</view>
                </view>
            </view>
        </view>
        <t-cell-group theme="card" title="按类型" t-title-class="mt-2">
            <t-cell v-for="(item, idx) in stat.typeItems" :key="'t'+idx" :title="item.name">
                <template #note>
                    <text class="text-muted">+{{ item.increase }} / -{{ item.decrease }}</text>
                </template>
            </t-cell>
            <m-empty v-if="!stat.typeItems.length">暂无数据</m-empty>
        </t-cell-group>
        <t-cell-group theme="card" title="按员工" t-title-class="mt-2">
            <t-cell v-for="(item, idx) in stat.staffItems" :key="'s'+idx" :title="item.name">
                <template #note>
                    <text class="text-muted">+{{ item.increase }} / -{{ item.decrease }}</text>
                </template>
            </t-cell>
            <m-empty v-if="!stat.staffItems.length">暂无数据</m-empty>
        </t-cell-group>
    </view>
</template>

<script setup>
import {onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'

const stat = ref()

const loadStat = () => {
    stat.value = undefined
    request.get('/seller/point/stat').then(res => {
        stat.value = res.data
    }).catch(() => {
        stat.value = {monthIncrease: 0, monthDecrease: 0, typeItems: [], staffItems: []}
    }).finally(() => uni.stopPullDownRefresh())
}

onShow(loadStat)
onPullDownRefresh(loadStat)
</script>

<style scoped>
.row.col-2 {
    display: flex;
}

.row.col-2 .stat {
    flex: 1;
}

.stat-value {
    font-size: 40rpx;
    font-weight: 600;
}

.stat-label {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}
</style>
