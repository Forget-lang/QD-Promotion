<template>
    <view class="page">
        <!-- 红色头部：系统导航栏同色拼色，非自定义导航 -->
        <view class="hero">
            <view class="hero-body">
                <view class="hero-text">
                    <view class="hero-label" @tap="onInfo">
                        <text>{{ headerLabel }}</text>
                        <t-icon name="info-circle" size="28rpx" color="rgba(255,255,255,0.9)"/>
                    </view>
                    <view class="hero-value">{{ headerValue }}</view>
                </view>
                <image class="hero-coin" src="https://cdn.lenmy.com/quandao/img/point-log-hero-coin.png"
                       mode="aspectFit"/>
            </view>
        </view>

        <!-- Tab + 筛选 -->
        <view class="toolbar">
            <view class="tabs">
                <view
                    v-for="tab in tabs"
                    :key="tab.value"
                    class="tab-item"
                    :class="{ active: direction === tab.value }"
                    @tap="onTabChange(tab.value)"
                >
                    <text>{{ tab.label }}</text>
                    <view v-if="direction === tab.value" class="tab-line"></view>
                </view>
            </view>
            <view class="filter-btn" :class="{ active: !!staffId }" @tap="showFilter = true">
                <text>筛选</text>
                <t-icon name="filter" size="28rpx" :color="staffId ? '#E53935' : '#666'"/>
            </view>
        </view>

        <!-- 列表 -->
        <view class="list-wrap">
            <m-loading v-if="items === undefined && page === 1"></m-loading>
            <m-empty v-else-if="items !== undefined && items.length === 0">暂无积分流水</m-empty>
            <template v-else-if="items">
                <view
                    v-for="item in items"
                    :key="item.id"
                    class="log-card"
                    @tap="onOpenCustomer(item)"
                >
                    <view class="log-avatar">
                        <image v-if="item.avatar" :src="item.avatar" mode="aspectFill"/>
                        <text v-else>{{ avatarText(item.nickname) }}</text>
                    </view>
                    <view class="log-main">
                        <view class="log-top">
                            <text class="log-name">{{ item.nickname || '客户' }}</text>
                            <text class="log-time">{{ formatDateTime(item.createdAt) }}</text>
                        </view>
                        <view class="log-mid">
                            <view class="log-type-row">
                                <text class="log-type">{{ item.pointTypeName || '积分变动' }}</text>
                                <text v-if="item.customerRemark" class="log-customer-remark">{{
                                        item.customerRemark
                                    }}
                                </text>
                            </view>
                            <text class="log-amount" :class="item.changeValue > 0 ? 'amount-plus' : 'amount-minus'">
                                {{ item.changeValue > 0 ? '+' : '' }}{{ item.changeValue }}
                            </text>
                        </view>
                        <view class="log-bottom">
                            <view class="log-meta">
                                <t-icon name="shop" size="24rpx" color="#999"/>
                                <text class="log-meta-text">{{ item.storeName || '-' }}</text>
                                <text class="log-meta-dot">·</text>
                                <text class="log-meta-text">{{ item.staffName || '系统发放' }}</text>
                                <view
                                    v-if="item.internalRemark"
                                    class="log-remark-icon"
                                    @tap.stop="onShowInternalRemark(item.internalRemark)"
                                >
                                    <t-icon name="chat-message" size="28rpx" color="#f5a623"/>
                                </view>
                            </view>
                            <text class="log-balance">余额: {{ item.balanceAfter }}</text>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <view v-else-if="isCompleted" class="nomore">—— 没有更多了 ——</view>
            </template>
        </view>

        <!-- 筛选弹层 -->
        <t-popup :visible="showFilter" placement="bottom" @visible-change="e => showFilter = e.detail.visible">
            <view class="popup-container container-safety">
                <view class="popup-header">
                    <view class="popup-header-title">筛选</view>
                    <view class="popup-header-close" @tap="showFilter = false">
                        <t-icon name="close" size="24px" color="#999"/>
                    </view>
                </view>
                <t-cell-group theme="card" t-class="mt-2">
                    <m-staff-select title="操作员工" :multiple="false" :show-disabled="true"
                                    v-model:value="draftStaffId"/>
                </t-cell-group>
                <view class="container mt-3">
                    <t-button theme="primary" block @click="onFilterConfirm">确定</t-button>
                    <t-button theme="default" variant="outline" block t-class="mt-2" @click="onFilterReset">重置
                    </t-button>
                </view>
            </view>
        </t-popup>
    </view>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import dayjs from 'dayjs'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {PERM_CUSTOMER} from '@/constants/permission'
import utils from '@/utils/utils'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

const tabs = [
    {value: '0', label: '全部'},
    {value: '1', label: '积分获取'},
    {value: '2', label: '积分消耗'},
]

const userId = ref('')
const direction = ref('0')
const staffId = ref('')
const draftStaffId = ref('')
const page = ref(1)
const pageSize = 20
const items = ref()
const isCompleted = ref(false)
const loadingMore = ref(false)
const showFilter = ref(false)
const headerLabel = ref('当前可用积分')
const headerValue = ref(0)

const avatarText = (name) => {
    const text = (name || '').trim()
    return text ? text.charAt(0) : '?'
}

const formatDateTime = (t) => t ? dayjs(t).format('YYYY-MM-DD HH:mm') : ''

const onShowInternalRemark = (remark) => {
    uni.showModal({
        title: '商家备注',
        content: remark || '',
        showCancel: false,
    })
}

const onOpenCustomer = (item) => {
    if (!item?.userId || !checkPermission(PERM_CUSTOMER.DETAIL)) return
    push('/pages_merchant/customer/detail?userId=' + item.userId)
}

const loadHeader = () => {
    if (userId.value) {
        headerLabel.value = '当前可用积分'
        request.get('/seller/customer/detail', {userId: userId.value}).then(res => {
            headerValue.value = res.data.pointBalance ?? 0
        }).catch(() => {
            headerValue.value = 0
        })
        return
    }
    headerLabel.value = '今日发放积分'
    request.get('/seller/point/overview').then(res => {
        headerValue.value = res.data.todayIncrease ?? 0
    }).catch(() => {
        headerValue.value = 0
    })
}

const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    const params = {
        page: page.value,
        pageSize,
        direction: Number(direction.value) || 0,
    }
    if (userId.value) params.userId = userId.value
    if (staffId.value) params.staffId = staffId.value
    request.get('/seller/point/log/list', params).then(res => {
        if (page.value === 1) items.value = []
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (page.value === 1) items.value = []
    }).finally(() => {
        loadingMore.value = false
        uni.stopPullDownRefresh()
    })
}

const reload = () => {
    page.value = 1
    isCompleted.value = false
    items.value = undefined
    getItems()
}

const onTabChange = (value) => {
    if (direction.value === value) return
    direction.value = value
    reload()
}

const onFilterConfirm = () => {
    staffId.value = draftStaffId.value || ''
    showFilter.value = false
    reload()
}

const onFilterReset = () => {
    draftStaffId.value = ''
    staffId.value = ''
    showFilter.value = false
    reload()
}

const onInfo = () => {
    utils.toast(userId.value ? '该客户当前可用的积分余额' : '今日商家累计发放的积分')
}

onLoad((e) => {
    if (e.userId) userId.value = e.userId
    loadHeader()
    getItems()
})

onPullDownRefresh(() => {
    loadHeader()
    page.value = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (isCompleted.value || loadingMore.value) return
    page.value++
    getItems()
})
</script>

<style scoped>
.page {
    min-height: 100vh;
    background: #f5f5f5;
}

.hero {
    background: #e53935;
    padding: 24rpx 40rpx 40rpx;
    overflow: hidden;
}

.hero-body {
    position: relative;
    min-height: 120rpx;
}

.hero-text {
    position: relative;
    z-index: 1;
    padding-right: 160rpx;
}

.hero-label {
    display: flex;
    align-items: center;
    gap: 8rpx;
    color: rgba(255, 255, 255, 0.95);
    font-size: 26rpx;
}

.hero-value {
    margin-top: 8rpx;
    color: #fff;
    font-size: 76rpx;
    font-weight: 700;
    line-height: 1.05;
    letter-spacing: 2rpx;
}

.hero-coin {
    position: absolute;
    right: -8rpx;
    bottom: -12rpx;
    width: 148rpx;
    height: 148rpx;
    z-index: 0;
    pointer-events: none;
}

.toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 8rpx 24rpx 16rpx;
    background: #fff;
}

.tabs {
    display: flex;
    align-items: center;
    gap: 40rpx;
}

.tab-item {
    position: relative;
    padding: 20rpx 0 16rpx;
    font-size: 28rpx;
    color: #888;
}

.tab-item.active {
    color: #222;
    font-weight: 600;
}

.tab-line {
    position: absolute;
    left: 50%;
    bottom: 0;
    width: 40rpx;
    height: 6rpx;
    margin-left: -20rpx;
    border-radius: 6rpx;
    background: #e53935;
}

.filter-btn {
    display: flex;
    align-items: center;
    gap: 6rpx;
    padding: 8rpx 18rpx;
    border-radius: 999rpx;
    border: 1rpx solid #e5e5e5;
    font-size: 24rpx;
    color: #666;
    background: #fafafa;
}

.filter-btn.active {
    color: #e53935;
    border-color: #f5b5b0;
    background: #fff5f4;
}

.list-wrap {
    padding: 16rpx 24rpx 40rpx;
}

.log-card {
    display: flex;
    align-items: flex-start;
    background: #fff;
    border-radius: 20rpx;
    padding: 28rpx 24rpx;
    margin-bottom: 20rpx;
}

.log-avatar {
    flex-shrink: 0;
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    margin-right: 20rpx;
    background: #f0f0f0;
    color: #666;
    font-size: 32rpx;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.log-avatar image {
    width: 100%;
    height: 100%;
}

.log-main {
    flex: 1;
    min-width: 0;
}

.log-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.log-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #222;
}

.log-time {
    flex-shrink: 0;
    font-size: 22rpx;
    color: #bbb;
}

.log-mid {
    display: flex;
    align-items: baseline;
    justify-content: space-between;
    gap: 16rpx;
    margin-top: 10rpx;
}

.log-type-row {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: baseline;
    flex-wrap: wrap;
    gap: 10rpx;
}

.log-type {
    font-size: 28rpx;
    font-weight: 600;
    color: #222;
}

.log-customer-remark {
    font-size: 24rpx;
    color: #999;
}

.log-amount {
    flex-shrink: 0;
    font-size: 36rpx;
    font-weight: 700;
    line-height: 1.2;
}

.amount-plus {
    color: #e53935;
}

.amount-minus {
    color: #07c160;
}

.log-bottom {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
    margin-top: 12rpx;
}

.log-meta {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: center;
    gap: 6rpx;
}

.log-meta-text {
    font-size: 22rpx;
    color: #999;
    max-width: 220rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.log-meta-dot {
    font-size: 22rpx;
    color: #ccc;
    margin: 0 2rpx;
}

.log-remark-icon {
    flex-shrink: 0;
    margin-left: 4rpx;
    padding: 4rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.log-balance {
    flex-shrink: 0;
    font-size: 22rpx;
    color: #999;
}

.nomore {
    text-align: center;
    color: #bbb;
    font-size: 24rpx;
    padding: 40rpx 0;
}
</style>
