<template>
    <view class="container container-safety">
        <view class="section mt-2 p-3 text-small">
            <view class="paragraph">
                <text class="font-bold">怎么发积分？</text>
            </view>
            <view class="paragraph">顾客出示客户码，商家用微信扫一扫打开客户详情，点击「给他发积分」或「减积分」。</view>
            <view class="paragraph">
                <text class="font-bold">谁能发？</text>
            </view>
            <view class="paragraph">只有在「发放员工设置」里的员工可以操作；名单为空时谁都不能发。</view>
            <view class="paragraph">
                <text class="font-bold">类型</text>
            </view>
            <view class="paragraph">发放、扣除可使用不同自定义类型；单次发放最多 1000 积分；扣除不能超过顾客当前余额。
            </view>
            <view class="paragraph">
                <text class="font-bold">发错了怎么办？</text>
            </view>
            <view class="paragraph">流水不能撤销，请用反向操作冲正（发多了就扣，扣多了就发）。</view>
            <view class="paragraph">
                <text class="font-bold">系统预留类型名</text>
            </view>
            <view class="paragraph">积分兑换、邀请奖励、转赠奖励、分享奖励 为系统预留，商家自定义类型不能使用这些名称。
            </view>
        </view>
    </view>
</template>

<script setup>
</script>

<style scoped>
.paragraph {
    margin-bottom: 24rpx;
    line-height: 1.7;
    color: #333;
}

.font-bold {
    font-weight: 600;
}
</style>
