<template>
    <view class="container">
        <view class="section mt-3 p-3">
            <view class="row col-4">
                <view class="stat">
                    <view class="stat-value">{{ stats.todayIncrease }}</view>
                    <view class="stat-label">今日发放</view>
                </view>
                <view class="stat">
                    <view class="stat-value">{{ stats.todayDecrease }}</view>
                    <view class="stat-label">今日消耗</view>
                </view>
                <view class="stat">
                    <view class="stat-value">{{ stats.yesterdayIncrease }}</view>
                    <view class="stat-label">昨日发放</view>
                </view>
                <view class="stat">
                    <view class="stat-value">{{ stats.yesterdayDecrease }}</view>
                    <view class="stat-label">昨日消耗</view>
                </view>
            </view>
        </view>
    </view>
    <t-cell-group title="操作设置" t-title-class="mt-2" theme="card">
        <t-grid :column="4">
            <t-grid-item v-if="checkPermission(PERM_POINT.STAFF)" text="发放员工" icon="user-setting"
                         @click="push('/pages_point/staff/list')"/>
            <t-grid-item v-if="checkPermission(PERM_POINT.TYPE)" text="积分类型" icon="root-list"
                         @click="push('/pages_point/type/index')"/>
            <t-grid-item v-if="checkPermission(PERM_POINT.LOG)" text="积分明细" icon="task"
                         @click="push('/pages_point/log/list')"/>
            <t-grid-item v-if="checkPermission(PERM_POINT.STAT)" text="发放统计" icon="chart-analytics"
                         @click="push('/pages_point/stat/index')"/>
        </t-grid>
    </t-cell-group>
    <view class="mt-2 mb-3">
        <view class="help-title">使用帮助</view>
        <t-collapse theme="card" expand-mutex :value="helpValues" @change="onHelpChange">
            <t-collapse-panel header="商家怎么发积分？" value="how">
                顾客出示客户码，商家用微信扫一扫打开客户详情，点击「发积分」或「扣积分」。通过客户管理，找到对应客户，也可以如此操作。
            </t-collapse-panel>
            <t-collapse-panel header="哪些员工能发积分？" value="who">
                在「发放员工设置」中授权的员工可以发，没有授权的员工不能发。
            </t-collapse-panel>
            <t-collapse-panel header="客户怎么用积分？" value="type">
                顾客自助在积分兑换(即将上线）您设置的积分商品。或者到店出示客户码，商家用微信扫一扫打开客户详情，点击「扣积分」灵活扣除。
            </t-collapse-panel>
            <t-collapse-panel header="发错了怎么办？" value="fix">
                流水不能撤销，请用反向操作冲正（发多了就扣，扣多了就发）。
            </t-collapse-panel>
        </t-collapse>
    </view>
</template>

<script setup>
import {onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request.js'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth'
import {PERM_POINT} from '@/constants/permission'

const {push} = useLink()
const {checkPermission} = useAuth()

const emptyStats = () => ({
    todayIncrease: 0,
    todayDecrease: 0,
    yesterdayIncrease: 0,
    yesterdayDecrease: 0,
})

const stats = ref(emptyStats())
const helpValues = ref(['how'])

const onHelpChange = (e) => {
    helpValues.value = e?.value ?? e?.detail?.value ?? []
}

const loadStats = () => {
    request.get('/seller/point/overview').then(res => {
        stats.value = {
            todayIncrease: res.data?.todayIncrease ?? 0,
            todayDecrease: res.data?.todayDecrease ?? 0,
            yesterdayIncrease: res.data?.yesterdayIncrease ?? 0,
            yesterdayDecrease: res.data?.yesterdayDecrease ?? 0,
        }
    }).catch(() => {
        // 保持当前展示，不随加载态隐藏
    }).finally(() => {
        uni.stopPullDownRefresh()
    })
}

onShow(() => {
    loadStats()
})

onPullDownRefresh(() => {
    loadStats()
})
</script>

<style scoped>
.help-title {
    padding: 24rpx 48rpx 16rpx;
    font-size: 28rpx;
    color: #999;
}
</style>
