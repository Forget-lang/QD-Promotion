<template>
    <m-result v-if="showSuccess" theme="success" title="扣除成功" :description="'当前余额 ' + resultBalance"
              back></m-result>
    <view v-else-if="customer === undefined" class="page">
        <m-loading/>
    </view>
    <m-empty v-else-if="customer === null">客户不存在</m-empty>
    <view v-else class="page">
        <view class="page-body">
            <view class="issue-card">
                <view class="issue-glow"></view>
                <view class="issue-spark issue-spark-a"></view>
                <view class="issue-spark issue-spark-b"></view>
                <view class="issue-head">
                    <image class="issue-head-icon" src="/static/img/home-point.png" mode="aspectFit"/>
                    <text class="issue-head-title">扣除积分</text>
                </view>
                <view class="issue-panel">
                    <view class="amount-head">
                        <text class="field-label">扣除积分数量</text>
                        <text class="balance-tip">积分余额：{{ customer.pointBalance ?? 0 }}</text>
                    </view>
                    <view class="amount-row">
                        <input
                            class="amount-input"
                            type="number"
                            :value="form.amount"
                            maxlength="8"
                            placeholder="0"
                            placeholder-class="amount-placeholder"
                            @input="onAmountInput"
                        />
                        <text class="amount-unit">分</text>
                    </view>
                    <view class="preset-row">
                        <view
                            v-for="n in presets"
                            :key="n"
                            class="preset-btn"
                            :class="{'preset-btn-active': Number(form.amount) === n}"
                            @tap="onPreset(n)"
                        >{{ n }}
                        </view>
                    </view>

                    <text class="field-label type-label">积分类型</text>
                    <view class="tag-row">
                        <view
                            v-for="item in types"
                            :key="item.id"
                            class="type-tag"
                            :class="{'type-tag-active': form.pointTypeId === item.id}"
                            @tap="form.pointTypeId = item.id"
                        >{{ item.name }}
                        </view>
                        <view class="type-tag type-tag-add" @tap="showAddType = true">
                            <t-icon name="add" size="28rpx" color="#07c160"/>
                        </view>
                    </view>
                    <text class="field-label type-label">扣除客户</text>
                    <view class="profile-row mt-2">
                        <view class="avatar">
                            <image v-if="customer.avatar" :src="customer.avatar" mode="aspectFill"/>
                            <text v-else>{{ avatarText }}</text>
                        </view>
                        <view class="profile-main">
                            <text class="name">{{ customer.nickname || '-' }}</text>
                            <view class="remark-row">
                                <text class="remark-text">{{ customer.remark || '暂无备注' }}</text>
                            </view>
                        </view>
                    </view>
                </view>
            </view>

            <view class="card remark-card">
                <view class="section-head">
                    <text class="section-title">客户备注（对外可见）</text>
                </view>
                <view class="remark-box">
                    <textarea
                        class="remark-textarea"
                        v-model="form.customerRemark"
                        maxlength="200"
                        :auto-height="false"
                        placeholder="选填，商户与客户可见"
                        placeholder-class="remark-placeholder"
                        :cursorSpacing="50"
                    />
                    <text class="remark-count">{{ (form.customerRemark || '').length }}/200</text>
                </view>
            </view>

            <view class="card remark-card">
                <view class="section-head">
                    <text class="section-title">内部备注（仅商户可见）</text>
                </view>
                <view class="remark-box">
                    <textarea
                        class="remark-textarea"
                        v-model="form.internalRemark"
                        maxlength="200"
                        :auto-height="false"
                        placeholder="选填，客户不可见，仅商户可见"
                        placeholder-class="remark-placeholder"
                        :cursorSpacing="50"
                    />
                    <text class="remark-count">{{ (form.internalRemark || '').length }}/200</text>
                </view>
            </view>
        </view>

        <m-submit :loading="loading" @click="onOpenConfirm">扣除积分</m-submit>
    </view>

    <t-popup :visible="showAddType" placement="bottom" @visible-change="onAddTypePopupChange">
        <view class="popup-container container-safety">
            <view class="popup-header">
                <view class="popup-header-title">添加类型</view>
                <view class="popup-header-close" @tap="showAddType = false">
                    <t-icon name="close" size="24px" color="#999"/>
                </view>
            </view>
            <t-cell-group theme="card" t-class="mt-2">
                <t-input v-model:value="newTypeName" placeholder="类型名称，最多6个字" :maxlength="6" :cursorSpacing="36"/>
            </t-cell-group>
            <view class="container mt-3">
                <t-button theme="primary" block @click="onAddType">保存</t-button>
            </view>
        </view>
    </t-popup>

    <t-popup :visible="showConfirm" placement="bottom" @visible-change="onConfirmPopupChange">
        <view class="popup-container container-safety">
            <view class="popup-header">
                <view class="popup-header-title">确认扣除积分</view>
                <view class="popup-header-close" @tap="showConfirm = false">
                    <t-icon name="close" size="24px" color="#999"/>
                </view>
            </view>
            <t-cell-group theme="card" t-class="mt-2">
                <t-cell title="动作" note="扣除积分"/>
                <t-cell title="积分类型" :note="selectedTypeName"/>
                <t-cell title="积分金额">
                    <template #note>
                        <text class="confirm-amount confirm-amount-minus">-{{ form.amount || 0 }}</text>
                    </template>
                </t-cell>
                <t-cell title="客户备注" :note="form.customerRemark || '未填写'"/>
                <t-cell title="内部备注" :note="form.internalRemark || '未填写'" :bordered="false"/>
            </t-cell-group>
            <view class="container mt-3">
                <t-button theme="primary" block :loading="loading" @click="onConfirm">确认扣除</t-button>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import to from '@/hooks/to'

const presets = [1, 5, 10, 20, 50]

const userId = ref('')
const customer = ref()
const types = ref([])
const form = ref({amount: '', pointTypeId: '', customerRemark: '', internalRemark: ''})
const loading = ref(false)
const showConfirm = ref(false)
const showAddType = ref(false)
const newTypeName = ref('')
const showSuccess = ref(false)
const resultBalance = ref(0)

const selectedTypeName = computed(() => types.value.find(t => t.id === form.value.pointTypeId)?.name || '-')

const avatarText = computed(() => {
    const name = (customer.value?.nickname || '').trim()
    return name ? name.charAt(0) : '?'
})

const loadCustomer = () => {
    if (!userId.value) return
    request.get('/seller/customer/detail', {userId: userId.value}).then(res => {
        customer.value = res.data
    }).catch(err => {
        console.error('获取客户详情失败:', err)
        customer.value = null
    })
}

const loadTypes = () => {
    request.get('/seller/point/type/list', {direction: 2, status: 1}).then(res => {
        types.value = to.Array(res.data.items)
        if (!form.value.pointTypeId && types.value[0]) {
            form.value.pointTypeId = types.value[0].id
        }
    })
}

const onAmountInput = (e) => {
    const raw = String(e?.detail?.value ?? '')
    form.value.amount = raw.replace(/\D/g, '').slice(0, 8)
}

const onPreset = (n) => {
    form.value.amount = String(n)
}

const onAddTypePopupChange = (e) => {
    showAddType.value = e && typeof e === 'object' ? !!(e.visible ?? e.detail?.visible) : !!e
}

const onConfirmPopupChange = (e) => {
    showConfirm.value = e && typeof e === 'object' ? !!(e.visible ?? e.detail?.visible) : !!e
}

const onAddType = () => {
    const name = (newTypeName.value || '').trim()
    if (!name) return utils.toast('请填写类型名称')
    if ([...name].length > 6) return utils.toast('类型名称最多6个字')
    request.post('/seller/point/type/create', {name, direction: 2}).then(res => {
        showAddType.value = false
        newTypeName.value = ''
        loadTypes()
        form.value.pointTypeId = res.data.id
    }).catch(err => utils.toast(err.message))
}

const onOpenConfirm = () => {
    const amount = Number(form.value.amount)
    if (!amount || amount < 1) return utils.toast('请填写扣除数量')
    if (!form.value.pointTypeId) return utils.toast('请选择积分类型')
    const balance = Number(customer.value?.pointBalance || 0)
    if (amount > balance) return utils.toast('积分余额不足')
    showConfirm.value = true
}

const onConfirm = () => {
    if (loading.value) return
    loading.value = true
    request.post('/seller/point/decrease', {
        userId: userId.value,
        pointTypeId: form.value.pointTypeId,
        amount: Number(form.value.amount),
        customerRemark: form.value.customerRemark,
        internalRemark: form.value.internalRemark,
    }).then(res => {
        showConfirm.value = false
        resultBalance.value = res.data.pointBalance
        showSuccess.value = true
    }).catch(err => utils.toast(err.message)).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    if (!e.userId) {
        utils.toast('缺少客户')
        return
    }
    userId.value = e.userId
    loadCustomer()
})

onShow(loadTypes)
</script>

<style scoped>
.page {
    min-height: 100vh;
    background: #f5f5f5;
    box-sizing: border-box;
    padding-bottom: 160rpx;
}

.page-body {
    padding: 16rpx 24rpx 0;
}

.card {
    background: #fff;
    border-radius: 20rpx;
    padding: 28rpx;
}

.profile-row {
    display: flex;
    align-items: flex-start;
}

.avatar {
    width: 68rpx;
    height: 68rpx;
    border-radius: 50%;
    overflow: hidden;
    background: #f0f0f0;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 28rpx;
    color: #999;
    font-weight: 600;
}

.avatar image {
    width: 100%;
    height: 100%;
}

.profile-main {
    flex: 1;
    min-width: 0;
    margin-left: 24rpx;
    padding-top: 4rpx;
}

.name {
    font-size: 28rpx;
    color: #222;
}

.remark-row {
    display: flex;
    align-items: center;
    gap: 8rpx;
}

.remark-text {
    flex: 1;
    min-width: 0;
    font-size: 24rpx;
    color: #888;
    line-height: 1.5;
}

.issue-card {
    position: relative;
    margin-bottom: 24rpx;
    padding: 28rpx 24rpx 24rpx;
    border-radius: 28rpx;
    overflow: hidden;
    background: linear-gradient(145deg, #2fd17a 0%, #07c160 48%, #06ad56 100%);
}

.issue-glow {
    position: absolute;
    top: -60rpx;
    right: -40rpx;
    width: 220rpx;
    height: 220rpx;
    border-radius: 50%;
    background: radial-gradient(circle, rgba(200, 255, 220, 0.5) 0%, rgba(200, 255, 220, 0) 70%);
    pointer-events: none;
}

.issue-spark {
    position: absolute;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.55);
    pointer-events: none;
}

.issue-spark-a {
    top: 36rpx;
    right: 120rpx;
    width: 10rpx;
    height: 10rpx;
}

.issue-spark-b {
    top: 72rpx;
    right: 88rpx;
    width: 6rpx;
    height: 6rpx;
    opacity: 0.8;
}

.issue-head {
    position: relative;
    z-index: 1;
    display: flex;
    align-items: center;
    gap: 12rpx;
    margin-bottom: 22rpx;
    padding-left: 4rpx;
}

.issue-head-icon {
    width: 44rpx;
    height: 44rpx;
}

.issue-head-title {
    font-size: 32rpx;
    font-weight: 700;
    color: #fff;
    letter-spacing: 1rpx;
    text-shadow: 0 2rpx 8rpx rgba(0, 100, 50, 0.28);
}

.issue-panel {
    position: relative;
    z-index: 1;
    background: #fff;
    border-radius: 22rpx;
    padding: 28rpx 24rpx 28rpx;
}

.amount-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.field-label {
    font-size: 26rpx;
    color: #8a8a8a;
}

.balance-tip {
    font-size: 24rpx;
    color: #07c160;
    flex-shrink: 0;
}

.amount-row {
    margin-top: 12rpx;
    display: flex;
    align-items: baseline;
    gap: 10rpx;
}

.amount-input {
    flex: 1;
    min-width: 0;
    font-size: 72rpx;
    font-weight: 800;
    color: #07c160;
    line-height: 1.15;
    height: 88rpx;
}

.amount-placeholder {
    color: #b8e8cc;
    font-weight: 700;
}

.amount-unit {
    font-size: 28rpx;
    color: #3aa86a;
    flex-shrink: 0;
    font-weight: 600;
}

.preset-row {
    margin-top: 24rpx;
    display: flex;
    gap: 14rpx;
}

.preset-btn {
    flex: 1;
    height: 64rpx;
    border-radius: 14rpx;
    border: 1rpx solid #c8ecd8;
    background: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28rpx;
    color: #07c160;
    font-weight: 700;
}

.preset-btn-active {
    border-color: #07c160;
    background: #f0faf4;
    color: #06ad56;
    box-shadow: 0 0 0 2rpx rgba(7, 193, 96, 0.18);
}

.type-label {
    display: block;
    margin-top: 36rpx;
}

.tag-row {
    margin-top: 16rpx;
    display: flex;
    flex-wrap: wrap;
    gap: 14rpx;
}

.type-tag {
    padding: 14rpx 24rpx;
    border-radius: 999rpx;
    border: 1rpx solid #e8e8e8;
    background: #fff;
    font-size: 26rpx;
    color: #555;
}

.type-tag-active {
    border-color: #07c160;
    background: #07c160;
    color: #fff;
    font-weight: 600;
}

.type-tag-add {
    width: 64rpx;
    padding: 14rpx 0;
    display: flex;
    align-items: center;
    justify-content: center;
    border-style: dashed;
    border-color: #c8ecd8;
    background: #f6fbf8;
}

.remark-card {
    margin-bottom: 24rpx;
}

.section-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.section-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.remark-box {
    margin-top: 16rpx;
    border: 1rpx solid #eee;
    border-radius: 12rpx;
    padding: 20rpx;
    background: #fff;
}

.remark-textarea {
    width: 100%;
    height: 60rpx;
    font-size: 28rpx;
    color: #333;
    line-height: 1.5;
}

.remark-placeholder {
    color: #bbb;
}

.remark-count {
    display: block;
    text-align: right;
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #bbb;
}

.confirm-amount {
    font-size: 28rpx;
    font-weight: 700;
}

.confirm-amount-minus {
    color: #07c160;
}
</style>
