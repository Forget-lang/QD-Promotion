<template>
    <view class="container-safety">
        <view class="container mt-2">
            <t-segmented
                block
                :options="tabOptions"
                :value="currentTab"
                @change="onTabChange"
            />
        </view>
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items.length === 0">暂无类型，可在发/扣积分页添加</m-empty>
        <t-cell-group v-else theme="card" t-class="mt-2">
            <t-swipe-cell
                v-for="item in items"
                :key="item.id"
                :disabled="!!item.isSystem || !canManage"
            >
                <t-cell
                    :title="item.name"
                    :note="item.isSystem ? '系统类型' : item.statusLabel"
                    :arrow="canManage && !item.isSystem"
                    :hover="canManage && !item.isSystem"
                    @click="openEdit(item)"
                />
                <template #right>
                    <view class="swipe-delete" @click.stop="onSwipeDelete(item)">删除</view>
                </template>
            </t-swipe-cell>
        </t-cell-group>
        <t-popup :visible="showEdit" placement="bottom" @visible-change="onEditVisible">
            <view class="popup-container container-safety">
                <view class="popup-header">
                    <view class="popup-header-title">{{ editingId ? '编辑类型' : '新建类型' }}</view>
                    <view class="popup-header-close" @tap="showEdit = false">
                        <t-icon name="close" size="24px" color="#999"/>
                    </view>
                </view>
                <t-cell-group theme="card" t-class="mt-2">
                    <t-input v-model:value="form.name" label="类型名称" placeholder="最多6个字" :maxlength="6"/>
                    <t-input v-model:value="form.sort" type="number" label="排序" placeholder="数字越小越靠前"/>
                    <t-cell v-if="editingId" title="状态">
                        <template #note>
                            <t-switch v-model:value="form.enabled"/>
                        </template>
                    </t-cell>
                </t-cell-group>
                <view class="container mt-3">
                    <t-button theme="primary" block :loading="saving" @click="onSave">保存</t-button>
                </view>
            </view>
        </t-popup>
        <m-submit v-if="canManage" @click="openCreate">新建类型</m-submit>
    </view>
</template>

<script setup>
import {onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useAuth} from '@/hooks/useAuth'
import {PERM_POINT} from '@/constants/permission'
import to from '@/hooks/to'

const {checkPermission} = useAuth()
const canManage = computed(() => checkPermission(PERM_POINT.TYPE))
// value 用字符串：小程序 change 常回字符串，与数字严格相等会导致激活态丢失
const tabOptions = [
    {value: '1', label: '发放积分'},
    {value: '2', label: '扣除积分'},
]
const currentTab = ref('1')
const items = ref()
const showEdit = ref(false)
const editingId = ref('')
const saving = ref(false)
const deleting = ref(false)
const form = ref({name: '', sort: '0', enabled: true})
let loadSeq = 0

const loadItems = () => {
    const seq = ++loadSeq
    const direction = Number(currentTab.value)
    request.get('/seller/point/type/list', {
        direction,
        status: 0,
    }).then(res => {
        if (seq !== loadSeq) return
        items.value = to.Array(res.data.items)
    }).catch(() => {
        if (seq !== loadSeq) return
        items.value = []
    }).finally(() => {
        if (seq === loadSeq) {
            uni.stopPullDownRefresh()
        }
    })
}

const onTabChange = (e) => {
    const next = e?.value ?? e?.detail?.value
    if (next === undefined || next === null || next === '') return
    const nextTab = String(next)
    if (nextTab === currentTab.value) return
    currentTab.value = nextTab
    loadItems()
}

const openCreate = () => {
    editingId.value = ''
    form.value = {name: '', sort: '0', enabled: true}
    showEdit.value = true
}

const openEdit = (item) => {
    if (!canManage.value) return
    if (item.isSystem) {
        utils.toast('系统类型不可修改')
        return
    }
    editingId.value = item.id
    form.value = {
        name: item.name || '',
        sort: String(item.sort ?? 0),
        enabled: Number(item.status) === 1,
    }
    showEdit.value = true
}

const onEditVisible = (e) => {
    showEdit.value = e.detail.visible
}

const doSave = () => {
    const name = (form.value.name || '').trim()
    if (!name) {
        utils.toast('请填写类型名称')
        return
    }
    if ([...name].length > 6) {
        utils.toast('类型名称最多6个字')
        return
    }
    saving.value = true
    const sort = Number(form.value.sort) || 0
    if (editingId.value) {
        request.post('/seller/point/type/update', {
            id: editingId.value,
            name,
            sort,
            status: form.value.enabled ? 1 : 2,
        }).then(() => {
            showEdit.value = false
            loadItems()
            utils.toast('已保存')
        }).catch(err => utils.toast(err.message)).finally(() => {
            saving.value = false
        })
        return
    }
    request.post('/seller/point/type/create', {
        name,
        direction: Number(currentTab.value),
        sort,
    }).then(() => {
        showEdit.value = false
        loadItems()
        utils.toast('已创建')
    }).catch(err => utils.toast(err.message)).finally(() => {
        saving.value = false
    })
}

const onSave = () => {
    if (saving.value) return
    const name = (form.value.name || '').trim()
    if (!name) {
        utils.toast('请填写类型名称')
        return
    }
    if ([...name].length > 6) {
        utils.toast('类型名称最多6个字')
        return
    }
    if (!editingId.value) {
        doSave()
        return
    }
    uni.showModal({
        title: '确认修改？',
        content: '只改以后发分、扣分时可选的类型，已经记下来的积分流水不会变。',
        confirmText: '确认修改',
        success: (res) => {
            if (!res.confirm) return
            doSave()
        },
    })
}

const doDelete = (id) => {
    if (!id || deleting.value) return
    deleting.value = true
    request.post('/seller/point/type/delete', {id}).then(() => {
        if (editingId.value === id) {
            showEdit.value = false
        }
        loadItems()
        utils.toast('已删除')
    }).catch(err => utils.toast(err.message)).finally(() => {
        deleting.value = false
    })
}

const onSwipeDelete = (item) => {
    if (!canManage.value || !item || item.isSystem || deleting.value) return
    uni.showModal({
        title: '确认删除？',
        content: '删掉后不能再用这个类型发分或扣分，已经记下来的积分流水不会变。',
        confirmText: '确认删除',
        confirmColor: '#e34d59',
        success: (res) => {
            if (!res.confirm) return
            doDelete(item.id)
        },
    })
}

onShow(loadItems)
onPullDownRefresh(loadItems)
</script>

<style scoped>
.swipe-delete {
    height: 100%;
    padding: 0 32rpx;
    background-color: #e34d59;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28rpx;
    box-sizing: border-box;
}
</style>
