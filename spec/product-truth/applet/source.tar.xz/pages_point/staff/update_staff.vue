<template>
    <!-- 成功反馈 -->
    <m-result v-if="showSuccess" theme="success" title="修改成功" back></m-result>
    <template v-else>
        <!-- 发放员工设置 -->
        <t-cell-group theme="card" t-class="mt-2">
            <m-staff-select required title="指定员工" :multiple="true" :show-disabled="true"
                            v-model:value="form.staffIds"></m-staff-select>
        </t-cell-group>

        <!-- 邀请员工 -->
        <view class="text-center mt-5">
            <text class="text-wechat" @click="push('/pages_merchant/staff/invite')">邀请员工辅助发积分</text>
        </view>

        <!-- 提交按钮 -->
        <m-submit v-if="checkPermission(PERM_POINT.STAFF)" :loading="loading" :disabled="loading" @click="onSubmit">
            确认修改
        </m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {PERM_POINT} from '@/constants/permission'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

const form = ref({
    staffIds: []
})
const loading = ref(false)
const showSuccess = ref(false)

const loadStaffs = () => {
    request.get('/seller/point/staff/list').then(res => {
        const items = to.Array(res.data.items)
        form.value.staffIds = items.map(item => item.id)
    })
}

const onSubmit = () => {
    if (!form.value.staffIds || form.value.staffIds.length === 0) {
        utils.toast('请至少选择一名发放员工')
        return
    }
    loading.value = true
    request.post('/seller/point/update-staffs', {
        staffIds: form.value.staffIds
    }).then(() => {
        showSuccess.value = true
    }).catch(err => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

onLoad(() => {
    loadStaffs()
})
</script>

<style scoped></style>
