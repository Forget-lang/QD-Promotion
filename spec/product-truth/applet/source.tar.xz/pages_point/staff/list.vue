<template>
    <m-loading v-if="items === undefined"></m-loading>
    <template v-else-if="is.Array(items)">
        <m-empty v-if="items.length === 0">暂无发放员工</m-empty>
        <view v-else class="container-safety">
            <t-cell-group theme="card" t-class="mt-2">
                <t-cell :arrow="true" v-for="item in items" :key="item.id" :title="item.name" :image="item.avatar"
                        @tap="push('/pages_merchant/staff/detail?staffId=' + item.id)">
                    <template #description>
                        <view class="m-flex mt-1">
                            <t-tag theme="success" variant="light-outline" size="small">{{ item.storeName }}</t-tag>
                            <t-tag theme="warning" variant="light" size="small">{{ item.roleName }}</t-tag>
                        </view>
                    </template>
                    <template #note>
                        <text class="text-muted"
                              :class="item.status === STAFF_STATUS.NORMAL ? 'text-success' : 'text-danger'">
                            {{ item.statusLabel }}
                        </text>
                    </template>
                </t-cell>
            </t-cell-group>

            <view class="mt-2 p-3 text-center text-muted text-small">
                共 {{ total }} 名发放员工
            </view>
        </view>
    </template>
    <m-submit v-if="items && checkPermission(PERM_POINT.STAFF)" @click="push('/pages_point/staff/update_staff')">
        设置发放员工
    </m-submit>
</template>

<script setup>
import {onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {PERM_POINT} from '@/constants/permission'
import {STAFF_STATUS} from '@/constants/merchant'
import is from '@/hooks/is'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

const items = ref()
const total = ref(0)
const loading = ref(false)

const getItems = () => {
    if (loading.value) return
    loading.value = true
    request.get('/seller/point/staff/list').then(res => {
        items.value = to.Array(res.data.items)
        total.value = res.data.total
    }).finally(() => {
        loading.value = false
    })
}

onShow(() => {
    getItems()
})

onPullDownRefresh(() => {
    getItems()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})
</script>

<style scoped></style>
