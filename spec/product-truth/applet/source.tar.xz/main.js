import App from './App'
import { createPinia } from 'pinia'

import {
	createSSRApp
} from 'vue'

export function createApp() {
	const app = createSSRApp(App)
	app.use(createPinia())
	app.config.errorHandler = (err, instance, info) => {
		console.error('[vue-error]', err, info)
		wx.reportEvent('vue_error', {
			message: err?.message || String(err),
			info: info || '',
		})
	}
	return {
		app
	}
}