<template>
	<m-result v-if="isInvalid" type="info" color="rgb(247, 77, 84)" title="邀请链接无效" desc="请联系邀请人重新发起邀请链接"></m-result>
	<m-loading v-else-if="data === undefined"></m-loading>
	<template v-else>
		<m-result v-if="data.isTimeout" type="info" color="rgb(247, 77, 84)" title="邀请链接已过期" desc="请联系邀请人重新发起邀请链接"></m-result>
		<template v-else>
			<view>
				<view class="container">
					<view class="section mt-2">
						<image :src="data.cover" style="height: auto;width: 100%;" mode="widthFix"></image>
						<view class="px-3 py-2 bottom-line">
							<view class="h2">{{data.name}}</view>
						</view>
						<view class="m-3">{{data.inviter}}邀请你加入【{{data.name}}】</view>
					</view>
				</view>
				<view v-if="isPending" class="container">
					<view class="section mt-2 pb-5">
						<m-result style="height: 600rpx" type="success" description="您的申请已提交，等待管理员审核" confirmText="进入商户中心" @confirm="push('/pages/merchant/select')"></m-result>
					</view>
				</view>
				<template v-else>
                    <t-cell-group t-class="mt-2" theme="card">
                        <t-cell title="角色" :note="data.roleName" :bordered="false" />
                    </t-cell-group>
					<!-- 未加入门店 -->
					<t-cell-group t-class="mt-2" theme="card">
						<t-input label="姓名" v-model:value="form.name" align="right" placeholder="请填写员工姓名" />
					</t-cell-group>
					<t-cell-group t-class="mt-2" theme="card">
						<t-input label="手机号" v-model:value="form.mobile" align="right" type="number" placeholder="请填写手机号码" />
					</t-cell-group>
					<t-cell-group t-class="mt-2" theme="card">
						<m-gender-picker v-model:value="form.gender"></m-gender-picker>
					</t-cell-group>

					<t-cell-group v-if="data.isSelectStore" t-class="mt-2" theme="card">
						<m-store-select v-model:value="form.storeId" label="所属门店" placeholder="请选择所属门店" gateway="/user/join/merchant/stores?inviteKey="
                                        :params="gatewayParams" :multiple="false"/>
					</t-cell-group>
					<view v-if="isLoggedIn && nickname" class="container mt-2">
						<view class="input user-info-section">
							<view class="input-label">用户</view>
							<view class="d-flex align-items-center mr-2">
								<view class="avatar-container">
									<image :src="avatar" class="avatar" mode="aspectFill"></image>
								</view>
								<view class="nickname">{{nickname}}</view>
							</view>
						</view>
					</view>
					<t-cell-group t-class="mt-5 container">
                        <t-button v-if="isLoggedIn && nickname" theme="danger" size="large" block :loading="loading"
                                  @click="registerSubscribeMessage">加入商家
                        </t-button>
						<get-user-info v-else :args="{ withCredentials: true, lang: 'en' }" @success="onGetUserInfoSuccess" @fail="onGetUserInfoFail">
                            <button class="button-normal"
                                    :style="{ height: '98rpx', backgroundColor: 'var(--td-brand-color)', color: '#fff', fontWeight: 600 }">
                                微信一键授权登录
                            </button>
						</get-user-info>
					</t-cell-group>
				</template>
			</view>
		</template>


	</template>
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref } from 'vue'
	import request from "@/hooks/request.js"
	import { useLink } from "@/hooks/useLink.js"
	import utils from '@/utils/utils.js'
	import config from '@/config.js'
	import { useAuth } from "@/hooks/useAuth.js"

	const { login, isLoggedIn, getAccount, nickname, avatar } = useAuth();
	const inviteKey = ref(undefined)
    const isInvalid = ref(false)
	const data = ref()
	const loading = ref(false)
	const isPending = ref(false)
	// 跳转到商户选择页
	const { push } = useLink()
	const form = ref({
		name: '',
		mobile: '',
		gender: undefined,
		storeId: undefined,
		isSelectStore: false
	})

    //用于通过inviteKey请求门店列表，因inviteKey通过gateway字符串传参会丢失部分数据，改为object传参方式
    const gatewayParams = ref()

	const getInviteInfo = () => {
		if (isLoggedIn.value && !nickname.value) {
			getAccount()
		}
		request.get('/user/join/merchant/info', { inviteKey: inviteKey.value }).then(res => {
			data.value = res.data
		})
	}

	// 用户授权成功事件
	const onGetUserInfoSuccess = (e) => {
		login({
			nickname: e.detail.userInfo.nickName,
			avatar: e.detail.userInfo.avatarUrl
		}).then(res => {
			console.log('员工加入Login :', res)
		})
	}
	// 用户一键授权失败事件
	const onGetUserInfoFail = (e) => {
		console.log(e)
	}

    const validateForm = () => {
        if (!form.value.name?.trim()) {
            utils.toast('请填写姓名')
            return false
        }
        if (!form.value.mobile?.trim()) {
            utils.toast('请填写手机号')
            return false
        }
        if (data.value?.isSelectStore && !form.value.storeId) {
            utils.toast('请选择门店')
            return false
        }
        return true
    }

    const registerSubscribeMessage = () => {
        if (!validateForm()) {
            return
        }
		loading.value = true
		utils.showLoading()
        uni.requestSubscribeMessage({
			tmplIds: config.subscribeMessage.pendingAudit,
            success() {
                onSubmit()
            },
            fail() {
                onSubmit()
            }
        })
    }

    const onSubmit = () => {
        if (!validateForm()) {
            utils.hideLoading()
            loading.value = false
            return
        }
		form.value.inviteKey = inviteKey.value
		request.post('/user/merchant/join', form.value).then(res => {
			isPending.value = true
			utils.hideLoading()
			loading.value = false
		}).catch(e => {
			loading.value = false
		})
	}
	onLoad((e) => {
        if (e.inviteKey !== undefined) {
            inviteKey.value = e.inviteKey
            isInvalid.value = false
            gatewayParams.value = {
                inviteKey: inviteKey.value
            }
            getInviteInfo()
        } else {
            isInvalid.value = true
        }
	})
</script>

<style scoped>
	.user-info-section {
		padding: 22rpx 32rpx !important;
		justify-content: space-between;
	}

	.avatar-container {
		width: 64rpx;
		height: 64rpx;
		border-radius: 50%;
		overflow: hidden;
		background-color: #f0f0f0;
	}

	.avatar {
		width: 100%;
		height: 100%;
	}


	.nickname {
		font-size: 32rpx;
		font-weight: 500;
		color: #333;
		margin-left: 16rpx;
	}
</style>