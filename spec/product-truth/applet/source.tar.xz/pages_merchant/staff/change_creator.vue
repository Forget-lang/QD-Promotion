<template>
    <m-result v-if="showSuccess" title="变更成功" description="超级管理员已成功变更" back></m-result>
    <view v-else class="container-safety">
        <t-cell-group title="当前超级管理员信息" theme="card">
            <m-sms-code
                gateway="/seller/merchant/send-sms-code-to-creator"
                :require-mobile="false"
                v-model:value="form.smsCode"
                label="验证码"
            />
        </t-cell-group>

        <t-cell-group title="新超级管理员信息" theme="card">
            <m-staff-select v-model:value="form.staffId" title="超级管理员" :multiple="false" placeholder="请选择员工"></m-staff-select>
            <t-input label="手机号" v-model:value="form.mobile" placeholder="请输入新管理员手机号" type="number"
                     :maxlength="11"/>
            <m-sms-code v-model:mobile="form.mobile" v-model:value="form.submitSmsCode" label="验证码"/>
        </t-cell-group>

        <view class="container mt-2">
            <view class="text-muted">
                变更超级管理员后，当前超级管理员将变更为普通员工，请审慎操作！
            </view>
        </view>
        <m-submit :loading="loading" :disabled="loading" @click="onSubmit">确认变更</m-submit>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'

const loading = ref(false)
const showSuccess = ref(false)
const form = ref({
    staffId: '',
    smsCode: '',
    mobile: '',
    submitSmsCode: ''
})

const onSubmit = () => {
    if (!form.value.smsCode) {
        utils.toast('请输入当前管理员验证码')
        return
    }
    if (!form.value.staffId) {
        utils.toast('请选择新管理员')
        return
    }
    if (!form.value.mobile) {
        utils.toast('请输入新管理员手机号')
        return
    }
    if (!utils.validateMobile(form.value.mobile)) {
        utils.toast('请输入正确的新管理员手机号')
        return
    }
    if (!form.value.submitSmsCode) {
        utils.toast('请输入新管理员验证码')
        return
    }

    loading.value = true
    request.post('/seller/staff/change-creator', {
        staffId: form.value.staffId,
        mobile: form.value.mobile,
        smsCode: form.value.smsCode,
        submitSmsCode: form.value.submitSmsCode,
    }).then(res => {
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}

onLoad(() => {
})
</script>

<style scoped>
</style>
