<template>
    <m-loading v-if="data === undefined"></m-loading>
    <template v-else>
        <view class="container-safety">
            <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                <t-cell title="员工编号" arrow @click="onCopyStaffCode">
                    <template #note>
                        <view class="cell-more">YG{{ utils.formatSeparator(data.id, '-') }}</view>
                    </template>
                </t-cell>
                <t-cell title="员工姓名">
                    <template #note>
                        {{ data.name }}
                    </template>
                </t-cell>
                <t-cell v-if="!isCreator" title="员工状态"
                        :arrow="canChangeStatus"
                        :hover="canChangeStatus" @click="showChangeStatus">
                    <template #note>
                        <text class="text-info" v-if="data.status === STAFF_STATUS.PENDING">{{ data.statusLabel }}</text>
                        <text class="text-success" v-if="data.status === STAFF_STATUS.NORMAL">{{ data.statusLabel }}</text>
                        <text class="text-danger" v-if="data.status === STAFF_STATUS.LEAVED || data.status === STAFF_STATUS.LOCKED">{{
                                data.statusLabel
                            }}
                        </text>
                    </template>
                </t-cell>
                <t-cell title="性别" :note="data.gender || '-'"/>
                <t-cell title="员工角色" :note="data.roleName"/>
                <t-cell title="联系方式" :note="data.mobile || '-'" :arrow="data.mobile.length > 0"
                        :hover="data.mobile.length > 0"
                        @click="utils.makePhoneCall(data.mobile, '')"/>
                <t-cell title="隐私数据脱敏" :note="data.isEncrypt?'是':'否'"/>
                <t-cell title="备注" :note="data.remark || '-'"/>
                <t-cell title="加入时间" :note="data.createdAt"/>
                <t-cell title="最后活跃时间" :note="data.activedAt || '-'" :bordered="!isCreator"/>
                <t-cell v-if="!isCreator" title="邀请人" :note="data.inviter || '-'" :bordered="false"/>
            </t-cell-group>

            <t-cell-group v-if="!isCreator" theme="card" title="门店信息" :bordered="false">
                <t-cell title="绑定门店" :note="data.storeName || '无'" :bordered="false"></t-cell>
                <!-- <view class="text-muted m-3">如员工绑定门店，则只能查看和操作门店的数据</view> -->
            </t-cell-group>


            <t-cell-group title="操作员工" theme="card" :bordered="false">
                <t-cell v-if="checkPermission(PERM_STAFF.VIEW)" title="查看操作日志" arrow hover
                        @click="push('/pages_merchant/staff/operation_log?staffId=' + data.id)"/>
                <t-cell v-if="isCreator && checkPermission(PERM_STAFF.UPDATE)" title="变更超级管理员" arrow hover
                        @click="push('/pages_merchant/staff/change_creator')" :bordered="false"/>
                <t-cell v-if="checkPermission(PERM_STAFF.DELETE) && !data.isCreator" title="删除员工" arrow hover
                        @click="onDeleteConfirm" :bordered="false">
                    <template #description>
                        <view class="text-muted text-danger">删除后不可恢复，请审慎操作！</view>
                    </template>
                </t-cell>
            </t-cell-group>
        </view>
        <m-submit v-if="checkPermission(PERM_STAFF.UPDATE)" @click="push('/pages_merchant/staff/edit?staffId='+staffId)">
            修改资料
        </m-submit>
        <t-action-sheet v-model:visible="showStatusSheet" description="修改员工状态" :items="options"
                        @selected="onStatusChange" @cancel="showStatusSheet = false"/>

        <t-action-sheet ref="sheetRef" @selected="onDelete"></t-action-sheet>
    </template>
</template>

<script setup>
import {onLoad, onUnload, onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from "@/hooks/request.js"
import {STAFF_STATUS} from "@/constants/merchant.js"
import utils from '@/utils/utils.js'
import {useAuth} from "@/hooks/useAuth.js"
import {PERM_STAFF} from "@/constants/permission.js"
import {useLink} from "@/hooks/useLink.js"
import {ActionSheetPlugin, ActionSheetTheme} from '@/uni_modules/tdesign-uniapp/components/index'

const {checkPermission} = useAuth();
const {push, back} = useLink()
const staffId = ref()
const isCreator = ref(false)
const data = ref()
const showModal = ref(false)
const showStatusSheet = ref(false)
const options = [{
    label: "解除冻结",
    color: "#00b359"
},
    {
        label: "冻结员工",
        color: "#EB0909"
    }
]
const isDeleteSuccess = ref(false)

// 是否可修改员工状态：有 StaffUpdate 权限且状态为正常/冻结时才允许
const canChangeStatus = computed(() => {
    return checkPermission(PERM_STAFF.UPDATE) &&
        (data.value?.status === STAFF_STATUS.NORMAL || data.value?.status === STAFF_STATUS.LOCKED)
})

// 复制员工编号
const onCopyStaffCode = () => {
    const code = 'YG' + utils.formatSeparator(data.value.id, '-')
    utils.copyClipboard(code, '员工编号已复制到剪切板')
}

const getStaff = () => {
    request.get('/seller/staff/one', {id: staffId.value}).then(res => {
        data.value = res.data
        isCreator.value = res.data.isCreator
    })
}

const showChangeStatus = () => {
    if (checkPermission(PERM_STAFF.UPDATE) &&
        (data.value.status === STAFF_STATUS.NORMAL || data.value.status === STAFF_STATUS.LOCKED)) {
        showStatusSheet.value = true
    }
}

// 改变员工状态
const changeStatus = (status) => {
    utils.showLoading()
    request.post('/seller/staff/toggle-status', {
        id: staffId.value,
        status: status
    }).then(res => {
        getStaff()
        utils.hideLoading()
        utils.toast(res.message)
    }).catch(() => {
        utils.hideLoading()
    })
}

// 状态改变选项事件
const onStatusChange = (e) => {
    showStatusSheet.value = false
    if (String(data.value.status) === e.status) {
        return
    }
    changeStatus(e.status)
}

const onDeleteConfirm = () => {
    ActionSheetPlugin.show({
        theme: ActionSheetTheme.List,
        selector: '#sheetRef',
        context: this,
        description: '删除不可撤回，确定要删除吗？',
        items: [{
            label: '删除员工',
            color: '#E3302D',
        },],
    })
}

const onDelete = () => {
    utils.showLoading()
    request.post('/seller/staff/delete', {id: staffId.value}).then(res => {
        isDeleteSuccess.value = true
        showModal.value = false
        utils.hideLoading()
        utils.alert('删除成功', () => {
            back()
        })
    }).catch(err => {
        utils.hideLoading()
    })
}

onLoad((e) => {
    staffId.value = e.staffId
})

onShow(() => {
    getStaff()
})

onPullDownRefresh(() => {
    getStaff()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})
</script>

<style scoped>
.tag-info {
    display: inline-block;
    padding: 4rpx 8rpx;
    margin-right: 10rpx;
    font-size: 22rpx;
    color: #fff;
    background-color: #00c352;
    border-radius: 4rpx;
}
</style>