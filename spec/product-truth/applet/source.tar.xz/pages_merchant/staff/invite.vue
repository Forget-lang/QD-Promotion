<template>
    <view class="container-safety">
        <view class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="h4">邀请须知：</view>
                <view class="mt-1 text-small">点击邀请会发起微信分享，所有收到分享的员工点击邀请可加入。请先分配角色</view>
                <view class="mt-1 text-small">如果选择了绑定的门店，则员工加入后默认为门店员工。后续可修改。</view>
                <view class="mt-1 text-small">为保障数据安全性，邀请链接有时间限制，超时后请重新发起邀请。</view>
            </view>
            <view class="section mt-2">
                <m-role-select v-model:value="form.roleId"></m-role-select>
                <view class="cell p-3 text-muted top-line">
                    <text>请选择邀请的员工默认角色</text>
                </view>
            </view>

            <view class="section mt-2">
                <view class="input">
                    <view class="input-label">邀请有效时长</view>
                </view>
                <view class="container bottom-line">
                    <m-tag-select v-model:value="form.expireTime" :column="5" :options="durationOptions"></m-tag-select>
                </view>
                <view class="d-flex text-muted p-3">
                    <text>超过有效期后，邀请链接失效，需要重新发起邀请。</text>
                </view>
            </view>
        </view>
        <view class="mt-2 mb-3">
            <view class="help-title">员工权限说明</view>
            <t-collapse theme="card" expand-mutex :value="helpValues" @change="onHelpChange">
                <t-collapse-panel header="如何授权员工发放卡券？" value="issueCoupon">
                    发放权限所有员工都具备。需要在创建优惠券、券包、次卡时被设置为发券员工后，才具备。
                </t-collapse-panel>
                <t-collapse-panel header="如何授权员工发放积分？" value="issuePoint">
                    发放权限所有员工都具备。需要在商户中心 - 积分 - 发放员工中设置，只有被授权后，才具备。
                </t-collapse-panel>
                <t-collapse-panel header="品牌管理员权限说明" value="brand">
                    品牌管理员除了不能操作注销商家，拥有创建人所有的权限。
                </t-collapse-panel>
                <t-collapse-panel header="门店管理员权限说明" value="storeManager">
                    门店管理员只能查看所属门店的数据，角色权限说明：查看、修改门店；查看员工；优惠券、券包、次卡的发放、核销、作废，查看领取、核销、作废记录，数据统计；积分的发放，查看发放明细、数据统计等。
                </t-collapse-panel>
                <t-collapse-panel header="门店核销员权限说明" value="storeVerifier">
                    门店核销员只能查看自己的数据，角色权限说明：优惠券、券包、次卡的发放、核销、作废，查看领取、核销、作废记录，我的个人业绩；积分的发放，查看发放明细、数据统计等。
                </t-collapse-panel>
                <t-collapse-panel header="门店发券员权限说明" value="storeCoupon">
                    门店发券员只能查看自己的数据，角色权限说明：优惠券、券包、次卡的发放，领取记录查看；积分的发放，查看发放明细、数据统计等。
                </t-collapse-panel>
            </t-collapse>
        </view>
    </view>
	<m-submit @click="onSubmit">提交</m-submit>

	<!-- 分享弹框 -->
	<t-popup :visible="showSharePopup" placement="bottom">
		<view class="popup-header">
			<view class="popup-header-title">邀请好友加入</view>
		</view>
		<view class="m-alert-content mt-4">
			<view class="section section-alert m-2 p-4">
				<view>点击邀请会发起微信分享，所有收到分享的员工点击邀请链接可加入。</view>
			</view>
			<view class="container mt-5">
				<t-button theme="danger" size="large" block openType="share" :disabled="!inviteKey">
					邀请员工
				</t-button>
			</view>
			<view class="text-center m-2 p-2">
				<span @click="showSharePopup = false" class="text-wechat">取消</span>
			</view>
		</view>
	</t-popup>

	<!-- 版本升级抽屉：员工额度超限后端 2006 拦截承接 -->
	<m-vip-upgrade/>
</template>

<script setup>
	import { onLoad, onShow, onShareAppMessage } from '@dcloudio/uni-app'
	import { ref } from 'vue'
	import request from "@/hooks/request.js"
	import { useSessionStore } from '@/stores/session'

	const sessionStore = useSessionStore()
	const form = ref({
		roleId: undefined,
		expireTime: 3600
	})
	const showSharePopup = ref(false)
	const inviteKey = ref()

	const helpValues = ref(['issueCoupon'])

	const onHelpChange = (e) => {
		helpValues.value = e?.value ?? e?.detail?.value ?? []
	}

	// 邀请有效时长选项
	const durationOptions = [
		{ label: '5分钟', value: 300 },
		{ label: '30分钟', value: 1800 },
		{ label: '1小时', value: 3600 },
		{ label: '12小时', value: 43200 },
		{ label: '1天', value: 86400 },
	]

	const onSubmit = () => {
		console.log('当前门店：', sessionStore.merchantName)
		request.get('/seller/staff/invite-key', form.value).then(res => {
			inviteKey.value = res.data.inviteKey // 邀请令牌，把令牌加入到邀请链接中
			showSharePopup.value = true
		}).catch(err => {

		})
	}

	onShareAppMessage((res) => {
		let title = '好友邀请你加入' + sessionStore.merchantName
		let share = {
			title: title,
			imageUrl: 'https://cdn.lenmy.com/img/faquanniu-invite-staff.png',
			desc: '一起来管理' + sessionStore.merchantName,
            path: '/pages_merchant/staff/join?inviteKey=' + inviteKey.value,
		};
		return share
	})
	onLoad((e) => {
        uni.hideShareMenu()
        uni.updateShareMenu({
            withShareTicket: true,
            isPrivateMessage: true
        })

	})
	onShow(() => {

	})
</script>

<style scoped>
.help-title {
	padding: 24rpx 48rpx 16rpx;
	font-size: 28rpx;
	color: #999;
}
</style>