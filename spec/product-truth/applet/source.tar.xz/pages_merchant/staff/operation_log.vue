<template>
    <m-loading v-if="items === undefined"></m-loading>
    <m-empty v-else-if="items === null">
        <view>加载失败</view>
        <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
    </m-empty>
    <view class="container mt-2" v-else>
        <m-empty v-if="items.length === 0">暂无操作日志</m-empty>
        <template v-else>
            <view
                class="log-item"
                v-for="(item, index) in items"
                :key="item.id || index"
            >
                <view class="log-header">
                    <view class="log-user">
                        <view class="log-avatar">
                            <image v-if="item.avatar" :src="item.avatar" mode="aspectFill"></image>
                            <text v-else>{{ (item.staffName || '?').charAt(0) }}</text>
                        </view>
                        <view class="log-user-meta">
                            <view class="log-name-row">
                                <text class="log-name">{{ item.staffName || '未知员工' }}</text>
                                <t-tag
                                    v-if="item.roleName"
                                    theme="warning"
                                    variant="light"
                                    size="small"
                                >{{ item.roleName }}
                                </t-tag>
                            </view>
                            <text class="log-time">{{ formatTime(item.createdAt) }}</text>
                        </view>
                    </view>
                    <text
                        class="log-status"
                        :class="item.status ? 'text-success' : 'text-danger'"
                    >
                        {{ item.status ? '操作成功' : '操作失败' }}
                    </text>
                </view>

                <view class="log-content">{{ item.content || '—' }}</view>

                <view class="log-meta" v-if="item.storeName || item.ip">
                    <text v-if="item.storeName" class="log-meta-text">{{ item.storeName }}</text>
                    <text v-if="item.storeName && item.ip" class="log-meta-sep">·</text>
                    <text v-if="item.ip" class="log-meta-text">{{ item.ip }}</text>
                </view>
            </view>
            <m-loading v-if="loadingMore" text="正在加载..."/>
            <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request.js'
import to from "@/hooks/to";

const search = ref({
    staffId: undefined,
    page: 1,
    pageSize: 20,
})
const items = ref()
const isCompleted = ref(false)
const loadingMore = ref(false)

const formatTime = (t) => {
    if (!t) return ''
    return String(t).replace('T', ' ').slice(0, 19)
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/staff/action/log', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(err => {
        if (search.value.page === 1) {
            //只有首次加载失败（请求超时等情况），页面显示网络错误样式，可重试请求
            items.value = null
        } else {
            // 加载失败，页码减一（因为onReachBottom已触发page+1，需要减掉）
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

onLoad((e) => {
    if (e.staffId) {
        search.value.staffId = e.staffId
        getItems()
    }
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.log-item {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
    margin-bottom: 20rpx;
}

.log-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16rpx;
}

.log-user {
    display: flex;
    align-items: flex-start;
    flex: 1;
    min-width: 0;
}

.log-avatar {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    background: #e8f8ef;
    color: #07c160;
    font-size: 28rpx;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
    overflow: hidden;
}

.log-avatar image {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}

.log-user-meta {
    flex: 1;
    min-width: 0;
    padding-top: 4rpx;
}

.log-name-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 12rpx;
    margin-bottom: 8rpx;
}

.log-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
}

.log-time {
    font-size: 24rpx;
    color: #999;
}

.log-status {
    flex-shrink: 0;
    font-size: 24rpx;
    margin-top: 8rpx;
}

.log-content {
    margin-top: 20rpx;
    font-size: 28rpx;
    color: #333;
    line-height: 1.6;
    word-break: break-all;
}

.log-meta {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 16rpx;
}

.log-meta-text {
    font-size: 22rpx;
    color: #999;
}

.log-meta-sep {
    margin: 0 8rpx;
    font-size: 22rpx;
    color: #ccc;
}
</style>
