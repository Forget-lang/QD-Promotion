<template>
	<m-loading v-if="items === undefined"></m-loading>
	<template v-else>
		<view class="container mt-2">
			<!-- 操作按钮 -->
			<view class="action-buttons">
				<view class="action-btn-left text-success" @click="selectAll(true)">
					<text class="action-dot"></text>
					全部通过
				</view>
				<view class="action-btn-right text-danger" @click="selectAll(false)">
					<text class="action-dot action-dot-red"></text>
					全部拒绝
				</view>
			</view>
        </view>
        <!-- 列表 -->
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell v-for="(item,index) in items" :key="index" :title="item.name" :image="item.avatar">
                <template #description>
                    <view class="m-flex mt-1">
                        <t-tag theme="success" variant="light-outline" size="small">{{item.storeName}}</t-tag>
                        <t-tag theme="warning" variant="light" size="small">{{item.roleName}}</t-tag>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="item.isConfirm"></t-switch>
                </template>
            </t-cell>
        </t-cell-group>
        <!-- 页面标题 -->
        <view class="page-header">
            <view class="page-stats">
                <text class="stat-passed">已通过 {{ passedCount }} 人</text>
                <text class="stat-rejected">已拒绝 {{ rejectedCount }} 人</text>
            </view>
        </view>
        <m-empty v-if="items.length === 0">暂无待审核员工</m-empty>
		<m-submit @click="onSubmit" :disabled="items.length === 0">提交</m-submit>
	</template>

	<!-- 版本升级抽屉：审核通过致员工数超限时后端 2006 拦截承接 -->
	<m-vip-upgrade/>
</template>

<script setup>
	import { onLoad, onShow, onPullDownRefresh } from '@dcloudio/uni-app'
	import { ref, computed } from 'vue'
	import request from "@/hooks/request.js"
	import utils from '@/utils/utils.js'

	const items = ref()

	const passedCount = computed(() => {
		return items.value ? items.value.filter(item => item.isConfirm).length : 0
	})

	const rejectedCount = computed(() => {
		return items.value ? items.value.filter(item => !item.isConfirm).length : 0
	})

	const allPassed = computed(() => {
		return items.value && items.value.length > 0 && passedCount.value === items.value.length
	})

	const allRejected = computed(() => {
		return items.value && items.value.length > 0 && rejectedCount.value === items.value.length
	})

	const getItems = () => {
		request.get('/seller/staff/pending-list').then(res => {
			items.value = (res.data.items || []).map(item => ({ ...item, isConfirm: true }))
		})
	}

	const toggleisConfirm = (item) => {
		item.isConfirm = !item.isConfirm
	}

	const selectAll = (isConfirm) => {
		items.value.forEach(item => {
			item.isConfirm = isConfirm
		})
	}

	const getRoleClass = (roleName) => {
		const roleClasses = {
			'超级管理员': 'role-super',
			'店长': 'role-manager',
			'核销员': 'role-verifier',
			'发券员': 'role-coupon'
		}
		return roleClasses[roleName] || ''
	}

	const onSubmit = () => {
		console.log(items.value)
		const submitData = items.value.map(item => ({
			staffId: item.id,
			isConfirm: item.isConfirm
		}))
		console.log(submitData)

		utils.showLoading()
		request.post('/seller/staff/update-pending', { items: submitData }).then(res => {
			utils.hideLoading()
			utils.toast(res.message || '操作成功')
			getItems()
		}).catch(() => {
			utils.hideLoading()
		})
	}

	onLoad((e) => {
		getItems()
	})

	onShow(() => {

	})

	onPullDownRefresh(() => {
		getItems()
		setTimeout(() => {
			uni.stopPullDownRefresh()
		}, 500)
	})
</script>

<style scoped>
	.page-header {
		padding: 30rpx;
		text-align: center;
	}

	.page-title {
		font-size: 36rpx;
		font-weight: 600;
		color: #333;
		margin-bottom: 12rpx;
	}

	.page-stats {
		display: flex;
		justify-content: center;
		gap: 30rpx;
	}

	.stat-passed {
		font-size: 24rpx;
		color: #00c352;
	}

	.stat-rejected {
		font-size: 24rpx;
		color: #EB0909;
	}

	.action-buttons {
		display: flex;
		border-radius: 18rpx;
		overflow: hidden;
		background-color: #fff;
		border: 1rpx solid #f5f5f5;
	}

	.action-btn-left {
		flex: 1;
		padding: 20rpx;
		text-align: center;
		font-size: 28rpx;
		border-right: 1rpx solid #f5f5f5;
		position: relative;
	}

	.action-btn-right {
		flex: 1;
		padding: 20rpx;
		text-align: center;
		font-size: 28rpx;
		position: relative;
	}

	.action-btn-left:hover,
	.action-btn-right:hover {
		background-color: rgba(0, 0, 0, 0.1);
	}

	.action-dot {
		display: inline-block;
		width: 10rpx;
		height: 10rpx;
		border-radius: 50%;
		background-color: #00c352;
		margin-right: 8rpx;
		vertical-align: middle;
	}

	.action-dot-red {
		background-color: #EB0909;
	}

	.apply-item {
		display: flex;
		align-items: center;
		justify-content: space-between;
		padding: 26rpx 30rpx;
		background-color: #fff;
		margin-bottom: 1rpx;
	}

	.apply-info {
		display: flex;
		align-items: center;
		flex: 1;
	}

	.info-content {
		flex: 1;
		display: flex;
		flex-direction: column;
	}

	.staff-name {
		font-size: 30rpx;
		font-weight: 500;
		color: #333;
		margin-bottom: 8rpx;
	}

	.apply-desc {
		display: flex;
		align-items: center;
		font-size: 24rpx;
		color: #999;
	}

	.role-tag {
		margin-left: 12rpx;
		padding: 4rpx 8rpx;
		border-radius: 4rpx;
		font-size: 20rpx;
		color: #fff;
	}

	.role-super {
		color: #EB0909;
	}

	.role-manager {
		color: #007AFF;
	}

	.role-verifier {
		color: #FF9500;
	}

	.role-coupon {
		color: #00c352;
	}

	.status-switch {
		flex-shrink: 0;
	}

	.switch {
		width: 80rpx;
		height: 44rpx;
		border-radius: 22rpx;
		position: relative;
		cursor: pointer;
		transition: all 0.3s;
	}

	.switch-toggle {
		width: 40rpx;
		height: 40rpx;
		border-radius: 50%;
		background-color: #fff;
		position: absolute;
		top: 2rpx;
		left: 2rpx;
		transition: all 0.3s;
	}
</style>