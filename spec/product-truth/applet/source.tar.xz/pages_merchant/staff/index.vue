<template>
    <view>
        <view class="container-search">
            <view class="input-search">
                <t-input
                    :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                    placeholder="请输入员工姓名或手机号"
                    v-model:value="search.staffName"
                    borderless
                    size="small"
                    :clearable="{ name: 'close-circle-filled', size: '36rpx' }"
                    @change="onInputChange"
                    @enter="onSearch"
                />
                <view class="input-search-actions">
                    <t-button theme="default" size="small" variant="text" icon="search" @click="onSearch"></t-button>
                </view>
            </view>
        </view>
        <!-- 版本权益卡片：当前门店版本 + 员工使用额度（配色随版本主题） -->
        <view class="container mt-2" v-if="editionName">
            <view class="edition-card" :class="'theme-' + editionTheme.key">
                <view class="edition-head">
                    <image
                        v-if="editionIconSmall"
                        class="edition-head-icon"
                        :src="editionIconSmall"
                        mode="aspectFit"
                    />
                    <view class="edition-head-info">
                        <view class="edition-head-name">{{ editionName }}</view>
                        <view class="edition-head-sub" v-if="isFreeEdition">永久有效</view>
                        <view class="edition-head-sub" v-else-if="editionExpiredAt">有效期至：{{ editionExpiredAt }}</view>
                    </view>
                    <view class="edition-detail" @tap="openFullFeatures">
                        <text>版本详情</text>
                        <t-icon name="chevron-right" size="24rpx" custom-style="margin-left: 2rpx;"/>
                    </view>
                </view>
                <view class="edition-body">
                    <view class="edition-quota-label">员工使用额度</view>
                    <view class="edition-quota-main">
                        <view class="edition-quota-left">
                            <view class="edition-quota-num">
                                <text class="edition-quota-used">{{ staffUsed }}</text>
                                <text class="edition-quota-sep">/</text>
                                <text class="edition-quota-max">{{ editionStaffLimit }}</text>
                                <text v-if="staffBonus > 0" class="edition-quota-bonus"> + {{ staffBonus }}</text>
                                <text class="edition-quota-unit">人</text>
                            </view>
                        </view>
                    </view>
                    <view class="d-flex justify-content-between">
                        <view class="edition-quota-bar">
                            <t-progress
                                    theme="line"
                                    :percentage="staffPercent"
                                    :stroke-width="8"
                                    :color="editionTheme.color"
                                    track-color="#E4E9F2"
                                />
                            <view class="edition-quota-tip">当前最多可添加 {{ editionStaffLimit + staffBonus }} 名员工
                            </view>
                        </view>
                        <view class="edition-expand" @tap="openVipUpgrade">
                            <t-icon name="add-circle" size="32rpx" custom-style="margin-right: 6rpx;"/>
                            <text>扩容员工数量</text>
                        </view>
                    </view>
                </view>
            </view>
        </view>
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无员工</m-empty>
            <template v-else>
                <t-cell-group t-class="mt-2" theme="card">
                    <t-cell :arrow="true" v-for="item in items" :key="item.id" :image="item.avatar"
                            @click="push('/pages_merchant/staff/detail?staffId=' + item.id)">
                        <template #title>
                            <view class="d-flex align-items-center">
                                <text>{{ item.name }}</text>
                                <t-tag theme="warning" variant="light" size="small" t-class="ml-1">{{ item.roleName }}</t-tag>
                            </view>
                        </template>
                        <template #description>
                            <view class="m-flex mt-1">
                                <t-tag theme="success" variant="light-outline" size="small" max-width="280rpx">{{ item.storeName }}</t-tag>
                            </view>
                        </template>
                        <template #note>
                            <text class="text-muted" :class="item.status === STAFF_STATUS.NORMAL ? 'text-success' : 'text-danger'">{{ item.statusLabel }}</text>
                        </template>
                    </t-cell>
                </t-cell-group>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
            <m-submit v-if="checkPermission(PERM_STAFF.CREATE)" @click="onAddStaff">添加员工</m-submit>
        </template>
    </view>
    <!-- VIP 升级抽屉：打开走 useVipGuard / 事件 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onShow, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from "@/hooks/request"
import {STAFF_STATUS} from "@/constants/merchant.js"
import {EDITION_FEATURES, EDITION_ID_FREE, getFeatureQuota, getQuotaOverflow} from "@/constants/edition"
import {useLink} from "@/hooks/useLink"
import {useAuth} from "@/hooks/useAuth"
import {useVipGuard} from "@/hooks/useVipGuard"
import {PERM_STAFF} from "@/constants/permission"
import to from '@/hooks/to'

const {push} = useLink();
const {checkPermission, getSession, session} = useAuth();
const {check, open: openVipUpgrade} = useVipGuard()

// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    staffName: undefined
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 当前门店版本名称（版本卡片头部）
const editionName = computed(() => session.value.editionName || '')
// 当前门店版本方形徽标图
const editionIconSmall = computed(() => session.value.editionIconSmall || '')
// 是否免费版（免费版不展示到期时间，显示永久有效）
const isFreeEdition = computed(() => String(session.value.editionId || '') === String(EDITION_ID_FREE))
// 版本到期日期（接口含时分秒，仅截取年月日展示）
const editionExpiredAt = computed(() => String(session.value.editionExpiredAt || '').slice(0, 10))
// 版本主题配色映射（与 m-vip-upgrade 升级弹窗保持一致）
const editionThemeMap = {
    '标准版': {key: 'blue', color: '#007AFF'},
    '专业版': {key: 'orange', color: '#FF9500'},
    '企业版': {key: 'purple', color: '#7B61FF'},
}
// 版本主题（未匹配到付费版本时兜底品牌绿，如免费版）
const editionTheme = computed(() => editionThemeMap[editionName.value] || {key: 'green', color: '#07C160'})
// 员工总数（列表接口 total，用于版本额度展示）
const totalCount = ref(0)
// 已用员工额度
const staffUsed = computed(() => totalCount.value)
// 版本员工上限（未返回时回退配置表档位）
const editionStaffLimit = computed(() => to.Int(session.value.editionStaffLimit) || getFeatureQuota(EDITION_FEATURES.STAFF_COUNT, session.value.editionId))
// 活动福利员工数（在版本基础上增加）
const staffBonus = computed(() => to.Int(session.value.extraStaffCount))
// 有效总额度 = 版本 + 福利（仅用于进度条与添加拦截）
const staffLimit = computed(() => editionStaffLimit.value + staffBonus.value)
// 员工额度使用百分比
const staffPercent = computed(() => {
    if (!staffLimit.value) return 0
    return Math.min(100, Math.round(staffUsed.value / staffLimit.value * 100))
})
// 完整功能对比页 H5 地址（与 m-vip-upgrade 保持一致）
const PRICE_TABLE_H5 = 'https://www.quandaokabao.com/price-table/'

// 添加员工：有效上限 = 版本 + 活动福利；未达上限可加，达上限再走升级提醒
const onAddStaff = () => {
    if (staffUsed.value < staffLimit.value) {
        push('/pages_merchant/staff/invite')
        return
    }
    const overflow = getQuotaOverflow(EDITION_FEATURES.STAFF_COUNT, session.value.editionId, staffUsed.value)
    if (overflow) {
        check(overflow)
        return
    }
    uni.showToast({title: `员工数量已达上限（${staffLimit.value}）`, icon: 'none'})
}
// 打开完整功能对比 H5
const openFullFeatures = () => {
    uni.navigateTo({
        url: `/pages_assist/help/article?url=${encodeURIComponent(PRICE_TABLE_H5)}&title=${encodeURIComponent('完整功能对比')}`,
    })
}

// 搜索员工
const onSearch = (e) => {
    search.value.page = 1
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 监听输入变化，内容删空（点清除图标或退格删空）后立即刷新
const onInputChange = (e) => {
    if (!e.value) {
        onClear()
    }
}

// 清空搜索条件并刷新列表
const onClear = (e) => {
    search.value.staffName = undefined
    search.value.page = 1
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取员工列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/staff/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        totalCount.value = to.Int(res.data.total)
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 刷新列表
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

onShow(() => {
    onRefresh()
    getSession()
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
/*
 * 自定义样式原因：TDesign / app.css 不提供「版本权益卡片」（版本标识 + 额度进度 + 扩容入口）能力。
 * 替代方案：配色通过 --ed-* 变量跟随版本主题（与 m-vip-upgrade 升级弹窗一致），仅补缺位视觉层。
 */
.edition-card {
    --ed-color: #07C160;
    --ed-border: #BCE6CD;
    padding: 28rpx;
    border-radius: 20rpx;
    background: #fff;
}

/* 版本主题变量：蓝(标准版) / 橙(专业版) / 紫(企业版)，默认绿（免费版兜底） */
.edition-card.theme-blue {
    --ed-color: #007AFF;
    --ed-border: #B8D5FF;
}

.edition-card.theme-orange {
    --ed-color: #FF9500;
    --ed-border: #FFD9A8;
}

.edition-card.theme-purple {
    --ed-color: #7B61FF;
    --ed-border: #D4C9FF;
}

/* 头部：版本徽标 + 名称 + 版本详情入口 */
.edition-head {
    display: flex;
    align-items: center;
}

.edition-head-icon {
    flex-shrink: 0;
    width: 80rpx;
    height: 80rpx;
    margin-right: 16rpx;
}

.edition-head-info {
    flex: 1;
    min-width: 0;
}

.edition-head-name {
    font-size: 32rpx;
    font-weight: bold;
    color: #1a1a1a;
}

.edition-head-sub {
    margin-top: 4rpx;
    font-size: 24rpx;
    color: #999;
}

.edition-detail {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    padding: 10rpx 22rpx;
    border: 2rpx solid #f1f1f1;
    border-radius: 12rpx;
    font-size: 24rpx;
    color: #666;
}

/* 额度区：大数字 + 进度条 + 扩容入口 */
.edition-body {
    margin-top: 24rpx;
}

.edition-quota-label {
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
}

.edition-quota-main {
    display: flex;
    align-items: center;
    margin-top: 12rpx;
}

.edition-quota-left {
    flex: 1;
    min-width: 0;
    margin-right: 24rpx;
}

.edition-quota-num {
    display: flex;
    align-items: baseline;
}

.edition-quota-used {
    font-size: 64rpx;
    font-weight: bold;
    line-height: 1.1;
    color: var(--ed-color);
}

.edition-quota-sep {
    margin: 0 8rpx;
    font-size: 40rpx;
    color: #bbb;
}

.edition-quota-max {
    font-size: 56rpx;
    font-weight: bold;
    color: #1a1a1a;
}

.edition-quota-bonus {
    margin-left: 4rpx;
    font-size: 32rpx;
    font-weight: 600;
    color: var(--ed-color);
}

.edition-quota-unit {
    margin-left: 8rpx;
    font-size: 26rpx;
    color: #666;
}

.edition-quota-bar {
    margin-top: 8rpx;
}

.edition-expand {
    flex-shrink: 0;
    align-self: flex-end;
    display: flex;
    align-items: center;
    padding: 14rpx 24rpx;
    border: 2rpx solid var(--ed-color);
    border-radius: 12rpx;
    font-size: 24rpx;
    font-weight: 600;
    color: var(--ed-color);
}

.edition-quota-tip {
    margin-top: 16rpx;
    font-size: 24rpx;
    color: #999;
}
</style>