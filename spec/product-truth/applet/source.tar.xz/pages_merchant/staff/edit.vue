<template>
    <m-loading v-if="form === undefined"></m-loading>
    <template v-else>
        <m-result v-if="showSuccess" title="修改成功" description="员工信息修改成功" back></m-result>
        <template v-else>
            <view class="container-safety">
                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <t-input label="员工姓名" v-model:value="form.name" align="right" placeholder="请填写员工姓名"/>
                </t-cell-group>

                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <t-input label="联系方式" v-model:value="form.mobile" align="right" type="number" placeholder="请填写手机号"/>
                </t-cell-group>

                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <t-cell v-if="form.isCreator" title="角色" description="超级管理员不支持修改角色" note="超级管理员"></t-cell>
                    <m-role-select v-else v-model:value="form.roleId" :default-label="form.roleName" :disabled="form.isCreator"></m-role-select>
                </t-cell-group>

                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <m-gender-picker v-model:value="form.gender"></m-gender-picker>
                </t-cell-group>
                <t-cell-group v-if="!form.isCreator && !isBrandRole" t-class="mt-2" theme="card" :bordered="false">
                    <m-store-select v-model:value="form.storeId" label="绑定门店" :multiple="false"></m-store-select>
                </t-cell-group>

                <t-cell-group v-if="!form.isCreator" t-class="mt-2" theme="card" :bordered="false">
                    <t-cell title="冻结员工" :bordered="false">
                        <template #note>
                            <t-switch :default-value="form.status === STAFF_STATUS.LOCKED" v-model:value="form.locked"/>
                        </template>
                        <template #description>
                            <view class="text-muted">被冻结的员工会立即退出登录，并拒绝登录。</view>
                        </template>
                    </t-cell>
                </t-cell-group>

                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <t-cell title="隐私数据脱敏" :bordered="false">
                        <template #note>
                            <t-switch :default-value="true" v-model:value="form.isEncrypt"/>
                        </template>
                        <template #description>
                            <view class="text-muted">开启后，查看与导出隐私数据都会脱敏，如：150****3210</view>
                        </template>
                    </t-cell>
                </t-cell-group>

                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <t-textarea label="备注" :maxlength="32" v-model:value="form.remark" placeholder="备注员工，方便区分"></t-textarea>
                </t-cell-group>
            </view>
            <m-submit @click="onSubmit" :loading="loading">保存修改</m-submit>
        </template>
    </template>
</template>

<script setup>
import {onLoad, onShow} from '@dcloudio/uni-app';
import {computed, ref} from 'vue';
import request from '@/hooks/request.js';
import {ROLE_LEVEL_TYPE, STAFF_STATUS} from '@/constants/merchant.js';
import utils from '@/utils/utils.js';
import to from '@/hooks/to.js';
import {useSessionStore} from '@/stores/session';
import {useLink} from '@/hooks/useLink.js';

const {push, back} = useLink();
const session = useSessionStore();
const staffId = ref();
const form = ref();
const roles = ref([]);
const loading = ref(false);
const showSuccess = ref(false);

// 品牌级角色归属总部，不展示门店选择（与加入商户 isSelectStore 一致）
const isBrandRole = computed(() => {
    if (!form.value?.roleId) return false;
    const role = roles.value.find((item) => to.String(item.id) === to.String(form.value.roleId));
    return Number(role?.levelType) === ROLE_LEVEL_TYPE.BRAND;
});

const getRoles = () => {
    request.get('/seller/role/list').then((res) => {
        roles.value = to.Array(res.data?.items);
    });
};

const getStaff = () => {
    request.get('/seller/staff/one', {id: staffId.value}).then((res) => {
        form.value = res.data;
        form.value.locked = form.value.status === STAFF_STATUS.LOCKED;
    });
};

const onSubmit = () => {
    if (!form.value.name) {
        utils.toast('请输入姓名');
        return;
    }
    if (!form.value.roleId) {
        utils.toast('请选择角色');
        return;
    }
    if (!isBrandRole.value && !form.value.storeId) {
        utils.toast('请选择门店');
        return;
    }
    if (form.value.locked) {
        form.value.status = 3;
    } else {
        form.value.status = 1;
    }

    loading.value = true;
    const params = {
        ...form.value,
        id: staffId.value,
    };

    request
        .post('/seller/staff/update', params)
        .then((res) => {
            loading.value = false;
            showSuccess.value = true;
        })
        .catch((err) => {
            loading.value = false;
        });
};

onLoad((e) => {
    staffId.value = e.staffId;
    getRoles();
});

onShow(() => {
    getStaff();
});
</script>

<style scoped></style>
