<template>
    <m-loading v-if="items === undefined"></m-loading>
    <view v-else>
        <m-empty v-if="items.length === 0">暂无发票</m-empty>
        <t-cell-group v-else t-class="mt-2" theme="card">
            <t-cell v-for="item in items" :key="item.id" :title="item.title" :note="item.invoiceStatusLabel" arrow
                    @click="push('/pages_merchant/invoice/detail?id=' + item.id)">
                <template #description>
                    <view class="text-muted">¥{{ item.totalAmount }} · {{ item.createdAt }}</view>
                </template>
            </t-cell>
        </t-cell-group>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink.js'

const {push} = useLink()
const items = ref()

const load = () => {
    request.get('/seller/invoice/list', {page: 1, pageSize: 50}, {showLoading: false}).then(res => {
        items.value = res.data.items || []
    }).finally(() => {
        uni.stopPullDownRefresh()
    })
}

onLoad(load)
onPullDownRefresh(load)
</script>
