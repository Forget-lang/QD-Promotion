<template>
    <m-loading v-if="invoice === undefined"></m-loading>
    <view v-else class="pb-4">
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="状态" :note="invoice.invoiceStatusLabel"></t-cell>
            <t-cell title="抬头" :note="invoice.title"></t-cell>
            <t-cell title="金额" :note="'¥' + invoice.totalAmount"></t-cell>
            <t-cell title="发票号码" :note="invoice.invoiceNo || '-'"></t-cell>
            <t-cell title="开票日期" :note="invoice.invoiceAt || '-'"></t-cell>
            <t-cell v-if="invoice.failReason" title="拒绝原因" :note="invoice.failReason"></t-cell>
            <t-cell v-if="invoice.discardRemark" :title="invoice.invoiceStatus === 'refunded' ? '退票原因' : '作废备注'"
                    :note="invoice.discardRemark"></t-cell>
        </t-cell-group>
        <t-cell-group v-if="invoice.orders?.length" t-class="mt-2" theme="card">
            <t-cell v-for="item in invoice.orders" :key="item.orderId" :title="item.title || item.orderId"
                    :note="'¥' + item.invoiceAmount"></t-cell>
        </t-cell-group>
        <view v-if="invoice.invoiceStatus === 'success' && invoice.fileUrl" class="p-3">
            <image class="invoice-qr" :src="invoice.fileUrl" mode="widthFix" show-menu-by-longpress></image>
            <t-button theme="primary" block class="mt-3" @click="onDownload">下载发票</t-button>
        </view>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {downloadImage} from '@/hooks/useFile'

const invoice = ref()

const onDownload = () => {
    downloadImage(invoice.value.fileUrl)
}

onLoad((q) => {
    request.get('/seller/invoice/detail', {id: q.id}).then(res => {
        invoice.value = res.data
    })
})
</script>

<style scoped>
.invoice-qr {
    display: block;
    width: 100%;
    background: #fff;
    border-radius: 16rpx;
}
</style>
