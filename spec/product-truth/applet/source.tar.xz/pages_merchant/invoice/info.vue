<template>
    <m-loading v-if="form === undefined"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <view class="section mt-2">
                <t-input label="发票类型" :line-left="false" v-model:value="form.invoiceType"
                         placeholder="增值税普通发票" backgroundColor="#ffffff00" disabled></t-input>
                <t-input label="发票抬头" :line-left="false" v-model:value="form.title" placeholder="公司或个体户名称"
                         backgroundColor="#ffffff00"></t-input>
                <t-input label="税号" :line-left="false" v-model:value="form.registerNo" placeholder="统一社会信用代码"
                         backgroundColor="#ffffff00"></t-input>
                <t-input label="开户行" :line-left="false" v-model:value="form.bank" placeholder="选填"
                         backgroundColor="#ffffff00"></t-input>
                <t-input label="银行账号" :line-left="false" v-model:value="form.bankNo" placeholder="选填"
                         backgroundColor="#ffffff00"></t-input>
                <t-input label="地址" :line-left="false" v-model:value="form.address" placeholder="选填"
                         backgroundColor="#ffffff00"></t-input>
                <t-input label="电话" :line-left="false" v-model:value="form.phone" placeholder="选填"
                         backgroundColor="#ffffff00"></t-input>
                <t-input label="邮箱" :line-left="false" v-model:value="form.email" placeholder="选填"
                         backgroundColor="#ffffff00"></t-input>
            </view>
        </view>
        <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'

const loading = ref(false)
const form = ref()

const onSubmit = () => {
    if (!form.value.title || !form.value.registerNo) {
        uni.showToast({title: '请填写抬头和税号', icon: 'none'})
        return
    }
    loading.value = true
    request.post('/seller/merchant/invoice', form.value).then(() => {
        uni.showToast({title: '已保存', icon: 'success'})
        setTimeout(() => uni.navigateBack(), 400)
    }).finally(() => {
        loading.value = false
    })
}

onLoad(() => {
    request.get('/seller/merchant/invoice').then(res => {
        form.value = {
            title: res.data.title || '',
            invoiceType: res.data.invoiceType || '增值税普通发票',
            registerNo: res.data.registerNo || '',
            bank: res.data.bank || '',
            bankNo: res.data.bankNo || '',
            address: res.data.address || '',
            phone: res.data.phone || '',
            email: res.data.email || '',
        }
    })
})
</script>
