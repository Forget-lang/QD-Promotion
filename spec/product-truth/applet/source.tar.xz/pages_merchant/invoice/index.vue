<template>
    <m-loading v-if="amount === undefined"></m-loading>
    <view v-else class="pb-4">
        <view class="amount-box mt-2">
            <view class="amount-item">
                <view class="amount-value">¥{{ amount.validAmount }}</view>
                <view class="amount-label">可开票</view>
            </view>
            <view class="amount-item">
                <view class="amount-value">¥{{ amount.pendingAmount }}</view>
                <view class="amount-label">开票中</view>
            </view>
            <view class="amount-item">
                <view class="amount-value">¥{{ amount.invoicedAmount }}</view>
                <view class="amount-label">已开票</view>
            </view>
        </view>
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell arrow title="发票信息" t-class-title="text-cell-title" t-class-note="text-ellipsis text-scroll-hidden" :note="headerNote" url="/pages_merchant/invoice/info"></t-cell>
            <t-cell arrow title="申请开票" note="选择可开票订单" url="/pages_merchant/invoice/create"></t-cell>
            <t-cell arrow title="我的订单" url="/pages_merchant/order/list"></t-cell>
            <t-cell arrow title="我的发票" url="/pages_merchant/invoice/list"></t-cell>
        </t-cell-group>
    </view>
</template>

<script setup>
import {onShow} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'

const amount = ref()
const header = ref()
const headerNote = computed(() => header.value?.title ? header.value.title : '未填写')

const load = () => {
    request.get('/seller/order/invoice-amount', {}, {showLoading: false}).then(res => {
        amount.value = res.data
    })
    request.get('/seller/merchant/invoice', {}, {showLoading: false}).then(res => {
        header.value = res.data
    })
}

onShow(load)
</script>

<style scoped>
.amount-box {
    display: flex;
    background: #fff;
    margin: 24rpx;
    border-radius: 16rpx;
    padding: 32rpx 0;
}

.amount-item {
    flex: 1;
    text-align: center;
}

.amount-value {
    font-size: 36rpx;
    font-weight: 600;
}

.amount-label {
    margin-top: 8rpx;
    color: #888;
    font-size: 24rpx;
}
</style>
