<template>
    <m-loading v-if="items === undefined"></m-loading>
    <view v-else class="pb-4">
        <m-empty v-if="items.length === 0">暂无可开票订单</m-empty>
        <t-cell-group v-else t-class="mt-2" theme="card">
            <t-cell v-for="item in items" :key="item.id" :title="item.title" :note="'可开票 ¥' + item.invoiceableAmount"
                    :hover="true" @click="toggle(item.id)">
                <template #left-icon>
                    <view class="check" :class="{on: checked.includes(item.id)}"></view>
                </template>
                <template #description>
                    <view class="text-muted">订单 {{ item.id }} · 实付 ¥{{ item.payAmount }}</view>
                </template>
            </t-cell>
        </t-cell-group>
        <view v-if="items.length" class="bar">
            <view>合计 ¥{{ total }}</view>
            <!-- custom-style 用于抵消 t-button 自带的 margin:auto，否则 flex 剩余空间被外边距吃掉导致不靠右 -->
            <t-button theme="primary" size="small" custom-style="margin-left: 0; margin-right: 0;"
                      :disabled="checked.length === 0 || loading" :loading="loading" @click="onSubmit">提交申请
            </t-button>
        </view>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import to from '@/hooks/to'
import config from '@/config.js'
import utils from '@/utils/utils'

// 可开票订单列表（undefined 加载中 / 加载完成后为数组）
const items = ref()
// 已勾选申请开票的订单 ID 集合
const checked = ref([])
// 提交申请请求中标志，同时用于按钮 loading 与防重复提交
const loading = ref(false)

// 计算已勾选订单的可开票金额合计（元，保留两位小数）
const total = computed(() => {
    if (!items.value) return '0.00'
    return items.value
        .filter(row => checked.value.includes(row.id))
        .reduce((sum, row) => sum + (row.invoiceableAmount || 0), 0)
        .toFixed(2)
})

// 切换订单的勾选状态
const toggle = (id) => {
    const i = checked.value.indexOf(id)
    if (i >= 0) {
        checked.value.splice(i, 1)
    } else {
        checked.value.push(id)
    }
}

// 提交开票申请，成功后跳转申请详情
const apply = () => {
    loading.value = true
    request.post('/seller/invoice', {orderIds: checked.value}).then(res => {
        uni.showToast({title: '已提交', icon: 'success'})
        setTimeout(() => {
            uni.redirectTo({url: '/pages_merchant/invoice/detail?id=' + res.data.id})
        }, 400)
    }).finally(() => {
        loading.value = false
    })
}

// 点击提交申请（节流防连点）：未勾选订单时不发起订阅与请求
const onSubmit = utils.throttle(() => {
    if (!checked.value.length) return
    const tmplIds = config.subscribeMessage.invoice
    uni.requestSubscribeMessage({
        tmplIds: tmplIds,
        complete() {
            apply()
        },
    })
})

// 页面加载：先校验开票资料，再拉取未开票订单
onLoad(() => {
    request.get('/seller/merchant/invoice').then(res => {
        if (!res.data?.title || !res.data?.registerNo) {
            uni.showToast({title: '请先完善发票信息', icon: 'none'})
            setTimeout(() => {
                uni.redirectTo({url: '/pages_merchant/invoice/info'})
            }, 400)
            return
        }
        request.get('/seller/order/uninvoiced').then(uninvoiced => {
            items.value = to.Array(uninvoiced.data.items)
        }).catch(() => {
            items.value = []
        })
    }).catch(() => {
        items.value = []
    })
})
</script>

<style scoped>
.check {
    width: 36rpx;
    height: 36rpx;
    border: 2rpx solid #ccc;
    border-radius: 50%;
    margin-right: 16rpx;
}

.check.on {
    background: #0052d9;
    border-color: #0052d9;
}

.bar {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20rpx 32rpx calc(20rpx + env(safe-area-inset-bottom));
    background: #fff;
}
</style>
