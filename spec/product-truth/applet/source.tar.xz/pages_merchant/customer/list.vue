<template>
    <view class="container-search">
        <view class="input-search">
            <t-input
                :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                placeholder="昵称/手机/备注"
                v-model:value="search.keyword"
                borderless
                size="small"
                :clearable="{ name: 'close-circle-filled', size: '36rpx' }"
                @change="onInputChange"
                @enter="onSearch"
            />
            <view class="input-search-actions">
                <t-button theme="default" size="small" variant="text" icon="search" @click="onSearch"></t-button>
            </view>
        </view>
    </view>

    <view class="filter-bar">
        <view class="filter-bar-left">
            <view class="filter-bar-item" @tap="showOrderPicker = true">
                <text class="filter-bar-label filter-bar-sort" :class="{ 'filter-bar-active': !isDefaultSort }">
                    {{ sortLabel }}
                </text>
                <t-icon name="chevron-down" size="24rpx" :color="!isDefaultSort ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showLevelPicker = true">
                <text class="filter-bar-label"
                      :class="{ 'filter-bar-active': search.memberLevelId !== undefined && search.memberLevelId !== '' }">
                    {{ levelFilterLabel }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.memberLevelId !== undefined && search.memberLevelId !== '' ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showTimePicker = true">
                <text class="filter-bar-label filter-bar-time"
                      :class="{ 'filter-bar-active': search.startTime && search.endTime }">
                    {{ search.startTime && search.endTime ? search.startTime + '~' + search.endTime : '注册时间' }}
                </text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.startTime && search.endTime ? 'var(--td-brand-color)' : '#999'"/>
            </view>
        </view>
        <view class="filter-bar-right" @tap="onResetFilter">
            <text class="filter-bar-action">重置</text>
        </view>
    </view>

    <m-loading v-if="items === undefined"></m-loading>
    <m-empty v-else-if="items === null">
        <view>加载失败</view>
        <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
    </m-empty>
    <template v-else>
        <m-empty v-if="items.length === 0">暂无客户</m-empty>
        <template v-else>
            <t-cell-group t-class="mt-2" theme="card">
                <t-cell
                    :arrow="checkPermission(PERM_CUSTOMER.DETAIL)"
                    v-for="item in items"
                    :key="item.id"
                    :image="item.avatar"
                    @click="checkPermission(PERM_CUSTOMER.DETAIL) && push('/pages_merchant/customer/detail?userId=' + item.userId)"
                >
                    <template #title>
                        <view class="customer-title">
                            <text class="customer-name text-ellipsis">{{ item.nickname || '-' }}</text>
                            <m-member-level-badge
                                v-if="item.memberLevel"
                                class="customer-level"
                                :name="item.memberLevel.name"
                                :icon-key="item.memberLevel.iconKey"
                                :color="item.memberLevel.color"
                                size="sm"
                            />
                        </view>
                    </template>
                    <template #description>
                        <view class="text-muted text-small mt-1 d-flex align-items-center"
                              style="flex-wrap:wrap;gap:8rpx;">
                            <text v-if="item.mobile">{{ item.mobile }}</text>
                            <text v-if="item.mobile && item.remark"> ·</text>
                            <text v-if="item.remark">{{ item.remark }}</text>
                        </view>
                    </template>
                    <template #note>
                        <view class="text-muted text-small">
                            <text>{{ getNoteText(item) }}</text>
                        </view>
                    </template>
                </t-cell>
            </t-cell-group>
            <m-loading v-if="loadingMore" text="正在加载..."/>
            <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            <m-submit v-if="checkPermission(PERM_CUSTOMER.EXPORT)" @click="onExportList">导出客户列表</m-submit>
        </template>
    </template>

    <t-popup placement="bottom" v-model:visible="showTimePicker" @visible-change="onTimePickerChange" :z-index="10000"
             :overlay-props="{ zIndex: 9999 }">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-cancel" @tap="showTimePicker = false">取消</view>
                <view class="popup-header-title">选择注册时间</view>
                <view class="popup-header-confirm" @tap="onClearTime">清空</view>
            </view>
            <view class="popup-body" style="height: 600rpx;">
                <t-cell-group theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.startTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="开始时间"
                        placeholder="请选择开始时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <t-cell-group t-class="mt-2" theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.endTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="结束时间"
                        placeholder="请选择结束时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <view class="popup-footer mt-5">
                    <t-button theme="danger" size="large" block @click="onConfirmTime">确认</t-button>
                </view>
            </view>
        </view>
    </t-popup>

    <t-action-sheet
        :visible="showOrderPicker"
        :items="orderItems"
        @selected="onSelectOrder"
        @cancel="showOrderPicker = false"
    ></t-action-sheet>
    <t-action-sheet
        :visible="showLevelPicker"
        :items="levelPickerItems"
        @selected="onSelectLevel"
        @cancel="showLevelPicker = false"
    ></t-action-sheet>

    <!-- VIP 升级抽屉：承接导出接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onShow, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import utils from '@/utils/utils'
import {useAuth} from '@/hooks/useAuth'
import {PERM_CUSTOMER} from '@/constants/permission'
import {saveBase64Excel} from '@/hooks/useFile'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    keyword: undefined,
    memberLevelId: undefined,
    sortBy: 'joinedAt',
    sorter: 'desc',
    startTime: undefined,
    endTime: undefined,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

const showTimePicker = ref(false)
const showOrderPicker = ref(false)
const showLevelPicker = ref(false)
const levelOptions = ref([])
const tempTime = ref({
    startTime: '',
    endTime: '',
})

const orderItems = [
    {label: '注册时间最新', value: 'joinedAt:desc'},
    {label: '注册时间最早', value: 'joinedAt:asc'},
    {label: '积分余额从高到低', value: 'pointBalance:desc'},
    {label: '优惠券领取数量从多到少', value: 'couponReceiveCount:desc'},
    {label: '优惠券核销数量从多到少', value: 'couponVerifyCount:desc'},
    {label: '次卡领取数量从多到少', value: 'cardReceiveCount:desc'},
    {label: '次卡核销数量从多到少', value: 'cardVerifyCount:desc'},
]

const levelPickerItems = computed(() => {
    const list = [
        {label: '全部等级', value: ''},
        {label: '未设等级', value: '0'},
    ]
    levelOptions.value.forEach((item) => {
        list.push({label: item.name, value: String(item.id)})
    })
    return list
})

const levelFilterLabel = computed(() => {
    const id = search.value.memberLevelId
    if (id === undefined || id === '') return '会员等级'
    if (id === '0') return '未设等级'
    const hit = levelOptions.value.find((item) => String(item.id) === String(id))
    return hit ? hit.name : '会员等级'
})

const sortLabelMap = {
    'joinedAt:desc': '注册最新',
    'joinedAt:asc': '注册最早',
    'pointBalance:desc': '积分最多',
    'couponReceiveCount:desc': '优惠券领取最多',
    'couponVerifyCount:desc': '优惠券核销最多',
    'cardReceiveCount:desc': '次卡领取最多',
    'cardVerifyCount:desc': '次卡核销最多',
}

const currentSortKey = computed(() => `${search.value.sortBy || 'joinedAt'}:${search.value.sorter || 'desc'}`)
const sortLabel = computed(() => sortLabelMap[currentSortKey.value] || '注册最新')
const isDefaultSort = computed(() => currentSortKey.value === 'joinedAt:desc')

const getNoteText = (item) => {
    switch (search.value.sortBy) {
        case 'pointBalance':
            return `积分 ${item.pointBalance ?? 0}`
        case 'couponReceiveCount':
            return `优惠券领取 ${item.couponReceiveCount ?? 0}`
        case 'couponVerifyCount':
            return `优惠券核销 ${item.couponVerifyCount ?? 0}`
        case 'cardReceiveCount':
            return `次卡领取 ${item.cardReceiveCount ?? 0}`
        case 'cardVerifyCount':
            return `次卡核销 ${item.cardVerifyCount ?? 0}`
        default:
            return ''
    }
}

// 搜索客户
const onSearch = () => {
    search.value.page = 1
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 监听输入变化，内容删空（点清除图标或退格删空）后立即刷新
const onInputChange = (e) => {
    if (!e.value) {
        onClear()
    }
}

// 清空搜索条件并刷新列表
const onClear = () => {
    search.value.keyword = undefined
    search.value.page = 1
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取客户列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/customer/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 刷新列表
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

const onTimePickerChange = (visible) => {
    showTimePicker.value = visible
    if (visible) {
        tempTime.value.startTime = search.value.startTime || ''
        tempTime.value.endTime = search.value.endTime || ''
    }
}

const onConfirmTime = () => {
    search.value.startTime = tempTime.value.startTime || undefined
    search.value.endTime = tempTime.value.endTime || undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

const onClearTime = () => {
    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    search.value.startTime = undefined
    search.value.endTime = undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

const onSelectOrder = (e) => {
    const value = e.selected.value || ''
    const parts = value.split(':')
    search.value.sortBy = parts[0] || 'joinedAt'
    search.value.sorter = parts[1] || 'desc'
    showOrderPicker.value = false
    applyFilterAndRefresh()
}

const onSelectLevel = (e) => {
    const value = e.selected.value
    search.value.memberLevelId = value === '' || value === undefined ? undefined : String(value)
    showLevelPicker.value = false
    applyFilterAndRefresh()
}

const applyFilterAndRefresh = () => {
    search.value.startTime = search.value.startTime || undefined
    search.value.endTime = search.value.endTime || undefined
    search.value.sortBy = search.value.sortBy || 'joinedAt'
    search.value.sorter = search.value.sorter || 'desc'
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

const onResetFilter = () => {
    search.value.sortBy = 'joinedAt'
    search.value.sorter = 'desc'
    search.value.memberLevelId = undefined
    search.value.startTime = undefined
    search.value.endTime = undefined
    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    applyFilterAndRefresh()
}

const loadLevels = () => {
    request.get('/seller/member-level/list', {}, {showLoading: false}).then((res) => {
        levelOptions.value = res.data.items || []
    }).catch(() => {
        levelOptions.value = []
    })
}

const onExportList = async () => {
    utils.showLoading()
    try {
        const res = await request.post('/seller/customer/export', search.value)
        await saveBase64Excel(res.data.file, '客户列表')
    } catch (err) {
        // ignore
    } finally {
        utils.hideLoading()
    }
}

onShow(() => {
    loadLevels()
    onRefresh()
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.filter-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20rpx 32rpx;
    background: #fff;
    border-bottom: 1rpx solid #eee;
}

.filter-bar-left {
    display: flex;
    align-items: center;
    gap: 40rpx;
}

.filter-bar-item {
    display: flex;
    align-items: center;
    gap: 6rpx;
    padding: 8rpx 0;
}

.filter-bar-label {
    font-size: 28rpx;
    color: #666;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.filter-bar-sort {
    max-width: 220rpx;
}

.filter-bar-time {
    max-width: 180rpx;
}

.filter-bar-active {
    color: var(--td-brand-color) !important;
}

.filter-bar-right {
    display: flex;
    align-items: center;
}

.filter-bar-action {
    font-size: 28rpx;
    color: var(--td-brand-color);
}

.customer-title {
    display: flex;
    align-items: center;
    min-width: 0;
    gap: 12rpx;
}

.customer-name {
    flex: 0 1 auto;
    min-width: 0;
    max-width: 280rpx;
}

.customer-level {
    flex-shrink: 0;
}

.popup-footer {
    display: flex;
    padding: 24rpx 32rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
}
</style>
