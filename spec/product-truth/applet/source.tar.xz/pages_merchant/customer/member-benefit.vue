<template>
    <m-loading v-if="loadingPage"></m-loading>
    <view v-else class="pb-4">
        <t-cell-group theme="card" title="会员等级" t-title-class="mt-2">
            <view v-if="levels.length === 0" class="empty-tip text-muted text-small">
                尚未设置会员等级，最多可添加 5 个
            </view>
            <t-cell
                v-for="item in levels"
                :key="item.id"
                :title="item.name"
                arrow
                hover
                @click="openEdit(item)"
            >
                <template #note>
                    <m-member-level-badge
                        :name="item.name"
                        :icon-key="item.iconKey"
                        :color="item.color"
                    />
                </template>
            </t-cell>
        </t-cell-group>

        <view class="container mt-3 mb-3 text-center" v-if="levels.length < MEMBER_LEVEL_MAX">
            <text class="text-wechat" @click="openCreate">
                {{ levels.length >= MEMBER_LEVEL_MAX ? '已达 5 个上限' : '添加会员等级' }}
            </text>
        </view>

        <t-cell-group theme="card" title="会员权益海报" t-title-class="mt-2">
            <view class="poster-preview mx-3 mt-2 mb-2">
                <image
                    v-if="posterUrl"
                    class="poster-img"
                    :src="posterUrl"
                    mode="aspectFit"
                    @click="onPreviewPoster"
                />
                <m-empty v-else :height="280">暂未设置会员权益海报</m-empty>
            </view>

        </t-cell-group>
        <view class="container text-center mt-2">
            <text class="text-wechat" @click="openPosterDrawer">设置会员权益海报</text>
        </view>
    </view>

    <t-popup
        :visible="showEditor"
        placement="bottom"
        @visible-change="onEditorPopupChange"
    >
        <view class="popup-container container-safety pb-3">
            <view class="popup-header">
                <view class="popup-header-cancel" @tap="showEditor = false">取消</view>
                <view class="popup-header-title">{{ editingId ? '编辑等级' : '新建等级' }}</view>
                <view class="popup-header-confirm" @tap="onSaveLevel">保存</view>
            </view>
            <scroll-view class="editor-body" scroll-y>
                <view class="editor-preview">
                    <m-member-level-badge
                        :name="form.name || '预览'"
                        :icon-key="form.iconKey"
                        :color="form.color"
                    />
                </view>
                <t-cell-group theme="card" t-class="mt-2">
                    <t-input
                        label="等级名称"
                        v-model:value="form.name"
                        :maxlength="MEMBER_LEVEL_NAME_MAX"
                        :cursorSpacing="36"
                        placeholder="最多6个字"
                        borderless
                        align="right"
                    />
                </t-cell-group>
                <view class="editor-section">
                    <view class="editor-label">图标</view>
                    <view class="icon-grid">
                        <view
                            v-for="icon in MEMBER_LEVEL_ICONS"
                            :key="icon.key"
                            class="icon-item"
                            :class="{active: form.iconKey === icon.key}"
                            @tap="form.iconKey = icon.key"
                        >
                            <t-icon
                                :name="icon.tdName"
                                size="44rpx"
                                :color="form.iconKey === icon.key
                                    ? getMemberLevelBadgeColors(form.color).fg
                                    : '#999'"
                            />
                        </view>
                    </view>
                </view>
                <view class="editor-section">
                    <view class="editor-label">颜色</view>
                    <view class="color-grid">
                        <view
                            v-for="c in MEMBER_LEVEL_COLORS"
                            :key="c"
                            class="color-item"
                            :class="{active: form.color === c}"
                            :style="{backgroundColor: c}"
                            @tap="form.color = c"
                        ></view>
                    </view>
                </view>
                <view v-if="editingId" class="px-3 mt-3 mb-2">
                    <t-button theme="danger" variant="outline" block @click="onDeleteLevel">删除该等级</t-button>
                </view>
            </scroll-view>
        </view>
    </t-popup>

    <t-popup
        :visible="showPosterDrawer"
        placement="bottom"
        @visible-change="onPosterPopupChange"
    >
        <view class="popup-container container-safety pb-3">
            <view class="popup-header">
                <view class="popup-header-cancel" @tap="showPosterDrawer = false">取消</view>
                <view class="popup-header-title">设置海报</view>
                <view class="popup-header-confirm" @tap="onSavePoster">保存</view>
            </view>
            <view class="container">
                <view class="alert-info mx-3 mt-3 mb-2">
                    温馨提示：可用豆包制作本店的会员权益海报后上传。
                </view>
                <view class="poster-box mx-3 mt-2" @click="onChoosePoster">
                    <image v-if="posterDraft" class="poster-img" :src="posterDraft" mode="aspectFit"/>
                    <view v-else class="poster-placeholder">
                        <t-icon name="add" size="48rpx" color="#999"/>
                        <text class="text-muted text-small mt-2">点击上传会员权益海报</text>
                    </view>
                    <view v-if="posterDraft" class="img-del" @tap.stop="posterDraft = ''"></view>
                </view>
            </view>
        </view>
    </t-popup>

    <m-compress v-model:show="showCompress" v-model:tempFile="compressFile" @compress="onCompress"></m-compress>
    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onShow} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import config from '@/config'
import {getUploadHeader} from '@/utils/upload'
import {
    MEMBER_LEVEL_COLORS,
    MEMBER_LEVEL_ICONS,
    MEMBER_LEVEL_MAX,
    MEMBER_LEVEL_NAME_MAX,
    getMemberLevelBadgeColors,
} from '@/constants/memberLevel'

const loadingPage = ref(true)
const levels = ref([])
const posterUrl = ref('')
const posterDraft = ref('')
const posterSaving = ref(false)
const showEditor = ref(false)
const showPosterDrawer = ref(false)
const editingId = ref('')
const form = ref({
    name: '',
    iconKey: 'crown',
    color: '#d09a45',
    sort: 0,
})
const showCompress = ref(false)
const compressFile = ref('')

const loadData = () => {
    loadingPage.value = true
    Promise.all([
        request.get('/seller/member-level/list', {}, {showLoading: false}),
        request.get('/seller/merchant', {}, {showLoading: false}),
    ]).then(([levelRes, merchantRes]) => {
        levels.value = levelRes.data.items || []
        posterUrl.value = merchantRes.data.memberBenefitImage || ''
    }).catch(() => {
        utils.toast('加载失败')
    }).finally(() => {
        loadingPage.value = false
    })
}

const openCreate = () => {
    editingId.value = ''
    form.value = {
        name: '',
        iconKey: 'crown',
        color: '#d09a45',
        sort: levels.value.length,
    }
    showEditor.value = true
}

const openEdit = (item) => {
    editingId.value = item.id
    form.value = {
        name: item.name,
        iconKey: item.iconKey,
        color: item.color,
        sort: item.sort || 0,
    }
    showEditor.value = true
}

const onEditorPopupChange = (e) => {
    showEditor.value = e && typeof e === 'object' ? !!(e.visible ?? e.detail?.visible) : !!e
}

const openPosterDrawer = () => {
    posterDraft.value = posterUrl.value || ''
    showPosterDrawer.value = true
}

const onPosterPopupChange = (e) => {
    showPosterDrawer.value = e && typeof e === 'object' ? !!(e.visible ?? e.detail?.visible) : !!e
}

const onPreviewPoster = () => {
    if (!posterUrl.value) return
    uni.previewImage({
        urls: [posterUrl.value],
        current: posterUrl.value,
    })
}

const onSaveLevel = () => {
    const name = (form.value.name || '').trim()
    if (!name) {
        utils.toast('请填写等级名称')
        return
    }
    if ([...name].length > MEMBER_LEVEL_NAME_MAX) {
        utils.toast('等级名称最多6个字')
        return
    }
    const payload = {
        name,
        iconKey: form.value.iconKey,
        color: form.value.color,
        sort: form.value.sort || 0,
    }
    const req = editingId.value
        ? request.post('/seller/member-level/update', {id: editingId.value, ...payload}, {showLoading: true})
        : request.post('/seller/member-level/create', payload, {showLoading: true})
    req.then(() => {
        showEditor.value = false
        utils.toast('已保存')
        loadData()
    })
}

const onDeleteLevel = () => {
    uni.showModal({
        title: '删除等级',
        content: '删除后，已绑定该等级的客户将变为未设等级，确认删除？',
        success: (res) => {
            if (!res.confirm) return
            request.post('/seller/member-level/delete', {id: editingId.value}, {showLoading: true}).then(() => {
                showEditor.value = false
                utils.toast('已删除')
                loadData()
            })
        },
    })
}

const onChoosePoster = () => {
    uni.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success: (res) => {
            const size = res.tempFiles[0].size
            if (5 * 1024 * 1024 < size) {
                utils.toast('单张图片大小不能超过：5MB')
                return
            }
            compressFile.value = res.tempFilePaths[0]
            showCompress.value = true
        },
    })
}

const onCompress = () => {
    uploadPoster(compressFile.value)
}

const uploadPoster = (file) => {
    utils.showLoading()
    const timestamp = utils.getUnixTime()
    const sign = utils.signParam({}, config.appSecret, timestamp)
    uni.uploadFile({
        url: config.apiUrl + '/seller/object/upload?sign=' + sign + '&timestamp=' + timestamp,
        filePath: file,
        name: 'file',
        header: getUploadHeader(),
        success: (uploadFileRes) => {
            utils.hideLoading()
            let result
            try {
                result = JSON.parse(uploadFileRes.data)
            } catch (e) {
                utils.toast('上传响应异常')
                return
            }
            if (result.code === 0) {
                if (result.data.isSuccess) {
                    posterDraft.value = result.data.url
                } else {
                    utils.alert(result.data.failReason)
                }
            } else {
                utils.alert(result.message)
            }
        },
        fail: () => {
            utils.hideLoading()
            utils.toast('上传失败')
        },
    })
}

const onSavePoster = () => {
    if (posterSaving.value) return
    const next = posterDraft.value || ''
    if (next === (posterUrl.value || '')) {
        showPosterDrawer.value = false
        return
    }
    posterSaving.value = true
    request.post('/seller/merchant/update/member-benefit-image', {
        image: next,
    }, {showLoading: true}).then(() => {
        posterUrl.value = next
        showPosterDrawer.value = false
        utils.toast('海报已保存')
    }).finally(() => {
        posterSaving.value = false
    })
}

onShow(() => {
    loadData()
})
</script>

<style scoped>
.empty-tip {
    padding: 24rpx 32rpx;
}


.poster-preview {
    height: 360rpx;
    padding: 24rpx 0;
    background: #fff;
    border-radius: 16rpx;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
}

.poster-box {
    position: relative;
    width: auto;
    height: 360rpx;
    max-height: 40vh;
    padding: 24rpx 0;
    background: #fff;
    border-radius: 16rpx;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    box-sizing: border-box;
}

.poster-img {
    width: 100%;
    height: 100%;
    display: block;
}

.poster-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 48rpx 0;
}

.img-del {
    position: absolute;
    right: 12rpx;
    top: 12rpx;
    width: 44rpx;
    height: 44rpx;
    border-radius: 50%;
    background: rgba(0, 0, 0, 0.45) url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 24 24' fill='%23fff'%3E%3Cpath d='M18.3 5.71L12 12.01 5.7 5.7 4.29 7.11 10.59 13.4 4.29 19.7 5.7 21.11 12 14.82 18.3 21.11 19.71 19.7 13.41 13.4 19.71 7.11z'/%3E%3C/svg%3E") center/24rpx no-repeat;
}

.editor-body {
    max-height: 70vh;
}

.editor-preview {
    display: flex;
    justify-content: center;
    padding: 24rpx 0 8rpx;
}

.editor-section {
    margin: 16rpx 24rpx 0;
    padding: 24rpx;
    background: #fff;
    border-radius: 16rpx;
}

.editor-label {
    margin-bottom: 16rpx;
    font-size: 26rpx;
    color: #666;
}

.icon-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 16rpx;
}

.icon-item {
    width: 88rpx;
    height: 88rpx;
    border-radius: 16rpx;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    border: 3rpx solid transparent;
    box-sizing: border-box;
}

.icon-item.active {
    border-color: var(--td-brand-color);
    background: #fff;
}

.color-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 16rpx;
}

.color-item {
    width: 56rpx;
    height: 56rpx;
    border-radius: 50%;
    border: 3rpx solid transparent;
    box-sizing: border-box;
}

.color-item.active {
    border-color: #111;
    box-shadow: 0 0 0 3rpx #fff inset;
}
</style>
