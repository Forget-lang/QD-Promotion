<template>
    <view>
        <!-- 重点提示 -->
        <view class="mass-notice">
            <t-icon name="error-circle-filled" size="40rpx" color="#e37318"/>
            <view class="mass-notice-text">
                <view class="mass-notice-title">每商家每周仅可群发一次</view>
                <view class="mass-notice-desc">提交后系统将向所选对象自动发放到账，发放后不可撤回，请谨慎选择。</view>
            </view>
        </view>

        <!-- 群发对象 -->
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="群发对象" arrow hover @click="showLevelPicker = true">
                <template #note>
                    <text>{{ targetLabel }}（共 {{ customerTotal }} 人）</text>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 群发优惠券 -->
        <t-cell-group t-class="mt-2" theme="card">
            <m-coupon-select
                required
                title="群发优惠券"
                tip="仅可选择「私密发放」类型的有效优惠券"
                v-model:value="form.couponId"
            />
        </t-cell-group>

        <!-- 每人发放张数：固定 1 张，不可改 -->
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="每人发放张数" note="1张">
                <template #description>
                    <view class="text-muted mt-1">每人固定发放1张，数量不可修改</view>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 发放备注 -->
        <t-cell-group theme="card" t-class="mt-2">
            <t-cell title="发放备注">
                <template #description>
                    <textarea
                        class="remark-textarea"
                        placeholder="请输入备注信息（选填，仅商家可见）"
                        v-model="form.remark"
                        :cursorSpacing="120"
                        maxlength="32"
                    />
                </template>
            </t-cell>
        </t-cell-group>

        <m-submit :disabled="loading" @click="onSubmit">开始群发</m-submit>

        <t-action-sheet
            :visible="showLevelPicker"
            :items="levelPickerItems"
            @selected="onSelectTarget"
            @cancel="showLevelPicker = false"
        ></t-action-sheet>
    </view>
    <!-- VIP 升级抽屉：承接群发/会员等级 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import to from '@/hooks/to'
import utils from '@/utils/utils'
import config from '@/config'

const loading = ref(false)
const customerTotal = ref(0)
const showLevelPicker = ref(false)
const levelOptions = ref([])
const form = ref({
    couponId: '',
    memberLevelId: 0,
    remark: '',
})

const levelPickerItems = computed(() => {
    const list = [{label: '全部客户', value: '0'}]
    levelOptions.value.forEach((item) => {
        list.push({label: item.name, value: String(item.id)})
    })
    return list
})

const targetLabel = computed(() => {
    if (!form.value.memberLevelId) return '全部客户'
    const hit = levelOptions.value.find((item) => String(item.id) === String(form.value.memberLevelId))
    return hit ? hit.name : '指定等级'
})

const getCustomerTotal = () => {
    const params = {}
    if (form.value.memberLevelId) {
        params.memberLevelId = String(form.value.memberLevelId)
        params.page = 1
        params.pageSize = 1
        request.get('/seller/customer/list', params, {showLoading: false}).then((res) => {
            customerTotal.value = to.Int(res.data.total)
        }).catch(() => {
        })
        return
    }
    request.get('/seller/customer/stats', {}, {showLoading: false}).then((res) => {
        customerTotal.value = to.Int(res.data.total)
    }).catch(() => {
    })
}

const loadLevels = () => {
    request.get('/seller/member-level/list', {}, {showLoading: false}).then((res) => {
        levelOptions.value = res.data.items || []
    }).catch(() => {
        levelOptions.value = []
    })
}

const onSelectTarget = (e) => {
    showLevelPicker.value = false
    form.value.memberLevelId = e.selected.value === '0' ? 0 : e.selected.value
    getCustomerTotal()
}

const onSubmit = () => {
    if (!form.value.couponId) {
        utils.toast('请选择群发优惠券')
        return
    }
    uni.showModal({
        title: '确认群发',
        content: `将向${targetLabel.value}共 ${customerTotal.value} 位客户每人发放 1 张，每周仅可群发一次，确认创建？`,
        success: (modalRes) => {
            if (!modalRes.confirm) return
            uni.requestSubscribeMessage({
                tmplIds: config.subscribeMessage.massComplete,
                complete: () => {
                    doCreate()
                },
            })
        },
    })
}

const doCreate = () => {
    loading.value = true
    request.post('/seller/coupon/mass/create', {
        couponId: form.value.couponId,
        memberLevelId: form.value.memberLevelId || 0,
        remark: form.value.remark,
    }, {showLoading: true}).then((res) => {
        loading.value = false
        if (res.data.taskId) {
            uni.redirectTo({url: '/pages_merchant/customer/mass_detail?id=' + res.data.taskId})
        }
    }).catch(() => {
        loading.value = false
    })
}

onLoad(() => {
    loadLevels()
    getCustomerTotal()
})
</script>

<style scoped>
.mass-notice {
    display: flex;
    align-items: flex-start;
    gap: 16rpx;
    margin: 24rpx 24rpx 0;
    padding: 24rpx;
    background: #fff7e8;
    border-radius: 16rpx;
}

.mass-notice-text {
    flex: 1;
}

.mass-notice-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #e37318;
}

.mass-notice-desc {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #996a3d;
    line-height: 1.5;
}

.remark-textarea {
    width: 100%;
    min-height: 120rpx;
    margin-top: 12rpx;
    font-size: 28rpx;
}
</style>
