<template>
    <m-loading v-if="form === undefined"></m-loading>
    <m-empty v-else-if="form === null">客户不存在</m-empty>
    <view v-else class="page">
        <!-- 顶部红色渐变（同优惠券详情） -->
        <view class="page-hero">
            <view class="card profile-card">
                <view class="profile-row">
                    <view class="avatar">
                        <image v-if="form.avatar" :src="form.avatar" mode="aspectFill"/>
                        <text v-else>{{ avatarText }}</text>
                    </view>
                    <view class="profile-main">
                        <view class="name-row">
                            <text class="name">{{ form.nickname || '-' }}</text>
                            <m-member-level-badge
                                v-if="form.memberLevel"
                                class="ml-2"
                                :name="form.memberLevel.name"
                                :icon-key="form.memberLevel.iconKey"
                                :color="form.memberLevel.color"
                                size="sm"
                            />
                        </view>
                        <view
                            class="remark-row"
                            @tap="checkPermission(PERM_CUSTOMER.UPDATE) && openRemarkPopup()"
                        >
                            <text class="remark-text">{{ form.remark || '暂无备注' }}</text>
                            <t-icon
                                v-if="checkPermission(PERM_CUSTOMER.UPDATE)"
                                name="edit-2"
                                size="28rpx"
                                color="#bbb"
                            />
                        </view>
                    </view>
                    <view
                        v-if="form.mobile"
                        class="call-btn"
                        :class="{'call-btn-disabled': !canCallMobile}"
                        @tap.stop="onCallMobile"
                    >
                        <t-icon
                            name="call"
                            size="40rpx"
                            :color="canCallMobile ? '#e2453d' : '#ccc'"
                        />
                    </view>
                </view>
                <t-divider/>
                <!-- 当前资产 -->
                <view class="stats-card mt-2">
                    <view class="stat-item" @tap="push('/pages_point/log/list?userId=' + userId)">
                        <view class="stat-icon" style="background:#ffe8e6">
                            <t-icon name="money" size="36rpx" color="#e2453d"/>
                        </view>
                        <text class="stat-label">积分</text>
                        <text class="stat-num text-red">{{ form.pointBalance ?? 0 }}</text>
                    </view>
                    <view class="stat-item">
                        <view class="stat-icon" style="background:#fff0e6">
                            <t-icon name="ticket" size="36rpx" color="#ff8a3d"/>
                        </view>
                        <text class="stat-label">优惠券</text>
                        <text class="stat-num" :class="{'text-red': (form.couponCount || 0) > 0}">
                            {{ form.couponCount ?? 0 }}
                        </text>
                    </view>
                    <view class="stat-item">
                        <view class="stat-icon" style="background:#e8f1ff">
                            <t-icon name="wallet" size="36rpx" color="#4d8dff"/>
                        </view>
                        <text class="stat-label">券包</text>
                        <text class="stat-num">{{ form.bundleCount ?? 0 }}</text>
                    </view>
                    <view class="stat-item">
                        <view class="stat-icon" style="background:#f0e8ff">
                            <t-icon name="card" size="36rpx" color="#8b5cf6"/>
                        </view>
                        <text class="stat-label">次卡</text>
                        <text class="stat-num">{{ form.cardCount ?? 0 }}</text>
                    </view>
                </view>
            </view>
        </view>

        <view class="page-body">
            <!-- 发/扣积分：入口常显，无权限时点击弹框提示 -->
            <view class="action-row">
                <view class="action-btn action-plus" @tap="onPointAction('/pages_point/point/increase?userId=' + userId, '发放')">
                    <view class="action-icon">
                        <t-icon name="add" size="36rpx" color="#fff"/>
                    </view>
                    <view class="action-copy">
                        <text class="action-title">发放积分</text>
                        <text class="action-sub">奖励客户</text>
                    </view>
                    <t-icon name="chevron-right" size="32rpx" color="rgba(255,255,255,0.8)"/>
                </view>
                <view class="action-btn action-minus" @tap="onPointAction('/pages_point/point/decrease?userId=' + userId, '扣除')">
                    <view class="action-icon">
                        <t-icon name="remove" size="36rpx" color="#fff"/>
                    </view>
                    <view class="action-copy">
                        <text class="action-title">扣除积分</text>
                        <text class="action-sub">扣减积分</text>
                    </view>
                    <t-icon name="chevron-right" size="32rpx" color="rgba(255,255,255,0.8)"/>
                </view>
            </view>
        </view>

        <t-cell-group title="累计数据" t-title-class="mt-2" theme="card">
            <view class="p-3 bg-white">
                <view class="row col-3">
                    <view class="stat" @tap="push('/pages_point/log/list?userId=' + userId)">
                        <view class="stat-value">{{ form.pointEarned ?? 0 }}</view>
                        <view class="stat-label">累计积分</view>
                    </view>
                    <view class="stat" @tap="push('/pages_coupon/receive/list?userId=' + userId)">
                        <view class="stat-value">{{ form.couponReceiveCount ?? 0 }}</view>
                        <view class="stat-label">券领取</view>
                    </view>
                    <view
                        class="stat"
                        @tap="checkPermission(PERM_COUPON.VERIFY_LIST) && push('/pages_coupon/verify/list?userId=' + userId)"
                    >
                        <view class="stat-value">{{ form.couponVerifyCount ?? 0 }}</view>
                        <view class="stat-label">券核销</view>
                    </view>
                    <view class="stat" @tap="push('/pages_card/receive/list?userId=' + userId)">
                        <view class="stat-value">{{ form.cardReceiveCount ?? 0 }}</view>
                        <view class="stat-label">次卡领取</view>
                    </view>
                    <view
                        class="stat"
                        @tap="checkPermission(PERM_CARD.VERIFY_LIST) && push('/pages_card/verify/list?userId=' + userId)"
                    >
                        <view class="stat-value">{{ form.cardVerifyCount ?? 0 }}</view>
                        <view class="stat-label">次卡核销</view>
                    </view>
                </view>
            </view>
        </t-cell-group>

        <t-cell-group title="客户资料" t-title-class="mt-2" theme="card">
            <t-cell
                title="会员等级"
                :arrow="checkPermission(PERM_CUSTOMER.UPDATE)"
                @click="checkPermission(PERM_CUSTOMER.UPDATE) && (showLevelPicker = true)"
            >
                <template #note>
                    <m-member-level-badge
                        v-if="form.memberLevel"
                        :name="form.memberLevel.name"
                        :icon-key="form.memberLevel.iconKey"
                        :color="form.memberLevel.color"
                        size="sm"
                    />
                    <text v-else class="text-muted">未设置</text>
                </template>
            </t-cell>
            <t-cell title="客户编码" arrow @click="onCopyUserId">
                <template #note>
                    <text class="text-muted">{{ form.userId || '-' }}</text>
                </template>
            </t-cell>
            <t-cell
                title="手机号"
                :arrow="checkPermission(PERM_CUSTOMER.UPDATE)"
                @click="onMobileRowTap"
            >
                <template #note>
                    <text class="text-muted">{{ displayMobile }}</text>
                </template>
            </t-cell>
            <t-cell
                title="客户备注"
                :arrow="checkPermission(PERM_CUSTOMER.UPDATE)"
                :note="form.remark || '未填写'"
                @click="checkPermission(PERM_CUSTOMER.UPDATE) && openRemarkPopup()"
            />
            <t-cell title="成为客户" :note="joinedAtFull"/>
            <t-cell title="最后活跃" :note="activedDate" :bordered="false"/>
        </t-cell-group>

        <view class="page-footer">首次到店：{{ joinedDate }}</view>
    </view>

    <t-popup :visible="showRemarkPopup" placement="bottom" @visible-change="onRemarkPopupChange">
        <view class="popup-container container-safety">
            <view class="popup-header">
                <view class="popup-header-title">编辑备注</view>
                <view class="popup-header-close" @tap="showRemarkPopup = false">
                    <t-icon name="close" size="24px" color="#999"/>
                </view>
            </view>
            <t-cell-group t-class="mt-2" theme="card">
                <t-textarea v-model:value="remarkDraft" placeholder="填写客户备注，仅商家可见" :maxlength="255"/>
            </t-cell-group>
            <view class="container mt-3">
                <t-button theme="primary" block @click="saveRemark" :loading="remarkSaving">保存</t-button>
            </view>
        </view>
    </t-popup>

    <t-popup :visible="showMobilePopup" placement="bottom" @visible-change="onMobilePopupChange">
        <view class="popup-container container-safety">
            <view class="popup-header">
                <view class="popup-header-title">编辑手机号</view>
                <view class="popup-header-close" @tap="showMobilePopup = false">
                    <t-icon name="close" size="24px" color="#999"/>
                </view>
            </view>
            <t-cell-group t-class="mt-2" theme="card">
                <t-input
                    v-model:value="mobileDraft"
                    type="number"
                    :maxlength="11"
                    clearable
                    placeholder="请输入客户手机号"
                />
            </t-cell-group>
            <view class="text-muted text-small px-3 mt-2" v-if="mobileMaskedHint">
                当前为脱敏展示，请重新填写完整手机号后保存
            </view>
            <view class="container mt-3">
                <t-button theme="primary" block @click="saveMobile" :loading="mobileSaving">保存</t-button>
            </view>
        </view>
    </t-popup>

    <t-action-sheet
        :visible="showLevelPicker"
        :items="levelPickerItems"
        @selected="onSelectMemberLevel"
        @cancel="showLevelPicker = false"
    ></t-action-sheet>

    <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import dayjs from 'dayjs'
import request from '@/hooks/request.js'
import utils from '@/utils/utils.js'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth'
import {PERM_CARD, PERM_COUPON, PERM_CUSTOMER, PERM_POINT} from '@/constants/permission'

const {push, reLaunch} = useLink()
const {checkPermission, isLoggedIn, isEntry} = useAuth()

const userId = ref('')
const form = ref()
const showRemarkPopup = ref(false)
const remarkDraft = ref('')
const remarkSaving = ref(false)
const showMobilePopup = ref(false)
const mobileDraft = ref('')
const mobileSaving = ref(false)
const mobileMaskedHint = ref(false)
const showLevelPicker = ref(false)
const levelOptions = ref([])

const levelPickerItems = computed(() => {
    const list = [{label: '未设置', value: '0'}]
    levelOptions.value.forEach((item) => {
        list.push({label: item.name, value: String(item.id)})
    })
    return list
})

const loadLevels = () => {
    request.get('/seller/member-level/list', {}, {showLoading: false}).then((res) => {
        levelOptions.value = res.data.items || []
    }).catch(() => {
        levelOptions.value = []
    })
}

const onSelectMemberLevel = (e) => {
    showLevelPicker.value = false
    const memberLevelId = e.selected.value === '0' ? 0 : e.selected.value
    request.post('/seller/customer/update-member-level', {
        userId: userId.value,
        memberLevelId,
    }, {showLoading: true}).then(() => {
        utils.toast('已更新会员等级')
        loadDetail(true)
    })
}

const displayMobile = computed(() => {
    const mobile = form.value?.mobile
    return mobile ? mobile : '未填写'
})

const avatarText = computed(() => {
    const name = (form.value?.nickname || '').trim()
    return name ? name.charAt(0) : '?'
})

const isMaskedMobile = (mobile) => {
    const s = String(mobile || '')
    return s.includes('*')
}

/** 仅完整手机号可拨打；脱敏员工看到的是处理后的号码，不能拨打 */
const canCallMobile = computed(() => {
    const mobile = form.value?.mobile
    return !!(mobile && !isMaskedMobile(mobile))
})

const formatDate = (raw, withTime = false) => {
    if (!raw) return '-'
    const d = dayjs(raw)
    if (!d.isValid()) return String(raw)
    return d.format(withTime ? 'YYYY-MM-DD HH:mm' : 'YYYY-MM-DD')
}

const joinedDate = computed(() => formatDate(form.value?.joinedAt))
const joinedAtFull = computed(() => formatDate(form.value?.joinedAt, true))
const activedDate = computed(() => formatDate(form.value?.activedAt))

const parseSceneUserId = (sceneRaw) => {
    if (sceneRaw == null || sceneRaw === '') return ''
    let scene = String(sceneRaw)
    try {
        scene = decodeURIComponent(scene)
    } catch (e) {
        // 已解码或非法编码时沿用原值
    }
    if (!scene) return ''
    if (!scene.includes('=')) {
        return scene
    }
    const params = {}
    scene.split('&').forEach((part) => {
        const eq = part.indexOf('=')
        if (eq === -1) return
        const key = part.slice(0, eq)
        const val = part.slice(eq + 1)
        if (key) params[key] = val
    })
    return params.u || params.userId || params.uid || ''
}

const loadDetail = (silent = false) => {
    if (!silent) {
        form.value = undefined
    }
    request.get('/seller/customer/detail', {userId: userId.value}).then(res => {
        form.value = res.data
    }).catch(err => {
        console.error('获取客户详情失败:', err)
        if (!silent) {
            form.value = null
        }
    }).finally(() => {
        uni.stopPullDownRefresh()
    })
}

const openRemarkPopup = () => {
    remarkDraft.value = form.value?.remark || ''
    showRemarkPopup.value = true
}

const onRemarkPopupChange = (e) => {
    showRemarkPopup.value = e && typeof e === 'object' ? !!(e.visible ?? e.detail?.visible) : !!e
}

const saveRemark = () => {
    if (remarkSaving.value) return
    remarkSaving.value = true
    request.post('/seller/customer/update-remark', {
        userId: userId.value,
        remark: remarkDraft.value || '',
    }).then(() => {
        form.value.remark = remarkDraft.value || ''
        showRemarkPopup.value = false
        utils.toast('备注已保存')
    }).catch(err => {
        console.error('保存备注失败:', err)
    }).finally(() => {
        remarkSaving.value = false
    })
}

const openMobilePopup = () => {
    const mobile = form.value?.mobile || ''
    mobileMaskedHint.value = isMaskedMobile(mobile)
    mobileDraft.value = mobileMaskedHint.value ? '' : mobile
    showMobilePopup.value = true
}

const onMobilePopupChange = (e) => {
    showMobilePopup.value = e && typeof e === 'object' ? !!(e.visible ?? e.detail?.visible) : !!e
}

const onMobileRowTap = () => {
    if (checkPermission(PERM_CUSTOMER.UPDATE)) {
        openMobilePopup()
        return
    }
    if (canCallMobile.value) {
        onCopyMobile()
        return
    }
    if (form.value?.mobile && isMaskedMobile(form.value.mobile)) {
        utils.toast('暂无权限查看完整手机号')
    }
}

const saveMobile = () => {
    if (mobileSaving.value) return
    const mobile = (mobileDraft.value || '').trim()
    if (mobile && !/^1\d{10}$/.test(mobile)) {
        utils.toast('请输入正确的手机号')
        return
    }
    mobileSaving.value = true
    request.post('/seller/customer/update-mobile', {
        userId: userId.value,
        mobile,
    }).then(() => {
        showMobilePopup.value = false
        utils.toast('手机号已保存')
        // 脱敏员工需重新拉详情，避免本地露出完整号码
        loadDetail(true)
    }).catch(err => {
        console.error('保存手机号失败:', err)
    }).finally(() => {
        mobileSaving.value = false
    })
}

const onCopyUserId = () => {
    if (!form.value?.userId) return
    utils.copyClipboard(String(form.value.userId), '客户编码已复制')
}

// 发/扣积分入口点击：有权限正常跳转，无权限按动作类型弹框提示（仅确认按钮）
const onPointAction = (url, action) => {
    if (!form.value?.canChangePoint || !checkPermission(PERM_POINT.CHANGE)) {
        uni.showModal({
            title: '提示',
            content: `您没有${action}积分权限，请管理员前往【商户中心>积分>发放员工】授权。`,
            showCancel: false,
        })
        return
    }
    push(url)
}

const onCopyMobile = () => {
    if (!form.value?.mobile || isMaskedMobile(form.value.mobile)) return
    utils.copyClipboard(String(form.value.mobile), '手机号已复制')
}

const onCallMobile = () => {
    const mobile = form.value?.mobile
    if (!mobile) {
        utils.toast('未填写手机号')
        return
    }
    if (isMaskedMobile(mobile)) {
        utils.toast('暂无权限查看完整手机号，无法拨打')
        return
    }
    utils.makePhoneCall(mobile, '')
}

const guardMerchantAccess = () => {
    if (!isLoggedIn.value) {
        wx.showModal({
            title: '提示',
            content: '此客户码仅供商家员工扫描',
            showCancel: false,
            success: () => reLaunch('/pages/index/index'),
        })
        return false
    }
    if (!isEntry.value) {
        wx.showModal({
            title: '提示',
            content: '此客户码仅供商家员工扫描，请先进入商家中心并选择门店',
            showCancel: false,
            success: () => reLaunch('/pages/merchant/index'),
        })
        return false
    }
    if (!checkPermission(PERM_CUSTOMER.DETAIL)) {
        wx.showModal({
            title: '提示',
            content: '暂无客户详情权限',
            showCancel: false,
            success: () => reLaunch('/pages/merchant/index'),
        })
        return false
    }
    return true
}

onLoad((options) => {
    if (!guardMerchantAccess()) {
        return
    }
    const id = options.userId || parseSceneUserId(options.scene)
    if (!id) {
        utils.toast('无法识别客户')
        setTimeout(() => uni.navigateBack(), 1500)
        return
    }
    userId.value = id
    loadDetail()
})

onShow(() => {
    if (!guardMerchantAccess()) {
        return
    }
    loadLevels()
    loadDetail()
})

onPullDownRefresh(() => {
    loadDetail()
})
</script>

<style scoped>
.page {
    min-height: 100vh;
    background: #f5f5f5;
    box-sizing: border-box;
}

.page-hero {
    padding: 24rpx 24rpx 8rpx;
    background: url("https://cdn.lenmy.com/quanketuan/2024/09/23/crodj1ide1heuifummd0.png") repeat-x 0 -200rpx;
}

.page-body {
    padding: 16rpx 24rpx 0;
    box-sizing: border-box;
}

.card {
    background: #fff;
    border-radius: 20rpx;
    padding: 28rpx 28rpx;
    margin-bottom: 24rpx;
}

.profile-card {
    margin-bottom: 0;
}

.profile-row {
    display: flex;
    align-items: flex-start;
}

.avatar {
    width: 104rpx;
    height: 104rpx;
    border-radius: 50%;
    overflow: hidden;
    background: #f0f0f0;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    font-size: 40rpx;
    color: #999;
    font-weight: 600;
}

.avatar image {
    width: 100%;
    height: 100%;
}

.profile-main {
    flex: 1;
    min-width: 0;
    margin-left: 24rpx;
    padding-top: 4rpx;
}

.call-btn {
    width: 72rpx;
    height: 72rpx;
    margin-left: 16rpx;
    border-radius: 50%;
    background: #ffe8e6;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.call-btn-disabled {
    background: #f0f0f0;
}

.name-row {
    display: flex;
    align-items: center;
    gap: 12rpx;
}

.name {
    font-size: 36rpx;
    font-weight: 700;
    color: #222;
}

.remark-row {
    margin-top: 14rpx;
    display: flex;
    align-items: flex-start;
    gap: 8rpx;
}

.remark-text {
    margin-right: 10rpx;
    min-width: 0;
    font-size: 24rpx;
    color: #888;
    line-height: 1.5;
}

.action-row {
    display: flex;
    gap: 20rpx;
    margin-bottom: 24rpx;
}

.action-btn {
    flex: 1;
    display: flex;
    align-items: center;
    border-radius: 16rpx;
    padding: 24rpx 20rpx;
    min-width: 0;
}

.action-plus {
    background: #e2453d;
}

.action-minus {
    background: #07c160;
}

.action-icon {
    width: 60rpx;
    height: 60rpx;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
}

.action-copy {
    flex: 1;
    min-width: 0;
    margin: 0 20rpx;
    display: flex;
    flex-direction: column;
    gap: 4rpx;
}

.action-title {
    font-size: 28rpx;
    font-weight: 700;
    color: #fff;
}

.action-sub {
    font-size: 20rpx;
    color: rgba(255, 255, 255, 0.85);
}

.stats-card {
    display: flex;
    align-items: stretch;
}

.stat-item {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    min-width: 0;
}

.stat-icon {
    width: 64rpx;
    height: 64rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stat-label {
    margin-top: 12rpx;
    font-size: 22rpx;
    color: #999;
}

.stat-num {
    margin-top: 8rpx;
    font-size: 36rpx;
    font-weight: 700;
    color: #222;
    font-variant-numeric: tabular-nums;
}

.text-red {
    color: #e2453d;
}

.page-footer {
    margin: 16rpx 0 48rpx;
    text-align: center;
    font-size: 22rpx;
    color: #bbb;
}
</style>
