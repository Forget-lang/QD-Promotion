<template>
    <m-loading v-if="stats === undefined"></m-loading>
    <view v-else class="container">
        <view class="section mt-3 p-3">
            <view class="row col-3">
                <view class="stat">
                    <view class="stat-value">{{ stats.todayJoined }}</view>
                    <view class="stat-label">今日新增客户</view>
                </view>
                <view class="stat">
                    <view class="stat-value">{{ stats.yesterdayJoined }}</view>
                    <view class="stat-label">昨日新增客户</view>
                </view>
                <view class="stat">
                    <view class="stat-value">{{ stats.total }}</view>
                    <view class="stat-label">客户总数</view>
                </view>
            </view>
        </view>
    </view>
    <t-cell-group theme="card" title="客户管理" t-title-class="mt-2">
        <t-cell title="客户列表" arrow hover @click="onCustomerList"></t-cell>
    </t-cell-group>
    <t-cell-group theme="card" t-title-class="mt-2" title="客户营销">
        <t-cell
            v-if="checkPermission(PERM_CUSTOMER.UPDATE)"
            title="会员权益"
            note="等级与权益设置"
            arrow
            hover
            @click="onMemberBenefit"
        ></t-cell>
        <t-cell
            v-if="checkPermission(PERM_CUSTOMER.MASS)"
            title="群发优惠券"
            note="给所有客户或指定会员"
            arrow
            hover
            @click="onMassCoupon"
        ></t-cell>
    </t-cell-group>

    <!-- 版本升级抽屉：会员权益/群发等受限跳转承接 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request.js'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth'
import {useVipGuard} from '@/hooks/useVipGuard'
import {EDITION_FEATURES} from '@/constants/edition'
import {PERM_CUSTOMER} from '@/constants/permission'

const {push} = useLink()
const {checkPermission, getSession} = useAuth()
const {check} = useVipGuard()
const stats = ref()

const loadStats = () => {
    request.get('/seller/customer/stats').then(res => {
        stats.value = res.data
    }).catch(err => {
        console.error('获取客户统计失败:', err)
    }).finally(() => {
        uni.stopPullDownRefresh()
    })
}

const onCustomerList = () => {
    push('/pages_merchant/customer/list')
}

// 会员权益：专业版及以上支持，检测通过后进入等级与权益海报
const onMemberBenefit = () => {
    check(EDITION_FEATURES.MEMBER_BENEFIT).then((allowed) => {
        if (allowed) push('/pages_merchant/customer/member-benefit')
    })
}

// 群发优惠券：企业版及以上支持，检测通过后进入群发记录
const onMassCoupon = () => {
    check(EDITION_FEATURES.MASS_COUPON).then((allowed) => {
        if (allowed) push('/pages_merchant/customer/mass_list')
    })
}

onShow(() => {
    loadStats()
    getSession()
})

onPullDownRefresh(() => {
    loadStats()
})
</script>

<style>
</style>
