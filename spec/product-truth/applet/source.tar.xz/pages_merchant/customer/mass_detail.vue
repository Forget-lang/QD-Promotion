<template>
    <view>
        <m-loading v-if="detail === undefined"/>
        <m-empty v-else-if="detail === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <!-- 任务概览 -->
            <t-cell-group t-class="mt-2" theme="card" title="任务概览">
                <t-cell title="优惠券">
                    <template #note>
                        <text>{{ detail.couponName }}</text>
                    </template>
                </t-cell>
                <t-cell title="任务状态">
                    <template #note>
                        <t-tag :theme="statusTheme(detail.status)" variant="light-outline" size="small">
                            {{ detail.statusLabel }}
                        </t-tag>
                    </template>
                </t-cell>
                <t-cell title="每人发放" :note="detail.perUserCount + ' 张'"/>
                <t-cell title="发放备注" :note="detail.remark || '—'"/>
                <t-cell title="发起员工" :note="detail.staffName"/>
                <t-cell title="创建时间" :note="detail.createdAt"/>
                <t-cell title="开始时间" :note="detail.startedAt || '—'"/>
                <t-cell title="完成时间" :note="detail.finishedAt || '—'"/>
            </t-cell-group>

            <!-- 数据看板 -->
            <t-cell-group t-class="mt-2" theme="card" title="数据看板">
                <view class="stat-grid">
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.expectUserCount }}</view>
                        <view class="stat-label">预期客户</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.successUserCount }}</view>
                        <view class="stat-label">发放成功</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.failUserCount }}</view>
                        <view class="stat-label">发放失败</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.receivedCount }}</view>
                        <view class="stat-label">到账张数</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.messageSuccessCount }}</view>
                        <view class="stat-label">消息成功</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.messageFailCount }}</view>
                        <view class="stat-label">消息失败</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.viewCount }}</view>
                        <view class="stat-label">浏览次数</view>
                    </view>
                    <view class="stat-item">
                        <view class="stat-value">{{ detail.viewUserCount }}</view>
                        <view class="stat-label">打开人数</view>
                    </view>
                </view>
            </t-cell-group>

            <!-- 客户明细 -->
            <t-cell-group t-class="mt-2" theme="card" title="客户明细">
                <view class="filter-bar">
                    <view
                        v-for="tab in filterTabs"
                        :key="tab.value"
                        class="filter-item"
                        :class="{active: filter === tab.value}"
                        @click="onFilterChange(tab.value)"
                    >{{ tab.label }}
                    </view>
                </view>
                <m-empty v-if="records.length === 0 && !recordsLoading">暂无记录</m-empty>
                <view v-for="item in records" :key="item.id" class="record-item">
                    <image class="record-avatar" :src="item.avatar" mode="aspectFill"/>
                    <view class="record-main">
                        <view class="record-name">{{ item.nickname || '微信用户' }}</view>
                        <view class="record-sub text-muted">
                            <text v-if="item.status === 3" class="record-fail">{{
                                    item.failReason || item.statusLabel
                                }}
                            </text>
                            <text v-else-if="item.status === 2">到账 {{ item.receiveCount }} 张 ·
                                消息{{ item.messageStatusLabel }}
                            </text>
                            <text v-else>{{ item.statusLabel }}</text>
                        </view>
                        <view class="record-sub text-muted" v-if="item.viewCount > 0">
                            已打开 {{ item.viewCount }} 次 · {{ item.firstViewedAt }}
                        </view>
                    </view>
                    <t-tag
                        :theme="recordTheme(item)"
                        variant="light-outline"
                        size="small"
                    >{{ item.statusLabel }}
                    </t-tag>
                </view>
                <m-loading v-if="recordsLoading" text="正在加载..."/>
                <m-nomore v-else-if="recordsCompleted && records.length > 0" backgroundColor="transparent"/>
            </t-cell-group>
        </template>

        <!-- 版本升级抽屉：企微接口 2006 拦截承接 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {PAGE_SIZE_DEFAULT} from '@/constants/common'

const taskId = ref('')
const detail = ref(undefined)

const filter = ref('all')
const filterTabs = [
    {label: '全部', value: 'all'},
    {label: '发放失败', value: 'fail'},
    {label: '消息失败', value: 'messageFail'},
    {label: '未打开', value: 'unviewed'},
]

const records = ref([])
const recordSearch = ref({page: 1, pageSize: PAGE_SIZE_DEFAULT})
const recordsCompleted = ref(false)
const recordsLoading = ref(false)

const statusTheme = (status) => {
    if (status === 2) return 'primary'
    if (status === 3) return 'success'
    return 'warning'
}

const recordTheme = (item) => {
    if (item.status === 2) return 'success'
    if (item.status === 3) return 'danger'
    return 'default'
}

const getDetail = () => {
    return request.get('/seller/coupon/mass/detail', {id: taskId.value}).then(res => {
        detail.value = res.data
    }).catch(() => {
        detail.value = null
    })
}

const getRecords = () => {
    recordsLoading.value = true
    return request.get('/seller/coupon/mass/record/list', {
        taskId: taskId.value,
        filter: filter.value,
        ...recordSearch.value,
    }).then(res => {
        const list = res.data.items || []
        if (recordSearch.value.page === 1) {
            records.value = list
        } else {
            records.value = [...records.value, ...list]
        }
        recordsCompleted.value = list.length < recordSearch.value.pageSize
    }).finally(() => {
        recordsLoading.value = false
    })
}

const onFilterChange = (value) => {
    if (filter.value === value) {
        return
    }
    filter.value = value
    recordSearch.value.page = 1
    recordsCompleted.value = false
    getRecords()
}

const onRetry = () => {
    detail.value = undefined
    getDetail()
}

onLoad((e) => {
    taskId.value = e.id
    getDetail()
    getRecords()
})

onPullDownRefresh(() => {
    recordSearch.value.page = 1
    recordsCompleted.value = false
    Promise.all([getDetail(), getRecords()]).finally(() => {
        uni.stopPullDownRefresh()
    })
})

onReachBottom(() => {
    if (recordsCompleted.value || recordsLoading.value) {
        return
    }
    recordSearch.value.page++
    getRecords()
})
</script>

<style scoped>
.stat-grid {
    display: flex;
    flex-wrap: wrap;
    padding: 10rpx 0 20rpx;
}

.stat-item {
    width: 25%;
    text-align: center;
    padding: 20rpx 0;
}

.stat-value {
    font-size: 36rpx;
    font-weight: 600;
    color: #333;
}

.stat-label {
    margin-top: 6rpx;
    font-size: 24rpx;
    color: #999;
}

.filter-bar {
    display: flex;
    gap: 16rpx;
    padding: 20rpx 24rpx;
    border-bottom: 1rpx solid #f3f3f3;
}

.filter-item {
    padding: 8rpx 24rpx;
    font-size: 26rpx;
    color: #666;
    background: #f5f5f5;
    border-radius: 28rpx;
}

.filter-item.active {
    color: #07c160;
    background: #e8f8ee;
}

.record-item {
    display: flex;
    align-items: center;
    gap: 20rpx;
    padding: 24rpx;
    border-bottom: 1rpx solid #f3f3f3;
}

.record-avatar {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    background: #f5f5f5;
    flex-shrink: 0;
}

.record-main {
    flex: 1;
    min-width: 0;
}

.record-name {
    font-size: 28rpx;
    color: #333;
}

.record-sub {
    margin-top: 6rpx;
    font-size: 24rpx;
}

.record-fail {
    color: #d54941;
}
</style>
