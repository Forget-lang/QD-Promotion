<template>
    <view>
        <m-loading v-if="items === undefined"/>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无群发记录</m-empty>
            <template v-else>
                <t-cell-group t-class="mt-2" theme="card">
                    <t-cell
                        v-for="item in items"
                        :key="item.id"
                        arrow
                        hover
                        :title="item.couponName"
                        @click="push('/pages_merchant/customer/mass_detail?id=' + item.id)"
                    >
                        <template #description>
                            <view class="text-muted text-small mt-1">{{ item.createdAt }} · {{ item.staffName }}</view>
                        </template>
                        <template #note>
                            <t-tag :theme="statusTheme(item.status)" variant="light-outline" size="small">
                                {{ item.statusLabel }}
                            </t-tag>
                        </template>
                    </t-cell>
                </t-cell-group>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
            <m-submit
                v-if="checkPermission(PERM_CUSTOMER.MASS)"
                @click="push('/pages_merchant/customer/mass_create')"
            >
                创建群发任务
            </m-submit>
        </template>
    </view>
</template>

<script setup>
import {onShow, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {PERM_CUSTOMER} from '@/constants/permission'
import {PAGE_SIZE_DEFAULT} from '@/constants/common'

const {push} = useLink()
const {checkPermission} = useAuth()

const items = ref(undefined)
const search = ref({page: 1, pageSize: PAGE_SIZE_DEFAULT})
const isCompleted = ref(false)
const loadingMore = ref(false)

const statusTheme = (status) => {
    if (status === 2) return 'primary'
    if (status === 3) return 'success'
    return 'warning'
}

const getItems = () => {
    return request.get('/seller/coupon/mass/list', search.value).then(res => {
        const list = res.data.items || []
        if (search.value.page === 1) {
            items.value = list
        } else {
            items.value = [...items.value, ...list]
        }
        isCompleted.value = list.length < search.value.pageSize
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        }
    })
}

const onRetry = () => {
    items.value = undefined
    search.value.page = 1
    isCompleted.value = false
    getItems()
}

onShow(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems().finally(() => {
        uni.stopPullDownRefresh()
    })
})

onReachBottom(() => {
    if (isCompleted.value || loadingMore.value || !items.value || items.value.length === 0) {
        return
    }
    loadingMore.value = true
    search.value.page++
    getItems().finally(() => {
        loadingMore.value = false
    })
})
</script>
