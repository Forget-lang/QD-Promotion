<template>
    <m-loading v-if="store === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="门店主营产品已修改成功" back></m-result>
        </template>
        <template v-else>
            <view class="container">
				<view class="section mt-2">
					<view class="input border-radius-0 bottom-line">
						<view class="input-label">主营产品</view>
						<view class="input-value">
							<text class="text-muted">可在门店主页展示，宣传门店产品</text>
						</view>
					</view>
					<m-major-select v-model:value="major"></m-major-select>
				</view>
			</view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>

</template>

<script setup>
import { onLoad } from '@dcloudio/uni-app'
import { ref } from 'vue'
import request from '@/hooks/request'

const loading = ref(false)
const store = ref()
const showSuccess = ref(false)
const major = ref([])
const storeId = ref('')

const onSubmit = () => {
    // 过滤掉空字符串
    const filteredMajor = major.value.filter(item => item && item.trim() !== '')
    
    if (filteredMajor.length === 0) {
        uni.showToast({
            title: '请输入主营产品',
            icon: 'none'
        })
        return
    }
    
    loading.value = true
    request.post('/seller/store/update/major', {
        id: storeId.value,
        major: filteredMajor,
    }).then(res => {
        loading.value = false
        showSuccess.value = true
    }).catch(() => {
        loading.value = false
    })
}

const getStore = () => {
    request.get('/seller/store', {id: storeId.value}, { showLoading: false }).then(res => {
        store.value = res.data
        major.value = res.data.major || []
    })
}

onLoad((e) => {
    if (e.storeId) {
        storeId.value = e.storeId
        getStore()
    }
})
</script>

<style scoped>
</style>
