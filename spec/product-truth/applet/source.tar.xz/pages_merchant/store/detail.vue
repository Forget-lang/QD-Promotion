<template>
    <m-loading v-if="store === undefined"></m-loading>
    <template v-else>
        <m-result v-if="isDeleteSuccess" title="删除成功" description="门店已删除" back></m-result>
        <view v-else class="container-safety">
            <t-cell-group t-class="mt-2" theme="card">
                <t-cell title="门店编号" arrow @click="onCopyStoreCode">
                    <template #note>
                        <view class="cell-more">MD{{ utils.formatSeparator(store.id, '-') }}</view>
                    </template>
                </t-cell>
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="门店名称" :note="store.name"
                        :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_name?storeId=' + storeId)"></t-cell>
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="门店LOGO" :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_logo?storeId=' + storeId)">
                    <template #note>
                        <image mode="widthFix" class="store-logo" :src="store.logo"/>
                    </template>
                </t-cell>
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="门店地址" t-class-title="text-cell-title" t-class-note="text-ellipsis text-scroll-hidden" :note="store.address"
                        :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_address?storeId=' + storeId)"></t-cell>
                <t-cell arrow title="营业状态" @click="onStatusClick">
                    <template #note>
                        <text :class="store.status === STORE_STATUS.NORMAL ? 'text-success' : 'text-warning'">{{ store.statusLabel }}</text>
                    </template>
                </t-cell>
                <t-cell title="审核状态">
                    <template #note>
                        <text :class="auditStatusClass">{{ store.auditStatusLabel }}</text>
                    </template>
                </t-cell>
            </t-cell-group>

            <t-cell-group title="营业信息" theme="card">
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="所在行业" :note="industryText"
                        :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_industry?storeId=' + storeId)"></t-cell>
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="主营产品" :note="majorText"
                        :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_major?storeId=' + storeId)"></t-cell>
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="营业时间" :note="businessHoursText"
                        :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_open_hour?storeId=' + storeId)"></t-cell>
                <t-cell :arrow="checkPermission(PERM_STORE.UPDATE)" title="客服电话" :note="store.servicePhone"
                        :hover="checkPermission(PERM_STORE.UPDATE)" @click="checkPermission(PERM_STORE.UPDATE) && push('/pages_merchant/store/update_phone?storeId=' + storeId)"></t-cell>
            </t-cell-group>

            <t-cell-group v-if="checkPermission(PERM_STORE.DELETE)" title="操作门店" theme="card">
                <t-cell title="删除门店" arrow hover @click="onDeleteConfirm" :bordered="false">
                    <template #description>
                        <view class="text-muted text-danger">删除后不可恢复，请审慎操作！</view>
                    </template>
                </t-cell>
            </t-cell-group>

            <t-action-sheet ref="sheetRef" @selected="onDelete"></t-action-sheet>
            <t-action-sheet ref="updateStatusRef" @selected="onActionSelected"></t-action-sheet>
        </view>
    </template>
</template>

<script setup>
import {onLoad, onShow} from '@dcloudio/uni-app'
import {ref, computed} from 'vue';
import {useLink} from "@/hooks/useLink.js"
import request from '@/hooks/request';
import {STORE_STATUS, STORE_AUDIT_STATUS} from '@/constants/merchant';
import utils from '@/utils/utils';
import {ActionSheetPlugin, ActionSheetTheme} from '@/uni_modules/tdesign-uniapp/components/index'
import {useAuth} from "@/hooks/useAuth.js"
import {PERM_STORE} from "@/constants/permission.js"

const {push} = useLink();
const {checkPermission} = useAuth();

const store = ref()
const storeId = ref('')
const isDeleteSuccess = ref(false)

// 审核状态文字颜色（通过绿 / 失败红 / 其余橙）
const auditStatusClass = computed(() => {
    if (!store.value) return ''
    if (store.value.auditStatus === STORE_AUDIT_STATUS.PASSED) return 'text-success'
    if (store.value.auditStatus === STORE_AUDIT_STATUS.FAILED) return 'text-danger'
    return 'text-warning'
})

// 行业文本
const industryText = computed(() => {
    if (!store.value) return ''
    const parts = []
    if (store.value.industryFirst) parts.push(store.value.industryFirst)
    if (store.value.industrySecond) parts.push(store.value.industrySecond)
    return parts.join(' / ')
})

// 主营产品文本
const majorText = computed(() => {
    if (!store.value || !store.value.major || store.value.major.length === 0) return '暂无'
    return store.value.major.join('、')
})

// 营业时间文本
const businessHoursText = computed(() => {
    if (!store.value) return ''
    if (store.value.isAlwaysOpen) return '全天营业'
    if (!store.value.openHour || store.value.openHour.length === 0) return '暂无'
    return store.value.openHour.map(item => `${item.startTime}-${item.endTime}`).join('，')
})

// 复制门店编号
const onCopyStoreCode = (event) => {
    let data = 'SD' + store.value.id
    utils.copyClipboard(data, '门店编号已复制到剪切板')
}

const getStore = () => {
    request.get('/seller/store', {id: storeId.value}, {showLoading: false}).then(res => {
        store.value = res.data
    })
}

const onDeleteConfirm = () => {
    ActionSheetPlugin.show({
        theme: ActionSheetTheme.List,
        selector: '#sheetRef',
        context: this,
        description: '删除不可撤回，确定要删除吗？',
        items: [{
            label: '删除门店',
            color: '#E3302D',
        },],
    })
}

const onDelete = () => {
    utils.showLoading()
    request.post('/seller/store/delete', {id: storeId.value}).then(res => {
        utils.hideLoading()
        isDeleteSuccess.value = true
        uni.$emit('onStoreChange', true)
    }).catch(err => {
        utils.hideLoading()
    })
}

// 点击门店状态
const onStatusClick = () => {
    // 只有正常和关店状态可以切换
    if (store.value.status !== STORE_STATUS.NORMAL && store.value.status !== STORE_STATUS.CLOSED) {
        utils.toast('当前状态不允许切换')
        return
    }

    // 构建 ActionSheet 选项
    const items = []
    if (store.value.status === STORE_STATUS.NORMAL) {
        // 当前是正常状态，显示关店选项
        items.push({
            label: '切换为关店',
            color: '#E3302D',
        })
    } else if (store.value.status === STORE_STATUS.CLOSED) {
        // 当前是关店状态，显示正常营业选项
        items.push({
            label: '切换为正常营业',
            color: '#00c352',
        })
    }

    ActionSheetPlugin.show({
        theme: ActionSheetTheme.List,
        selector: '#updateStatusRef',
        context: this,
        description: '确定要切换门店状态吗？',
        items: items,
    })
}

// 处理 ActionSheet 选择
const onActionSelected = (selected) => {
    // 判断是删除还是切换状态
    if (selected.label === '删除门店') {
        onDelete()
        return
    }

    const newStatus = store.value.status === STORE_STATUS.NORMAL ? STORE_STATUS.CLOSED : STORE_STATUS.NORMAL
    const statusText = newStatus === STORE_STATUS.NORMAL ? '正常营业' : '关店'

    request.post('/seller/store/update/status', {
        id: storeId.value,
        status: newStatus
    }, {
        showLoading: true
    }).then(res => {
        // 更新本地状态
        getStore()
        // store.value.status = newStatus
        utils.toast(`门店状态已切换为"${statusText}"`)
    }).catch(err => {

    })
}

onLoad((e) => {
    if (e.storeId) {
        storeId.value = e.storeId
    }
})

onShow(() => {
    if (storeId.value) {
        getStore()
    }
})
</script>

<style scoped>
.store-logo {
    width: 50rpx;
    height: 50rpx;
    border-radius: 100%;
}

.tag-warning {
    padding: 4rpx 12rpx;
    font-size: 20rpx;
    color: #ff7900;
    background-color: #fff3e0;
    border-radius: 4rpx;
}

.tag-success {
    padding: 4rpx 12rpx;
    font-size: 20rpx;
    color: #00c352;
    background-color: #e8f5e9;
    border-radius: 4rpx;
}
</style>
