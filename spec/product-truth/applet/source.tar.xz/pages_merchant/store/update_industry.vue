<template>
    <m-loading v-if="store === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="门店行业已修改成功" back></m-result>
        </template>
        <template v-else>
            <view class="container-safety">
                <t-cell-group theme="card" t-class="mt-2">
                    <m-industry-picker v-model:value="industry"></m-industry-picker>
                </t-cell-group>
            </view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>

</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'

const loading = ref(false)
const store = ref()
const showSuccess = ref(false)
const industry = ref([])
const storeId = ref('')

const onSubmit = () => {
    if (!industry.value || industry.value.length === 0) {
        uni.showToast({
            title: '请选择行业',
            icon: 'none'
        })
        return
    }

    loading.value = true
    request.post('/seller/store/update/industry', {
        id: storeId.value,
        industry: industry.value,
    }).then(res => {
        loading.value = false
        showSuccess.value = true
    }).catch(() => {
        loading.value = false
    })
}

const getStore = () => {
    request.get('/seller/store', {id: storeId.value}, {showLoading: false}).then(res => {
        store.value = res.data
        industry.value = [res.data.industryFirst, res.data.industrySecond]
    })
}

onLoad((e) => {
    if (e.storeId) {
        storeId.value = e.storeId
        getStore()
    }
})
</script>

<style scoped>
</style>
