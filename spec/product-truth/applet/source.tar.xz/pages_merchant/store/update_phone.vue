<template>
	<template v-if="showSuccess">
        <m-result title="设置成功" description="门店客服电话已成功修改" back></m-result>
    </template>
    <template v-else>
        <view class="container-safety">
            <t-cell-group theme="card" t-class="mt-2">
                <t-input label="客服电话" v-model:value="servicePhone" placeholder="请输入手机号码" type="number"
                    :maxlength="11" />
                <m-sms-code v-model:mobile="servicePhone" v-model:value="smsCode" label="短信验证码" />
            </t-cell-group>
        </view>
        <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
    </template>
	
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref } from 'vue'
	import request from '@/hooks/request'

	const loading = ref(false)
	const store = ref()
	const showSuccess = ref(false)
	const servicePhone = ref('')
	const smsCode = ref('')
	const storeId = ref('')

	const onSubmit = () => {
		if (!servicePhone.value) {
			uni.showToast({
				title: '请输入客服电话',
				icon: 'none'
			})
			return
		}
		
		if (!smsCode.value) {
			uni.showToast({
				title: '请输入验证码',
				icon: 'none'
			})
			return
		}
		
		loading.value = true
		request.post('/seller/store/update/phone', {
			id: storeId.value,
			servicePhone: servicePhone.value,
			smsCode: smsCode.value,
		}).then(res => {
			loading.value = false
			showSuccess.value = true
		}).catch(() => {
			loading.value = false
		})
	}

	onLoad((e) => {
		if (e.storeId) {
			storeId.value = e.storeId
		}
	})
</script>

<style scoped>
</style>
