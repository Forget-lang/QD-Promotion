<template>
	<m-loading v-if="store === undefined"></m-loading>
	<template v-else>
		<template v-if="showSuccess">
			<m-result title="设置成功" description="门店名称已修改成功" back></m-result>
		</template>
		<template v-else>
			<view class="container container-safety">
				<view class="section mt-2">
					<t-input label="门店名称" :line-left="false" v-model:value="name" placeholder="请输入门店名称" backgroundColor="#ffffff00"></t-input>
					<view class="text-muted p-3">
						门店名称最多64个字。
					</view>
				</view>
		    </view>
			<m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
		</template>
	</template>
	
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref } from 'vue'
	import request from '@/hooks/request'
	import utils from '@/utils/utils'

	const loading = ref(false)
	const store = ref()
	const showSuccess = ref(false)
	const name = ref()
	const storeId = ref('')

	const onSubmit = () => {
		if (!name.value || name.value.trim() === '') {
			uni.showToast({
				title: '请输入门店名称',
				icon: 'none'
			})
			return
		}
		
		loading.value = true
		request.post('/seller/store/update/name', {
			id: storeId.value,
			name: name.value,
		}).then(res => {
			loading.value = false
			showSuccess.value = true
		}).catch(() => {
			loading.value = false
		})
	}
	
	const getStore = () => {
		request.get('/seller/store', {id: storeId.value}, { showLoading: false }).then(res => {
			store.value = res.data
			name.value = res.data.name
		})
	}

	onLoad((e) => {
		if (e.storeId) {
			storeId.value = e.storeId
			getStore()
		}
	})
</script>

<style scoped>
</style>
