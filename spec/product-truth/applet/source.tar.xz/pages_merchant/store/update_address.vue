<template>
	<m-loading v-if="store === undefined"></m-loading>
	<template v-else>
		<template v-if="showSuccess">
			<m-result title="设置成功" description="门店地址已修改成功" back></m-result>
		</template>
		<template v-else>
			<view class="container-safety">
				<t-cell-group theme="card" t-class="mt-2">
					<m-area-picker v-model:value="store.area" @change="onChangeArea"></m-area-picker>
				</t-cell-group>
				
				<t-cell-group t-class="mt-2" theme="card">
					<t-input v-if="!store.address" label="详细地址" placeholder="点击选择地址(可编辑)" :readonly="!store.address" @click="chooseLocation">
						<template #extra>
							<t-icon name="location-filled" size="48rpx" color="#000"></t-icon>
						</template>
					</t-input>
					<template v-else>
						<t-textarea v-model:value="store.address" placeholder="请编辑地址" custom-style="height:160rpx"></t-textarea>
						<view class="text-muted bg-white p-3 top-line d-flex align-items-center justify-content-between" @click="chooseLocation">
							<text>地址如不准确，可编辑修改。</text>
							<t-icon name="location-filled" size="36rpx" color="#000"></t-icon>
						</view>
					</template>
				</t-cell-group>
		    </view>
			<m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
		</template>
	</template>
	
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref } from 'vue'
	import request from '@/hooks/request'
	import utils from '@/utils/utils'

	const loading = ref(false)
	const store = ref()
	const showSuccess = ref(false)
	const storeId = ref('')

	const onChangeArea = (area) => {
		if (area.length === 3) {
			store.value.province = area[0]
			store.value.city = area[1]
			store.value.district = area[2]
		}
	}

	const chooseLocation = () => {
		uni.chooseLocation({
			latitude: store.value.lat || 0,
			longitude: store.value.lng || 0,
			success(res) {
				store.value.address = res.address
				store.value.lat = res.latitude
				store.value.lng = res.longitude
			},
			fail() {
				utils.toast('门店地址选择失败，请重试')
			}
		})
	}

	const onSubmit = () => {
		if (!store.value.province || !store.value.city || !store.value.district) {
			uni.showToast({
				title: '请选择省市区',
				icon: 'none'
			})
			return
		}
		
		if (!store.value.address) {
			uni.showToast({
				title: '请输入详细地址',
				icon: 'none'
			})
			return
		}
		
		loading.value = true
		request.post('/seller/store/update/address', {
			id: storeId.value,
			province: store.value.province,
			city: store.value.city,
			district: store.value.district,
			address: store.value.address,
			lat: store.value.lat,
			lng: store.value.lng,
		}).then(res => {
			loading.value = false
			showSuccess.value = true
		}).catch(() => {
			loading.value = false
		})
	}
	
	const getStore = () => {
		request.get('/seller/store', {id: storeId.value}, { showLoading: false }).then(res => {
			store.value = res.data
            store.value.area = [store.value.province, store.value.city, store.value.district]
		})
	}

	onLoad((e) => {
		if (e.storeId) {
			storeId.value = e.storeId
			getStore()
		}
	})
</script>

<style scoped>
</style>
