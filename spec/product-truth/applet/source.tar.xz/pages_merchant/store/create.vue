<template>
    <m-result v-if="showSuccess" title="添加成功" description="门店添加成功" back></m-result>
    <view v-else class="container-safety">
        <t-cell-group t-class="mt-2" theme="card">
            <m-logo v-model:value="form.logo" emitName="storeCreateLogo"></m-logo>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <t-input label="门店简称" v-model:value="form.name" align="right" borderless placeholder="请输入简称"></t-input>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <m-area-picker @change="onChangeArea"></m-area-picker>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <t-input v-if="!form.address" label="详细地址" placeholder="点击选择地址(可编辑)" align="right" borderless :readonly="!form.address"
                     @click="chooseLocation">
                <template #extra>
                    <t-icon name="location-filled" size="48rpx" color="#000"></t-icon>
                </template>
            </t-input>
            <template v-else>
                <t-textarea v-model:value="form.address" placeholder="请编辑地址" custom-style="height:120rpx"></t-textarea>
                <view class="text-muted bg-white p-3 top-line d-flex align-items-center justify-content-between" @click="chooseLocation">
                    <text>地址如不准确，可编辑修改。</text>
                    <t-icon name="location-filled" size="36rpx" color="#000"></t-icon>
                </view>
            </template>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <m-industry-picker v-model:value="form.industry"></m-industry-picker>
        </t-cell-group>

        <view class="container">
            <view class="section mt-2">
                <view class="input border-radius-0 bottom-line">
                    <view class="input-label">主营产品</view>
                    <view class="input-value">
                        <text class="text-muted">可在门店主页展示，宣传门店产品</text>
                    </view>
                </view>
                <m-major-select v-model:value="form.major"></m-major-select>
            </view>
        </view>

        <view class="container">
            <view class="paragraph">营业时间</view>
            <view class="section mt-2">
                <t-cell title="24小时营业">
                    <template #note>
                        <t-switch v-model:value="form.isAlwaysOpen"></t-switch>
                    </template>
                </t-cell>
                <m-openhour-picker v-if="!form.isAlwaysOpen" v-model:value="form.openHour"></m-openhour-picker>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="复用商家客服电话">
                <template #note>
                    <t-switch v-model:value="form.isReuseServicePhone" :color="'#00c352'"></t-switch>
                </template>
            </t-cell>
            <template v-if="!form.isReuseServicePhone">
                <t-input :line-left="false" label="客服电话" :labelWidth="160" v-model:value="form.servicePhone" placeholder="请输入手机号码" type="number"
                         :maxlength="11"/>
                <m-sms-code v-model:mobile="form.servicePhone" v-model:value="form.smsCode" label="验证电话" :labelWidth="160"/>
            </template>
        </t-cell-group>


        <view class="container mt-5">
            <t-button @click="onSubmit" size="large" theme="danger" block :disabled="disable || loading"
                      :loading="loading">创建门店
            </t-button>
        </view>

        <!-- 版本升级抽屉：门店额度超限后端 2006 拦截承接 -->
        <m-vip-upgrade/>
    </view>
</template>
<script setup>
import {ref, computed} from 'vue'
import request from "@/hooks/request.js"
import {useSessionStore} from '@/stores/session'
import {useLink} from "@/hooks/useLink.js"
import utils from '@/utils/utils'

const {push, replace, switchTab, back} = useLink();

const showSuccess = ref(false)
const loading = ref(false)
const form = ref({
    isReuseServicePhone: true,
    servicePhone: '',
    openHour: [],
    major: [],
    isAlwaysOpen: false,
})
const disable = computed(() => {
    if (form.value.name &&
        form.value.province &&
        form.value.city &&
        form.value.district &&
        form.value.address &&
        form.value.industry
    ) {
        return false
    } else {
        return true
    }
})

const chooseLocation = () => {
    uni.chooseLocation({
        latitude: form.value.lat,
        longitude: form.value.lng,
        success(res) {
            console.log('地图选择信息：' + JSON.stringify(res))
            form.value.address = res.address
            form.value.lat = res.latitude
            form.value.lng = res.longitude
        },
        fail(err) {
            utils.toast('门店选择失败，请重新选择')
        }
    });
}

const onChangeArea = (area) => {
    if (area.length === 3) {
        form.value.province = area[0]
        form.value.city = area[1]
        form.value.district = area[2]
    }
}

const onSubmit = () => {
    if (loading.value || disable.value) return
    loading.value = true
    request.post('/seller/store/create', form.value).then(res => {
        loading.value = false
        showSuccess.value = true
    }).catch(() => {
        loading.value = false
    })
}
</script>

<style scoped>
.border-radius-0 {
    border-radius: 0 !important;
}

.input-logo-margin {
    margin-top: 18rpx !important;
    margin-bottom: 18rpx !important;
    overflow: visible !important;
}
</style>