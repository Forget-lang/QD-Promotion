<template>
    <m-loading v-if="store === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="门店营业时间已修改成功" back></m-result>
        </template>
        <template v-else>
            <view class="container">
				<view class="paragraph">营业时间</view>
				<view class="section mt-2">
					<t-cell title="24小时营业">
						<template #note>
							<t-switch v-model:value="isAlwaysOpen"></t-switch>
						</template>
					</t-cell>
					<view v-if="!isAlwaysOpen" class="p-3">
						<m-openhour-picker v-model:value="openHour"></m-openhour-picker>
					</view>
				</view>
			</view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>

</template>

<script setup>
import { onLoad } from '@dcloudio/uni-app'
import { ref } from 'vue'
import request from '@/hooks/request'

const loading = ref(false)
const store = ref()
const showSuccess = ref(false)
const isAlwaysOpen = ref(false)
const openHour = ref([])
const storeId = ref('')

const onSubmit = () => {
    // 如果不是24小时营业，必须设置营业时间
    if (!isAlwaysOpen.value && (!openHour.value || openHour.value.length === 0)) {
        uni.showToast({
            title: '请设置营业时间',
            icon: 'none'
        })
        return
    }
    
    loading.value = true
    request.post('/seller/store/update/open-hour', {
        id: storeId.value,
        isAlwaysOpen: isAlwaysOpen.value,
        openHour: isAlwaysOpen.value ? [] : openHour.value,
    }).then(res => {
        loading.value = false
        showSuccess.value = true
    }).catch(() => {
        loading.value = false
    })
}

const getStore = () => {
    request.get('/seller/store', {id: storeId.value}, { showLoading: false }).then(res => {
        store.value = res.data
        isAlwaysOpen.value = res.data.isAlwaysOpen || false
        openHour.value = res.data.openHour || []
    })
}

onLoad((e) => {
    if (e.storeId) {
        storeId.value = e.storeId
        getStore()
    }
})
</script>

<style scoped>
</style>
