<template>
    <m-result v-if="showSuccess" type="success" title="注销成功" description="商家账号已成功注销"
              confirmText="返回" @confirm="onSuccessBack"></m-result>
    <template v-else>
        <view class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="h4">注销须知：</view>
                <view class="mt-1 text-small">1. 商家注销后，<text class="text-danger">所有数据将被清除且无法恢复</text>，请谨慎操作！</view>
                <view class="mt-1 text-small">2. 注销后将无法使用该商家账号登录。</view>
                <view class="mt-1 text-small">3. 注销前请确保已处理完所有卡券、券包、次卡及员工相关事项。</view>
            </view>
        </view>

            <t-cell-group t-class="mt-2" theme="card">
                <t-cell title="注销条件" t-class-title="text-cell-title"></t-cell>
                <view class="condition-list">
                    <view class="condition-item" v-for="(item, index) in conditions" :key="index">
                        <t-icon :name="item.passed ? 'check-circle-filled' : 'close-circle-filled'"
                                :color="item.passed ? '#07c160' : '#fa5151'"
                                :size="20"></t-icon>
                        <text class="condition-text ml-1">{{ item.label }}</text>
                    </view>
                </view>
            </t-cell-group>

        <view class="mt-3">
            <t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless icon="circle"
                        relation-key="-1" custom-style="background-color: transparent;"
                        :disabled="!allConditionsPassed">
                <template #label>
                    <view class="agreement">
                        我已阅读并知晓注销商家的风险，确认要注销商家账号及所有数据。
                    </view>
                </template>
            </t-checkbox>
        </view>

        <!-- 提交按钮 -->
        <m-submit :loading="loading" :disabled="loading || !allowAgreement || !allConditionsPassed" @click="onSubmit">确认注销</m-submit>
    </template>
</template>

<script setup>
import { onLoad } from '@dcloudio/uni-app';
import { ref, computed } from 'vue'
import request from "@/hooks/request.js"
import MResult from "@/components/m/m-result/m-result.vue";
import utils from "@/utils/utils";
import {useSessionStore} from "@/stores/session.js";
import {useLink} from "@/hooks/useLink.js";

const {reLaunch} = useLink()

const sessionStore = useSessionStore()
const allowAgreement = ref(false)
const loading = ref(false)
const showSuccess = ref(false)

const conditions = ref([
    {key: 'noActiveTemplates', label: '账号下不存在有效中的卡券模版、券包、次卡', passed: false},
    {key: 'noOtherStaff', label: '已删除除超级管理员之外的所有员工', passed: false},
    {key: 'isSuperAdmin', label: '当前操作人为商家超级管理员', passed: false},
])

const allConditionsPassed = computed(() => {
    return conditions.value.every(item => item.passed)
})

const checkConditions = () => {
    request.get('/seller/merchant/cancel/check').then(res => {
        const data = res.data || {}
        conditions.value.forEach(item => {
            item.passed = !!data[item.key]
        })
    }).catch(err => {
        utils.toast(err.message || '检查注销条件失败')
    })
}

const onSubmit = () => {
    if (!allConditionsPassed.value) {
        utils.toast('请先满足所有注销条件')
        return
    }

    uni.showModal({
        title: '确认注销',
        content: '注销后所有数据将被清除且无法恢复，确认要注销吗？',
        confirmColor: '#E3302D',
        success(res) {
            if (res.confirm) {
                loading.value = true
                request.post('/seller/merchant/cancel').then(() => {
                    sessionStore.exitMerchant()
                    showSuccess.value = true
                }).catch(err => {
                    utils.toast(err.message || '注销失败')
                }).finally(() => {
                    loading.value = false
                })
            }
        }
    })
}

const onSuccessBack = () => {
    reLaunch('/pages/merchant/index')
}

onLoad(() => {
    checkConditions()
})
</script>

<style scoped>
.condition-list {
    padding: 20rpx 30rpx;
    background-color: #fff;
}

.condition-item {
    display: flex;
    align-items: center;
    padding: 16rpx 0;
}

.condition-text {
    font-size: 28rpx;
    color: #333;
}
</style>
