<template>
	<m-loading v-if="merchant === undefined"></m-loading>
	<template v-else>
		<template v-if="showSuccess">
			<m-result title="设置成功" description="商家简称已修改成功" back></m-result>
		</template>
		<template v-else>
			<view class="container container-safety">
				<view class="section mt-2">
					<t-input label="商家简称" :line-left="false" v-model:value="name" placeholder="请输入商家简称" backgroundColor="#ffffff00"></t-input>
					<view class="text-muted p-3">
						商家简称每个月可修改{{merchant.cycleMonthMaxCount}}次，已修改{{merchant.cycleNameCount}}次。
					</view>
				</view>
		    </view>
			<m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
		</template>
	</template>
	
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref, computed } from 'vue'
	import request from '@/hooks/request'
	import utils from '@/utils/utils'

	const loading = ref(false)
	const merchant = ref()
	const showSuccess = ref(false)
	const name = ref()

	const onSubmit = () => {
		loading.value = true
		request.post('/seller/merchant/update/name', {
			name:name.value,
		}).then(res => {
			loading.value = false
			showSuccess.value = true
		}).catch(() => {
			loading.value = false
		})
	}
	
	const getMerchant = () => {
		request.get('/seller/merchant', {}, { showLoading: false }).then(res => {
			merchant.value = res.data
            name.value = res.data.name
		})
	}

	onLoad(() => {
		getMerchant()
	})
</script>

<style scoped>
</style>
