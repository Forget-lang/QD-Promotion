<template>
    <m-loading v-if="merchant === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="商家门头照片已修改成功" back></m-result>
        </template>
        <template v-else>
            <view class="container pt-2">
                <m-cover v-model:value="merchant.cover" emitName="merchantCreatCover"></m-cover>
            </view>
            <view class="container mt-2">
                <view class="text-muted mt-1">最佳宽高比例3:2，建议图片尺寸600x400</view>
                <view class="text-muted">
                    商家门头照片每个月可修改{{ merchant.cycleMonthMaxCount }}次，已修改{{ merchant.cycleCoverCount }}次。
                </view>
            </view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>

</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from "@/hooks/request.js"

const merchant = ref()
const showSuccess = ref(false)
const loading = ref(false)

const onSubmit = () => {
    loading.value = true
    request.post('/seller/merchant/update/cover', {
		id:merchant.value.id,
        cover: merchant.value.cover,
	}).then(res => {
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}

const getMerchant = () => {
    request.get('/seller/merchant', {}, {showLoading: false}).then(res => {
        merchant.value = res.data
    })
}

onLoad(() => {
    getMerchant()
})
</script>

<style scoped>

</style>