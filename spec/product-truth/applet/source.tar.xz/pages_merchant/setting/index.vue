<template>
	<m-loading v-if="merchant === undefined"></m-loading>
	<view v-else class="pb-4">
        <!-- 商家与版本信息 -->
        <view class="container mt-2" v-if="edition">
            <view class="section">
                <view class="edition-row">
                    <image class="edition-logo" :src="merchant.logo" mode="aspectFill" v-if="merchant.logo"/>
                    <view class="edition-info">
                        <view class="edition-merchant-name">{{ merchant.name }}</view>
                        <view class="edition-meta">
                            <image class="edition-icon" :src="edition.icon" mode="aspectFit" v-if="edition.icon"/>
                            <text class="edition-expire" v-if="edition.isFree">永久免费</text>
                            <text class="edition-expire" v-else-if="edition.expiredAt">到期 {{ edition.expiredAt }}</text>
                        </view>
                    </view>
                    <view class="edition-action" @click="openVipUpgrade">
                        <text>{{ edition.isFree ? '升级' : '续费' }}</text>
                        <t-icon name="chevron-right" size="32rpx" color="#999999"/>
                    </view>
                </view>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="商家编号" arrow @click="onCopyMerchantCode">
                <template #note>
                    <view class="cell-more">SJ{{utils.formatSeparator(merchant.id, '-')}}</view>
                </template>
            </t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="商家名称" :note="merchant.name" :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/name')"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="商家地址" t-class-title="text-cell-title"
                    t-class-note="text-ellipsis text-scroll-hidden" :note="merchant.address"
                    :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/address')"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="所在行业" :note="merchant.industry" :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/industry')"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="客服电话" :note="merchant.servicePhone" :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/phone')"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="门头照片" :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/cover')"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="商家LOGO" :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/logo')">
                <template #note>
                    <image mode="widthFix" class="merchant-logo" :src="merchant.logo" />
                </template>
            </t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="微信卡包设置" note="LOGO、封面与主题色"
                    :hover="checkPermission(PERM_MERCHANT.SETTING)"
                    @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/wecard/index')"></t-cell>
        </t-cell-group>
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell arrow title="企业微信" note="授权安装企业微信应用" url="/pages_wecom/wecom/auth" v-if="checkPermission(PERM_WECOM.CORP_CONFIG)"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="客户注册" note="设置客户注册方式" url="/pages_merchant/setting/register" v-if="checkPermission(PERM_MERCHANT.SETTING)"></t-cell>
            <t-cell :arrow="checkPermission(PERM_MERCHANT.SETTING)" title="商家认证" :note="merchant.authStatusLabel" :hover="checkPermission(PERM_MERCHANT.SETTING)" @click="checkPermission(PERM_MERCHANT.SETTING) && push('/pages_merchant/setting/auth')"></t-cell>
            <t-cell v-if="checkPermission(PERM_MERCHANT.SETTING)" arrow title="订单发票" note="发票信息、订单与开票"
                    url="/pages_merchant/invoice/index"></t-cell>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell arrow title="服务协议" url="/pages_assist/agreement/agreement"></t-cell>
            <t-cell arrow title="隐私政策" url="/pages_assist/agreement/privacy"></t-cell>
        </t-cell-group>
        <t-cell-group t-class="mt-2" theme="card" v-if="checkPermission(PERM_MERCHANT.CANCEL)">
            <t-cell arrow title="商家注销" url="/pages_merchant/setting/cancel"></t-cell>
        </t-cell-group>
        <!-- VIP 升级抽屉：打开走 useVipGuard / 事件 -->
        <m-vip-upgrade/>
	</view>
</template>

<script setup>
import {onShow} from '@dcloudio/uni-app'
import {ref} from 'vue'
import {useAuth} from '@/hooks/useAuth.js'
import {useLink} from '@/hooks/useLink.js'
import {useVipGuard} from '@/hooks/useVipGuard'
import {PERM_MERCHANT} from '@/constants/permission'
import {PERM_WECOM} from '@/constants/permission'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {EDITION_ID_FREE} from '@/constants/edition'

const {checkPermission, getSession} = useAuth()
const {push} = useLink()
const {open: openVipUpgrade} = useVipGuard()
// 商家资料
const merchant = ref()
// 当前版本信息
const edition = ref(null)

// 拉取当前版本信息（统一走 useAuth 的 getSession，每次进入页面重新请求）
const getEdition = () => {
    getSession().then(d => {
        const data = d || {}
        edition.value = {
            id: data.editionId,
            name: data.editionName,
            icon: data.editionIcon,
            expiredAt: String(data.editionExpiredAt || '').slice(0, 10),
            isFree: String(data.editionId) === String(EDITION_ID_FREE),
        }
    })
}

// 复制商家编号
const onCopyMerchantCode = () => {
    utils.copyClipboard('SJ' + merchant.value.id, '商家编号已复制到剪切板')
}

// 拉取商家资料
const getMerchant = () => {
    request.get('/seller/merchant', {}, {showLoading: false}).then(res => {
        merchant.value = res.data
    })
}

// 每次进入页面刷新商家与版本
onShow(() => {
    getMerchant()
    getEdition()
})
</script>

<style scoped>
/*
 * 自定义样式原因：版本信息需在标准 section 内做 LOGO + 名称/版本 + 操作的横向布局，
 * t-cell 无法自然承载头像与双行文案组合。
 */
.merchant-logo {
    width: 50rpx;
    height: 50rpx;
    border-radius: 100%;
}

.edition-row {
    display: flex;
    align-items: center;
    padding: 28rpx 32rpx;
}

.edition-logo {
    width: 88rpx;
    height: 88rpx;
    border-radius: 12rpx;
    margin-right: 24rpx;
    flex-shrink: 0;
}

.edition-info {
    flex: 1;
    min-width: 0;
}

.edition-merchant-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #000;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.edition-meta {
    display: flex;
    align-items: center;
    margin-top: 10rpx;
}

.edition-icon {
    width: 120rpx;
    height: 48rpx;
    margin-right: 16rpx;
    flex-shrink: 0;
}

.edition-expire {
    font-size: 24rpx;
    color: #999;
}

.edition-action {
    display: flex;
    align-items: center;
    flex-shrink: 0;
    margin-left: 16rpx;
    font-size: 26rpx;
    color: #999;
}
</style>
