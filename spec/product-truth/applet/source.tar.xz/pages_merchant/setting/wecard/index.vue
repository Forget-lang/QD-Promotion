<template>
    <m-loading v-if="form === undefined"></m-loading>
    <view v-else class="container-safety">
        <view class="container mt-2">
            <view class="alert-warning">修改设置后，仅对新创建并同步到微信卡包的优惠券生效。</view>
        </view>
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell arrow title="LOGO设置" :hover="true" @click="push('/pages_merchant/setting/wecard/logo')">
                <template #note>
                    <image v-if="form.wecardLogoUrl" class="preview-logo" mode="aspectFill" :src="form.wecardLogoUrl"/>
                    <text v-else class="text-muted">未设置</text>
                </template>
            </t-cell>
            <t-cell arrow title="封面设置" :hover="true" @click="push('/pages_merchant/setting/wecard/image')">
                <template #note>
                    <image v-if="form.wecardImageUrl" class="preview-cover" mode="aspectFill"
                           :src="form.wecardImageUrl"/>
                    <text v-else class="text-muted">未设置</text>
                </template>
            </t-cell>
            <t-cell arrow title="主题设置" :hover="true" @click="push('/pages_merchant/setting/wecard/color')">
                <template #note>
                    <view class="d-flex align-items-center">
                        <view class="color-dot" :style="{ backgroundColor: form.wecardColorHex || '#cc463d' }"></view>
                        <text>{{ form.wecardColor }}</text>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>
    </view>
</template>

<script setup>
import {onShow} from '@dcloudio/uni-app'
import {ref} from 'vue'
import {useLink} from '@/hooks/useLink.js'
import request from '@/hooks/request'

const {push} = useLink()
const form = ref()

const load = () => {
    request.get('/seller/merchant/wecard', {}, {showLoading: false}).then(res => {
        form.value = res.data
    })
}

onShow(() => {
    load()
})
</script>

<style scoped>
.preview-logo {
    width: 56rpx;
    height: 56rpx;
    border-radius: 8rpx;
}

.preview-cover {
    width: 120rpx;
    height: 68rpx;
    border-radius: 8rpx;
}

.color-dot {
    width: 32rpx;
    height: 32rpx;
    border-radius: 50%;
    margin-right: 12rpx;
}
</style>
