<template>
    <m-loading v-if="color === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="主题色已更新，仅对新券生效" back></m-result>
        </template>
        <template v-else>
            <view class="container container-safety container-submit">
                <view class="mt-2">
                    <view class="alert-warning">请选择微信官方支持的卡券背景色，修改后仅对新创建的卡包券生效。</view>
                </view>
                <view class="color-grid mx-3 mt-3">
                    <view
                        v-for="item in colors"
                        :key="item.value"
                        class="color-item"
                        :class="{ active: color === item.value }"
                        @click="color = item.value"
                    >
                        <view class="swatch" :style="{ backgroundColor: item.hex }"></view>
                        <view class="label">{{ item.value }}</view>
                    </view>
                </view>
                <view class="preview-wrap mx-3 mt-4">
                    <view class="preview-card" :style="{ backgroundColor: currentHex }">
                        <view class="preview-title">卡券主题预览</view>
                        <view class="preview-sub">{{ color }}</view>
                    </view>
                </view>
            </view>
            <m-submit :loading="loading" :disable="loading" @click="onSubmit">保存主题</m-submit>
        </template>
    </template>
    <!-- VIP 升级抽屉：不支持功能后端 2006 拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'

const colors = [
    {value: 'Color010', hex: '#63b359'},
    {value: 'Color020', hex: '#2c9f67'},
    {value: 'Color030', hex: '#509fc9'},
    {value: 'Color040', hex: '#5885cf'},
    {value: 'Color050', hex: '#9062c0'},
    {value: 'Color060', hex: '#d09a45'},
    {value: 'Color070', hex: '#e4b138'},
    {value: 'Color080', hex: '#ee903c'},
    {value: 'Color090', hex: '#dd6549'},
    {value: 'Color100', hex: '#cc463d'},
]

const color = ref()
const showSuccess = ref(false)
const loading = ref(false)

const currentHex = computed(() => {
    const hit = colors.find((c) => c.value === color.value)
    return hit ? hit.hex : '#cc463d'
})

const onSubmit = () => {
    if (!color.value) {
        utils.toast('请选择主题色')
        return
    }
    loading.value = true
    request.post('/seller/merchant/wecard/color', {color: color.value}).then(() => {
        loading.value = false
        showSuccess.value = true
    }).catch(() => {
        loading.value = false
    })
}

onLoad(() => {
    request.get('/seller/merchant/wecard', {}, {showLoading: false}).then((res) => {
        color.value = res.data.wecardColor || 'Color100'
    })
})
</script>

<style scoped>
.color-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20rpx;
}

.color-item {
    width: calc(50% - 10rpx);
    background: #fff;
    border-radius: 12rpx;
    padding: 20rpx;
    box-sizing: border-box;
    display: flex;
    align-items: center;
    border: 2rpx solid transparent;
}

.color-item.active {
    border-color: #0052d9;
}

.swatch {
    width: 48rpx;
    height: 48rpx;
    border-radius: 50%;
    margin-right: 16rpx;
}

.label {
    font-size: 26rpx;
    color: #333;
}

.preview-card {
    border-radius: 16rpx;
    padding: 48rpx 32rpx;
    color: #fff;
}

.preview-title {
    font-size: 32rpx;
    font-weight: 600;
}

.preview-sub {
    margin-top: 12rpx;
    font-size: 24rpx;
    opacity: 0.9;
}
</style>
