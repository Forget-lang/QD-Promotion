<template>
    <m-loading v-if="form === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="微信卡包封面已更新，仅对新券生效" back></m-result>
        </template>
        <template v-else>
            <view class="container-safety">
                <view class="container mt-2">
                    <view class="alert-warning">微信要求尺寸 1074×603，JPG/PNG，不超过
                        2MB。上传后会同步到微信支付营销素材。
                    </view>
                </view>
                <view class="img-upload" @click="onChooseImage">
                    <image v-if="previewUrl" class="cover-img" :src="previewUrl" mode="aspectFill"></image>
                    <t-icon v-else class="merchant-img-add" name="add" color="#999" :size="50"></t-icon>
                    <view v-if="previewUrl" class="img-del" @tap.stop="onDelete"></view>
                </view>
            </view>
            <m-submit :loading="loading" :disable="loading" @click="onSubmit">保存封面</m-submit>
        </template>
        <m-compress v-model:show="showCompress" v-model:tempFile="compressFile" @compress="onCompress"></m-compress>
    </template>
    <!-- VIP 升级抽屉：不支持功能后端 2006 拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref, onBeforeUnmount} from 'vue'
import {useLink} from '@/hooks/useLink.js'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import config from '@/config'
import {getUploadHeader} from '@/utils/upload'

const {push} = useLink()
const form = ref()
const previewUrl = ref('')
const pendingUrl = ref('')
const showSuccess = ref(false)
const loading = ref(false)
const showCompress = ref(false)
const compressFile = ref('')

const uploadImage = (file) => {
    utils.showLoading()
    const timestamp = utils.getUnixTime()
    const sign = utils.signParam({}, config.appSecret, timestamp)
    uni.uploadFile({
        url: config.apiUrl + '/seller/object/upload?sign=' + sign + '&timestamp=' + timestamp,
        filePath: file,
        name: 'file',
        header: getUploadHeader(),
        success: (uploadFileRes) => {
            utils.hideLoading()
            let result
            try {
                result = JSON.parse(uploadFileRes.data)
            } catch (e) {
                utils.toast('上传响应异常')
                return
            }
            if (result.code === 0) {
                if (result.data.isSuccess) {
                    pendingUrl.value = result.data.url
                    previewUrl.value = result.data.url
                } else {
                    utils.alert(result.data.failReason)
                }
            } else {
                utils.alert(result.message)
            }
        },
        fail: () => {
            utils.hideLoading()
            utils.toast('上传失败')
        }
    })
}

const onChooseImage = () => {
    uni.chooseImage({
        count: 1,
        sizeType: ['original', 'compressed'],
        sourceType: ['album', 'camera'],
        success: (res) => {
            const size = res.tempFiles[0].size
            const path = res.tempFilePaths[0]
            if (size > 2 * 1024 * 1024) {
                utils.toast('单张图片大小不能超过：2MB')
                return
            }
            uni.getImageInfo({
                src: path,
                success: (info) => {
                    if (info.width === 1074 && info.height === 603) {
                        uploadImage(path)
                    } else {
                        push('/pages_merchant/media/cropper?path=' + path + '&width=358&height=201&emitName=onCropperWecardImage', true)
                    }
                },
                fail: () => {
                    push('/pages_merchant/media/cropper?path=' + path + '&width=358&height=201&emitName=onCropperWecardImage', true)
                }
            })
        }
    })
}

const onDelete = () => {
    previewUrl.value = ''
    pendingUrl.value = ''
}

const onCompress = () => {
    uploadImage(compressFile.value)
}

const onSubmit = () => {
    if (!pendingUrl.value) {
        utils.toast('请先选择封面')
        return
    }
    loading.value = true
    request.post('/seller/merchant/wecard/image', {image: pendingUrl.value}).then(() => {
        loading.value = false
        showSuccess.value = true
    }).catch(() => {
        loading.value = false
    })
}

const load = () => {
    request.get('/seller/merchant/wecard', {}, {showLoading: false}).then((res) => {
        form.value = res.data
        previewUrl.value = res.data.wecardImageUrl || ''
        pendingUrl.value = ''
    })
}

onLoad(() => {
    load()
    uni.$on('onCropperWecardImage', (file) => {
        compressFile.value = file
        showCompress.value = true
    })
})

onBeforeUnmount(() => {
    uni.$off('onCropperWecardImage')
})
</script>

<style scoped>
.img-upload {
    margin: 80rpx auto 24rpx;
    background-color: #fff;
    width: 640rpx;
    height: 360rpx;
    text-align: center;
    position: relative;
    display: flex;
    align-items: center;
    justify-content: center;
}

.cover-img {
    width: 640rpx;
    height: 360rpx;
    border-radius: 16rpx;
}

.img-del {
    width: 18px;
    height: 18px;
    position: absolute;
    right: -6px;
    top: -6px;
    background-color: #EB0909;
    border-radius: 50%;
    z-index: 200;
}

.img-del::before {
    content: '';
    width: 8px;
    height: 1px;
    position: absolute;
    left: 5px;
    top: 9px;
    background-color: #fff;
}
</style>
