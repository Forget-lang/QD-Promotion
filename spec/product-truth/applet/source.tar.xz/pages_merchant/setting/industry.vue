<template>
    <m-loading v-if="merchant === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="商家行业已修改成功" back></m-result>
        </template>
        <template v-else>
            <view class="container-safety">
                <t-cell-group theme="card" t-class="mt-2">
                    <m-industry-picker v-model:value="industry"></m-industry-picker>
                </t-cell-group>
            </view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>

</template>

<script setup>
import { onLoad } from '@dcloudio/uni-app'
import { ref } from 'vue'
import request from '@/hooks/request'

const loading = ref(false)
const merchant = ref()
const showSuccess = ref(false)
const industry = ref([])

const onSubmit = () => {
    loading.value = true
    request.post('/seller/merchant/update/industry', {
        industry: industry.value,
    }).then(res => {
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}

const getMerchant = () => {
    request.get('/seller/merchant', {}, { showLoading: false }).then(res => {
        merchant.value = res.data
        industry.value = res.data.industry.split('/') || []
    })
}

onLoad(() => {
    getMerchant()
})
</script>

<style scoped>
</style>
