<template>
    <template v-if="showResult">
        <m-result v-if="merchant.authStatus === AUTH_STATUS.SUCCESS" title="商家认证成功" type="success" back></m-result>
        <m-result v-else-if="merchant.authStatus === AUTH_STATUS.AUDITING" title="商家认证审核中" type="info"
                  description="预计3个工作日内完成人工审核，请耐心等待" back></m-result>
        <m-result v-else-if="merchant.authStatus === AUTH_STATUS.FAILED" title="商家认证失败"
                  :description="failReason || '上传的营业执照或法人信息错误'" type="error" confirmText="重新认证"
                  @confirm="showResult = false"></m-result>
    </template>
	<m-loading v-else-if="merchant === undefined"></m-loading>
	<template v-else>
        <view class="container pb-4">
            <view class="alert-success mt-2 d-flex align-items-center" v-if="showNotice">
                <t-icon name="user-safety" color="var(--td-brand-color)" size="60rpx"></t-icon>
                <text class="ml-2">平台承诺：商家的身份信息绝对保密，仅用于商家真实性认证，请您放心提交。</text>
            </view>
            <view class="section mt-2">
                <t-input label="商家名称" required v-model:value="form.name" align="right" borderless
                         placeholder="请填写营业执照商户简称" :maxlength="32"></t-input>
                <view class="name-tip">
                    商家名称须与营业执照主体相关或简称，若无明显关联，请上传附件证明关系（如授权书、品牌授权等）。
                </view>
            </view>
            <view class="section mt-2">
                <view class="section-header bottom-line">
                    <text class="section-title">营业执照</text>
                </view>
                <view class="business-card-wrap">
                    <view class="business-card uploaded-slot" v-if="form.companyCert"
                          @click="onChooseImage('companyCert')">
                        <view class="upload-success">
                            <t-icon name="check-circle-filled" size="56rpx" color="#07C160"></t-icon>
                            <text class="upload-success-text">已提交</text>
                        </view>
                        <view class="img-delete" @click.stop="onDeleteImage('companyCert')">
                            <t-icon name="close-circle-filled" size="44rpx" color="#ff5d50"></t-icon>
                        </view>
                    </view>
                    <view class="business-card" v-else @click="onChooseImage('companyCert')">
                        <image class="business-card-img" src="https://cdn.lenmy.com/quanxiangtuan/2024/10/24/csd6s4qde1he2qci29dg.png" mode="aspectFill"></image>
                        <view class="business-card-mask"></view>
                        <view class="business-card-upload">
                            <image class="upload-icon" src="/static/img/camara.png" mode="aspectFit"></image>
                            <text class="upload-name">营业执照</text>
                        </view>
                    </view>
                </view>
            </view>
            <view class="section mt-2">
                <view class="section-header bottom-line">
                    <text class="section-title">法人身份证</text>
                </view>
                <view class="cer-info-item">
                    <view class="cer-info-sample">
                        <image class="cer-info-image" src="https://cdn.lenmy.com/quanxiangtuan/2024/10/23/cscekeide1h3joufcjmg.png" mode="aspectFill">
                        </image>
                        <view class="right-rect"></view>
                        <text class="right-tip">示例</text>
                    </view>
                    <view class="cer-info-sample uploaded-slot" v-if="form.masterFront"
                          @click="onChooseImage('masterFront')">
                        <view class="upload-success cer-upload-success">
                            <t-icon name="check-circle-filled" size="56rpx" color="#07C160"></t-icon>
                            <text class="upload-success-text">已提交</text>
                        </view>
                        <view class="img-delete" @click.stop="onDeleteImage('masterFront')">
                            <t-icon name="close-circle-filled" size="44rpx" color="#ff5d50"></t-icon>
                        </view>
                    </view>
                    <view class="cer-info-sample" v-else @click="onChooseImage('masterFront')">
                        <image class="cer-info-image" src="https://cdn.lenmy.com/quanxiangtuan/2024/10/23/cscekeide1h3joufcjmg.png" mode="aspectFill"></image>
                        <view class="cer-info-mask"></view>
                        <view class="cer-upload">
                            <image class="upload-icon" src="/static/img/camara.png" mode="aspectFit"></image>
                            <text class="upload-name">身份证正面</text>
                        </view>
                    </view>
                </view>
                <view class="cer-info-item">
                    <view class="cer-info-sample">
                        <image class="cer-info-image" src="https://cdn.lenmy.com/quanxiangtuan/2024/10/23/cscelride1h3joufcjn0.png" mode="aspectFill">
                        </image>
                        <view class="right-rect"></view>
                        <text class="right-tip">示例</text>
                    </view>
                    <view class="cer-info-sample uploaded-slot" v-if="form.masterBack"
                          @click="onChooseImage('masterBack')">
                        <view class="upload-success cer-upload-success">
                            <t-icon name="check-circle-filled" size="56rpx" color="#07C160"></t-icon>
                            <text class="upload-success-text">已提交</text>
                        </view>
                        <view class="img-delete" @click.stop="onDeleteImage('masterBack')">
                            <t-icon name="close-circle-filled" size="44rpx" color="#ff5d50"></t-icon>
                        </view>
                    </view>
                    <view class="cer-info-sample" v-else @click="onChooseImage('masterBack')">
                        <image class="cer-info-image" src="https://cdn.lenmy.com/quanxiangtuan/2024/10/23/cscelride1h3joufcjn0.png" mode="aspectFill"></image>
                        <view class="cer-info-mask"></view>
                        <view class="cer-upload">
                            <image class="upload-icon" src="/static/img/camara.png" mode="aspectFit"></image>
                            <text class="upload-name">身份证反面</text>
                        </view>
                    </view>
                </view>
            </view>
            <view class="section mt-2">
                <t-cell title="关系证明附件" note="选填"></t-cell>
                <view class="business-card-wrap">
                    <view class="business-card uploaded-slot" v-if="form.attachment"
                          @click="onChooseImage('attachment')">
                        <view class="upload-success">
                            <t-icon name="check-circle-filled" size="56rpx" color="#07C160"></t-icon>
                            <text class="upload-success-text">已提交</text>
                        </view>
                        <view class="img-delete" @click.stop="onDeleteImage('attachment')">
                            <t-icon name="close-circle-filled" size="44rpx" color="#ff5d50"></t-icon>
                        </view>
                    </view>
                    <view class="business-card attach-empty" v-else @click="onChooseImage('attachment')">
                        <view class="business-card-upload">
                            <image class="upload-icon" src="/static/img/camara.png" mode="aspectFit"></image>
                            <text class="upload-name">上传附件</text>
                        </view>
                    </view>
                </view>
                <view class="cell-helper">名称与执照无明显关联时请上传（授权书、商标注册证等）。</view>
            </view>
            <t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless
                        icon="rectangle" relation-key="-1" custom-style="background-color: transparent;">
                <template #label>
                    <view class="user-agreement">
                        <view>我已阅读并同意券到卡包</view>
                        <navigator class="link" url="/pages_assist/agreement/privacy" @click.stop>《隐私政策》
                        </navigator>
                        及
                        <navigator class="link" url="/pages_assist/agreement/agreement" @click.stop>《服务协议》
                        </navigator>
                    </view>
                </template>
            </t-checkbox>
            <t-button block size="large" theme="danger" :loading="loading" :disabled="disable" @click="onSubscribeMessage">提交</t-button>
        </view>
		<m-compress v-model:show="compressShow" v-model:tempFile="compressFile" @compress="onCompressed"></m-compress>
	</template>
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
    import {ref, computed} from 'vue'
    import config from '@/config.js'
    import utils from '@/utils/utils'
    import {useSessionStore} from '@/stores/session'
    import request from '@/hooks/request'
    import {AUTH_STATUS} from '@/constants/merchant'

	const session = useSessionStore()

	const merchant = ref()
	const showNotice = ref(true)
	const showResult = ref(false)
	const loading = ref(false)
	const allowAgreement = ref(false)
    const failReason = ref('')
	const form = ref({
        name: '',
        companyCert: '',
        masterFront: '',
        masterBack: '',
        attachment: ''
    })
    const compressShow = ref(false)
    const compressFile = ref('')
    const compressField = ref('')

    // 提交按钮禁用状态：未勾选协议或提交中均禁用
    const disable = computed(() => {
        return !allowAgreement.value || loading.value
    })

    const onChooseImage = (field) => {
        uni.chooseImage({
            count: 1,
            sizeType: ['original'],
            success: (res) => {
                compressField.value = field
                compressFile.value = res.tempFilePaths[0]
                compressShow.value = true
            }
        })
    }

    const onCompressed = () => {
        const field = compressField.value
        const filePath = compressFile.value
        const timestamp = utils.getUnixTime()
        const sign = utils.signParam({}, config.appSecret, timestamp)
        uni.showLoading({ title: '上传中' })
        uni.uploadFile({
            url: config.apiUrl + '/seller/object/upload-private?sign=' + sign + '&timestamp=' + timestamp,
            filePath: filePath,
            name: 'file',
            header: {
                'Authorization': session.token,
                'Merchant-Id': session.merchantId,
                'App-Name': 'applet',
                'Version': config.version,
            },
            success: (uploadRes) => {
                uni.hideLoading()
                const result = JSON.parse(uploadRes.data)
                if (result.code === 0) {
                    form.value[field] = result.data.url
                } else {
                    utils.toast(result.message)
                }
            },
            fail: (err) => {
                uni.hideLoading()
                utils.toast('上传失败：' + err.errMsg)
            }
        })
    }

	const onDeleteImage = (field) => {
		form.value[field] = ''
	}

	const onSubscribeMessage = () => {
        utils.showLoading()
        const tmplIds = (config.subscribeMessage.merchantAuth || []).filter(Boolean)
        if (!tmplIds.length) {
            utils.hideLoading()
            onSubmit()
            return
        }
        uni.requestSubscribeMessage({
            tmplIds,
            success() {
                utils.hideLoading()
                onSubmit()
            },
            fail() {
                utils.hideLoading()
                onSubmit()
            }
        })
	}

    const onSubmit = () => {
        if (utils.isEmptyObject(form.value.name) || !String(form.value.name).trim()) {
            utils.toast('请填写商家名称')
            return
        }
        if (utils.isEmptyObject(form.value.companyCert)) {
            utils.toast('请上传营业执照')
            return
        }
        if (utils.isEmptyObject(form.value.masterFront)) {
            utils.toast('请上传身份证正面')
            return
        }
        if (utils.isEmptyObject(form.value.masterBack)) {
            utils.toast('请上传身份证反面')
            return
        }
        if (!allowAgreement.value) {
            utils.toast('请阅读并同意《服务协议》及《隐私政策》')
            return
        }

        loading.value = true
        request.post('/seller/merchant/audit', {
            name: String(form.value.name).trim(),
            companyCert: form.value.companyCert,
            masterFront: form.value.masterFront,
            masterBack: form.value.masterBack,
            attachment: form.value.attachment || ''
        }, {
            showLoading: true
        }).then(res => {
            loading.value = false
            const data = res.data || {}
            merchant.value.authStatus = data.authStatus
            merchant.value.authStatusLabel = data.authStatusLabel
            failReason.value = data.failReason || ''
            showResult.value = true
        }).catch(() => {
            loading.value = false
        })
    }

    const getMerchant = () => {
        request.get('/seller/merchant').then(res => {
            merchant.value = res.data
            if (merchant.value.authStatus !== AUTH_STATUS.NONE && merchant.value.authStatus !== AUTH_STATUS.MUST) {
                showResult.value = true
            }
        })
    }

    onLoad(() => {
        getMerchant()
    })
</script>

<style scoped>
	.cer-info-item {
		display: flex;
		align-items: center;
		padding: 30rpx 15rpx;
	}

	.cer-info-sample {
		position: relative;
		flex: 1;
		background-color: #F7F7F7;
		padding: 20rpx;
		margin: 0 15rpx;
		border-radius: 8rpx;
	}

	.cer-info-image {
		width: 100%;
		/* 固定宽高比展示，避免竖向图片按宽度等比放大高度撑高内容区 */
		height: 200rpx;
		display: block;
	}

	.business-card-wrap {
		display: flex;
		justify-content: center;
		padding: 20rpx 0;
	}

	.business-card {
		position: relative;
		width: 280rpx;
		background-color: #F7F7F7;
		border-radius: 8rpx;
		padding: 20rpx;
	}

    .uploaded-slot {
        min-height: 200rpx;
        display: flex;
        align-items: center;
        justify-content: center;
    }

    .upload-success {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 180rpx;
    }

    .cer-upload-success {
        height: 200rpx;
    }

    .upload-success-text {
        margin-top: 12rpx;
        font-size: 28rpx;
        color: #07C160;
    }

	.img-delete {
		position: absolute;
		top: -16rpx;
		right: -16rpx;
		z-index: 1;
	}

	.business-card-img {
		width: 100%;
		/* 固定高度裁剪显示，避免竖向图片撑高容器 */
		height: 180rpx;
		display: block;
	}

	.business-card-mask {
		position: absolute;
		left: 20rpx;
		right: 20rpx;
		top: 20rpx;
		bottom: 20rpx;
		background-color: #fcfcfc;
		opacity: 0.8;
	}

	.business-card-upload {
		position: absolute;
		left: 20rpx;
		right: 20rpx;
		top: 20rpx;
		bottom: 20rpx;
		display: flex;
		align-items: center;
		flex-direction: column;
		justify-content: center;
	}

	.right-rect {
		position: absolute;
		right: 0;
		top: 0;
		width: 0;
		height: 0;
		border-bottom: 65rpx solid transparent;
		border-right: 65rpx solid #1ec179;
		color: white;
		font-size: 24rpx;
	}

	.right-tip {
		position: absolute;
		transform: rotate(45deg);
		right: 0;
		top: 6rpx;
		font-size: 20rpx;
		color: #ffffff;
	}

	.cer-info-mask {
		position: absolute;
		left: 20rpx;
		right: 20rpx;
		bottom: 20rpx;
		top: 20rpx;
		background-color: #fcfcfc;
		opacity: 0.8;
	}

	.cer-upload {
		position: absolute;
		left: 20rpx;
		right: 20rpx;
		bottom: 20rpx;
		top: 20rpx;
		display: flex;
		align-items: center;
		flex-direction: column;
		justify-content: center;
		background-color: transparent;
	}

	.upload-icon {
		width: 80rpx;
		height: 80rpx;
	}

	.upload-name {
		margin-top: 10rpx;
		font-size: 28rpx;
		color: #6e6e6e;
	}

	.user-agreement {
		color: #999;
		font-size: 24rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-wrap: wrap;
	}

	.link {
        color: #07C160;
    }

    .name-tip {
        padding: 0 32rpx 24rpx;
        font-size: 24rpx;
        color: #999;
        line-height: 1.5;
    }

    .attach-empty {
        min-height: 200rpx;
        display: flex;
        align-items: center;
        justify-content: center;
    }
</style>

<style>
.agreement-checkbox {
    margin-right: 10rpx !important;
    scale: 0.8;
	}
</style>
