<template>
	<m-loading v-if="merchant === undefined"></m-loading>
	<template v-else>
		<template v-if="showSuccess">
			<m-result title="设置成功" description="商家LOGO已修改成功" back></m-result>
		</template>
		<template v-else>
			<view class="container">
				<view class="mt-2">
					<view class="img-upload" @click="onChooseImage">
						<image v-if="merchant.logo != ''" class="merchant-logo" :src="merchant.logo" mode="widthFix"></image>
						<t-icon v-else class="merchant-img-add" name="add" color="#999" :size="50"></t-icon>
						<view v-if="merchant.logo !== ''" class="img-del" @tap.stop="onDelete"></view>
					</view>
					<view class="note text-center">每个月可修改{{merchant.cycleMonthMaxCount}}次，已修改{{merchant.cycleLogoCount}}次。</view>
				</view>
			</view>
			<m-submit :loading="loading" :disable="loading" @click="onSubmit">保存LOGO</m-submit>
		</template>
		<m-compress v-model:show="showCompress" v-model:tempFile="compressFile" @compress="onCompress"></m-compress>
	</template>
</template>

<script setup>
	import { onLoad  } from '@dcloudio/uni-app'
	import { ref, onBeforeUnmount } from 'vue';
	import { useLink } from "@/hooks/useLink.js"
	import request from '@/hooks/request'
	import utils from '@/utils/utils'
	import config from '@/config';
    import {getUploadHeader} from '@/utils/upload';
	
	const { push } = useLink()
	
	const merchant = ref()
	const showSuccess = ref(false)
	const loading = ref()
	const showCompress = ref(false)
	const compressFile = ref('')
	
	const uploadLogo = (file) => {
		utils.showLoading()
		let timestamp = utils.getUnixTime()
		let sign = utils.signParam({}, config.appSecret, timestamp)
		uni.uploadFile({
			url: config.apiUrl + '/seller/object/upload?sign=' + sign + '&timestamp=' + timestamp,
			filePath: file,
			name: 'file',
            header: getUploadHeader(),
			success: (uploadFileRes) => {
				utils.hideLoading()
				//uploadFile将真实返回结果为Json字符串，封装到data字段中
                let result
                try {
                    result = JSON.parse(uploadFileRes.data)
                } catch (e) {
                    utils.toast('上传响应异常')
                    return
                }
				if (result.code === 0) {
                    if (result.data.isSuccess){
                        merchant.value.logo = result.data.url
                    } else {
                        utils.alert(result.data.failReason)
                    }
				} else { //上传错误时，使用接口返回的错误信息
					utils.alert(result.message)
				}
			},
			fail: (err) => {
				utils.hideLoading()
				console.log(err);
			}
		})
	}
	
	const onDelete = () => {
		merchant.value.logo = ''
	}
	
	const onChooseImage = () => {
		uni.chooseImage({
			count: 1,
			sizeType: ['original', 'compressed'],
			sourceType: ['album', 'camera'],
			success: res => {
				let size = res.tempFiles[0].size;
				if (5 * 1024 * 1024 < size) {
					let err = `单张图片大小不能超过：2MB`
					utils.toast(err)
				} else {
                    push('/pages_merchant/media/cropper?path=' + res.tempFilePaths[0] + '&width=300&height=300&emitName=onCropperMerchantLogo',
						true)
				}
			}
		});
	}
	
	const onCompress = () => {
		uploadLogo(compressFile.value)
	}
	
	const getMerchant = () => {
		request.get('/seller/merchant', {}, { showLoading: false }).then(res => {
			merchant.value = res.data
		})
	}
	
	const onSubmit = () => {
		loading.value = true
		request.post('/seller/merchant/update/logo', {
			logo:merchant.value.logo,
		}).then(res => {
			loading.value = false
			showSuccess.value = true
		}).catch(() => {
			loading.value = false
		})
	}
	
	onLoad(() => {
		getMerchant()
		uni.$on('onCropperMerchantLogo', (file) => {
			compressFile.value = file
			showCompress.value = true
		})
	})
	
	onBeforeUnmount(() => {
		uni.$off('onCropperMerchantLogo')
	})
	
</script>

<style scoped>
	.img-upload {
		margin: 100rpx auto;
		background-color: #fff;
		width: 360rpx;
		height: 360rpx;
		text-align: center;
		position: relative;
		border-radius: 16rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	
	.merchant-logo {
		width: 360rpx;
		height: 360rpx;
		border-radius: 16rpx;
	}
	
	.img-del {
		width: 18px;
		height: 18px;
		position: absolute;
		right: -6px;
		top: -6px;
		background-color: #EB0909;
		border-radius: 50%;
		color: white;
		font-size: 17px;
		z-index: 200;
	}
	
	.img-del::before {
		content: '';
		width: 8px;
		height: 1px;
		position: absolute;
		left: 5px;
		top: 9px;
		background-color: #fff;
	}
</style>