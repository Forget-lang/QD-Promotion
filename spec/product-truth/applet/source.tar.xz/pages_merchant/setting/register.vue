<template>
    <m-loading v-if="merchant === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="客户注册方式已修改成功" back></m-result>
        </template>
        <template v-else>
            <view class="container-safety">
                <!-- 两个互斥注册方式卡片 -->
                <t-cell-group t-class="mt-2" theme="card">
                    <t-cell title="微信授权注册" description="授权获取客户的微信昵称和头像，增强使用体验">
                        <template #note>
                            <t-switch :value="registerType === REGISTER_TYPE.WECHAT" @change="onSwitchWechat"/>
                        </template>
                    </t-cell>
                    <t-cell title="匿名注册" description="客户首次领券自动注册，无需授权，昵称为「微信用户」">
                        <template #note>
                            <t-switch :value="registerType === REGISTER_TYPE.ANONYMOUS" @change="onSwitchAnonymous"/>
                        </template>
                    </t-cell>
                </t-cell-group>

                <view class="container mt-2">
                    <view class="section tips-card">
                        <view class="d-flex align-items-center">
                            <t-icon name="info-circle-filled" size="32rpx" color="#d46b08" />
                            <text class="tips-title ml-1">温馨提示</text>
                        </view>
                        <view class="tips-text mt-2">
                            匿名注册模式下，客户无需授权即可快速领取优惠券，注册门槛更低。
                        </view>
                        <view class="tips-text mt-2" style="font-weight:600;color:#c41d00;">
                            修改注册方式仅对新注册客户生效，已注册客户不受影响。
                        </view>
                    </view>
                </view>
            </view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>
</template>

<script setup>
import { onLoad } from '@dcloudio/uni-app'
import { ref } from 'vue'
import request from '@/hooks/request'
import { REGISTER_TYPE } from '@/constants/merchant'

const merchant = ref()
const loading = ref(false)
const showSuccess = ref(false)
const registerType = ref(REGISTER_TYPE.WECHAT)

// 匿名注册 switch（直接设置，互斥）
const onSwitchAnonymous = () => {
    registerType.value = REGISTER_TYPE.ANONYMOUS
}

// 微信授权注册 switch（直接设置，互斥）
const onSwitchWechat = () => {
    registerType.value = REGISTER_TYPE.WECHAT
}

// 提交修改
const onSubmit = () => {
    loading.value = true
    request.post('/seller/merchant/update/register-type', {
        registerType: registerType.value
    }).then(res => {
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}

// 加载商户当前设置
const getMerchant = () => {
    request.get('/seller/merchant', {}, { showLoading: false }).then(res => {
        merchant.value = res.data
        registerType.value = res.data.registerType || REGISTER_TYPE.WECHAT
    })
}

onLoad(() => {
    getMerchant()
})
</script>

<style scoped>
</style>
