<template>
	<m-loading v-if="merchant === undefined"></m-loading>
	<template v-else>
		<template v-if="showSuccess">
			<m-result title="设置成功" description="商家客服电话已成功修改" back></m-result>
		</template>
		<template v-else>
			<view class="container-safety">
				<t-cell-group theme="card" t-class="mt-2">
					<t-input label="客服电话" v-model:value="servicePhone" placeholder="请输入手机号码" type="number"
						:maxlength="11" />
					<m-sms-code v-model:mobile="servicePhone" :disabled="isLimited" v-model:value="smsCode" label="短信验证码" />
				</t-cell-group>
				
				<view class="container mt-2">
					<view class="text-muted">
						商家简称每个月可修改{{merchant.cycleMonthMaxCount}}次，已修改{{merchant.cyclePhoneCount}}次。
					</view>
				</view>
		    </view>
			<m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
		</template>
	</template>
	
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref, computed } from 'vue'
	import request from '@/hooks/request'
	import utils from '@/utils/utils'

	const loading = ref(false)
	const merchant = ref()
	const showSuccess = ref(false)
	const servicePhone = ref('')
	const smsCode = ref('')
	
	const isLimited = computed(()=>{
        return merchant.value.cyclePhoneCount >= merchant.value.cycleMonthMaxCount
	})

	const onSubmit = () => {
		loading.value = true
		request.post('/seller/merchant/update/servicePhone', {
			servicePhone: servicePhone.value,
			smsCode: smsCode.value,
		}).then(res => {
			showSuccess.value = true
		}).finally(() => {
			loading.value = false
		})
	}

	
	const getMerchant = () => {
		request.get('/seller/merchant', {}, { showLoading: false }).then(res => {
			merchant.value = res.data
		})
	}

	onLoad(() => {
		getMerchant()
	})
</script>

<style scoped>
</style>
