<template>
	<m-loading v-if="merchant === undefined"></m-loading>
	<template v-else>
		<template v-if="showSuccess">
			<m-result title="设置成功" description="商家地址已修改成功" back></m-result>
		</template>
		<template v-else>
			<view class="container-safety">
				<t-cell-group theme="card" t-class="mt-2">
					<m-area-picker v-model:value="area" @change="onChangeArea"></m-area-picker>
				</t-cell-group>
				
				<t-cell-group t-class="mt-2" theme="card">
					<t-input v-if="!merchant.address" label="运营地址" placeholder="点击选择地址(可编辑)" :readonly="!merchant.address" @click="chooseLocation">
						<template #extra>
							<t-icon name="location-filled" size="48rpx" color="#000"></t-icon>
						</template>
					</t-input>
					<template v-else>
						<t-textarea v-model:value="merchant.address" placeholder="请编辑地址" custom-style="height:120rpx"></t-textarea>
						<view class="text-muted bg-white p-3 top-line d-flex align-items-center justify-content-between" @click="chooseLocation">
							<text>地址如不准确，可编辑修改。</text>
							<t-icon name="location-filled" size="36rpx" color="#000"></t-icon>
						</view>
					</template>
				</t-cell-group>
				<view class="container mt-2">
					<view class="text-muted">
						商家地址每个月可修改{{merchant.cycleMonthMaxCount}}次，已修改{{merchant.cycleAddressCount}}次。
					</view>
				</view>
		    </view>
			<m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
		</template>
	</template>
	
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref, computed } from 'vue'
	import request from '@/hooks/request'
	import utils from '@/utils/utils'

	const loading = ref(false)
	const merchant = ref()
	const showSuccess = ref(false)
    const area = ref([])

	const onChangeArea = (area) => {
        console.log(area)
		if (area.length === 3) {
			merchant.value.province = area[0]
			merchant.value.city = area[1]
			merchant.value.district = area[2]
            area.value = area
		}
	}

	const chooseLocation = () => {
		uni.chooseLocation({
			latitude: merchant.value.lat,
			longitude: merchant.value.lng,
			success(res) {
				merchant.value.address = res.address
				merchant.value.lat = res.latitude
				merchant.value.lng = res.longitude
			},
			fail() {
				utils.toast('门店地址选择失败，请重试')
			}
		})
	}

	const onSubmit = () => {
		loading.value = true
		request.post('/seller/merchant/update/address', merchant.value).then(res => {
			showSuccess.value = true
		}).finally(() => {
			loading.value = false
		})
	}
	
	const getMerchant = () => {
		request.get('/seller/merchant', {}, { showLoading: false }).then(res => {
			merchant.value = res.data
            area.value = [res.data.province, res.data.city, res.data.district]
		})
	}

	onLoad(() => {
		getMerchant()
	})
</script>

<style scoped>
</style>
