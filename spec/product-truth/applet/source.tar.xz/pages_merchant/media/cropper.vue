<template>
	<view class="cropper-container">
		<m-picture-cropper custom :startCutting="startCutting" :rotateAngle="rotateAngle" :height="height" :width="width" :scaleRatio="scaleRatio"
			lockRatio :imageUrl="imageUrl" :quality="1" @ready="ready" @cropper="cropper">
		</m-picture-cropper>
		<view class="t-cropper-tabbar">
			<view class="t-op-btn" @tap.stop="onCancel">取消</view>
			<image src="@/static/components/cropper/img_rotate.png" class="t-rotate-img" @tap="setAngle"></image>
			<view class="t-op-btn" @tap.stop="onCropper">完成</view>
		</view>
	</view>
</template>

<script setup>
	import { onLoad } from '@dcloudio/uni-app'
	import { ref } from "vue";
	import utils from '@/utils/utils';

	const path = ref('') //图片临时路径
	const imageUrl = ref('') //裁剪加载图片
	const width = ref(300) //裁剪框宽度px
	const height = ref(240) //裁剪框高度px
	const cropEmit = ref('cropEmit')
	const scaleRatio = ref(1)
	const startCutting = ref(0)
	const rotateAngle = ref(0)

	const ready = () => {
		imageUrl.value = path.value
	}

	const cropper = (e) => {
		if (e.url) {
			// //打印数据使用
			// const imageInfo = utils.getImgInfo(e.url)
			// console.log('裁剪后的图片信息', imageInfo);
			// uni.getFileSystemManager().getFileInfo({
			// 	filePath: e.url,
			// 	success(res) {
			// 		console.log('裁剪后的图片大小', res.size / 1024 / 1024)
			// 	},
			// })

			uni.$emit(cropEmit.value, e.url)
			uni.navigateBack()

		} else {
			utils.toast('图片裁剪失败,请重试')
			setTimeout(() => {
				uni.navigateBack()
			}, 1200)
		}
	}

	const setAngle = () => {
		rotateAngle.value += 90
	}

	const onCropper = () => {
		startCutting.value += 1
	}

	const onCancel = () => {
		uni.navigateBack()
	}

	//计算裁剪图片输出比例
	const loadScaleRatio = async () => {
		const imageInfo = await utils.getImgInfo(path.value)
		// console.log('imageInfo:', imageInfo)
		if (imageInfo) {
			scaleRatio.value = imageInfo.width / width.value
		} else {
			utils.alert('图片格式不支持，请重新选择图片', () => { uni.navigateBack() })
		}

		// console.log('要裁剪的图片信息', imageInfo);
		// console.log('scaleRatio', scaleRatio.value);
	}

	onLoad((e) => {
		if (e.path) {
			path.value = e.path
		}
		if (e.width) {
			width.value = parseInt(e.width)
		}
		if (e.height) {
			height.value = parseInt(e.height)
		}
		if (e.emitName) {
			cropEmit.value = e.emitName
		}

		loadScaleRatio()
	})
</script>

<style scoped>
	.t-cropper-tabbar {
		width: 100%;
		height: 120rpx;
		padding: 0 40rpx;
		box-sizing: border-box;
		position: fixed;
		left: 0;
		bottom: 0;
		z-index: 99;
		display: flex;
		align-items: center;
		justify-content: space-between;
		color: #ffffff;
		font-size: 32rpx;
	}

	.t-cropper-tabbar::after {
		content: ' ';
		position: absolute;
		top: 0;
		right: 0;
		left: 0;
		border-top: 1rpx solid rgba(255, 255, 255, 0.2);
		-webkit-transform: scaleY(0.5) translateZ(0);
		transform: scaleY(0.5) translateZ(0);
		transform-origin: 0 100%;
	}

	.t-op-btn {
		height: 80rpx;
		display: flex;
		align-items: center;
	}

	.t-rotate-img {
		width: 44rpx;
		height: 44rpx;
	}

	.canvas-positon {
		position: absolute;
		left: -5000px;
		top: -5000px;
	}
</style>