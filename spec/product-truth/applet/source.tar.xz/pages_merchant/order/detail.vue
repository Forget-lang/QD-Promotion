<template>
    <m-loading v-if="order === undefined"></m-loading>
    <view v-else>
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="订单号" :note="order.id"></t-cell>
            <t-cell title="标题" :note="order.title"></t-cell>
            <t-cell title="版本" :note="order.editionName"></t-cell>
            <t-cell title="实付" :note="'¥' + order.payAmount"></t-cell>
            <t-cell title="支付渠道" :note="order.payChannelLabel"></t-cell>
            <t-cell title="订单状态" :note="order.orderStatusLabel"></t-cell>
            <t-cell title="开票状态" :note="order.invoiceStatusLabel"></t-cell>
            <t-cell title="到期时间" :note="order.editionEndAt || '-'"></t-cell>
            <t-cell title="创建时间" :note="order.createdAt"></t-cell>
        </t-cell-group>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'

const order = ref()

onLoad((q) => {
    request.get('/seller/order/detail', {id: q.id}).then(res => {
        order.value = res.data
    })
})
</script>
