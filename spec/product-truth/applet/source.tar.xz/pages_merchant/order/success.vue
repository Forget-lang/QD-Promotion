<template>
    <view class="success-root" :class="headerTheme">
        <m-navigation-bar
            title="支付结果"
            home-url="/pages/merchant/index"
            class="success-navbar"
        />
        <m-loading v-if="order === undefined"></m-loading>
        <view v-else class="success-page pb-4">
            <view class="success-header" :class="headerTheme" :style="{ paddingTop: navHeight + 'px' }">
                <view class="success-badge">
                    <view class="success-badge-core">
                        <t-icon :name="headerIcon" size="120rpx" color="#ffffff" custom-style="font-weight: bold;"/>
                    </view>
                </view>
                <view class="success-title">{{ headerTitle }}</view>
            </view>

            <view class="pay-card anim-up">
                <view class="pay-amount-head">
                    <text class="pay-amount-label">{{ isPaid ? '实付金额' : '订单金额' }}</text>
                    <text class="pay-status-badge" :class="headerTheme" v-if="order.orderStatusLabel">
                        {{ order.orderStatusLabel }}
                    </text>
                </view>
                <view class="pay-amount">
                    <text class="pay-amount-symbol">¥</text>
                    <text class="pay-amount-num">{{ order.payAmount }}</text>
                </view>
                <view class="pay-info-list">
                    <view class="pay-info-row">
                        <text class="pay-info-label">订单号</text>
                        <view class="pay-info-value-wrap" @click="copyOrderId">
                            <text class="pay-info-value">{{ order.id }}</text>
                            <t-icon name="copy" size="28rpx" color="#999999"
                                    custom-style="margin-left: 8rpx; flex-shrink: 0;"/>
                        </view>
                    </view>
                    <view class="pay-info-row">
                        <text class="pay-info-label">{{ isPaid ? '支付时间' : '下单时间' }}</text>
                        <text class="pay-info-value">{{ payTimeText }}</text>
                    </view>
                    <view class="pay-info-row" v-if="order.payChannelLabel">
                        <text class="pay-info-label">支付渠道</text>
                        <text class="pay-info-value">{{ order.payChannelLabel }}</text>
                    </view>
                    <view class="pay-info-row" v-if="order.editionName">
                        <text class="pay-info-label">购买版本</text>
                        <text class="pay-info-value">{{ order.editionName }}</text>
                    </view>
                    <view class="pay-info-row">
                        <text class="pay-info-label">版本到期</text>
                        <text class="pay-info-value">{{ editionEndText }}</text>
                    </view>
                </view>
            </view>

            <view class="action-btn outline anim-up delay-1 mt-2" v-if="isPaid" @click="goInvoice">
                <t-icon name="bill" size="36rpx" color="#07C160"/>
                <text class="action-btn-text">申请开发票</text>
                <text class="action-btn-tip">电子发票，3-5 个工作日</text>
                <t-icon name="chevron-right" size="32rpx" color="#999999"/>
            </view>

            <view class="action-btn outline anim-up delay-2" @click="contactService">
                <t-icon name="service" size="36rpx" color="#07C160"/>
                <text class="action-btn-text">支付有问题，联系客服</text>
                <t-icon name="chevron-right" size="32rpx" color="#999999"/>
            </view>

            <m-submit @click="back">返回</m-submit>
        </view>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils'

const {reLaunch,back} = useLink()

const navHeight = ref(0)
const order = ref()

const isPaid = computed(() => order.value?.orderStatus === 'success')

const headerTheme = computed(() => {
    const s = order.value?.orderStatus
    if (s === 'unpaid') return 'theme-pending'
    if (s === 'closed' || s === 'refund') return 'theme-muted'
    return 'theme-success'
})

const headerTitle = computed(() => {
    const s = order.value?.orderStatus
    if (s === 'success') return order.value.editionName + '开通成功'
    if (s === 'unpaid') return '待支付'
    if (s === 'closed') return '订单已关闭'
    if (s === 'refund') return '已退款'
    return order.value?.orderStatusLabel || '订单详情'
})

const headerIcon = computed(() => {
    if (isPaid.value) return 'check-circle-filled'
    if (order.value?.orderStatus === 'unpaid') return 'info-circle-filled'
    return 'minus-circle-filled'
})

const payTimeText = computed(() => {
    const o = order.value
    if (!o) return '-'
    return o.payedAt || o.createdAt || '-'
})

const editionEndText = computed(() => {
    const raw = order.value?.editionEndAt
    if (!raw) return '-'
    return String(raw).slice(0, 10)
})

const copyOrderId = () => {
    if (!order.value?.id) return
    uni.setClipboardData({data: String(order.value.id)})
}

const goInvoice = () => {
    uni.navigateTo({url: '/pages_merchant/invoice/create'})
}

const contactService = () => {
    utils.openCustomerService()
}

const goHome = () => {
    reLaunch('/pages/merchant/index')
}

onLoad((q) => {
    navHeight.value = utils.getNavBarHeight()
    request.get('/seller/order/detail', {id: q.orderId}).then(res => {
        order.value = res.data
    })
})
</script>

<style scoped lang="scss">
.success-root {
    --td-navbar-color: #fff;
    min-height: 100vh;
    background: #f5f5f5;
}

.success-root.theme-success {
    background: linear-gradient(180deg, var(--td-brand-color, #07C160) 0, var(--td-brand-color, #07C160) 240rpx, #f5f5f5 240rpx);
}

.success-root.theme-pending {
    background: linear-gradient(180deg, #FF9500 0, #FF9500 240rpx, #f5f5f5 240rpx);
}

.success-root.theme-muted {
    background: linear-gradient(180deg, #8A8A8A 0, #8A8A8A 240rpx, #f5f5f5 240rpx);
}

.success-page {
    min-height: 100vh;
    background: transparent;
    padding-bottom: 200rpx;
}

.success-header {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 24rpx 32rpx 120rpx;
}

.success-header.theme-success {
    background: linear-gradient(160deg, #10D870 0%, var(--td-brand-color, #07C160) 100%);
}

.success-header.theme-pending {
    background: linear-gradient(160deg, #FFB84D 0%, #FF9500 100%);
}

.success-header.theme-muted {
    background: linear-gradient(160deg, #B0B0B0 0%, #8A8A8A 100%);
}

.success-badge {
    position: relative;
    width: 144rpx;
    height: 144rpx;
    margin-top: 30rpx;
    margin-bottom: 12rpx;
}

.success-badge-core {
    width: 144rpx;
    height: 144rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.success-title {
    color: #fff;
    font-size: 42rpx;
    font-weight: bold;
    letter-spacing: 2rpx;
}

.pay-card {
    margin: -76rpx 24rpx 0;
    padding: 32rpx;
    background: #fff;
    border-radius: 20rpx;
}

.pay-amount-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.pay-amount-label {
    color: #999;
    font-size: 26rpx;
}

.pay-status-badge {
    padding: 4rpx 16rpx;
    font-size: 22rpx;
    border-radius: 100rpx;
    background: #f0f0f0;
    color: #666;
}

.pay-status-badge.theme-success {
    background: var(--td-brand-color-light, #e8f8ee);
    color: var(--td-brand-color, #07C160);
}

.pay-status-badge.theme-pending {
    background: #FFF5E6;
    color: #FF9500;
}

.pay-amount {
    display: flex;
    align-items: baseline;
    margin: 12rpx 0 24rpx;
    color: #333;
}

.pay-amount-symbol {
    font-size: 32rpx;
    font-weight: bold;
    margin-right: 4rpx;
}

.pay-amount-num {
    font-size: 64rpx;
    font-weight: bold;
    line-height: 1.1;
}

.pay-info-list {
    border-top: 1rpx solid #f0f0f0;
    padding-top: 8rpx;
}

.pay-info-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 18rpx 0;
}

.pay-info-label {
    color: #999;
    font-size: 26rpx;
    flex-shrink: 0;
    margin-right: 24rpx;
}

.pay-info-value-wrap {
    display: flex;
    align-items: center;
    min-width: 0;
}

.pay-info-value {
    color: #333;
    font-size: 26rpx;
    text-align: right;
    word-break: break-all;
}

.action-btn {
    display: flex;
    align-items: center;
    margin: 0 24rpx 16rpx;
    padding: 28rpx 32rpx;
    background: #fff;
    border-radius: 16rpx;
    transition: transform .15s ease, opacity .15s ease;
}

.action-btn:active {
    transform: scale(.98);
    opacity: .85;
}

.action-btn.outline {
    gap: 16rpx;
}

.action-btn-text {
    flex: 1;
    font-size: 30rpx;
    color: #333;
}

.action-btn-tip {
    color: #999;
    font-size: 24rpx;
    margin-right: 8rpx;
}

.anim-up {
    animation: fade-up .45s ease both;
}

.delay-1 {
    animation-delay: .08s;
}

.delay-2 {
    animation-delay: .16s;
}

@keyframes fade-up {
    0% {
        transform: translateY(32rpx);
        opacity: 0;
    }
    100% {
        transform: translateY(0);
        opacity: 1;
    }
}
</style>
