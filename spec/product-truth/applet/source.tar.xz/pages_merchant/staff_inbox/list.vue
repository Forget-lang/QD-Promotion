<template>
    <view>
        <t-tabs v-model:value="tab" @change="onTabChange">
            <t-tab-panel :value="0" label="全部"/>
            <t-tab-panel :value="1" label="未读"/>
            <t-tab-panel :value="2" label="已读"/>
        </t-tabs>
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无消息</m-empty>
            <template v-else>
                <t-cell-group theme="card" t-class="mt-2">
                    <t-cell
                        v-for="item in items"
                        :key="item.id"
                        :arrow="true"
                        @click="push('/pages_merchant/staff_inbox/detail?id=' + item.id)"
                    >
                        <template #title>
                            <view class="staffinbox-row">
                                <text
                                    class="ellipsis"
                                    :class="item.isRead ? 'text-muted' : 'text-wechat'"
                                >{{ item.title }}
                                </text>
                            </view>
                        </template>
                        <template #description>
                            <view class="mt-1">
                                <text class="text-muted">{{ item.publisher }}</text>
                                <text class="text-muted ml-2">{{ item.messageType }}</text>
                                <text class="text-muted ml-2">{{ formatTime(item.createdAt) }}</text>
                            </view>
                        </template>
                    </t-cell>
                </t-cell-group>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import to from '@/hooks/to'

const {push} = useLink()
// 当前 Tab（0全部/1未读/2已读）
const tab = ref(0)
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    readStatus: 0
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

const formatTime = (t) => {
    if (!t) return ''
    return String(t).replace('T', ' ').slice(0, 16)
}

const onTabChange = (e) => {
    tab.value = e.detail?.value ?? e
    search.value.readStatus = Number(tab.value) || 0
    search.value.page = 1
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取消息列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/staff/inbox/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

onLoad(() => {
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
</style>
