<template>
    <m-loading v-if="item === undefined"></m-loading>
    <view class="article" v-else>
        <view class="article-title mb-4">{{ item.title }}</view>
        <view class="d-flex text-muted justify-content-center align-items-center top-line py-3">
            <view>{{ item.publisher }}</view>
            <view class="ml-2">{{ item.createdAt }}</view>
        </view>
        <view class="article-content" v-html="item.content"></view>
        <view v-if="attachmentImages.length > 0" class="article-attachments top-line pt-4">
            <view class="attachment-title mb-3">附件</view>
            <scroll-view scroll-x class="attachment-scroll">
                <view class="attachment-list">
                    <view
                        v-for="(image, index) in attachmentImages"
                        :key="image"
                        class="attachment-item"
                        @click="previewAttachment(index)"
                    >
                        <t-image
                            :src="image"
                            width="160rpx"
                            height="160rpx"
                            mode="aspectFill"
                            shape="round"
                            :lazy="true"
                        />
                    </view>
                </view>
            </scroll-view>
        </view>
        <view v-if="item.readAt" class="text-right text-muted top-line py-3">
            <view>已读于 {{ item.readAt }}</view>
        </view>
        <t-image-viewer
            v-model:visible="previewVisible"
            :images="attachmentImages"
            :initial-index="previewIndex"
            :show-index="true"
            :close-btn="true"
        />
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request.js'

const inboxId = ref()
const item = ref()
const previewVisible = ref(false)
const previewIndex = ref(0)

const attachmentImages = computed(() => {
    return normalizeAttachment(item.value?.attachment)
        .map(file => {
            if (typeof file === 'string') {
                return file
            }
            return file?.url || file?.Url || file?.path || file?.src || ''
        })
        .filter(Boolean)
})

const normalizeAttachment = (attachment) => {
    if (!attachment) {
        return []
    }
    if (Array.isArray(attachment)) {
        return attachment
    }
    if (typeof attachment === 'string') {
        const value = attachment.trim()
        if (value === '') {
            return []
        }
        try {
            const parsed = JSON.parse(value)
            return Array.isArray(parsed) ? parsed : [parsed]
        } catch (e) {
            return [value]
        }
    }
    return [attachment]
}

const previewAttachment = (index) => {
    previewIndex.value = index
    previewVisible.value = true
}

const getItem = () => {
    request.get('/seller/staff/inbox/one', {id: inboxId.value}).then(res => {
        item.value = res.data
        uni.setNavigationBarTitle({
            title: res.data.title
        })
    })
}

onLoad((e) => {
    console.log(e)
    inboxId.value = e.id
    getItem()
})
</script>

<style>
.article {
    background-color: #fff;
    padding: 40rpx;
    min-height: 100vh;
}

.article-title {
    font-size: 38rpx;
    color: #222;
    text-align: center;
    padding-top: 30rpx;
    font-weight: bold;
}

.article-content {
    overflow: auto;
    margin-top: 40rpx;
    color: #333;
    line-height: 46rpx;
    font-size: 30rpx;
}

.article-attachments {
    margin-top: 40rpx;
}

.attachment-title {
    color: #333;
    font-size: 30rpx;
    font-weight: 600;
}

.attachment-scroll {
    width: 100%;
    white-space: nowrap;
}

.attachment-list {
    display: inline-flex;
    gap: 20rpx;
    padding-bottom: 4rpx;
}

.attachment-item {
    width: 160rpx;
    height: 160rpx;
    flex: 0 0 160rpx;
    overflow: hidden;
}
</style>
