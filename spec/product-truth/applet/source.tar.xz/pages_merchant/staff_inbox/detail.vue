<template>
    <m-loading v-if="item === undefined"></m-loading>
    <view class="article" v-else>
        <view class="article-title mb-4">{{ item.title }}</view>
        <view class="d-flex text-muted justify-content-center align-items-center top-line py-3">
            <view>{{ item.publisher }}</view>
            <view class="ml-2">{{ item.createdAt }}</view>
        </view>
        <view class="article-content" v-html="contentHtml"></view>
        <view v-if="attachmentImages.length > 0" class="article-attachments top-line pt-4">
            <view class="attachment-title mb-3">附件</view>
            <scroll-view scroll-x class="attachment-scroll">
                <view class="attachment-list">
                    <view
                        v-for="(image, index) in attachmentImages"
                        :key="image"
                        class="attachment-item"
                        @click="previewAttachment(index)"
                    >
                        <t-image
                            :src="image"
                            width="160rpx"
                            height="160rpx"
                            mode="aspectFill"
                            shape="round"
                            :lazy="true"
                        />
                    </view>
                </view>
            </scroll-view>
        </view>
        <view v-if="item.readAt" class="text-right text-muted top-line py-3">
            <view>已读于 {{ item.readAt }}</view>
        </view>
        <t-image-viewer
            v-model:visible="previewVisible"
            :images="attachmentImages"
            :initial-index="previewIndex"
            :show-index="true"
            :close-btn="true"
        />
    </view>
    <m-submit @click="goMerchantCenter">返回商户中心</m-submit>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request.js'
import {useLink} from '@/hooks/useLink.js'

const {switchTab} = useLink()

const inboxId = ref()
const item = ref()
const previewVisible = ref(false)
const previewIndex = ref(0)

const contentHtml = computed(() => {
    const html = item.value?.content
    if (!html) {
        return ''
    }
    // 小程序 rich-text 吃不到外层 CSS，给 img 直接写死最大宽度
    return html.replace(/<img\b([^>]*)\/?>/gi, (full, attrs) => {
        let next = String(attrs || '')
            .replace(/\s*style\s*=\s*("[^"]*"|'[^']*')/gi, '')
            .replace(/\s*width\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
            .replace(/\s*height\s*=\s*("[^"]*"|'[^']*'|[^\s>]+)/gi, '')
        return `<img${next} style="max-width:100%;height:auto;display:block;" />`
    })
})

const attachmentImages = computed(() => {
    return normalizeAttachment(item.value?.attachment)
        .map(file => {
            if (typeof file === 'string') {
                return file
            }
            return file?.url || file?.Url || file?.path || file?.src || ''
        })
        .filter(Boolean)
})

const normalizeAttachment = (attachment) => {
    if (!attachment) {
        return []
    }
    if (Array.isArray(attachment)) {
        return attachment
    }
    if (typeof attachment === 'string') {
        const value = attachment.trim()
        if (value === '') {
            return []
        }
        try {
            const parsed = JSON.parse(value)
            return Array.isArray(parsed) ? parsed : [parsed]
        } catch (e) {
            return [value]
        }
    }
    return [attachment]
}

const previewAttachment = (index) => {
    previewIndex.value = index
    previewVisible.value = true
}

const getItem = () => {
    request.get('/seller/staff/inbox/one', {id: inboxId.value}).then(res => {
        item.value = res.data
        uni.setNavigationBarTitle({
            title: res.data.title
        })
    })
}

// 返回商户中心（Tab 页需用 switchTab 跳转）
const goMerchantCenter = () => {
    switchTab('/pages/merchant/index')
}

onLoad((e) => {
    console.log(e)
    inboxId.value = e.id
    getItem()
})
</script>

<style>
/*
 * 自定义样式原因：app.css / m-submit 不提供「文章详情页底部固定跳转按钮」能力（m-submit 为表单提交场景）。
 * 替代方案：fixed 底栏 + 安全区适配，内容区加 padding-bottom 防遮挡；按钮用 t-button 自动跟随品牌主题色。
 */
.article {
    background-color: #fff;
    padding: 40rpx;
    padding-bottom: calc(180rpx + env(safe-area-inset-bottom));
    min-height: 100vh;
    box-sizing: border-box;
}

.article-title {
    font-size: 38rpx;
    color: #222;
    text-align: center;
    padding-top: 30rpx;
    font-weight: bold;
}

.article-content {
    overflow: auto;
    margin-top: 40rpx;
    color: #333;
    line-height: 46rpx;
    font-size: 30rpx;
}

.article-content img,
.article-content rich-text img {
    max-width: 100% !important;
    height: auto !important;
    display: block;
}

.article-attachments {
    margin-top: 40rpx;
}

.attachment-title {
    color: #333;
    font-size: 30rpx;
    font-weight: 600;
}

.attachment-scroll {
    width: 100%;
    white-space: nowrap;
}

.attachment-list {
    display: inline-flex;
    gap: 20rpx;
    padding-bottom: 4rpx;
}

.attachment-item {
    width: 160rpx;
    height: 160rpx;
    flex: 0 0 160rpx;
    overflow: hidden;
}
</style>
