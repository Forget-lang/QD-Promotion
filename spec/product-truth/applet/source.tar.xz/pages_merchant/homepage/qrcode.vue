<template>
    <m-loading v-if="qrcode === undefined"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <view class="tips-card mt-2">
                <text class="tips-title">使用说明</text>
                <view class="tips-item">
                    <text class="tips-text">保存商家码，顾客使用微信扫一扫即可打开本店主页领券</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">可打印在海报、台卡、宣传单等物料上使用</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">支持线下张贴，也可在图文消息中发送</text>
                </view>
            </view>

            <view class="section section-body mt-2">
                <view class="qrcode-image-container">
                    <image class="qrcode-image" :src="qrcode" mode="widthFix" v-if="qrcode"></image>
                    <m-loading v-else/>
                </view>
            </view>
        </view>
        <m-submit @click="downloadImage(qrcode)">下载商家码</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {downloadImage} from '@/hooks/useFile'
import utils from '@/utils/utils'

const qrcode = ref()

onLoad(() => {
    request.get('/seller/merchant/home/qrcode').then((res) => {
        qrcode.value = res.data.qrcode
    }).catch((err) => {
        qrcode.value = ''
        utils.toast(err.message)
    })
})
</script>

<style scoped>
.qrcode-image-container {
    text-align: center;
    min-height: 440rpx;
}

.qrcode-image {
    width: 100%;
    max-width: 400rpx;
    border-radius: 8rpx;
    margin: 20rpx auto;
}
</style>
