<template>
    <view>
        <m-loading v-if="items === undefined"></m-loading>
        <template v-else>
            <view class="container mt-2" v-if="items.length > 0">
                <view class="swipe-hint alert-info">
                    <t-icon name="info-circle-filled" size="32rpx"/>
                    <text>左滑优惠券可将其移出领券中心，取消向顾客展示；优惠券本身不受影响，可随时重新添加。</text>
                </view>
            </view>
            <view class="pt-2">
                <t-cell-group theme="card" v-if="items.length > 0">
                    <t-swipe-cell v-for="item in items" :key="item.id">
                        <t-cell
                            :title="item.name"
                            :note="item.couponTypeLabel"
                            arrow
                            hover
                            @click="push('/pages_coupon/coupon/detail?couponId=' + item.couponId)"
                        ></t-cell>
                        <template #right>
                            <view class="swipe-delete" @click.stop="onRemove(item)">删除</view>
                        </template>
                    </t-swipe-cell>
                </t-cell-group>
                <m-empty v-else>还没有添加到主页的优惠券</m-empty>
            </view>
            <m-submit :disabled="adding" @click="onOpenAdd">添加优惠券</m-submit>
        </template>

        <t-popup v-model:visible="showAdd" placement="bottom">
            <view class="popup-container pb-3">
                <view class="popup-header">
                    <view class="popup-header-cancel" @click="showAdd = false">取消</view>
                    <view class="popup-header-title">添加公开券</view>
                    <view class="popup-header-confirm" @click="onConfirmAdd">确定</view>
                </view>
                <view class="popup-tip">仅可添加公开领取优惠券，最多 {{ limit }} 张，还可添加 {{ remain }} 张</view>
                <scroll-view class="popup-body" scroll-y>
                    <t-checkbox-group v-if="selectable.length > 0" v-model:value="selectedIds">
                        <t-checkbox
                            v-for="item in selectable"
                            :key="item.id"
                            :value="item.id"
                            :label="item.name + ' · ' + item.couponTypeLabel"
                            placement="right"
                        />
                    </t-checkbox-group>
                    <m-empty v-else-if="selectableLoaded">暂无可添加的公开券</m-empty>
                    <m-loading v-else></m-loading>
                </scroll-view>
            </view>
        </t-popup>

        <!-- VIP 升级抽屉：承接添加接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import {EDITION_FEATURES, getFeatureQuota, getQuotaOverflow} from '@/constants/edition'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import {useVipGuard} from '@/hooks/useVipGuard'
import to from '@/hooks/to'
import utils from '@/utils/utils'

const {push} = useLink()
const {getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()

const items = ref()
const showAdd = ref(false)
const selectable = ref([])
const selectableLoaded = ref(false)
const selectedIds = ref([])
const adding = ref(false)

// 领券中心数量上限：按当前版本档位取值（免费 3 / 标准 10 / 专业 30 / 企业 100）
const limit = computed(() => getFeatureQuota(EDITION_FEATURES.HOME_COUPON, staffSession.value?.editionId))
// 还可添加张数
const remain = computed(() => Math.max(0, limit.value - to.Array(items.value).length))

const loadList = () => {
    request.get('/seller/merchant/home/coupon/list').then((res) => {
        items.value = to.Array(res.data.items)
    }).catch((err) => {
        items.value = []
        utils.toast(err.message)
    })
}

const loadSelectable = () => {
    selectableLoaded.value = false
    selectable.value = []
    request.get('/seller/merchant/home/coupon/selectable').then((res) => {
        selectable.value = to.Array(res.data.items)
    }).catch((err) => {
        selectable.value = []
        utils.toast(err.message)
    }).finally(() => {
        selectableLoaded.value = true
    })
}

// 点击添加优惠券：达到当前版本档位上限时走统一受限提醒（升级抽屉预选目标版本）
const onOpenAdd = () => {
    const overflow = getQuotaOverflow(EDITION_FEATURES.HOME_COUPON, staffSession.value?.editionId, to.Array(items.value).length)
    if (overflow) {
        check(overflow)
        return
    }
    selectedIds.value = []
    showAdd.value = true
    loadSelectable()
}

const onConfirmAdd = () => {
    const couponIds = to.Array(selectedIds.value)
    if (couponIds.length === 0) {
        utils.toast('请选择优惠券')
        return
    }
    if (couponIds.length > remain.value) {
        utils.toast('最多再添加' + remain.value + '张')
        return
    }
    adding.value = true
    request.post('/seller/merchant/home/coupon/create', {couponIds}).then(() => {
        showAdd.value = false
        loadList()
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        adding.value = false
    })
}

// 移除优惠券（从领券中心取消展示，不删除优惠券本身）
const onRemove = (item) => {
    uni.showModal({
        title: '移除优惠券',
        content: '从领券中心移除，不会删除优惠券本身',
        confirmColor: '#e34d59',
        success: (res) => {
            if (!res.confirm) return
            request.post('/seller/merchant/home/coupon/delete', {id: item.id}).then(() => {
                loadList()
            }).catch((err) => {
                utils.toast(err.message)
            })
        },
    })
}

// 每次进入页面刷新列表与员工会话，保证档位预检用的版本数据最新
onShow(() => {
    loadList()
    getSession()
})
</script>

<style scoped>
/*
 * 自定义样式原因：全局 .alert-info 只有纯文字形态，这里需要「图标 + 文案」横排布局。
 * 替代方案：复用 alert-info 配色边框，仅补充 flex 排版与图标间距。
 */
.swipe-hint {
    display: flex;
    align-items: center;
    gap: 12rpx;
    line-height: 1.6;
}

.swipe-hint text {
    flex: 1;
}

/* 左滑删除按钮：满高红底，样式对齐 pages_point/type/index 的同款交互 */
.swipe-delete {
    height: 100%;
    padding: 0 32rpx;
    background-color: #e34d59;
    color: #fff;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 28rpx;
    box-sizing: border-box;
}

.popup-tip {
    padding: 16rpx 32rpx 0;
    font-size: 24rpx;
    color: #999;
    line-height: 1.5;
}

.popup-body {
    max-height: 60vh;
    padding: 16rpx 32rpx 0;
    box-sizing: border-box;
}
</style>
