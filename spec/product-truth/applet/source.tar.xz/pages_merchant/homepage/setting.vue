<template>
    <m-loading v-if="loaded === undefined"></m-loading>
    <template v-else>
        <template v-if="showSuccess">
            <m-result title="设置成功" description="主页设置已保存" back></m-result>
        </template>
        <template v-else>
            <view class="container-safety">
                <t-cell-group t-class="mt-2" theme="card" :bordered="false">
                    <t-input
                        label="分享标题"
                        v-model:value="homeShareTitle"
                        align="right"
                        placeholder="选填，最多32个字"
                        :maxlength="32"
                    ></t-input>
                </t-cell-group>
                <view class="text-muted px-3 mt-2">
                    顾客转发商家主页时显示这行标题。不填则用店名。
                </view>
                <view class="mt-2">
                    <m-theme-select v-model:value="homeTheme"/>
                </view>
            </view>
            <m-submit :loading="loading" :disabled="loading" @click="onSubmit">保存</m-submit>
        </template>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {defaultHomeTheme} from '@/utils/homeTheme'

const loaded = ref()
const loading = ref(false)
const showSuccess = ref(false)
const homeShareTitle = ref('')
const homeTheme = ref(defaultHomeTheme)

const onSubmit = () => {
    loading.value = true
    request.post('/seller/merchant/home/setting/update', {
        homeShareTitle: homeShareTitle.value,
        homeTheme: homeTheme.value,
    }).then(() => {
        showSuccess.value = true
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

onLoad(() => {
    request.get('/seller/merchant/home/setting').then((res) => {
        homeShareTitle.value = res.data.homeShareTitle || ''
        homeTheme.value = Number(res.data.homeTheme) || defaultHomeTheme
        loaded.value = true
    }).catch((err) => {
        loaded.value = true
        utils.toast(err.message)
    })
})
</script>
