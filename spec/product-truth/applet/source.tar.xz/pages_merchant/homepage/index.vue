<template>
    <view class="pb-4">
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell arrow title="主页设置" url="/pages_merchant/homepage/setting"></t-cell>
            <t-cell arrow title="门头设置" url="/pages_merchant/setting/cover"></t-cell>
            <t-cell arrow title="领券中心" url="/pages_merchant/homepage/coupon"></t-cell>
        </t-cell-group>
        <t-cell-group title="推广" t-title-class="mt-2" theme="card">
            <t-cell arrow title="下载商家码" url="/pages_merchant/homepage/qrcode"></t-cell>
        </t-cell-group>
        <m-submit @click="onPreview">预览商家主页</m-submit>
    </view>
</template>

<script setup>
import {useLink} from '@/hooks/useLink.js'
import request from '@/hooks/request'
import utils from '@/utils/utils'

const {push} = useLink()

// 预览顾客端商家主页（本地缓存的 merchantId 是令牌，须用接口返回的真实商户 ID）
const onPreview = () => {
    request.get('/seller/merchant').then((res) => {
        if (!res.data.id) {
            utils.toast('商家信息不存在')
            return
        }
        push('/pages_user/merchant/home?id=' + String(res.data.id))
    })
}
</script>
