// 优惠券域枚举：取值语义以 server 端定义为唯一事实来源
// 展示文案一律使用后端返回的 *Label 字段直出，禁止在此建 label→文案映射

// 优惠券类型（couponType）
export const COUPON_TYPE = Object.freeze({
    CASH: 1, // 代金券
    PACKAGE: 2, // 套餐券
    REDUCE: 3, // 满减券
    DISCOUNT: 4, // 折扣券
    EXCHANGE: 5, // 兑换券
    RANDOM: 6, // 随机金额券
})

// 券面是否为金额型展示（代金/套餐/满减/随机显金额，折扣显折数，兑换显图标）
// 替代散落各页的 couponType < 4 || couponType === 6 写法
export const isAmountFace = (type) => {
    return type === COUPON_TYPE.CASH
        || type === COUPON_TYPE.PACKAGE
        || type === COUPON_TYPE.REDUCE
        || type === COUPON_TYPE.RANDOM
}

// 优惠券状态（商家侧 status，对齐 server CouponStatus，仅 1-5）
export const COUPON_STATUS = Object.freeze({
    ISSUING: 1, // 有效中/发放中（可暂停）
    PAUSED: 2, // 已暂停（可恢复）
    DISCARDED: 3, // 已作废
    EXPIRED: 4, // 已过期
    FROZEN: 5, // 已冻结
})

// 是否为冻结态（冻结中的优惠券不可删除）
export const isCouponFrozen = (status) => {
    return status === COUPON_STATUS.FROZEN
}

// 用户领取记录状态（receiveStatus，对应用户端 Tab 与券面印戳）
export const RECEIVE_STATUS = Object.freeze({
    UNUSED: 1, // 未使用
    USED: 2, // 已使用
    DISCARDED: 3, // 已作废
    EXPIRED: 4, // 已过期
})

// 优惠券发放方式（issueType，对齐 server IssueType）
export const ISSUE_TYPE = Object.freeze({
    PUBLIC: 1, // 公开领取
    PRIVATE: 2, // 私密发放
    BUNDLE: 3, // 券包（随券包发放）
    POINTS: 4, // 积分兑换（前端占位，服务端尚未开放）
})

// 优惠券有效期类型（validType，对齐 server CouponValidType）
export const VALID_TYPE = Object.freeze({
    CUSTOM: 1, // 指定有效期内有效
    TODAY: 2, // 领券当日起有效
    NEXT_DAY: 3, // 领券次日起有效
})

// 私密发放记录状态（issue.status，对齐 server CouponIssuePrivateStatus）
export const ISSUE_PRIVATE_STATUS = Object.freeze({
    VALID: 1, // 待领取
    RECEIVED: 2, // 已领取
    EXPIRED: 3, // 已过期
    DISCARDED: 4, // 已作废
})

// 发券员工状态（发放员工记录 status，对齐 server CouponStaffStatus；后端仅定义未做相关业务逻辑）
export const ISSUE_STAFF_STATUS = Object.freeze({
    VALID: 1, // 正常
    STOP: 2, // 停止
})

// 核销/转赠奖励发放状态（对齐 server CouponVerifyRewardStatus；无奖励时不看本字段）
export const VERIFY_REWARD_STATUS = Object.freeze({
    DEFAULT: 0, // 默认值（非业务态）
    SUCCESS: 1, // 奖励成功
    FAILED: 2, // 奖励失败
    COMPENSATE: 3, // 待补偿
})

// 转赠记录状态（transferStatus）
export const TRANSFER_STATUS = Object.freeze({
    TRANSFERRING: 1, // 转赠中（可取消）
    CANCELED: 2, // 已取消
    RECEIVED: 3, // 已领取
})

// 领取口令类型（cipherType，对齐 server CipherType）
export const CIPHER_TYPE = Object.freeze({
    OFF: 0,
    FIXED: 1,
    RANDOM: 2,
})
