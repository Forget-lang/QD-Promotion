/** 会员等级预设图标与色板（与后端 model/member_level.go 保持一致） */
export const MEMBER_LEVEL_ICONS = [
    {key: 'crown', tdName: 'user-vip-filled', label: 'VIP'},
    {key: 'star', tdName: 'star-filled', label: '星星'},
    {key: 'diamond', tdName: 'cardmembership-filled', label: '会员'},
    {key: 'medal', tdName: 'certificate-filled', label: '勋章'},
    {key: 'flower', tdName: 'heart-filled', label: '爱心'},
    {key: 'fire', tdName: 'rocket-filled', label: '火箭'},
]

/**
 * 预设色：color 存库/选色；fg/bg 徽章展示写死，保证对比度。
 * 黄金示例对齐效果图：#795228 / #f8dda8
 */
export const MEMBER_LEVEL_COLOR_PRESETS = [
    {color: '#63b359', fg: '#2f6b2c', bg: '#d8efd5'},
    {color: '#2c9f67', fg: '#1a5c3d', bg: '#cfeadf'},
    {color: '#509fc9', fg: '#1f5f7a', bg: '#d2e9f4'},
    {color: '#5885cf', fg: '#2a4a8a', bg: '#d5e0f6'},
    {color: '#9062c0', fg: '#5a3480', bg: '#e8daf3'},
    {color: '#d09a45', fg: '#795228', bg: '#f8dda8'},
    {color: '#e4b138', fg: '#7a5c12', bg: '#f7ebb0'},
    {color: '#ee903c', fg: '#8a4a14', bg: '#f8dfc4'},
    {color: '#dd6549', fg: '#8a3020', bg: '#f5d4cc'},
    {color: '#cc463d', fg: '#7a221c', bg: '#f2d0cd'},
    {color: '#333333', fg: '#333333', bg: '#e8e8e8'},
]

/** 选色圆点 / 后端校验用的色值列表 */
export const MEMBER_LEVEL_COLORS = MEMBER_LEVEL_COLOR_PRESETS.map((item) => item.color)

export const MEMBER_LEVEL_MAX = 5
export const MEMBER_LEVEL_NAME_MAX = 6

const memberLevelColorPresetMap = Object.fromEntries(
    MEMBER_LEVEL_COLOR_PRESETS.map((item) => [item.color.toLowerCase(), item]),
)

/** 业务 key → TDesign 图标名 */
export function getMemberLevelTdIcon(iconKey) {
    const hit = MEMBER_LEVEL_ICONS.find((item) => item.key === iconKey)
    return hit ? hit.tdName : MEMBER_LEVEL_ICONS[0].tdName
}

/** 按存库 color 匹配徽章前景色 / 底色 */
export function getMemberLevelBadgeColors(color) {
    const key = String(color || '').trim().toLowerCase()
    const hit = memberLevelColorPresetMap[key]
    if (hit) {
        return {fg: hit.fg, bg: hit.bg}
    }
    // 兜底：黄金会员效果图
    return {fg: '#795228', bg: '#f8dda8'}
}
