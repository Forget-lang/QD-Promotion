/** 打开 VIP 升级抽屉（当前页挂载的 m-vip-upgrade 监听；App.vue 不能挂视图） */
export const VIP_UPGRADE_OPEN = 'vip-upgrade-open'
/** 关闭 VIP 升级抽屉 */
export const VIP_UPGRADE_CLOSE = 'vip-upgrade-close'
/** VIP 支付成功通知 */
export const VIP_UPGRADE_SUCCESS = 'vip-upgrade-success'
