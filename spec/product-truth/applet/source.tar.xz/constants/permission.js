// 权限别名清单：供 checkPermission(alias) 引用，消除裸字符串 typo 风险
// 来源：docs/功能模块与权限清单.md + 代码实测并集；新代码强制引用，旧代码随迭代替换
// 模块级别名用于商户中心入口显隐，操作级别名用于页面内按钮显隐

// 模块级入口权限
export const PERM_MODULE = Object.freeze({
    MERCHANT: 'Merchant', // 商户管理
    STORE: 'Store', // 门店管理
    STAFF: 'Staff', // 员工管理
    COUPON: 'Coupon', // 优惠券管理
    BUNDLE: 'Bundle', // 券包管理
    CARD: 'Card', // 次卡管理
    POINT: 'Point', // 积分管理
    CUSTOMER: 'Customer', // 客户管理
    ACTIVITY_POSTER: 'ActivityPoster', // 活动海报
})

// 优惠券操作权限
export const PERM_COUPON = Object.freeze({
    VIEW: 'CouponView', // 查看优惠券
    CREATE: 'CouponCreate', // 创建优惠券
    UPDATE: 'CouponUpdate', // 修改优惠券
    DELETE: 'CouponDelete', // 删除优惠券
    ISSUE: 'CouponIssue', // 发放优惠券
    VERIFY: 'CouponVerify', // 核销优惠券
    VERIFY_LIST: 'CouponVerifyList', // 核销记录
    RECEIVE_LIST: 'CouponReceiveList', // 领取记录
    DISCARD_LIST: 'CouponDiscardList', // 作废记录
    DISCARD: 'CouponDiscard', // 作废优惠券（卡券模板）
    RECEIVE_DISCARD: 'CouponReceiveDiscard', // 作废已领取的优惠券
    EXPORT: 'CouponExport', // 导出优惠券
    STAT: 'CouponStat', // 数据统计
    // STAT_STORE_OVERVIEW: 'CouponStatStoreOverview', // 门店概览统计
    STAT_STAFF_OVERVIEW: 'CouponStatStaffOverview', // 我的个人业绩
    STAT_STORE_RANK: 'CouponStatStoreRank', // 门店排行统计
    STAT_STAFF_RANK: 'CouponStatStaffRank', // 员工排行统计
    STAT_CHANNEL_RANK: 'CouponStatChannelRank', // 发放渠道排行统计
    STAT_USER_TRANSFER: 'CouponStatUserTransfer', // 用户转赠统计
    STAT_USER_VERIFY: 'CouponStatUserVerify', // 用户核销统计
})

// 次卡操作权限
export const PERM_CARD = Object.freeze({
    CREATE: 'CardCreate', // 创建次卡
    UPDATE: 'CardUpdate', // 修改次卡
    ISSUE: 'CardIssue', // 发放次卡
    VERIFY: 'CardVerify', // 核销次卡
    VERIFY_LIST: 'CardVerifyList', // 核销记录
    RECEIVE_LIST: 'CardReceiveList', // 领取记录
    DISCARD: 'CardDiscard', // 作废次卡（次卡模板）
    RECEIVE_DISCARD: 'CardReceiveDiscard', // 作废已领取的次卡
    DELETE: 'CardDelete', // 删除次卡
    EXPORT: 'CardExport', // 导出次卡
    STAT: 'CardStat', // 数据统计
    STAT_STAFF_RANK: 'CardStatStaffRank', // 员工排行统计
    STAT_STORE_RANK: 'CardStatStoreRank', // 门店排行统计
    STAT_CHANNEL_RANK: 'CardStatChannelRank', // 发放渠道排行统计
    STAT_USER_TRANSFER: 'CardStatUserTransfer', // 用户转赠统计
    STAT_USER_VERIFY: 'CardStatUserVerify', // 用户核销统计
})

// 积分操作权限
export const PERM_POINT = Object.freeze({
    TYPE: 'PointType',
    STAFF: 'PointStaff',
    LOG: 'PointLog',
    STAT: 'PointStat',
    CHANGE: 'PointChange',
})

// 券包操作权限
export const PERM_BUNDLE = Object.freeze({
    CREATE: 'BundleCreate', // 创建券包
    UPDATE: 'BundleUpdate', // 修改券包
    DELETE: 'BundleDelete', // 删除券包
    ISSUE: 'BundleIssue', // 发放券包
    DISCARD: 'BundleDiscard', // 作废券包（券包模板）
    RECEIVE_DISCARD: 'BundleReceiveDiscard', // 作废已领取券包内的优惠券
    RECEIVE_LIST: 'BundleReceiveList', // 领取记录
    STAT: 'BundleStat', // 数据统计
    EXPORT: 'BundleExport', // 导出券包
    STAT_STAFF_RANK: 'BundleStatStaffRank', // 员工排行统计
    STAT_STORE_RANK: 'BundleStatStoreRank', // 门店排行统计
    STAT_CHANNEL_RANK: 'BundleStatChannelRank', // 发放渠道统计
})

// 门店操作权限
export const PERM_STORE = Object.freeze({
    VIEW: 'StoreView', // 查看门店
    CREATE: 'StoreCreate', // 创建门店
    UPDATE: 'StoreUpdate', // 修改门店
    DELETE: 'StoreDelete', // 删除门店
})

// 员工操作权限
export const PERM_STAFF = Object.freeze({
    VIEW: 'StaffView', // 查看员工
    CREATE: 'StaffCreate', // 添加员工
    UPDATE: 'StaffUpdate', // 修改员工
    DELETE: 'StaffDelete', // 删除员工
})

// 商户操作权限
export const PERM_MERCHANT = Object.freeze({
    SETTING: 'MerchantSetting', // 商户设置
    CANCEL: 'MerchantCancel', // 注销商户
    UPGRADE: 'MerchantUpgrade', // 版本升级支付（仅创建人、品牌管理员）
})

// 客户操作权限
export const PERM_CUSTOMER = Object.freeze({
    DETAIL: 'CustomerDetail', // 客户详情
    UPDATE: 'CustomerUpdate', // 修改客户
    EXPORT: 'CustomerExport', // 导出客户
    MASS: 'CustomerMass', // 群发优惠券
})

// 活动海报操作权限
export const PERM_ACTIVITY = Object.freeze({
    POSTER_CREATE: 'ActivityPosterCreate', // 创建海报
    POSTER_UPDATE: 'ActivityPosterUpdate', // 修改海报
    POSTER_DELETE: 'ActivityPosterDelete', // 删除海报
})

// 企业微信操作权限
export const PERM_WECOM = Object.freeze({
    CORP_CONFIG: 'CorpConfig', // 企微主体配置
})
