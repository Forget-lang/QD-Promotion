// 商品（可发放物）类型枚举：取值语义以 server 端定义为唯一事实来源
// 企微加好友发券 / 群发等场景共用，按类型调用对应 detail 接口

export const PRODUCT_TYPE = Object.freeze({
    COUPON: 1, // 优惠券
    BUNDLE: 2, // 券包
    CARD: 3, // 次卡
})
