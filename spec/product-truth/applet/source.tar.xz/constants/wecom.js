// 企业微信域枚举：取值语义以 server 端定义为唯一事实来源

// 企微主体授权状态（corp.status，对齐 server WecomCorpStatus）
export const CORP_STATUS = Object.freeze({
    UNAUTHORIZED: 0, // 未授权
    AUTHORIZED: 1, // 已授权
    UNBOUND: 2, // 已解绑
})
