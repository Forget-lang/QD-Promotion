// 后端统一响应业务码：与 server 统一响应格式一致
// 注意：1000/1001/1009 的处理逻辑只允许出现在 hooks/request.js
export const RESPONSE_CODE = Object.freeze({
    SUCCESS: 0, // 请求成功
    TOKEN_EXPIRED: 1000, // 用户 token 过期，登出并回到卡包首页
    STAFF_EXIT: 1001, // 员工须退出门店，回到商户中心
    NEED_AUTH: 1009, // 商户未认证，前往商家认证页
    RESOURCE_DELETED: 2000, // 资源已被删除（券/券包/领取记录等详情不存在）
    EDITION_UPGRADE: 2006, // 当前版本不支持此功能，需升级版本
})
