// 通用常量：分页、品牌色、推荐跳转类型等跨域共用取值

// 列表分页默认每页条数
export const PAGE_SIZE_DEFAULT = 20

// 下拉选择类接口每页条数（如发券选员工）
export const PAGE_SIZE_SELECT = 100

// 推荐位跳转类型（recommendType，utils.js openPosition）
export const RECOMMEND_TYPE = Object.freeze({
    VIDEO_CHANNEL: 2, // 视频号
    OFFICIAL_ACCOUNT: 3, // 公众号链接
    MINI_PROGRAM_PAGE: 4, // 小程序内页
})

// 推荐位固定 ID（接口 /position 的 id 参，后台配置的推荐位固定标识）
export const POSITION_ID = Object.freeze({
    MERCHANT_HOME: 9, // 商户中心首页推荐位
    WECOM_BIND: 10, // 企微绑定页推荐位
    MERCHANT_CENTER: 11, // 进入商户中心推荐位-获客教程
    HELP_HOT: '2037870075771359232', // 使用帮助——热门问题
    HELP_CATEGORY: '203787007577135924', // 使用帮助——问题分类
})

// 发放渠道类型（channelType，对齐 server ChannelType；券/包/卡三域发放与领取记录共用）
export const CHANNEL_TYPE = Object.freeze({
    PUBLIC_WECHAT: 1, // 公开——微信好友/群
    PUBLIC_QRCODE: 2, // 公开——二维码
    PUBLIC_POSTER: 3, // 公开——海报
    PUBLIC_OFFICIAL: 4, // 公开——公众号
    PUBLIC_LINK: 5, // 公开——小程序链接
    ACTIVITY_POSTER: 6, // 活动海报
    MERCHANT_HOME: 7, // 商家主页领券中心
    PRIVATE_WECHAT: 11, // 私密——微信好友/群
    PRIVATE_QRCODE: 12, // 私密——二维码
    PRIVATE_LINK: 15, // 私密——小程序链接
    TRANSFER_REWARD: 21, // 转赠奖励
    VERIFY_REWARD: 22, // 核销奖励
    STORE_CARD: 23, // 商家名片
    WECOM_EXTERNAL_CONTACT: 31, // 企微好友（员工加好友发券）
    WECOM_GROUP_JOIN: 32, // 企微进群
    WECOM_BATCH: 33, // 企微客户群发
    WECOM_BOT: 34, // 企微小助理
    COUPON_MASS: 41, // 客户群发
})
