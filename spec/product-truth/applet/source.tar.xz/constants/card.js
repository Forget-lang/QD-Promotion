// 次卡域枚举：取值语义以 server 端定义为唯一事实来源
// 与券/券包状态不跨域合并，宁可形似重复

// 次卡类型（cardType，对齐 server CardType）
export const CARD_TYPE = Object.freeze({
    UNLIMITED: 1, // 通卡：有效期内不限次数
    TIMES: 2, // 次卡：按次数核销
    BENEFIT: 3, // 权益卡：逐项权益核销
})

// 次卡状态（status）
export const CARD_STATUS = Object.freeze({
    ISSUING: 1, // 发放中（可暂停）
    PAUSED: 2, // 已暂停（可恢复）
    DISCARDED: 3, // 已作废
    EXPIRED: 4, // 已过期
})

// 次卡审核状态（auditStatus）
export const CARD_AUDIT_STATUS = Object.freeze({
    PASSED: 2, // 审核通过
})

// 次卡领取记录状态（C 端 status，对齐 server CardReceiveStatus）
export const RECEIVE_STATUS = Object.freeze({
    VALID: 1, // 使用中（尚有剩余次数）
    USED: 2, // 已用完
    DISCARDED: 3, // 已作废
    EXPIRED: 4, // 已过期
})

// 次卡核销记录状态（status，对齐 server CardVerifyStatus）
export const VERIFY_STATUS = Object.freeze({
    SUCCESS: 1, // 已核销
    DISCARD: 2, // 已作废
})

// 次卡有效期类型（validType，对齐 server CardValidType）
export const VALID_TYPE = Object.freeze({
    CUSTOM: 1, // 指定有效期内有效
    TODAY: 2, // 领取当日起有效
    NEXT_DAY: 3, // 领取次日起有效
})

// 次卡权益项类型（benefitType，对齐 server CardBenefitType）
export const BENEFIT_TYPE = Object.freeze({
    AMOUNT: 1, // 金额
    DISCOUNT: 2, // 折扣
    SERVICE: 3, // 服务
})

// 私密发放记录状态（issue.status，对齐 server CardIssuePrivateStatus）
export const ISSUE_PRIVATE_STATUS = Object.freeze({
    VALID: 1, // 待领取
    RECEIVED: 2, // 已领取
    EXPIRED: 3, // 已过期
    DISCARDED: 4, // 已作废
})

// 发券员工状态（发放员工记录 status，对齐 server CardStaffStatus；后端仅定义未做相关业务逻辑）
export const ISSUE_STAFF_STATUS = Object.freeze({
    VALID: 1, // 正常可发
    STOP: 2, // 停止
})
