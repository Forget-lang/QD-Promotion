export const EDITION_ID_FREE = '1' // 免费版 ID
export const EDITION_ID_STANDARD = '2' // 标准版 ID
export const EDITION_ID_PROFESSIONAL = '3' // 专业版 ID
export const EDITION_ID_ENTERPRISE = '4' // 企业版 ID

// 判断当前版本是否不低于所需版本（版本 ID 按免费→标准→专业→企业递增，取值以服务端为准）
export const hasEdition = (currentId, requiredId) => {
    return Number(currentId || 0) >= Number(requiredId || 0)
}

// 版本 ID → 版本名（用于受限提示文案拼装 / 角标文案）
export const EDITION_NAMES = Object.freeze({
    [EDITION_ID_STANDARD]: '标准版',
    [EDITION_ID_PROFESSIONAL]: '专业版',
    [EDITION_ID_ENTERPRISE]: '企业版',
})

// 版本 ID → 角标色 class（标准蓝 / 专业橙 / 企业紫，与 app.css .edition-badge-* 一致）
export const EDITION_BADGE_CLASS = Object.freeze({
    [EDITION_ID_STANDARD]: 'edition-badge-blue',
    [EDITION_ID_PROFESSIONAL]: 'edition-badge-orange',
    [EDITION_ID_ENTERPRISE]: 'edition-badge-purple',
})

// 版本 ID → 版本主题（tone 为视觉色名 blue/orange/purple，用于拼主题 class；color/bg/border 与 App.vue 的 --edition-* 变量一一对应，改色需两处同步；light 仅升级弹窗使用，不入全局变量）
export const EDITION_THEME = Object.freeze({
    [EDITION_ID_FREE]: Object.freeze({key: 'free', tone: '', color: '#07C160', bg: '#e8f8ee', border: '#BCE6CD', light: '#F2FAF5'}),
    [EDITION_ID_STANDARD]: Object.freeze({key: 'standard', tone: 'blue', color: '#007AFF', bg: '#E6F2FF', border: '#B8D5FF', light: '#E9F3FF'}),
    [EDITION_ID_PROFESSIONAL]: Object.freeze({key: 'professional', tone: 'orange', color: '#FF9500', bg: '#FFF5E6', border: '#FFD9A8', light: '#FFF6E9'}),
    [EDITION_ID_ENTERPRISE]: Object.freeze({key: 'enterprise', tone: 'purple', color: '#7B61FF', bg: '#F0EBFF', border: '#D4C9FF', light: '#F1ECFF'}),
})

// 默认主题（版本未知时回落免费版品牌绿）
export const EDITION_THEME_DEFAULT = EDITION_THEME[EDITION_ID_FREE]

// 获取版本主题（editionId 容错，未知版本回落默认主题）
export const getEditionTheme = (editionId) => {
    return EDITION_THEME[String(editionId)] || EDITION_THEME_DEFAULT
}

// 获取版本主题对应的 CSS 变量集合（供页面/区块根节点 :style 注入 --edition-current-*，子树内统一消费）
export const editionStyleVars = (editionId) => {
    const theme = getEditionTheme(editionId)
    return {
        '--edition-current-color': theme.color,
        '--edition-current-bg': theme.bg,
        '--edition-current-border': theme.border,
    }
}

// 按功能配置生成受限提示文案
export const getFeatureContent = (feature) => {
    const name = EDITION_NAMES[feature.requiredEdition] || '更高版本'
    return `${feature.name}功能，${name}及以上版本支持，请升级版本。`
}

// 版本功能配置表：前端版本受限项的唯一配置源
// name - 功能名称（用于受限提示文案）
// requiredEdition - 功能所需最低版本 ID
// quota - 数量档位（可选，仅数量型功能需要），key 为版本 ID
export const EDITION_FEATURES = Object.freeze({
    // 微信卡包：专业版及以上支持
    WECARD: Object.freeze({name: '微信卡包', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 填写手机号：标准版及以上支持
    GET_MOBILE: Object.freeze({name: '填写手机号', requiredEdition: EDITION_ID_STANDARD}),
    // 仅新客户可领：标准版及以上支持
    ONLY_NEW_CUSTOMER: Object.freeze({name: '仅新客户可领', requiredEdition: EDITION_ID_STANDARD}),
    // 指定手机号可领取：专业版及以上支持
    MOBILE_LIMIT: Object.freeze({name: '指定手机号可领取', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 核销后赠券：标准版及以上支持
    VERIFY_REWARD: Object.freeze({name: '核销后赠券', requiredEdition: EDITION_ID_STANDARD}),
    // 转赠奖励：专业版及以上支持
    TRANSFER_REWARD: Object.freeze({name: '转赠奖励', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 动态核销码：企业版及以上支持
    VERIFY_SIGN: Object.freeze({name: '动态核销码', requiredEdition: EDITION_ID_ENTERPRISE}),
    // 领取口令：企业版及以上支持
    RECEIVE_CIPHER: Object.freeze({name: '领取口令', requiredEdition: EDITION_ID_ENTERPRISE}),
    // 券包：免费/标准不支持，专业 5 种、企业 10 种（券创建的券包发放方式与券包制作共用）
    BUNDLE_ISSUE: Object.freeze({
        name: '券包',
        unit: '种',
        requiredEdition: EDITION_ID_PROFESSIONAL,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 0,
            [EDITION_ID_STANDARD]: 0,
            [EDITION_ID_PROFESSIONAL]: 5,
            [EDITION_ID_ENTERPRISE]: 10,
        }),
    }),
    // 通卡：专业版及以上支持
    UNLIMITED_CARD: Object.freeze({name: '通卡', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 权益卡：专业版及以上支持
    BENEFIT_CARD: Object.freeze({name: '权益卡', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 券内容图片：专业版及以上支持
    PRODUCT_IMAGE: Object.freeze({name: '券内容图片', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 卡券有效期时长（天）：免费 180 / 标准·专业 365 / 企业 1095（仅用于输入提示，拦截走后端 2006；开启微信卡包时受微信侧 365 天限制）
    COUPON_VALID_DAY: Object.freeze({
        name: '卡券有效期',
        unit: '天',
        requiredEdition: EDITION_ID_FREE,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 180,
            [EDITION_ID_STANDARD]: 365,
            [EDITION_ID_PROFESSIONAL]: 365,
            [EDITION_ID_ENTERPRISE]: 1095,
        }),
    }),
    // 次卡有效期（天）：免费·标准·专业 365 / 企业 1095（仅用于输入提示，拦截走后端 2006）
    CARD_VALID_DAY: Object.freeze({
        name: '次卡有效期',
        unit: '天',
        requiredEdition: EDITION_ID_FREE,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 365,
            [EDITION_ID_STANDARD]: 365,
            [EDITION_ID_PROFESSIONAL]: 365,
            [EDITION_ID_ENTERPRISE]: 1095,
        }),
    }),
    // 次卡每张包含次数：免费 7 / 标准 30 / 专业 100 / 企业 365（仅用于输入提示，拦截走后端 2006）
    CARD_TIMES: Object.freeze({
        name: '次卡次数',
        unit: '次',
        requiredEdition: EDITION_ID_FREE,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 7,
            [EDITION_ID_STANDARD]: 30,
            [EDITION_ID_PROFESSIONAL]: 100,
            [EDITION_ID_ENTERPRISE]: 365,
        }),
    }),
    // 活动海报：免费 1 个 / 标准 3 个 / 专业 10 个 / 企业不限（Infinity 表达不限档位）
    ACTIVITY_POSTER: Object.freeze({
        name: '活动海报',
        unit: '个',
        requiredEdition: EDITION_ID_FREE,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 1,
            [EDITION_ID_STANDARD]: 3,
            [EDITION_ID_PROFESSIONAL]: 10,
            [EDITION_ID_ENTERPRISE]: Infinity,
        }),
    }),
    // 领券中心：主页可添加的优惠券数量（免费 3 / 标准 10 / 专业 30 / 企业 100）
    HOME_COUPON: Object.freeze({
        name: '领券中心',
        unit: '张',
        requiredEdition: EDITION_ID_FREE,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 3,
            [EDITION_ID_STANDARD]: 10,
            [EDITION_ID_PROFESSIONAL]: 30,
            [EDITION_ID_ENTERPRISE]: 100,
        }),
    }),
    // 一键复制优惠券：标准版及以上支持
    COUPON_COPY: Object.freeze({name: '一键复制优惠券', requiredEdition: EDITION_ID_STANDARD}),
    // 会员权益：专业版及以上支持
    MEMBER_BENEFIT: Object.freeze({name: '会员权益', requiredEdition: EDITION_ID_PROFESSIONAL}),
    // 群发优惠券：企业版及以上支持
    MASS_COUPON: Object.freeze({name: '群发优惠券', requiredEdition: EDITION_ID_ENTERPRISE}),
    // 多张封面图：免费/标准 1 张，专业/企业 5 张
    COVER_IMAGE: Object.freeze({
        name: '多张封面图',
        requiredEdition: EDITION_ID_PROFESSIONAL,
        quota: Object.freeze({
            [EDITION_ID_FREE]: 1,
            [EDITION_ID_STANDARD]: 1,
            [EDITION_ID_PROFESSIONAL]: 5,
            [EDITION_ID_ENTERPRISE]: 5,
        }),
    }),
    // 门店数量：免费 3 / 标准 10 / 专业 30 / 企业 100（拦截判断以后端会话 editionStoreLimit 为准，档位表用于推算升级目标版本）
    STORE_COUNT: Object.freeze({
        name: '门店数量',
        unit: '家',
        quota: Object.freeze({
            [EDITION_ID_FREE]: 3,
            [EDITION_ID_STANDARD]: 10,
            [EDITION_ID_PROFESSIONAL]: 30,
            [EDITION_ID_ENTERPRISE]: 100,
        }),
    }),
    // 员工数量：免费 5 / 标准 30 / 专业 100 / 企业 300（拦截判断以后端会话 editionStaffLimit 为准，档位表用于推算升级目标版本）
    STAFF_COUNT: Object.freeze({
        name: '员工数量',
        unit: '名',
        quota: Object.freeze({
            [EDITION_ID_FREE]: 5,
            [EDITION_ID_STANDARD]: 30,
            [EDITION_ID_PROFESSIONAL]: 100,
            [EDITION_ID_ENTERPRISE]: 300,
        }),
    }),
})

// 获取功能在当前版本下的数量档位（无 quota 配置返回 null）
export const getFeatureQuota = (feature, editionId) => {
    if (!feature?.quota) return null
    return Number(feature.quota[String(editionId)] ?? feature.quota[EDITION_ID_FREE])
}

// 数量档位型功能：已用数量达到当前版本档位上限时，返回 check 所需的 {edition, content}
// （edition 为档位更大的下一个版本，用于升级抽屉预选；未达上限返回 null）
// 上限判定以本配置表 quota 为准（版本权益调整只需改这里），后端 2006 做最终兜底
export const getQuotaOverflow = (feature, editionId, count) => {
    const quota = feature?.quota
    if (!quota) return null
    const current = Number(editionId || EDITION_ID_FREE)
    const curQuota = Number(quota[String(current)] ?? quota[EDITION_ID_FREE])
    if (Number(count || 0) < curQuota) return null
    const order = [EDITION_ID_FREE, EDITION_ID_STANDARD, EDITION_ID_PROFESSIONAL, EDITION_ID_ENTERPRISE]
    for (const id of order) {
        if (Number(id) <= current) continue
        const nextQuota = Number(quota[String(id)] ?? quota[EDITION_ID_FREE])
        if (nextQuota > curQuota) {
            const name = EDITION_NAMES[id] || '更高版本'
            const unit = feature.unit || ''
            // 0 档 = 当前版本不支持该功能；Infinity = 不限数量；非 0 有限档 = 已达数量上限，文案区分
            const content = curQuota === 0
                ? `${feature.name}功能当前版本不支持，升级到${name}可使用，请升级版本。`
                : nextQuota === Infinity
                    ? `${feature.name}已达当前版本上限（${curQuota}${unit}），请升级版本。`
                    : `${feature.name}已达当前版本上限（${curQuota}${unit}），请升级版本。`
            return {
                edition: id,
                content,
            }
        }
    }
    return null
}
