// 素材/媒体域枚举：后端 docs/后端枚举值.md 暂未收录本域，取值经产品确认（2026-07-26）
// 展示文案一律使用后端返回的 *Label 字段直出，禁止在此建 label→文案映射

// 图片素材审核状态（status，接口 /seller/object/list）
export const MEDIA_AUDIT_STATUS = Object.freeze({
    AUDITING: 1, // 审核中（待审核）
    PASSED: 2, // 审核成功
    REJECTED: 3, // 违规（审核失败）
})
