// 活动海报域枚举：后端 docs/后端枚举值.md 暂未收录本域，取值经产品确认（2026-07-26）
// 展示文案一律使用后端返回的 *Label 字段直出，禁止在此建 label→文案映射

// 活动海报状态（status）
export const ACTIVITY_STATUS = Object.freeze({
    ONLINE: 1, // 上架
    OFFLINE: 2, // 下架
})
