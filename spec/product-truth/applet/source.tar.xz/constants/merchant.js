// 商户/门店/员工域枚举：取值语义以 server 端定义为唯一事实来源

// 商户认证状态（authStatus，对齐 server MerchantAuthStatus）
export const STATUS = Object.freeze({
    NORMAL: 1, // 正常
})

// 商户认证状态（authStatus，对齐 server MerchantAuthStatus）
export const AUTH_STATUS = Object.freeze({
    NONE: 0, // 未认证
    MUST: 1, // 必须认证
    AUDITING: 2, // 审核中
    SUCCESS: 3, // 已认证
    FAILED: 4, // 审核拒绝
})

// 商户客户注册方式（registerType，对齐 server RegisterType）
export const REGISTER_TYPE = Object.freeze({
    WECHAT: 1, // 微信登录
    ANONYMOUS: 2, // 匿名登录
})

// 门店状态（status，对齐 server StoreStatus，仅定义 1/4；审核态走独立的 auditStatus 字段）
export const STORE_STATUS = Object.freeze({
    NORMAL: 1, // 正常
    CLOSED: 4, // 关店
})

// 门店审核状态（auditStatus，对齐 server StoreAuditStatus）
export const STORE_AUDIT_STATUS = Object.freeze({
    NONE: 0, // 未审核
    PENDING: 1, // 审核中
    PASSED: 2, // 审核通过
    FAILED: 3, // 审核失败
})

// 员工状态（status，对齐 server StaffStatus）
export const STAFF_STATUS = Object.freeze({
    PENDING: 0, // 待确认
    NORMAL: 1, // 正常在职
    LEAVED: 2, // 离职
    LOCKED: 3, // 冻结
})

// 角色级别（levelType，对齐 server RoleLevelType）
export const ROLE_LEVEL_TYPE = Object.freeze({
    BRAND: 1, // 品牌级
    STORE: 2, // 门店级
    STAFF: 3, // 员工级
})
