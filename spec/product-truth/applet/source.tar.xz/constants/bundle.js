// 券包域枚举：取值语义以 server 端定义为唯一事实来源
// 与券/次卡状态不跨域合并，宁可形似重复

// 券包状态（status）
// 注：server BundleStatus typed const 仅定义 1/2/3；前端 delete/private_receive 实际消费 4，是否为运行时动态值待后端确认，确认前保留
export const BUNDLE_STATUS = Object.freeze({
    ISSUING: 1, // 有效中/发放中（可暂停）
    PAUSED: 2, // 已暂停（可恢复）
    DISCARDED: 3, // 已作废
    EXPIRED: 4, // 已过期（待后端确认）
    FROZEN: 5, // 冻结态（前端暂无消费位；原误判 bundle/detail.vue 的 status===5，实为券包内优惠券的 CouponStatus.FROZEN；待后端确认）
})

// 券包审核状态（auditStatus，对齐 server BundleAuditStatus，前端仅消费“是否通过”）
export const BUNDLE_AUDIT_STATUS = Object.freeze({
    PASSED: 2, // 审核通过
})

// 券包领取方式（receiveType，对齐 server BundleReceiveType）
export const BUNDLE_RECEIVE_TYPE = Object.freeze({
    ALL: 1, // 一键全部领取
    RANDOM: 2, // 随机领取一种
    CHOOSE: 3, // 自选一种
})

// 私密发放记录状态（issue.status，对齐 server BundleIssuePrivateStatus）
export const ISSUE_PRIVATE_STATUS = Object.freeze({
    VALID: 1, // 待领取
    RECEIVED: 2, // 已领取
    EXPIRED: 3, // 已过期
    DISCARDED: 4, // 已作废
})

// 发券员工状态（发放员工记录 status，对齐 server BundleStaffStatus；后端仅定义未做相关业务逻辑）
export const ISSUE_STAFF_STATUS = Object.freeze({
    VALID: 1, // 正常
    STOP: 2, // 停止
})

// 券包内容限制（对齐 server/internal/consts/bundle.go）
export const BUNDLE_COUPON_LIMIT = Object.freeze({
    MIN_TYPE_COUNT: 2, // BundleMinCouponTypeCount
    MAX_TYPE_COUNT: 10, // BundleMaxCouponTypeCount
    MIN_ISSUE_COUNT_PER_TYPE: 1, // BundleMinCouponIssueCountPerType
    MAX_ISSUE_COUNT_PER_TYPE: 5, // BundleMaxCouponIssueCountPerType
})
