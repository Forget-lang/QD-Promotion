<template>
    <t-cell-group t-class="mt-2" theme="card">
        <t-cell title="我的业绩" arrow :url="'/pages_coupon/stat/staff_overview?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_CHANNEL_RANK)" title="发券渠道统计" arrow
                :url="'/pages_coupon/stat/channel_issue_rank?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_STORE_RANK)" title="门店发券统计" arrow :url="'/pages_coupon/stat/store_issue_rank?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_STORE_RANK)" title="门店核销统计" arrow :url="'/pages_coupon/stat/store_verify_rank?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_STAFF_RANK)" title="员工发券统计" arrow :url="'/pages_coupon/stat/staff_issue_rank?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_STAFF_RANK)" title="员工核销统计" arrow :url="'/pages_coupon/stat/staff_verify_rank?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_USER_TRANSFER)" title="顾客转赠统计" arrow :url="'/pages_coupon/stat/user_transfer_rank?couponId=' + couponId"/>
        <t-cell v-if="checkPermission(PERM_COUPON.STAT_USER_VERIFY)" title="顾客核销统计" arrow :url="'/pages_coupon/stat/user_verify_rank?couponId=' + couponId"/>
    </t-cell-group>
</template>

<script setup>
import {ref} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import {useAuth} from "@/hooks/useAuth.js";
import {PERM_COUPON} from "@/constants/permission.js";

const {checkPermission} = useAuth();
const couponId = ref();
onLoad((e) => {
    couponId.value = e.couponId
})
</script>

<style scoped>

</style>