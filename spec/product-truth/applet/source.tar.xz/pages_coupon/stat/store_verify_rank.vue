<template>
    <view class="stat-filter">
        <view class="stat-date-filter">
            <text class="stat-filter-item" :class="{active:options.timeType === 'today'}"
                  @click="onChangeTimeType('today')">今天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'yesterday'}"
                  @click="onChangeTimeType('yesterday')">昨天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'month'}"
                  @click="onChangeTimeType('month')">本月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'lastMonth'}"
                  @click="onChangeTimeType('lastMonth')">上月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'cumulative'}"
                  @click="onChangeTimeType('cumulative')">累计
            </text>
        </view>
    </view>

    <view class="container">
        <view class="section mt-3">
            <view class="section-header bottom-line">
                <view class="section-title">门店核销业绩排行</view>
            </view>
            <view class="section-body pt-0">
                <m-empty v-if="!items.length">暂无排行数据</m-empty>
                <view class="rank-list" v-else>
                    <view class="rank-row" v-for="(item, index) in items" :key="item.storeId">
                        <view class="rank-idx rank-idx--top" v-if="index < 3">
                            <image class="rank-idx-img" :src="rankIcons[index]" mode="aspectFit"/>
                        </view>
                        <view class="rank-idx" v-else>{{ index + 1 }}</view>
                        <view class="rank-avatar">
                            <image v-if="item.logo" :src="item.logo" mode="aspectFill"/>
                            <text v-else>{{ (item.storeName || '').charAt(0) }}</text>
                        </view>
                        <view class="rank-info">
                            <view class="rank-name">{{ item.storeName }}</view>
                        </view>
                        <view class="rank-right">
                            <view class="rank-main">{{ item.verifyCount }}张</view>
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {ref} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import request from "@/hooks/request";

const options = ref({
    timeType: 'cumulative',
})
const items = ref([])
const couponId = ref()

const onChangeTimeType = (val) => {
    options.value.timeType = val
    getStoreRank()
}

const rankIcons = [
    'https://cdn.lenmy.com/img/sort-1.png',
    'https://cdn.lenmy.com/img/sort-2.png',
    'https://cdn.lenmy.com/img/sort-3.png',
]

const getStoreRank = () => {
    request.get('/seller/coupon/stat/store-verify-rank', {
        couponId: couponId.value,
        ...options.value,
    }).then(res => {
        items.value = res.data.items || []
    })
}

onLoad((e) => {
    couponId.value = e.couponId
    getStoreRank()
})
</script>

<style scoped>
.rank-list {
    margin-top: 8rpx;
}

.rank-row {
    display: flex;
    align-items: center;
    padding: 16rpx 0;
    border-bottom: 1rpx solid #f1f5f9;
}

.rank-row:last-child {
    border-bottom: none;
}

.rank-idx {
    width: 44rpx;
    height: 44rpx;
    border-radius: 50%;
    background: #f1f5f9;
    color: #64748b;
    font-size: 22rpx;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
}

.rank-idx--top {
    background: none;
}

.rank-idx-img {
    width: 44rpx;
    height: 44rpx;
}

.rank-avatar {
    width: 64rpx;
    height: 64rpx;
    border-radius: 12rpx;
    background: #f1f5f9;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
}

.rank-avatar image {
    width: 100%;
    height: 100%;
}

.rank-avatar text {
    font-size: 24rpx;
    font-weight: 600;
    color: #94a3b8;
}

.rank-info {
    flex: 1;
    min-width: 0;
}

.rank-name {
    font-size: 26rpx;
    color: #0f172a;
    font-weight: 500;
}

.rank-right {
    text-align: right;
    flex-shrink: 0;
}

.rank-main {
    font-size: 28rpx;
    font-weight: 600;
    color: #0f172a;
}
</style>
