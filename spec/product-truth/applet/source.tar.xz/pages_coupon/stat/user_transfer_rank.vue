<template>
    <view class="stat-filter">
        <view class="stat-date-filter">
            <text class="stat-filter-item" :class="{active:options.timeType === 'today'}"
                  @click="onChangeTimeType('today')">今天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'yesterday'}"
                  @click="onChangeTimeType('yesterday')">昨天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'month'}"
                  @click="onChangeTimeType('month')">本月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'lastMonth'}"
                  @click="onChangeTimeType('lastMonth')">上月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'cumulative'}"
                  @click="onChangeTimeType('cumulative')">累计
            </text>
        </view>
    </view>
    <view class="container">
        <m-empty v-if="!isTransfer">该券未开启转赠</m-empty>
        <template v-else>
            <view class="section mt-3">
                <view class="section-header bottom-line">
                    <view class="section-title">转赠概况</view>
                </view>
                <view class="section-body">
                    <view class="three-col">
                        <view class="three-col-item">
                            <view class="three-col-value">{{ summary.transferTotalCount || 0 }}</view>
                            <view class="three-col-label">转赠总次数</view>
                        </view>
                        <view class="three-col-item">
                            <view class="three-col-value">{{ summary.successRate || 0 }}%</view>
                            <view class="three-col-label">转赠成功率</view>
                        </view>
                        <view class="three-col-item">
                            <view class="three-col-value">{{ summary.transferSuccessCount || 0 }}</view>
                            <view class="three-col-label">成功次数</view>
                        </view>
                    </view>
                </view>
            </view>

            <view class="section mt-3">
                <view class="section-header bottom-line">
                    <view class="section-title">顾客转赠排行</view>
                </view>
                <view class="section-body pt-0">
                    <m-empty v-if="!items.length">暂无转赠数据</m-empty>
                    <view class="rank-list" v-else>
                        <view class="rank-row" v-for="(item, index) in items" :key="item.userId">
                            <view class="rank-idx rank-idx--top" v-if="index < 3">
                                <image class="rank-idx-img" :src="rankIcons[index]" mode="aspectFit"/>
                            </view>
                            <view class="rank-idx" v-else>{{ index + 1 }}</view>
                            <view class="rank-avatar">
                                <image v-if="item.avatar" :src="item.avatar" mode="aspectFill"/>
                                <text v-else>{{ (item.nickname || '?').charAt(0) }}</text>
                            </view>
                            <view class="rank-info">
                                <view class="rank-name">{{ item.nickname || '未知用户' }}</view>
                                <view class="rank-sub">成功 {{ item.successCount }} 次</view>
                            </view>
                            <view class="rank-right">
                                <view class="rank-main">{{ item.transferCount }}</view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
        </template>
    </view>
</template>

<script setup>
import {ref} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import request from "@/hooks/request";

const options = ref({
    timeType: 'cumulative',
})
const summary = ref({})
const items = ref([])
const couponId = ref()
const isTransfer = ref(true)

const onChangeTimeType = (val) => {
    options.value.timeType = val
    getTransferRank()
}

const rankIcons = [
    'https://cdn.lenmy.com/img/sort-1.png',
    'https://cdn.lenmy.com/img/sort-2.png',
    'https://cdn.lenmy.com/img/sort-3.png',
]

const getCouponInfo = () => {
    return request.get('/seller/coupon/detail', {id: couponId.value}).then(res => {
        isTransfer.value = !!res.data.isTransfer
    })
}

const getTransferRank = () => {
    if (!isTransfer.value) {
        return
    }
    request.get('/seller/coupon/stat/user-transfer-rank', {
        couponId: couponId.value,
        timeType: options.value.timeType,
    }).then(res => {
        summary.value = res.data.summary || {}
        items.value = res.data.items || []
    })
}

onLoad((e) => {
    couponId.value = e.couponId
    getCouponInfo().then(() => {
        getTransferRank()
    })
})
</script>

<style scoped>
.three-col {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    text-align: center;
    padding: 20rpx 0;
    background: #fff7ed;
    border-radius: 16rpx;
}

.three-col-item + .three-col-item {
    border-left: 2rpx dashed #fed7aa;
}

.three-col-value {
    font-size: 36rpx;
    font-weight: 700;
    color: #e2453d;
}

.three-col-label {
    font-size: 22rpx;
    color: #94a3b8;
    margin-top: 4rpx;
}

.rank-list {
    margin-top: 8rpx;
}

.rank-row {
    display: flex;
    align-items: center;
    padding: 16rpx 0;
    border-bottom: 1rpx solid #f1f5f9;
}

.rank-row:last-child {
    border-bottom: none;
}

.rank-idx {
    width: 44rpx;
    height: 44rpx;
    border-radius: 50%;
    background: #f1f5f9;
    color: #64748b;
    font-size: 22rpx;
    font-weight: 600;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
}

.rank-idx--top {
    background: none;
}

.rank-idx-img {
    width: 44rpx;
    height: 44rpx;
}

.rank-avatar {
    width: 64rpx;
    height: 64rpx;
    border-radius: 12rpx;
    background: #f1f5f9;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
}

.rank-avatar image {
    width: 100%;
    height: 100%;
}

.rank-avatar text {
    font-size: 24rpx;
    font-weight: 600;
    color: #94a3b8;
}

.rank-info {
    flex: 1;
    min-width: 0;
}

.rank-name {
    font-size: 26rpx;
    color: #0f172a;
    font-weight: 500;
}

.rank-sub {
    font-size: 22rpx;
    color: #94a3b8;
    margin-top: 2rpx;
}

.rank-right {
    text-align: right;
    flex-shrink: 0;
}

.rank-main {
    font-size: 28rpx;
    font-weight: 600;
    color: #0f172a;
}
</style>
