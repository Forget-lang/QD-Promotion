<template>
    <m-result v-if="showSuccess" title="作废成功" description="所有已被领取的优惠券也一并作废。" back></m-result>
    <template v-else>
        <view class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="h4">作废须知：</view>
                <view class="mt-1 text-small">1. 此券模版下所有
                    <text class="text-danger">已领取未核销的券都将作废</text>
                    ，请谨慎操作！
                </view>
                <view class="mt-1 text-small">2. 作废后券模版不可恢复，所有已领取未核销的券不可恢复。</view>
                <view class="mt-1 text-small">3. 优惠券作废后，可进行删除操作。</view>
            </view>
        </view>
        <t-cell-group t-class="mt-2" theme="card">
            <t-textarea required label="作废原因" v-model:value="form.reason" :maxlength="32" :indicator="true"
                        placeholder="请输入作废原因"></t-textarea>
        </t-cell-group>
        <view class="mt-3">
            <t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless icon="circle"
                        relation-key="-1" custom-style="background-color: transparent;">
                <template #label>
                    <view class="agreement">
                        我已阅读并知晓作废优惠券的风险，确认要作废优惠券模版及所有数据。
                    </view>
                </template>
            </t-checkbox>
        </view>
        <!-- 提交按钮 -->
        <m-submit :loading="loading" :disabled="loading || !allowAgreement" @click="onSubmit">确认作废</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app';
import {ref} from 'vue'
import request from "@/hooks/request.js"
import MResult from "@/components/m/m-result/m-result.vue";
import utils from "@/utils/utils";

const couponId = ref()
const allowAgreement = ref(false)
const loading = ref(false)
const form = ref({
    reason: ''
})
const showSuccess = ref(false)

const onSubmit = () => {
    loading.value = true
    request.post('/seller/coupon/discard', {id: couponId.value, reason: form.value.reason},{disableErrorToast: true}).then(res => {
        uni.$emit('onCouponDiscard', {id: couponId.value})
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    }).catch((err) => {
        utils.alert(err.message)
    })
}

onLoad((e) => {
    couponId.value = e.couponId
})
</script>

<style scoped>

</style>