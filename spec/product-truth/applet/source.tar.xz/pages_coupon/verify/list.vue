<template>
    <view class="container-search">
        <view class="input-search">
            <t-input
                :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                placeholder="支持优惠券券码搜索"
                v-model:value="search.couponReceiveId"
                borderless
                size="small"
                :clearable="{ name: 'close-circle-filled', size: '36rpx' }"
                @clear="onClearKeyword"
                @enter="onKeywordSearch"
            />
            <view class="input-search-actions">
                <t-button theme="default" size="small" variant="text" icon="search" @click="onKeywordSearch"></t-button>
            </view>
        </view>
    </view>

    <!-- 筛选条 -->
    <view class="filter-bar">
        <view class="filter-bar-left">
            <view class="filter-bar-item" @tap="showOrderPicker = true">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.sorter === 'desc' }">{{ search.sorter === 'desc' ? '最新' : '最早' }}</text>
                <t-icon name="chevron-down" size="24rpx" :color="search.sorter === 'desc' ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showTimePicker = true">
                <text class="filter-bar-label filter-bar-time" :class="{ 'filter-bar-active': search.startTime && search.endTime }">
                    时间
                </text>
                <t-icon name="chevron-down" size="24rpx" :color="search.startTime && search.endTime ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showChannelPicker = true">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.channelType }">渠道</text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.channelType ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="storeSelectRef?.onOpen">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.verifyStoreId }">门店</text>
                <t-icon name="chevron-down" size="24rpx" :color="search.verifyStoreId ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="staffSelectRef?.onOpen">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.verifyStaffId }">员工</text>
                <t-icon name="chevron-down" size="24rpx" :color="search.verifyStaffId ? 'var(--td-brand-color)' : '#999'"/>
            </view>
        </view>
        <view class="filter-bar-right" @tap="onResetFilter">
            <text class="filter-bar-action">重置</text>
        </view>
    </view>

    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无核销记录</m-empty>
            <template v-else>
                <view
                    class="record-item"
                    v-for="item in items"
                    :key="item.id"
                    @tap="push('/pages_coupon/verify/detail?id=' + item.id)"
                >
                    <view class="record-header">
                        <view class="record-user">
                            <view class="user-avatar">
                                <image v-if="item.avatar" :src="item.avatar" mode="aspectFill"></image>
                                <text v-else>{{ (item.nickname || '').charAt(0) }}</text>
                            </view>
                            <view class="user-info">
                                <view class="user-name-row">
                                    <text class="user-name">{{ item.nickname }}</text>
                                </view>
                                <view class="user-time">{{ item.verifyAt }}</view>
                            </view>
                        </view>
                        <view class="record-status" :class="'status-' + item.status">{{ item.statusLabel }}</view>
                    </view>
                    <view class="coupon-info-row" v-if="!search.couponId">
                        <view class="coupon-info-left">
                            <t-tag theme="danger" size="small" variant="light-outline">{{ item.couponTypeLabel }}</t-tag>
                            <text class="coupon-info-name text-ellipsis">{{ item.couponName }}</text>
                        </view>
                        <view class="coupon-info-right">
                            <text class="coupon-info-face" v-if="isAmountFace(item.couponType)">
                                ￥{{ item.couponAmount }}
                            </text>
                            <text class="coupon-info-face" v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">{{
                                    item.couponAmount
                                }}折
                            </text>
                            <t-icon v-else-if="item.couponType === COUPON_TYPE.EXCHANGE" name="gift-filled" color="#e84c59" size="36rpx"/>
                        </view>
                    </view>
                    <view class="record-body">
                        <view class="issue-grid">
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">领取渠道</text>
                                <text class="issue-grid-value">{{ item.channelTypeLabel }}</text>
                            </view>
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">核销门店</text>
                                <text class="issue-grid-value text-ellipsis">{{ item.verifyStoreName || '-' }}</text>
                            </view>
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">核销员工</text>
                                <text class="issue-grid-value text-ellipsis">{{ item.verifyStaffName || '-' }}</text>
                            </view>
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">核销备注</text>
                                <text class="issue-grid-value text-ellipsis">{{ item.verifyRemark || '无' }}</text>
                            </view>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
    <m-submit v-if="checkPermission(PERM_COUPON.EXPORT) && items && items.length > 0" @click="onExportList">导出核销记录</m-submit>

    <!-- 时间选择弹框 -->
    <t-popup placement="bottom" v-model:visible="showTimePicker" @visible-change="onTimePickerChange" :z-index="10000" :overlay-props="{ zIndex: 9999 }">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-cancel" @tap="showTimePicker = false">取消</view>
                <view class="popup-header-title">选择时间</view>
                <view class="popup-header-confirm" @tap="onClearTime">清空</view>
            </view>
            <view class="popup-body" style="height: 600rpx;">
                <t-cell-group theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.startTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="开始时间"
                        placeholder="请选择开始时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <t-cell-group t-class="mt-2" theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.endTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="结束时间"
                        placeholder="请选择结束时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <view class="popup-footer mt-5">
                    <t-button theme="danger" size="large" block @click="onConfirmTime">确认</t-button>
                </view>
            </view>
        </view>
    </t-popup>

    <!-- 排序选择 ActionSheet -->
    <t-action-sheet
        :visible="showOrderPicker"
        :items="orderItems"
        @selected="onSelectOrder"
        @cancel="showOrderPicker = false"
    ></t-action-sheet>

    <!-- 领取渠道选择 ActionSheet -->
    <t-action-sheet
        :visible="showChannelPicker"
        :items="channelActionItems"
        @selected="onSelectChannel"
        @cancel="showChannelPicker = false"
    ></t-action-sheet>

    <!-- 门店选择 -->
    <m-store-select
        ref="storeSelectRef"
        v-model:value="search.verifyStoreId"
        title="核销门店"
        placeholder="请选择核销门店"
        :multiple="false"
        :hidden="true"
        @label-change="onStoreLabelChange"
    />

    <!-- 员工选择 -->
    <m-staff-select
        ref="staffSelectRef"
        v-model:value="search.verifyStaffId"
        title="核销员工"
        placeholder="请选择核销员工"
        :multiple="false"
        :hidden="true"
        @label-change="onStaffLabelChange"
    />

    <!-- VIP 升级抽屉：承接导出接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {useLink} from '@/hooks/useLink'
import utils from '@/utils/utils'
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {useAuth} from '@/hooks/useAuth'
import {PERM_COUPON} from '@/constants/permission'
import {saveBase64Excel} from '@/hooks/useFile'
import dayjs from "dayjs";
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

const search = ref({
    page: 1,
    pageSize: 20,
    couponId: undefined,
    couponReceiveId: undefined,
    status: undefined,
    startTime: undefined,
    endTime: undefined,
    sorter: 'desc',
    channelType: undefined,
    verifyStoreId: undefined,
    verifyStaffId: undefined,
    userId: undefined,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 筛选弹框相关
const showTimePicker = ref(false)
const showOrderPicker = ref(false)
const showChannelPicker = ref(false)
const storeSelectRef = ref()
const storeLabel = ref()
const staffSelectRef = ref()
const staffLabel = ref()
// 排序选项
const orderItems = [
    {label: '最新', value: 'desc'},
    {label: '最早', value: 'asc'},
]
// 领取渠道选项
const channelOptions = [
    {label: '微信好友/群', value: 1},
    {label: '二维码', value: 2},
    {label: '海报', value: 3},
    {label: '公众号', value: 4},
]
const channelActionItems = channelOptions.map(o => ({label: o.label, value: o.value}))
// 时间选择临时变量
const tempTime = ref({
    startTime: '',
    endTime: '',
})

const onClearKeyword = () => {
    search.value.couponReceiveId = undefined
    onKeywordSearch()
}

const onKeywordSearch = () => {
    search.value.couponReceiveId = search.value.couponReceiveId || undefined
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取核销记录列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/coupon/verify/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 刷新列表
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

const onExportList = async () => {
    utils.showLoading()
    try {
        const res = await request.post('/seller/coupon/verify/export', search.value)
        await saveBase64Excel(res.data.file, '优惠券核销记录')
    } catch (err) {
        // ignore
    } finally {
        utils.hideLoading()
    }
}


// 选择组件标签变更
const onStoreLabelChange = (label) => {
    storeLabel.value = label
    applyFilterAndRefresh()
}
const onStaffLabelChange = (label) => {
    staffLabel.value = label
    applyFilterAndRefresh()
}

// 时间弹框显示/隐藏
const onTimePickerChange = (visible) => {
    showTimePicker.value = visible
    if (visible) {
        tempTime.value.startTime = search.value.startTime || ''
        tempTime.value.endTime = search.value.endTime || ''
    }
}

// 时间确认
const onConfirmTime = () => {
    search.value.startTime = tempTime.value.startTime || undefined
    search.value.endTime = tempTime.value.endTime || undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

// 清空时间
const onClearTime = () => {
    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    search.value.startTime = undefined
    search.value.endTime = undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

// 排序选择
const onSelectOrder = (e) => {
    search.value.sorter = e.selected.value
    showOrderPicker.value = false
    applyFilterAndRefresh()
}

// 领取渠道选择
const onSelectChannel = (e) => {
    search.value.channelType = e.selected.value
    showChannelPicker.value = false
    applyFilterAndRefresh()
}

// 应用筛选并刷新
const applyFilterAndRefresh = () => {
    search.value.startTime = search.value.startTime || undefined
    search.value.endTime = search.value.endTime || undefined
    search.value.sorter = search.value.sorter || 'desc'
    search.value.channelType = search.value.channelType || undefined
    search.value.verifyStoreId = search.value.verifyStoreId || undefined
    search.value.verifyStaffId = search.value.verifyStaffId || undefined

    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 重置筛选
const onResetFilter = () => {
    const userId = search.value.userId
    const status = search.value.status
    const couponId = search.value.couponId
    search.value.startTime = undefined
    search.value.endTime = undefined
    search.value.sorter = 'desc'
    search.value.channelType = undefined
    search.value.verifyStoreId = undefined
    search.value.verifyStaffId = undefined
    search.value.couponReceiveId = undefined
    search.value.userId = userId
    search.value.status = status
    search.value.couponId = couponId

    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    storeLabel.value = ''
    staffLabel.value = ''

    applyFilterAndRefresh()
}

onLoad((e) => {
    if (e.couponId) {
        search.value.couponId = e.couponId
    }
    if (e.userId) {
        search.value.userId = e.userId
    }
    if (e.type === 'today') {
        search.value.startTime = dayjs().format('YYYY-MM-DD') + ' 00:00:00'
        search.value.endTime = dayjs().format('YYYY-MM-DD') + ' 23:59:59'
    }
    getItems()
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
/* 筛选条 */
.filter-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20rpx 32rpx;
    background: #fff;
    border-bottom: 1rpx solid #eee;
}

.filter-bar-left {
    display: flex;
    align-items: center;
    gap: 40rpx;
}

.filter-bar-item {
    display: flex;
    align-items: center;
    gap: 6rpx;
    padding: 8rpx 0;
}

.filter-bar-label {
    font-size: 28rpx;
    color: #666;
    max-width: 70rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.filter-bar-time {
    max-width: 180rpx;
}

.filter-bar-active {
    color: var(--td-brand-color) !important;
}

.filter-bar-right {
    display: flex;
    align-items: center;
}

.filter-bar-action {
    font-size: 28rpx;
    color: var(--td-brand-color);
}

.popup-footer {
    display: flex;
    padding: 24rpx 32rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
}

.record-item {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
    margin-bottom: 20rpx;
    position: relative;
}

.record-header {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 20rpx;
}

.record-user {
    display: flex;
    align-items: flex-start;
    flex: 1;
}

.user-avatar {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    background: #e8f4ff;
    color: #fff;
    font-size: 28rpx;
    font-weight: bold;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 16rpx;
    flex-shrink: 0;
}

.user-avatar image {
    width: 100%;
    height: 100%;
    border-radius: 50%;
}

.user-info {
    flex: 1;
}

.user-name-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    margin-bottom: 8rpx;
}

.user-name {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    margin-right: 12rpx;
}

.user-mobile {
    font-size: 26rpx;
    color: #333;
    margin-right: 12rpx;
}

.copy-btn {
    font-size: 24rpx;
    color: #07c160;
}

.user-time {
    font-size: 24rpx;
    color: #999;
}

.record-status {
    font-size: 24rpx;
    padding: 4rpx 16rpx;
    border-radius: 20rpx;
    flex-shrink: 0;
}

.status-1 {
    color: #07c160;
}

.status-2 {
    color: #1989fa;
}

.status-3 {
    color: #999;
}

.record-body {
    padding-bottom: 4rpx;
}

/* 优惠券信息行（跨券概览时展示顾客核销的是哪张券） */
.coupon-info-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
    background: #fafafa;
    border-radius: 12rpx;
    padding: 16rpx 20rpx;
    margin-bottom: 16rpx;
}

.coupon-info-left {
    display: flex;
    align-items: center;
    gap: 8rpx;
    flex: 1;
    min-width: 0;
}

.coupon-info-name {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.coupon-info-right {
    display: flex;
    align-items: baseline;
    gap: 8rpx;
    flex-shrink: 0;
}

.coupon-info-face {
    font-size: 32rpx;
    font-weight: 700;
    color: #e84c59;
}

.issue-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16rpx;
}

.issue-grid-item {
    background: #fafafa;
    border-radius: 12rpx;
    padding: 16rpx 20rpx;
    /* grid 子项默认最小宽度为 auto，会导致内部 text-ellipsis 失效而撑开格子，置 0 让省略生效 */
    min-width: 0;
}

.issue-grid-label {
    display: block;
    font-size: 22rpx;
    color: #999;
    margin-bottom: 8rpx;
}

.issue-grid-value {
    display: block;
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
}
</style>
