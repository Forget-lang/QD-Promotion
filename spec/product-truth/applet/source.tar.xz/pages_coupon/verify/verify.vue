<template>
    <view class="container-search">
        <view class="input-search">
            <t-input
                :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                placeholder="请输入优惠券码"
                v-model:value="verifyCode"
                borderless
                size="small"
                :clearable="{ name: 'close-circle-filled', size: '36rpx' }"
                @enter="onSearch"
            />
            <view class="input-search-actions">
                <t-button theme="default" size="large" variant="text" icon="scan" @click="onReset"></t-button>
            </view>
        </view>
    </view>

    <m-loading v-if="loading"/>
    <m-result
        v-else-if="verifyResult"
        :type="resultType"
        :title="resultTitle"
        :description="resultDescription"
    >
        <view v-if="verifyResult.isVerify && hasAnyReward" class="section mt-4 w-100">
            <view class="section-body">
                <view v-if="verifyResult.isVerifyReward" class="reward-item">
                    <view class="reward-item-main">
                        <view class="reward-item-left">
                            <t-icon name="gift-filled" size="40rpx" :color="rewardIconColor(verifyResult.verifyRewardStatus)"/>
                            <view class="reward-item-text">
                                <text class="reward-item-name">核销奖励</text>
                                <text class="reward-item-desc">顾客核销后可再得本券一张</text>
                            </view>
                        </view>
                        <t-tag :theme="rewardTagTheme(verifyResult.verifyRewardStatus)" variant="light" size="small">
                            <text :class="rewardTagTextClass(verifyResult.verifyRewardStatus)">
                                {{ rewardStatusLabel(verifyResult.verifyRewardStatus) }}
                            </text>
                        </t-tag>
                    </view>
                    <view
                        v-if="showRewardReason(verifyResult.verifyRewardStatus) && verifyResult.verifyRewardFailReason"
                        class="reward-item-reason">
                        {{ verifyResult.verifyRewardFailReason }}
                    </view>
                </view>
                <view v-if="verifyResult.isTransferReward" class="reward-item">
                    <view class="reward-item-main">
                        <view class="reward-item-left">
                            <t-icon name="gift-filled" size="40rpx" :color="rewardIconColor(verifyResult.transferRewardStatus)"/>
                            <view class="reward-item-text">
                                <text class="reward-item-name">转赠奖励</text>
                                <text class="reward-item-desc">转赠并核销后赠原转赠人奖励券</text>
                            </view>
                        </view>
                        <t-tag :theme="rewardTagTheme(verifyResult.transferRewardStatus)" variant="light" size="small">
                            <text :class="rewardTagTextClass(verifyResult.transferRewardStatus)">
                                {{ rewardStatusLabel(verifyResult.transferRewardStatus) }}
                            </text>
                        </t-tag>
                    </view>
                    <view
                        v-if="showRewardReason(verifyResult.transferRewardStatus) && verifyResult.transferRewardFailReason"
                        class="reward-item-reason">
                        {{ verifyResult.transferRewardFailReason }}
                    </view>
                </view>
            </view>
        </view>
    </m-result>
    <m-empty v-else-if="couponInfo === null">未搜索到卡券</m-empty>
    <view v-else-if="couponInfo" class="container-safety">

        <!-- 过期 / 转赠中提示 -->
        <view v-if="couponInfo.isQrcodeExpired" class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="text-warning">{{ couponInfo.qrcodeExpiredTip }}</view>
            </view>
        </view>
        <view v-else-if="couponInfo.transferLock" class="container mt-2">
            <view class="section p-3 section-alert">
                <view class="text-warning">优惠券转赠中，暂不可核销</view>
            </view>
        </view>

        <!-- 优惠券概览 -->
        <view class="container mt-2">
            <view class="coupon mt-2">
                <view class="coupon-header">
                    <!-- 代金券、套餐券、满减券、手气券 -->
                    <view class="coupon-face" v-if="isAmountFace(couponInfo.couponType)">
                        <text class="coupon-face-unit">￥</text>
                        <text class="coupon-face-money">{{ couponInfo.couponAmount }}</text>
                    </view>
                    <!-- 折扣券 -->
                    <view class="coupon-face" v-if="couponInfo.couponType === COUPON_TYPE.DISCOUNT">
                        <text class="coupon-face-money">{{ couponInfo.couponAmount }}</text>
                        <text class="coupon-face-font">折</text>
                    </view>
                    <!-- 兑换券 -->
                    <view class="coupon-face" v-if="couponInfo.couponType === COUPON_TYPE.EXCHANGE">
                        <t-icon name="gift-filled" color="#e84c59" size="64rpx"></t-icon>
                    </view>
                    <view class="coupon-type">{{ couponInfo.couponTypeLabel }}</view>
                </view>
                <view class="coupon-body">
                    <view class="coupon-name">{{ couponInfo.couponName }}</view>
                    <view class="coupon-threshold">{{ couponInfo.threshold }}
                        <text class="ml-1" v-if="couponInfo.couponType === COUPON_TYPE.EXCHANGE">{{ couponInfo.exchangeProduct }}</text>
                    </view>
                    <view class="coupon-validity">
                        有效期 {{ validStartDate }} 至 {{ validEndDate }}
                    </view>
                </view>
                <view class="coupon-footer">
                    <t-tag v-if="couponInfo.couponTransferId > 0" theme="default" variant="outline" size="small">
                        转赠获得
                    </t-tag>
                    <view class="coupon-status" :class="'status-' + couponInfo.status">{{ couponInfo.statusLabel }}</view>
                </view>
            </view>
        </view>
        <!-- 优惠券概览 -->

        <!-- 广告位 -->
        <view class="section container mt-2" v-if="adUnitVerify">
            <ad-custom :unit-id="adUnitVerify"></ad-custom>
        </view>

        <!-- 领取信息 -->
        <t-cell-group title="领取信息" t-title-class="mt-2" theme="card" :bordered="false">
            <t-cell title="领取渠道" :note="couponInfo.channelTypeLabel"></t-cell>
            <t-cell title="领取时间" :note="couponInfo.receivedAt"/>
            <t-cell title="发放门店" :note="couponInfo.issueStoreName ? couponInfo.issueStoreName : '-'"/>
            <t-cell title="发放员工" :note="couponInfo.issueStaffName ? couponInfo.issueStaffName : '-'"/>
            <t-cell title="发放备注" :note="couponInfo.issueRemark ? couponInfo.issueRemark : '-'"/>
        </t-cell-group>

        <!-- 已核销信息 -->
        <t-cell-group v-if="couponInfo.status === RECEIVE_STATUS.USED" title="核销信息" t-title-class="mt-2" theme="card"
                      :bordered="false">
            <t-cell title="核销店铺" :note="couponInfo.verifyStoreName ? couponInfo.verifyStoreName : '-'"/>
            <t-cell title="核销员工" :note="couponInfo.verifyStaffName ? couponInfo.verifyStaffName : '-'"/>
            <t-cell title="核销备注" :note="couponInfo.verifyRemark ? couponInfo.verifyRemark : '-'"/>
            <t-cell title="核销时间" :note="couponInfo.verifyAt" :bordered="false"/>
        </t-cell-group>

        <!-- 已作废信息 -->
        <t-cell-group v-if="couponInfo.status === RECEIVE_STATUS.DISCARDED" title="作废信息" t-title-class="mt-2" theme="card"
                      :bordered="false">
            <t-cell title="作废原因" :note="couponInfo.discardRemark"/>
            <t-cell title="操作门店" :note="couponInfo.discardStoreName ? couponInfo.discardStoreName : '-'"/>
            <t-cell title="操作员工" :note="couponInfo.discardStaffName ? couponInfo.discardStaffName : '-'"/>
            <t-cell title="作废时间" :note="couponInfo.discardAt" :bordered="false"/>
        </t-cell-group>

        <!-- 作废优惠券（弱操作入口） -->
        <view v-if="canDiscard" class="mt-3 mb-3 text-center" @click="discardVisible = true">
            <text class="text-muted text-small">作废该优惠券</text>
        </view>

        <!-- 核销确认弹框 -->
        <t-popup placement="bottom" :visible="verifyVisible" @visible-change="onVerifyPopupChange">
            <view class="popup-container">
                <view class="popup-header">
                    <view class="popup-header-title">核销优惠券</view>
                    <view class="popup-header-close">
                        <t-icon name="close" size="24px" @click="verifyVisible = false"/>
                    </view>
                </view>
                <view class="popup-body">
                    <t-cell-group theme="card">
                        <m-store-select v-model:value="form.storeId" title="核销门店" :multiple="false"
                                        :auto-selected="true" gateway="/seller/coupon/verify/stores"
                                        :params="{couponId:couponInfo.couponId}"></m-store-select>
                    </t-cell-group>
                    <t-cell-group t-class="mt-2" theme="card">
                        <t-textarea
                            custom-style="height:260rpx"
                            placeholder="请输入核销备注（选填，仅商家可见）"
                            v-model:value="form.remark"
                            :maxlength="32"
                            :indicator="true"
                            :cursor-spacing="120"
                        />
                    </t-cell-group>
                    <view class="text-center text-small text-muted mt-2">
                        小技巧：使用微信扫一扫，可快速核销
                    </view>

                </view>
                <view class="popup-footer">
                    <t-button
                        theme="danger"
                        size="large"
                        block
                        t-class="mt-3"
                        :loading="submitLoading"
                        @click="onConfirmVerify"
                    >确认核销
                    </t-button>
                </view>
            </view>
        </t-popup>

        <!-- 作废确认弹框 -->
        <t-popup placement="bottom" :visible="discardVisible" @visible-change="onDiscardPopupChange">
            <view class="popup-container">
                <view class="popup-header">
                    <view class="popup-header-title">作废优惠券</view>
                    <view class="popup-header-close">
                        <t-icon name="close" size="24px" @click="discardVisible = false"/>
                    </view>
                </view>
                <view class="popup-body">
                    <t-cell-group theme="card">
                        <t-textarea
                            custom-style="height:300rpx"
                            placeholder="请输入作废原因（仅商家可见）"
                            v-model:value="discardForm.reason"
                            :maxlength="32"
                            :indicator="true"
                            :cursor-spacing="120"
                        />
                    </t-cell-group>
                </view>
                <view class="popup-footer">
                    <t-button
                        theme="danger"
                        size="large"
                        block
                        t-class="mt-3"
                        :loading="discardLoading"
                        @click="onConfirmDiscard"
                    >确认作废
                    </t-button>
                </view>
            </view>
        </t-popup>

        <m-submit v-if="canVerify" :loading="submitLoading" :disabled="submitLoading" @click="onSubmit">确认核销</m-submit>
    </view>
    <view v-else class="empty-state-container">
        <view class="empty-state-icon">
            <t-icon name="scan" size="120rpx" color="#d9d9d9"/>
        </view>
        <view class="empty-state-title">请扫描或输入优惠券码</view>
        <view class="empty-state-description">
            点击顶部扫码按钮或直接输入券码进行核销
        </view>
        <view class="empty-state-tips">
            <view class="tip-item">
                <t-icon name="qrcode" size="32rpx" color="#07c160"/>
                <text>支持扫描优惠券核销码</text>
            </view>
            <view class="tip-item">
                <t-icon name="edit-1" size="32rpx" color="#07c160"/>
                <text>支持手动输入优惠券编码</text>
            </view>
        </view>
    </view>

    <template v-if="verifyResult || (couponInfo && couponInfo.isVerify)">
        <m-submit @click="onReset">继续核销</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request.js'
import {COUPON_TYPE, RECEIVE_STATUS, isAmountFace, VERIFY_REWARD_STATUS} from '@/constants/coupon.js'
import {PERM_COUPON} from '@/constants/permission.js'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils'
import {useAuth} from "@/hooks/useAuth";
import config from '@/config'

const {isLoggedIn, isEntry, checkPermission, getSession, session} = useAuth();
const {push, reLaunch} = useLink()
const verifyCode = ref('')
const loading = ref(false)
const couponReceiveId = ref('')
const verifySign = ref('')
const verifySource = ref(2) // 1扫码 2手动券码
const couponInfo = ref()
const verifyResult = ref(null) // null=无结果, object=接口返回的完整数据
const submitLoading = ref(false)
const verifyVisible = ref(false)
const form = ref({storeId: '', remark: ''})
// 作废弹框显示状态
const discardVisible = ref(false)
// 作废提交中
const discardLoading = ref(false)
// 作废表单
const discardForm = ref({reason: ''})

// 核销页广告位 unit-id
const adUnitVerify = computed(() => {
    if (config.adUnit?.verify && session.value?.editionAllowAd) {
        return config.adUnit.verify
    }
    return ''
})

const formatDate = (t) => {
    if (!t) return ''
    return String(t).split(' ')[0]
}

const validStartDate = computed(() => formatDate(couponInfo.value?.validStartTime))
const validEndDate = computed(() => formatDate(couponInfo.value?.validEndTime))

// status 1 未使用；且未核销、未作废、未转赠中、二维码未过期
const canVerify = computed(() => {
    if (!couponInfo.value) return false
    if (couponInfo.value.status !== RECEIVE_STATUS.UNUSED) return false
    if (couponInfo.value.isVerify) return false
    if (couponInfo.value.transferLock) return false
    if (couponInfo.value.isQrcodeExpired) return false
    return true
})

// 未使用、未转赠中、本次未核销，且有作废权限时展示作废弱操作入口
const canDiscard = computed(() => {
    if (!couponInfo.value) return false
    if (couponInfo.value.status !== RECEIVE_STATUS.UNUSED) return false
    if (couponInfo.value.isVerify) return false
    if (couponInfo.value.transferLock) return false
    return checkPermission(PERM_COUPON.RECEIVE_DISCARD)
})

const hasAnyReward = computed(() =>
    verifyResult.value?.isVerifyReward || verifyResult.value?.isTransferReward
)

const hasRewardFail = computed(() => {
    const r = verifyResult.value
    if (!r?.isVerify) return false
    return (r.isVerifyReward && r.verifyRewardStatus === VERIFY_REWARD_STATUS.FAILED)
        || (r.isTransferReward && r.transferRewardStatus === VERIFY_REWARD_STATUS.FAILED)
})

const hasRewardCompensate = computed(() => {
    const r = verifyResult.value
    if (!r?.isVerify) return false
    return (r.isVerifyReward && r.verifyRewardStatus === VERIFY_REWARD_STATUS.COMPENSATE)
        || (r.isTransferReward && r.transferRewardStatus === VERIFY_REWARD_STATUS.COMPENSATE)
})

const resultType = computed(() => {
    if (!verifyResult.value?.isVerify) return 'danger'
    return 'success'
})

const resultTitle = computed(() => {
    if (!verifyResult.value?.isVerify) return '核销失败'
    return '核销成功'
})

const resultDescription = computed(() => {
    const r = verifyResult.value
    if (!r?.isVerify) return r?.message || '核销失败'
    const name = couponInfo.value?.couponName || '优惠券'
    if (hasRewardFail.value) return `「${name}」已核销，部分奖励失败`
    if (hasRewardCompensate.value) return `「${name}」已核销，部分奖励待补偿`
    return `「${name}」已核销`
})

const rewardStatusLabelMap = {
    [VERIFY_REWARD_STATUS.SUCCESS]: '奖励成功',
    [VERIFY_REWARD_STATUS.FAILED]: '奖励失败',
    [VERIFY_REWARD_STATUS.COMPENSATE]: '待补偿',
}
const rewardStatusLabel = (status) => rewardStatusLabelMap[status] || '-'
const showRewardReason = (status) =>
    status === VERIFY_REWARD_STATUS.FAILED || status === VERIFY_REWARD_STATUS.COMPENSATE
const rewardTagTheme = (status) => {
    if (status === VERIFY_REWARD_STATUS.SUCCESS) return 'success'
    if (status === VERIFY_REWARD_STATUS.COMPENSATE) return 'warning'
    return 'danger'
}
const rewardTagTextClass = (status) => {
    if (status === VERIFY_REWARD_STATUS.SUCCESS) return 'text-success'
    if (status === VERIFY_REWARD_STATUS.COMPENSATE) return 'text-warning'
    return 'text-danger'
}
// 奖励图标颜色：成功绿 / 待补偿橙 / 失败红
const rewardIconColor = (status) => {
    if (status === VERIFY_REWARD_STATUS.SUCCESS) return '#07c160'
    if (status === VERIFY_REWARD_STATUS.COMPENSATE) return '#ed7b2f'
    return '#e2453d'
}

// 搜索核销码
const onSearch = () => {
    const code = verifyCode.value.trim()
    if (!code) {
        utils.toast('请输入优惠券券码')
        return
    }
    couponReceiveId.value = code
    getCouponInfo(2)
}

const getCouponInfo = (source) => {// 1:扫码 2:输入券码
    if (!isLoggedIn.value) {
        wx.showModal({
            title: '提示',
            content: '您还未登录，请先登录！',
            showCancel: false,
            success: () => {
                reLaunch('/pages/merchant/index')
            }
        })
        return
    }
    if (!isEntry.value) {
        wx.showModal({
            title: '提示',
            content: '您还未加入商家，请先加入！',
            showCancel: false,
            success: () => {
                reLaunch('/pages/merchant/index')
            }
        })
        return
    }
    verifySource.value = source
    loading.value = true
    couponInfo.value = undefined
    verifyResult.value = null
    form.value = {remark: ''}
    const params = {
        couponReceiveId: couponReceiveId.value,
        source: source,
    }
    if (source === 1) {
        params.verifySign = verifySign.value
    }

    request.get('/seller/coupon/verify/info', params).then((res) => {
        couponInfo.value = res.data
    }).catch(() => {
        couponInfo.value = null
    }).finally(() => {
        loading.value = false
    })
}

const onVerifyPopupChange = (e) => {
    const visible = e && typeof e === 'object' ? e.visible : !!e
    verifyVisible.value = visible
    if (!visible) {
        form.value.remark = ''
    }
}

// 作废弹框显示/隐藏，关闭时清空作废原因
const onDiscardPopupChange = (e) => {
    const visible = e && typeof e === 'object' ? e.visible : !!e
    discardVisible.value = visible
    if (!visible) {
        discardForm.value = {reason: ''}
    }
}

// 确认作废优惠券，成功后刷新券信息展示作废状态
const onConfirmDiscard = () => {
    discardLoading.value = true
    request.post('/seller/coupon/receive/discard', {
        id: couponReceiveId.value,
        reason: discardForm.value.reason,
    }).then(() => {
        utils.toast('作废成功')
        discardVisible.value = false
        getCouponInfo(verifySource.value)
    }).catch((err) => {
        utils.toast(err.message || '作废失败')
    }).finally(() => {
        discardLoading.value = false
    })
}

const onSubmit = () => {
    if (!canVerify.value) {
        utils.toast('该券不可核销')
        return
    }
    verifyVisible.value = true
}

const onConfirmVerify = () => {
    if (!form.value.storeId) {
        utils.toast('请选择核销门店')
        return
    }
    submitLoading.value = true
    const data = {
        couponReceiveId: couponReceiveId.value,
        source: verifySource.value,
        remark: form.value.remark,
    }
    if (verifySource.value === 1) {
        data.verifySign = verifySign.value
    }
    if (form.value.storeId) {
        data.storeId = form.value.storeId
    }
    request.post('/seller/coupon/verify', data, {disableErrorToast: true}).then((res) => {
        verifyVisible.value = false
        verifyResult.value = {...res.data, message: res.message}
        couponInfo.value = {...couponInfo.value, status: 2, isVerify: true}
    }).catch((err) => {
        verifyVisible.value = false
        verifyResult.value = {isVerify: false, message: err?.message || '核销失败'}
    }).finally(() => {
        submitLoading.value = false
    })
}

//扫码核销
const onScan = () => {
    couponInfo.value = undefined
    uni.scanCode({
        success: (res) => {
            console.log('扫码成功：', res)
            if (res.path) {
                var path = ''
                if (!res.path.startsWith('/')) {
                    path = '/' + res.path
                } else {
                    path = res.path
                }
                // 从路径中提取 scene 参数填入输入框并自动搜索
                const match = path.match(/scene=([^&]+)/)
                if (!match?.[1]) {
                    utils.toast('请提供正确的优惠券核销码')
                    return
                }
                decodeScene(match[1])
            } else {
                utils.toast('请提供正确的优惠券核销码')
            }
        },
        fail: (err) => {
            console.log('扫码失败：', err)
            if (err.errMsg !== 'scanCode:fail cancel') {
                utils.toast(err.errMsg)
            }
        }
    })
}

// 重置到初始状态
const onReset = () => {
    verifyCode.value = ''
    couponReceiveId.value = ''
    verifySign.value = ''
    verifySource.value = 2
    // couponInfo.value = undefined
    verifyResult.value = null
    form.value = {remark: ''}
    onScan()
}

const decodeScene = (scene) => {
    const arr = String(scene).split('-')
    if (arr.length !== 2) {
        utils.toast('请提供正确的优惠券核销码')
        return
    }
    couponReceiveId.value = arr[0]
    verifySign.value = arr[1]
    getCouponInfo(1)
}

onLoad((options) => {
    // 扫码进入：从 scene 解析券码
    if (options.scene) {
        decodeScene(options.scene)
    }
    if (isEntry.value) {
        getSession()
    }

})
</script>

<style scoped>
.coupon {
    position: relative;
    background: #fff;
    border-radius: 20rpx;
    padding: 32rpx;
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    -webkit-mask-image: radial-gradient(circle at 9px 50%, transparent 9px, red 9.5px);
    -webkit-mask-position: -9px;
}

.coupon-header {
    order: 1; /* 设置更大的 order 值，把它挤到最后 */
    width: 180rpx;
    flex-shrink: 0;
    overflow: hidden;
    text-align: center;
}

.coupon-face {
    display: inline-block;
    color: #e84c59;
    position: relative;
}

.coupon-face-unit {
    position: absolute;
    left: -25rpx;
    top: 8rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-face-font {
    margin-top: 6rpx;
    margin-left: 4rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-face-money {
    font-weight: bold;
    font-size: 60rpx;
}

.coupon-type {
    margin-top: 5rpx;
    color: #e84c59;
    font-size: 24rpx;
}

.coupon-body {
    flex: 1;
    margin-left: 20rpx;
}

.coupon-name {
    font-weight: 600;
    font-size: 32rpx;
    margin-bottom: 12rpx;;
}

.coupon-threshold {
    color: #666;
    font-size: 28rpx;
}

.coupon-valid {
    color: #666;
    font-size: 28rpx;
    margin-top: 5rpx;
}

.coupon-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    border-top: #f3f3f3 1px solid;
    margin-top: 20rpx;
    padding-top: 20rpx;
    font-size: 24rpx;
    color: #666;
    order: 3;
    flex: 0 0 100%;
}

.coupon-validity {
    font-size: 24rpx;
    color: #999;
}

.coupon-status {
    font-size: 24rpx;
    padding: 4rpx 16rpx;
    border-radius: 8rpx;
    flex-shrink: 0;
}

.status-1 {
    background-color: rgba(7, 193, 96, 0.1);
    color: #07c160;
}

.status-2 {
    background-color: rgba(33, 150, 243, 0.1);
    color: #2196f3;
}

.status-3 {
    background-color: rgba(255, 152, 0, 0.1);
    color: #ff9800;
}

.status-4 {
    background-color: rgba(153, 153, 153, 0.1);
    color: #999;
}

.popup-body {
    height: 550rpx;
}

.textarea-wrapper {
    margin: 24rpx 0;
}

.popup-footer {
    display: flex;
    gap: 24rpx;
    padding: 24rpx 24rpx calc(24rpx + env(safe-area-inset-bottom));
}

/* 空状态样式 */
.empty-state-container {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 120rpx 48rpx;
    min-height: 60vh;
}

.empty-state-icon {
    margin-bottom: 40rpx;
    opacity: 0.5;
}

.empty-state-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
    margin-bottom: 16rpx;
    text-align: center;
}

.empty-state-description {
    font-size: 26rpx;
    color: #999;
    text-align: center;
    line-height: 1.6;
    margin-bottom: 60rpx;
}

.empty-state-tips {
    width: 100%;
    max-width: 480rpx;
}

.tip-item {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 20rpx 24rpx;
    background: #fff;
    border-radius: 12rpx;
    margin-bottom: 16rpx;
    box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.04);
}

.tip-item text {
    margin-left: 16rpx;
    font-size: 26rpx;
    color: #666;
}

.reward-section-title {
    font-size: 26rpx;
    color: #999;
    margin-bottom: 16rpx;
    padding-left: 4rpx;
}

.reward-item {
    padding: 24rpx 0;
    border-bottom: 1rpx solid #f0f0f0;
}

.reward-item:last-child {
    border-bottom: none;
}

.reward-item-main {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16rpx;
}

.reward-item-left {
    display: flex;
    align-items: flex-start;
    gap: 16rpx;
    flex: 1;
    min-width: 0;
}

.reward-item-text {
    display: flex;
    flex-direction: column;
    gap: 6rpx;
}

.reward-item-name {
    text-align: left;
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.reward-item-desc {
    font-size: 24rpx;
    color: #999;
    line-height: 1.5;
}

.reward-item-reason {
    margin-top: 16rpx;
    padding: 16rpx;
    background: rgba(226, 69, 61, 0.06);
    border-radius: 8rpx;
    font-size: 24rpx;
    color: #d73050;
    line-height: 1.5;
}

</style>
