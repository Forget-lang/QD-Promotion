<template>
    <m-loading v-if="detail === undefined"></m-loading>
    <m-empty v-else-if="detail === null">核销记录不存在</m-empty>
    <template v-else>
        <view class="container-safety">
            <!-- 优惠券概览 -->
            <view class="container mt-2">
                <view class="coupon">
                    <!-- 头部：券类型 + 状态 -->
                    <view class="coupon-header">
                        <t-tag theme="danger" size="small">{{ detail.couponTypeLabel }}</t-tag>
                        <t-tag :theme="statusTheme[detail.status]" size="small" variant="light-outline">
                            {{ detail.statusLabel }}
                        </t-tag>
                    </view>
                    <view class="coupon-line"></view>
                    <!-- 主体：券名 + 面额 -->
                    <view class="coupon-body">
                        <view class="coupon-content">
                            <view class="coupon-name text-ellipsis-break">{{ detail.couponName }}</view>
                            <view class="coupon-valid">{{ detail.threshold }}</view>
                        </view>
                        <view class="coupon-value">
                            <!-- 代金券、套餐券、满减券、手气券 -->
                            <view class="coupon-face"
                                  v-if="isAmountFace(detail.couponType)">
                                <text class="coupon-face-unit">￥</text>
                                <text class="coupon-face-money">{{ detail.couponAmount }}</text>
                            </view>
                            <!-- 折扣券 -->
                            <view class="coupon-face" v-else-if="detail.couponType === COUPON_TYPE.DISCOUNT">
                                <text class="coupon-face-money">{{ detail.couponAmount }}</text>
                                <text class="coupon-face-font">折</text>
                            </view>
                            <!-- 兑换券 -->
                            <view class="coupon-face" v-else-if="detail.couponType === COUPON_TYPE.EXCHANGE">
                                <t-icon name="gift-filled" color="e84c59" size="64rpx"></t-icon>
                            </view>
                        </view>
                    </view>
                    <view class="coupon-line"></view>
                    <!-- 脚部：有效期 -->
                    <view class="coupon-footer">
                        <view class="coupon-footer-label">有效期</view>
                        <view class="coupon-footer-value">{{ validStartDate }} 至 {{ validEndDate }}</view>
                    </view>
                </view>
            </view>
            <!-- /优惠券概览 -->

            <!-- 领取客户（可跳转客户详情） -->
            <t-cell-group title="领取客户" t-title-class="mt-2" theme="card" v-if="detail.userId">
                <t-cell
                    :image="detail.avatar"
                    :title="detail.nickname || '-'"
                    :description="detail.mobile || '未绑定手机'"
                    arrow
                    hover
                    @tap="onViewCustomer"
                />
            </t-cell-group>

            <!-- 核销信息 -->
            <t-cell-group title="核销信息" t-title-class="mt-2" theme="card">
                <t-cell title="核销状态" :note="detail.statusLabel"/>
                <t-cell title="核销门店" :note="detail.verifyStoreName || '-'"/>
                <t-cell title="核销员工" :note="detail.verifyStaffName || '-'"/>
                <t-cell title="核销时间" :note="detail.verifyAt || '-'"/>
                <t-cell title="核销备注" :note="detail.verifyRemark || '无'"/>
            </t-cell-group>

            <!-- 发放信息 -->
            <t-cell-group title="发放信息" t-title-class="mt-2" theme="card">
                <t-cell title="发券门店" :note="detail.issueStoreName || '-'"/>
                <t-cell title="发券员工" :note="detail.issueStaffName || '-'"/>
                <t-cell title="发放备注" :note="detail.issueRemark || '无'"/>
            </t-cell-group>

            <!-- 奖励情况 -->
            <t-cell-group title="奖励情况" t-title-class="mt-2" theme="card">
                <t-cell title="核销奖励" :note="detail.isVerifyReward ? '有' : '无'"/>
                <t-cell
                    v-if="detail.isVerifyReward"
                    title="核销奖励状态"
                    :note="rewardStatusLabel(detail.verifyRewardStatus)"
                />
                <t-cell
                    v-if="detail.isVerifyReward && showRewardReason(detail.verifyRewardStatus, detail.verifyRewardFailReason)"
                    :title="rewardReasonTitle(detail.verifyRewardStatus, '核销奖励')"
                    :note="detail.verifyRewardFailReason || '-'"
                />
                <t-cell title="转赠奖励" :note="detail.isTransferReward ? '有' : '无'"/>
                <t-cell
                    v-if="detail.isTransferReward"
                    title="转赠奖励状态"
                    :note="rewardStatusLabel(detail.transferRewardStatus)"
                />
                <t-cell
                    v-if="detail.isTransferReward && showRewardReason(detail.transferRewardStatus, detail.transferRewardFailReason)"
                    :title="rewardReasonTitle(detail.transferRewardStatus, '转赠奖励')"
                    :note="detail.transferRewardFailReason || '-'"
                />
            </t-cell-group>
        </view>
    </template>
</template>

<script setup>
import {ref, computed} from 'vue'
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import { RESPONSE_CODE } from '@/constants/code'
import {COUPON_TYPE, isAmountFace, VERIFY_REWARD_STATUS} from '@/constants/coupon'
import {useLink} from '@/hooks/useLink'
import utils from '@/utils/utils'

const {push} = useLink()
const verifyId = ref('')
const detail = ref()

// 状态标签主题映射（按 status：1 已核销 / 2 已撤回）
const statusTheme = {
    1: 'success',
    2: 'warning'
}

const rewardStatusLabelMap = {
    [VERIFY_REWARD_STATUS.DEFAULT]: '-',
    [VERIFY_REWARD_STATUS.SUCCESS]: '奖励成功',
    [VERIFY_REWARD_STATUS.FAILED]: '奖励失败',
    [VERIFY_REWARD_STATUS.COMPENSATE]: '待补偿',
}

const rewardStatusLabel = (status) => rewardStatusLabelMap[status] || '-'
// 失败必展示原因；待补偿有原因时展示（库存不足等）
const showRewardReason = (status, reason) => {
    if (status === VERIFY_REWARD_STATUS.FAILED) return true
    if (status === VERIFY_REWARD_STATUS.COMPENSATE) return !!reason
    return false
}
const rewardReasonTitle = (status, prefix) =>
    status === VERIFY_REWARD_STATUS.COMPENSATE ? `${prefix}待补偿原因` : `${prefix}失败原因`

const getDetail = () => {
    request.get('/seller/coupon/verify/detail', {id: verifyId.value}).then((res) => {
        detail.value = res.data
        uni.setNavigationBarTitle({title: res.data.couponName || '核销详情'})
    }).catch((err) => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            detail.value = null
        }
    })
}

const formatDate = (t) => {
    if (!t) return ''
    return String(t).split(' ')[0].replace(/-/g, '/')
}

const validStartDate = computed(() => formatDate(detail.value?.validStartTime))
const validEndDate = computed(() => formatDate(detail.value?.validEndTime))

// 跳转客户详情
const onViewCustomer = () => {
    if (!detail.value?.userId) {
        return
    }
    push('/pages_merchant/customer/detail?userId=' + detail.value.userId)
}

onLoad((e) => {
    if (!e.id) {
        utils.toast('缺少核销记录ID')
        setTimeout(() => uni.navigateBack(), 1500)
        return
    }
    verifyId.value = e.id
    getDetail()
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})
</script>

<style scoped>
.coupon {
    position: relative;
    background: #fff;
    border-radius: 20rpx;
    margin-bottom: 20rpx;
}

/* 头部：券类型 + 状态 */
.coupon-header {
    padding: 32rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/* 主体 */
.coupon-body {
    padding: 10rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.coupon-content {
    flex: 1;
    min-width: 0;
    padding-right: 16rpx;
}

.coupon-name {
    font-weight: 600;
    font-size: 32rpx;
    color: #181818;
    margin-bottom: 12rpx;
}

.coupon-valid {
    color: #666;
    font-size: 28rpx;
}

.coupon-value {
    max-width: 260rpx;
    flex-shrink: 0;
    overflow: hidden;
    text-align: right;
}

.coupon-face {
    color: #e84c59;
    position: relative;
    display: flex;
    align-items: start;
    justify-content: flex-end;
}

.coupon-face-unit {
    font-weight: 600;
    font-size: 28rpx;
    margin-right: 2rpx;
    margin-top: 6rpx;
}

.coupon-face-font {
    margin-top: 6rpx;
    margin-left: 4rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-face-money {
    font-weight: bold;
    font-size: 56rpx;
}

/* 脚部：有效期 */
.coupon-footer {
    padding: 0 32rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 26rpx;
}

.coupon-footer-label {
    color: #999;
    flex-shrink: 0;
}

.coupon-footer-value {
    color: #999;
    margin-left: 16rpx;
    text-align: right;
}

/* 凹槽背景色对齐页面背景 */
.coupon-line::before,
.coupon-line::after {
    background-color: #f6f6f6;
}
</style>
