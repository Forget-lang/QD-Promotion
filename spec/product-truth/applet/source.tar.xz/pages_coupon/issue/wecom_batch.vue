<template>
    <m-loading v-if="corp === undefined"></m-loading>
    <template v-else-if="corp">
        <view class="container mt-2">
            <view class="tips-card">
                <text class="tips-title">功能介绍</text>
                <view class="tips-item">
                    <text class="tips-text">
                        创建群发任务后，所选成员会在企业微信收到待确认通知，确认后才会发给其名下全部客户。
                    </text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">每位客户每月可接收的群发条数有限，超限客户可能收不到。</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">适合会员日、节日、活动等对存量客户的触达。</text>
                </view>
            </view>
        </view>

        <template v-if="corp.status === CORP_STATUS.UNAUTHORIZED">
            <view class="container mt-2">
                <view class="section section-body">
                    <m-result type="info" title="企业微信未授权"
                              description="请企业微信管理员先授权企业微信，然后进行配置。">
                        <template #actions>
                            <t-button theme="primary" @click="push('/pages_wecom/wecom/auth')">授权企业微信</t-button>
                        </template>
                    </m-result>
                </view>
            </view>
        </template>

        <template v-else-if="corp.status === CORP_STATUS.AUTHORIZED">
            <template v-if="!created">
                <view class="container-safety">
                    <t-cell-group theme="card" t-class="mt-2">
                        <m-loading v-if="members === undefined"></m-loading>
                        <t-cell v-else title="发送成员" arrow hover required @click="onOpenCorpUser">
                            <template #note>
                                <ww-open-data v-if="form.corpUserId" type="userName" :corpid="corpId"
                                              :openid="form.corpUserId"></ww-open-data>
                                <text v-else class="lh-24">请选择企业成员</text>
                            </template>
                        </t-cell>
                        <t-input label="卡片标题" v-model:value="form.shareTitle" align="right"
                                 placeholder="例如：会员专享，点击领取。" :maxlength="64"></t-input>
                    </t-cell-group>


                    <view class="container">
                        <view class="section mt-2">
                            <view class="section-header">
                                <view class="section-title">消息内容<text class="required-mark">*</text></view>
                            </view>
                            <t-textarea v-model:value="form.content" :bordered="true"
                                        custom-style="margin: 0 24rpx 30rpx; height: 280rpx;"
                                        placeholder="请输入消息内容（必填，每次发放时与优惠券卡片一起显示）">
                            </t-textarea>
                        </view>

                        <view class="section mt-2">
                            <view class="section-header">
                                <view class="section-title">发放备注</view>
                            </view>
                            <t-textarea v-model:value="form.issueRemark" :bordered="true" :maxlength="32" :indicator="true"
                                        custom-style="margin: 20rpx 24rpx; height: 280rpx;"
                                        placeholder="请输入备注信息（选填，仅商家可见，客户不可见）">
                            </t-textarea>
                        </view>
                    </view>
                </view>

                <t-popup v-model:visible="showCorpUserPopup" placement="bottom">
                    <view class="popup-header">
                        <view class="popup-header-cancel" @click="onCancelCorpUser">取消</view>
                        <view class="popup-header-title">请选择企业成员</view>
                        <view class="popup-header-confirm" @click="onConfirmCorpUser">确定</view>
                    </view>
                    <scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
                        <m-empty v-if="!members || members.length === 0" description="暂无可选成员"></m-empty>
                        <t-radio-group v-else v-model:value="tempCorpUserId">
                            <t-radio v-for="item in members" :key="item.corpUserId"
                                     :value="item.corpUserId">
                                <ww-open-data type="userName" :corpid="corpId"
                                              :openid="item.corpUserId"></ww-open-data>
                            </t-radio>
                        </t-radio-group>
                    </scroll-view>
                </t-popup>

                <m-submit @click="onSubmit" :loading="loading" :disabled="loading">创建群发任务</m-submit>
            </template>

            <view v-else class="container mt-2">
                <!-- 结果头部：图标 + 标题 + 描述 -->
                <view class="section section-body result-hero">
                    <t-icon name="check-circle-filled" color="var(--td-brand-color)" size="120rpx"/>
                    <view class="result-hero-title">群发任务已创建</view>
                    <view class="result-hero-desc">请通知所选成员打开企业微信，在「客户联系 · 群发助手」中确认发送，确认前客户不会收到消息。</view>
                </view>

<!--                &lt;!&ndash; 任务 ID 卡片：整卡点击复制 &ndash;&gt;-->
<!--                <view class="section task-card mt-2" hover-class="task-card-hover" hover-stay-time="80"-->
<!--                      @click="utils.copyClipboard(created.msgid, '任务ID已复制')">-->
<!--                    <view class="task-card-label">任务 ID</view>-->
<!--                    <view class="task-card-value">{{ created.msgid || '' }}</view>-->
<!--                    <view class="task-card-action">-->
<!--                        <t-icon name="file-copy" size="28rpx" color="var(&#45;&#45;td-brand-color)"/>-->
<!--                        <text class="task-card-action-text">点击复制</text>-->
<!--                    </view>-->
<!--                </view>-->

<!--                <view class="d-flex justify-content-center mt-4">-->
<!--                    <t-button theme="primary" variant="outline" @click="resetForm">再发一次</t-button>-->
<!--                </view>-->
            </view>
        </template>
    </template>

    <!-- VIP 升级抽屉：承接群发接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {CORP_STATUS} from '@/constants/wecom'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import MResult from '@/components/m/m-result/m-result.vue'

const {push} = useLink()

const couponId = ref('')
const corp = ref()
const corpId = ref('')
const members = ref()
const loading = ref(false)
const created = ref(null)
const showCorpUserPopup = ref(false)
const tempCorpUserId = ref('')

const form = ref({
    corpUserId: '',
    shareTitle: '',
    content: '',
    issueRemark: '',
})

const getCorp = () => {
    return request.get('/seller/wecom/corp').then(res => {
        corp.value = res.data
        if (res.data.status === CORP_STATUS.AUTHORIZED) {
            getMembers()
        }
    })
}

const getMembers = () => {
    request.get('/seller/wecom/follow-users').then(res => {
        corpId.value = res.data.corpId
        members.value = res.data.items || []
    }).catch(err => {
        members.value = []
        utils.toast(err.message)
    })
}

const onOpenCorpUser = () => {
    if (members.value === undefined) {
        return
    }
    tempCorpUserId.value = form.value.corpUserId || ''
    showCorpUserPopup.value = true
}

const onCancelCorpUser = () => {
    showCorpUserPopup.value = false
}

const onConfirmCorpUser = () => {
    form.value.corpUserId = tempCorpUserId.value || ''
    showCorpUserPopup.value = false
}

const onSubmit = () => {
    if (!form.value.corpUserId) {
        utils.toast('请选择企业成员')
        return
    }
    if (!form.value.shareTitle) {
        utils.toast('请填写卡片标题')
        return
    }
    if (!form.value.content) {
        utils.toast('请输入消息内容')
        return
    }
    loading.value = true
    request.post('/seller/wecom/batch/create', {
        couponId: couponId.value,
        corpUserId: form.value.corpUserId,
        shareTitle: form.value.shareTitle,
        content: form.value.content,
        issueRemark: form.value.issueRemark,
    }, {showLoading: true}).then(res => {
        created.value = res.data
        utils.toast('创建成功')
    }).catch(err => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

const resetForm = () => {
    created.value = null
    form.value.corpUserId = ''
}

onLoad((e) => {
    couponId.value = e.couponId || ''
    if (e.shareTitle) {
        form.value.shareTitle = decodeURIComponent(e.shareTitle)
    }
    getCorp()
})
</script>

<script>
export default {
    options: {
        styleIsolation: 'shared',
    },
}
</script>

<style scoped>
/* 文本域标题，与 TDesign label 字号对齐 */
.textarea-label {
    font-size: 28rpx;
    line-height: 44rpx;
    color: var(--td-text-color-primary, rgba(0, 0, 0, 0.9));
}

/* 必填星号，使用主题错误色 */
.required-mark {
    margin-left: 4rpx;
    color: var(--td-error-color, #e34d59);
}

/*
 * 自定义样式原因：群发成功区为「结果头部 + 整卡可点任务ID卡」组合，
 * m-result 是整页结果组件（result-action 带 200rpx 上边距），不适合卡片内嵌套内容；app.css 无整卡可点复制卡。
 * 替代方案：基于 section 卡片派生结果头部与任务卡，颜色取 --td-brand-color，仅补缺位视觉层。
 */
.result-hero {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding-top: 64rpx;
    padding-bottom: 64rpx;
}

.result-hero-title {
    font-size: 36rpx;
    font-weight: 600;
    color: #191919;
    margin-top: 32rpx;
}

.result-hero-desc {
    font-size: 26rpx;
    color: #888;
    line-height: 1.7;
    text-align: center;
    margin-top: 20rpx;
    padding: 0 32rpx;
}

.task-card {
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 40rpx 32rpx;
}

.task-card-hover {
    background-color: #FAFAFA;
}

.task-card-label {
    font-size: 24rpx;
    color: #999;
}

.task-card-value {
    font-size: 30rpx;
    font-weight: 500;
    color: #333;
    font-family: 'Courier New', monospace;
    letter-spacing: 1rpx;
    margin-top: 16rpx;
    word-break: break-all;
    text-align: center;
}

.task-card-action {
    display: flex;
    align-items: center;
    margin-top: 24rpx;
    padding: 10rpx 32rpx;
    background-color: var(--td-brand-color-light);
    border-radius: 999rpx;
}

.task-card-action-text {
    font-size: 24rpx;
    color: var(--td-brand-color);
    margin-left: 8rpx;
}
</style>
