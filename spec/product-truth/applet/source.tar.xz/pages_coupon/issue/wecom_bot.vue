<template>
    <m-loading v-if="corp === undefined"></m-loading>
    <template v-if="corp">
        <view class="container mt-2">
            <view class="tips-card">
                <text class="tips-title">功能介绍</text>
                <view class="tips-item">
                    <text class="tips-text">企微群开启小助理，群内客户@小助理，输入关键字（可自定义）即可让群成员自助领券。
                    </text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">比如输入“领券”口令，即可自助领券</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">适合企业微信群内日常发券任务。</text>
                </view>
            </view>
        </view>
        <template v-if="corp.status === CORP_STATUS.UNAUTHORIZED">
            <view class="container mt-2">
                <view class="section section-body">
                    <!-- 未授权 -->
                    <m-result type="info" title="企业微信未授权"
                              description="请企业微信管理员先授权企业微信，然后进行配置。">
                        <template #actions>
                            <t-button theme="primary" @click="push('/pages_wecom/wecom/auth')">授权企业微信</t-button>
                        </template>
                    </m-result>
                </view>
            </view>
        </template>
        <template v-else-if="corp.status === CORP_STATUS.AUTHORIZED">
            <m-loading v-if="issueParam === undefined"></m-loading>
            <view v-else class="container container-safety">
                <view class="section section-body mt-2">
                    <view class="media">
                        <view class="media-header">
                            <t-icon name="logo-miniprogram-filled" size="60rpx" color="#605AB0"/>
                        </view>
                        <view class="media-body">
                            <view class="media-content">
                                <view class="lh-25">小程序AppID</view>
                                <view class="text-small text-muted">{{ issueParam.appId || '' }}</view>
                            </view>
                            <view class="media-action">
                                <view class="button-gold"
                                      @click="utils.copyClipboard(issueParam.appId,'小程序AppID已复制')">
                                    复制
                                </view>
                            </view>
                        </view>
                    </view>
                </view>

                <view class="section section-body mt-2">
                    <view class="media">
                        <view class="media-header">
                            <t-icon name="logo-wechat-stroke-filled" size="60rpx" color="#03da6b"/>
                        </view>
                        <view class="media-body">
                            <view class="media-content">
                                <view class="lh-25">小程序路径</view>
                                <view class="text-small text-muted text-scroll-hidden" style="max-width: 380rpx">
                                    {{ issueParam.appletPath || '' }}
                                </view>
                            </view>
                            <view class="media-action">
                                <view class="button-gold"
                                      @click="utils.copyClipboard(issueParam.appletPath,'小程序路径已复制')">复制
                                </view>
                            </view>
                        </view>
                    </view>
                </view>
                <view class="mt-5 d-flex justify-content-center">
                    <t-button theme="primary" @click="push('/pages_wecom/bot/help')">详细使用教程</t-button>
                </view>
            </view>
        </template>
    </template>
    <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import {CORP_STATUS} from "@/constants/wecom";
import {CHANNEL_TYPE} from "@/constants/common";
import utils from "@/utils/utils";
import {useLink} from "@/hooks/useLink";
import MResult from "@/components/m/m-result/m-result.vue";

const {push} = useLink()
const couponId = ref('');
const issueParam = ref();

// 企微主体信息
const corp = ref()

// 获取企业关联的企业微信
const getCorp = () => {
    request.get('/seller/wecom/corp').then(res => {
        corp.value = res.data
        // 已授权
        if (res.data.status === CORP_STATUS.AUTHORIZED) {
            getIssueParam()
        }
    })
}

// 获取企微小助理发券参数
const getIssueParam = () => {
    request.post('/seller/coupon/public/issue/create', {couponId: couponId.value, channelType: CHANNEL_TYPE.WECOM_BOT}).then(res => {
        issueParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    couponId.value = e.couponId;
    getCorp()
})


</script>


<style scoped>

</style>
