<template>
    <m-loading v-if="issueParam === undefined"></m-loading>
    <view v-else class="container container-safety">
        <view class="tips-card mt-2">
            <text class="tips-title">使用说明</text>
            <view class="tips-item">
                <text class="tips-text">小程序AppID和路径可用于生成小程序码，或在公众号文章中添加小程序卡片</text>
            </view>
            <view class="tips-item">
                <text class="tips-text">公众号链接适用于公众号图文消息</text>
            </view>
            <view class="tips-item">
                <text class="tips-text">小程序短链接可直接在微信中打开</text>
            </view>
        </view>

        <view class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-miniprogram-filled" size="60rpx" color="#605AB0"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">小程序AppID</view>
                        <view class="text-small text-muted">{{ issueParam.appId || '' }}</view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold" @click="utils.copyClipboard(issueParam.appId,'小程序AppID已复制')">复制</view>
                    </view>
                </view>
            </view>
        </view>

        <view class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-wechat-stroke-filled" size="60rpx" color="#03da6b"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">小程序路径</view>
                        <view class="text-small text-muted text-scroll-hidden" style="max-width: 380rpx">{{ issueParam.appletPath || '' }}</view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold" @click="utils.copyClipboard(issueParam.appletPath,'小程序路径已复制')">复制</view>
                    </view>
                </view>
            </view>
        </view>

        <view class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-ie-filled" size="60rpx" color="#1280f5"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">公众号链接</view>
                        <view class="text-small text-muted text-scroll-hidden" style="max-width: 380rpx">{{ issueParam.appletHref || '' }}</view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold" @click="utils.copyClipboard(issueParam.appletHref,'公众号链接已复制')">复制</view>
                    </view>
                </view>
            </view>
        </view>

        <view v-if="issueParam.appletLink" class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-ie-filled" size="60rpx" color="#1280f5"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">小程序链接</view>
                        <view class="text-small text-muted text-scroll-hidden" style="max-width: 380rpx">{{ issueParam.appletLink || '' }}</view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold" @click="utils.copyClipboard(issueParam.appletLink,'小程序链接已复制')">复制</view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {onLoad} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import {CHANNEL_TYPE} from "@/constants/common";
import utils from "@/utils/utils";

const couponId = ref('');
const issueParam = ref();

const getIssueParam = () => {
    request.post('/seller/coupon/public/issue/create', {couponId: couponId.value, channelType: CHANNEL_TYPE.PUBLIC_OFFICIAL}).then(res => {
        issueParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    couponId.value = e.couponId;
    getIssueParam()
})


</script>


<style scoped>
</style>
