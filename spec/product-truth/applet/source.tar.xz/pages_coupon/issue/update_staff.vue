<template>
    <!-- 成功反馈 -->
    <m-result v-if="showSuccess" theme="success" title="修改成功" back></m-result>
    <template v-else>
        <!-- 发券员工设置 -->
        <t-cell-group theme="card" t-class="mt-2">
            <m-staff-select required title="指定员工" :multiple="true" :show-disabled="true"
                            v-model:value="form.staffIds"></m-staff-select>
        </t-cell-group>

        <!-- 邀请员工辅助发券 -->
        <view class="text-center mt-5">
            <text class="text-wechat" @click="push('/pages_merchant/staff/invite')">邀请员工辅助发券</text>
        </view>

        <!-- 提交按钮 -->
        <m-submit v-if="checkPermission(PERM_COUPON.UPDATE)" :loading="loading" :disabled="loading" @click="onSubmit">确认修改</m-submit>

        <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app';
import {ref} from 'vue';
import request from '@/hooks/request';
import utils from '@/utils/utils';
import {useLink} from '@/hooks/useLink';
import {useAuth} from '@/hooks/useAuth.js';
import {PERM_COUPON} from '@/constants/permission.js';

const {push, back} = useLink();
const {checkPermission} = useAuth()

// 优惠券ID
const couponId = ref('');
// 表单数据
const form = ref({
    isCustomIssueStaff: false,
    staffIds: []
});
// 加载状态
const loading = ref(false);
// 是否显示成功反馈
const showSuccess = ref(false);

// 获取优惠券信息
const getCouponInfo = () => {
    request.get('/seller/coupon/detail', {id: couponId.value}).then((res) => {
        form.value.staffIds = res.data.staffIds || []
    })
}

// 提交修改
const onSubmit = () => {
    if (!form.value.staffIds || form.value.staffIds.length === 0) {
        utils.toast('请至少选择一名发券员工');
        return;
    }
    loading.value = true;
    request.post('/seller/coupon/update-staffs', {
        id: couponId.value,
        staffIds: form.value.staffIds
    }).then(() => {
        showSuccess.value = true
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
};

onLoad((e) => {
    if (!e.couponId) {
        utils.toast('缺少优惠券ID');
        setTimeout(() => {
            back();
        }, 1500);
        return;
    }
    couponId.value = e.couponId;
    getCouponInfo();
});
</script>

<style scoped></style>