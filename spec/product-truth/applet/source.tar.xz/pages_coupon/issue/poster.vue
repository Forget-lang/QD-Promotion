<template>
    <m-loading v-if="issueParam === undefined"></m-loading>
    <view v-else class="container container-safety">
        <view class="tips-card mt-2">
            <text class="tips-title">使用说明</text>
            <view class="tips-item">
                <text class="tips-text">保存海报图片，客户使用微信扫一扫即可领取</text>
            </view>
            <view class="tips-item">
                <text class="tips-text">支持打印后线下发放，也可在线上图文消息中使用</text>
            </view>
        </view>

        <m-poster ref="posterRef" :width="750" :height="1334" @ready="onPosterReady" :pixel="2"></m-poster>

        <view class="section section-body mt-2">
            <view class="image-poster-container">
                <image v-if="posterUrl" class="image-poster" :src="posterUrl" mode="widthFix"></image>
                <m-loading v-else/>
            </view>
        </view>

        <t-button v-if="posterUrl" t-class="mt-3" theme="primary" size="large" block @click="onSavePoster">保存海报</t-button>
        <!--        <m-landscape :show="showLandscape" :position="2" iconTop="0rpx" iconRight="50rpx" :maskClosable="true" @close="onClose">-->
        <!--            <view class="landscape-poster">-->
        <!--                <image :src="posterUrl" mode="widthFix" style="width:100%;height:auto;border-radius: 16rpx;"></image>-->
        <!--            </view>-->
        <!--            <t-button theme="primary" size="large" block @click="onSavePoster">保存海报</t-button>-->
        <!--        </m-landscape>-->
    </view>
</template>

<script setup>
import {onLoad} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import {CHANNEL_TYPE} from "@/constants/common";
import {COUPON_TYPE} from "@/constants/coupon";
import utils from "@/utils/utils";
import {useSessionStore} from '@/stores/session.js'
import {saveImageToAlbum} from '@/hooks/useFile.js'

const session = useSessionStore()
const couponId = ref('');
const issueParam = ref();
const coupon = ref();

const posterRef = ref()
const isInit = ref(false)
const posterUrl = ref('')
const showLandscape = ref(false)
const qrcode = ref()
let posterData = []

const getCoupon = () => {
    request.get("/seller/coupon/detail", {
        id: couponId.value,
    }).then(res => {
        coupon.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

const getIssueParam = () => {
    request.post('/seller/coupon/public/issue/create', {couponId: couponId.value, channelType: CHANNEL_TYPE.PUBLIC_POSTER}).then(res => {
        issueParam.value = res.data
        qrcode.value = res.data.qrcode
        setTimeout(() => {
            posterDraw()
        }, 800)
    }).catch(err => {
        utils.toast(err.message)
    })
}

const setPosterJson = () => {
    posterData = []
    posterData = posterData.concat(bgImage) //海报背景
    posterData = posterData.concat(parseMerchant(coupon.value)) //商家信息
    posterData = posterData.concat(parseCoupon(coupon.value)) // 卡券信息
    posterData = posterData.concat(parseCouponType(coupon.value)) // 券类型
    if (coupon.value.stores.length > 1) {
        posterData = posterData.concat(parseShop(coupon.value))
    } else if (coupon.value.stores.length == 1) {
        posterData = posterData.concat(parseShopOne(coupon.value))
    }
    posterData = posterData.concat(parseLimit(coupon.value)) // 限领数量
    posterData = posterData.concat(parseRule(coupon.value)) // 须知
    posterData = posterData.concat(parseContent(coupon.value)) // 说明
    // posterData = posterData.concat(parseLeftFooter(session.data, props.channel))
    posterData = posterData.concat(parseQRCode(qrcode.value))
    console.log('posterData:', posterData)
}

//海报背景
let bgImage = [{
    type: 'image',
    imgType: 1,
    // src: 'https://cdn.lenmy.com/img/shop.png',
    src: '/pages_coupon/static/share-canvas-bg.png',
    style: {
        left: 0,
        top: 0,
        width: 750,
        height: 1334,
        borderRadius: 20,
    }
}]
//商家信息
const parseMerchant = (coupon) => {
    let logo
    let imgType
    if (session.merchantLogo !== '') {
        logo = session.merchantLogo
        imgType = 2
    } else {
        logo = '/static/img/3-store.png' //如果未设置Logo则使用默认图片
        imgType = 1
    }
    let merchantName
    if (session.merchantName !== '') {
        merchantName = session.merchantName
    } else {
        merchantName = '商户名称'
    }
    //产品图第一张
    let thumb
    if (coupon.cover) {
        thumb = coupon.cover
    } else {
        thumb = coupon.coverImages[0]
    }
    //
    // let industry = '所在行业'
    return [{
        type: 'image',
        imgType: imgType,
        src: logo,
        style: {
            left: 37,
            top: 38,
            width: 72,
            height: 72,
            borderRadius: 20,
        }
    },
        {
            type: 'text',
            text: merchantName,
            style: {
                left: 130,
                top: 85,
                width: 600,
                fontSize: 40,
                color: '#FFF',
                fontWeight: 'bold',
                textAlign: 'left',
                rows: 1,
                lineHeight: 36,
            }
        },
        // {
        //     type: 'text',
        //     text: industry,
        //     style: {
        //         left: 130,
        //         top: 105,
        //         width: 550,
        //         fontSize: 24,
        //         color: '#FFF',
        //         textAlign: 'left',
        //         rows: 1,
        //         lineHeight: 24,
        //     }
        // },
        {
            type: 'image',
            imgType: 2,
            src: thumb,
            style: {
                left: 37,
                top: 140,
                width: 691,
                height: 508,
                borderRadius: {topLeft: 40, topRight: 40, bottomRight: 0, bottomLeft: 0},
            }
        }
    ]
}

//卡券信息
const parseCoupon = (coupon) => {
    // 代金券(1)、套餐券(2)：faceAmount
    if (coupon.couponType === COUPON_TYPE.CASH || coupon.couponType === COUPON_TYPE.PACKAGE) {
        return [{
            type: 'text',
            text: '¥' + coupon.faceAmount,
            style: {
                left: 170,
                top: 784,
                width: 165,
                fontSize: 48,
                color: '#FA6120',
                fontWeight: 'bold',
                textAlign: 'center',
                lineHeight: 48,
            }
        },
            {
                type: 'text',
                text: coupon.threshold,
                style: {
                    left: 170,
                    top: 824,
                    width: 165,
                    fontSize: 24,
                    color: '#FA6120',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            },
            {
                type: 'text',
                text: coupon.name,
                style: {
                    left: 490,
                    top: 770,
                    width: 400,
                    fontSize: 28,
                    color: '#111',
                    textAlign: 'center',
                    lineHeight: 28,
                }
            },
            {
                type: 'text',
                text: coupon.validLabel,
                style: {
                    left: 490,
                    top: 830,
                    width: 400,
                    fontSize: 24,
                    color: '#999',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            }
        ]
    } else if (coupon.couponType === COUPON_TYPE.REDUCE) {
        //满减券：reduceAmount
        return [{
            type: 'text',
            text: '¥' + coupon.reduceAmount,
            style: {
                left: 170,
                top: 784,
                width: 165,
                fontSize: 48,
                color: '#FA6120',
                fontWeight: 'bold',
                textAlign: 'center',
                lineHeight: 48,
            }
        },
            {
                type: 'text',
                text: coupon.threshold,
                style: {
                    left: 170,
                    top: 824,
                    width: 165,
                    fontSize: 24,
                    color: '#FA6120',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            },
            {
                type: 'text',
                text: coupon.name,
                style: {
                    left: 490,
                    top: 770,
                    width: 400,
                    fontSize: 28,
                    color: '#111',
                    textAlign: 'center',
                    lineHeight: 28,
                }
            },
            {
                type: 'text',
                text: coupon.validLabel,
                style: {
                    left: 490,
                    top: 830,
                    width: 400,
                    fontSize: 24,
                    color: '#999',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            }
        ]
    } else if (coupon.couponType === COUPON_TYPE.DISCOUNT) {
        //折扣券：discountAmount + 折
        return [{
            type: 'text',
            text: coupon.discountAmount + '折',
            style: {
                left: 170,
                top: 784,
                width: 165,
                fontSize: 36,
                color: '#FA6120',
                fontWeight: 'bold',
                textAlign: 'center',
                lineHeight: 36,
            }
        },
            {
                type: 'text',
                text: coupon.threshold,
                style: {
                    left: 170,
                    top: 824,
                    width: 165,
                    fontSize: 24,
                    color: '#FA6120',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            },
            {
                type: 'text',
                text: coupon.name,
                style: {
                    left: 490,
                    top: 770,
                    width: 400,
                    fontSize: 28,
                    color: '#111',
                    textAlign: 'center',
                    lineHeight: 28,
                }
            },
            {
                type: 'text',
                text: coupon.validLabel,
                style: {
                    left: 490,
                    top: 830,
                    width: 400,
                    fontSize: 24,
                    color: '#999',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            }
        ]
    } else if (coupon.couponType === COUPON_TYPE.EXCHANGE) {
        //兑换券：展示兑换文字（canvas不支持icon）
        return [{
            type: 'text',
            text: '兑换',
            style: {
                left: 170,
                top: 784,
                width: 165,
                fontSize: 48,
                color: '#FA6120',
                fontWeight: 'bold',
                textAlign: 'center',
                lineHeight: 48,
            }
        },
            {
                type: 'text',
                text: coupon.threshold,
                style: {
                    left: 170,
                    top: 824,
                    width: 165,
                    fontSize: 24,
                    color: '#FA6120',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            },
            {
                type: 'text',
                text: coupon.name,
                style: {
                    left: 490,
                    top: 770,
                    width: 400,
                    fontSize: 28,
                    color: '#111',
                    textAlign: 'center',
                    lineHeight: 28,
                }
            },
            {
                type: 'text',
                text: coupon.validLabel,
                style: {
                    left: 490,
                    top: 830,
                    width: 400,
                    fontSize: 24,
                    color: '#999',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            }
        ]
    } else if (coupon.couponType === COUPON_TYPE.RANDOM) {
        //手气券：randomMinAmount ~ randomMaxAmount
        return [{
            type: 'text',
            text: '¥',
            style: {
                left: 90,
                top: 784,
                width: 30,
                fontSize: 36,
                color: '#FA6120',
                fontWeight: 'bold',
                textAlign: 'left',
                lineHeight: 48,
            }
        }, {
            type: 'text',
            text: coupon.randomMinAmount + '~' + coupon.randomMaxAmount,
            style: {
                left: 176,
                top: 784,
                width: 145,
                fontSize: 48,
                color: '#FA6120',
                fontWeight: 'bold',
                textAlign: 'center',
                lineHeight: 48,
            }
        },
            {
                type: 'text',
                text: coupon.threshold,
                style: {
                    left: 170,
                    top: 824,
                    width: 165,
                    fontSize: 24,
                    color: '#FA6120',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            },
            {
                type: 'text',
                text: coupon.name,
                style: {
                    left: 490,
                    top: 770,
                    width: 400,
                    fontSize: 28,
                    color: '#111',
                    textAlign: 'center',
                    lineHeight: 28,
                }
            },
            {
                type: 'text',
                text: coupon.validLabel,
                style: {
                    left: 490,
                    top: 830,
                    width: 400,
                    fontSize: 24,
                    color: '#999',
                    textAlign: 'center',
                    lineHeight: 24,
                }
            }
        ]
    }
}

//须知
const parseRule = (coupon) => {
    let desc = coupon.validTimeLabel + ' ● '
    if (coupon.isAppt) {
        desc = desc + coupon.appDesc
    } else {
        desc = desc + '无需预约'
    }
    if (coupon.isTransfer) {
        desc = desc + ' ● ' + '可赠送'
    }

    return [
        {
            type: 'text',
            text: '须知',
            style: {
                left: 66,
                top: 1080,
                width: 70,
                fontSize: 24,
                color: '#999',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        },
        {
            type: 'text',
            text: desc,
            style: {
                left: 136,
                top: 1080,
                width: 330,
                fontSize: 24,
                color: '#161722',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        }
    ]
}

//适用门店 -- 多加门店
const parseShop = (coupon) => {
    return [
        {
            type: 'text',
            text: '门店',
            style: {
                left: 66,
                top: 1000,
                width: 70,
                fontSize: 24,
                color: '#999',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        },
        {
            type: 'text',
            text: (coupon.storeIds.length).toString() + '家门店通用',
            style: {
                left: 136,
                top: 1000,
                width: 174,
                fontSize: 24,
                color: '#ef8b3c',
                fontWeight: 'bold',
            }
        }
    ]
}

//适用门店 -- 1家门店
const parseShopOne = (coupon) => {
    let storeInfo = coupon.stores[0]
    let nameWitdh = storeInfo.name.length * 25
    let addressWith
    if (nameWitdh > 200) {
        nameWitdh = 200
    }
    addressWith = 296 - nameWitdh
    return [{
        type: 'text',
        text: '门店',
        style: {
            left: 66,
            top: 1000,
            width: 70,
            fontSize: 24,
            color: '#999',
            textAlign: 'left',
            rows: 1,
            lineHeight: 32,
        }
    },
        {
            type: 'text',
            text: storeInfo.name,
            style: {
                left: 136,
                top: 1000,
                width: nameWitdh,
                fontSize: 24,
                color: '#ef8b3c',
                fontWeight: 'bold',
            },
        },
        // {
        //     type: 'text',
        //     text: '●',
        //     style: {
        //         left: 140 + nameWitdh,
        //         top: 1010,
        //         width: 20,
        //         fontSize: 24,
        //         color: '#ef8b3c',
        //         fontWeight: 'bold',
        //     },
        // },
        // {
        //     type: 'text',
        //     text: storeInfo.address,
        //     style: {
        //         left: nameWitdh + 170,
        //         top: 1010,
        //         width: addressWith,
        //         fontSize: 24,
        //         color: '#161722',
        //     }
        // }
    ]
}

//券类型 + 原价
const parseCouponType = (coupon) => {
    if (!coupon.couponTypeLabel) return []
    //类型文本
    let text = coupon.couponTypeLabel
    //原价（仅当面额低于原价时展示）
    let faceValue = coupon.faceAmount || coupon.reduceAmount || 0
    if (coupon.originalPrice && faceValue > 0 && coupon.originalPrice > faceValue) {
        text = text + '  ●  原价¥' + coupon.originalPrice
    }
    return [
        {
            type: 'text',
            text: '类型',
            style: {
                left: 66,
                top: 960,
                width: 70,
                fontSize: 24,
                color: '#999',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        },
        {
            type: 'text',
            text: text,
            style: {
                left: 136,
                top: 960,
                width: 330,
                fontSize: 24,
                color: '#161722',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        }
    ]
}

//限领数量
const parseLimit = (coupon) => {
    if (!coupon.isTotalLimit || !coupon.totalLimitCount) return []
    return [
        {
            type: 'text',
            text: '限领',
            style: {
                left: 66,
                top: 1040,
                width: 70,
                fontSize: 24,
                color: '#999',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        },
        {
            type: 'text',
            text: '每人限领' + coupon.totalLimitCount + '张',
            style: {
                left: 136,
                top: 1040,
                width: 330,
                fontSize: 24,
                color: '#161722',
                textAlign: 'left',
                rows: 1,
                lineHeight: 32,
            }
        }
    ]
}

//说明
const parseContent = (coupon) => {
    let content = coupon.content || ''

    return [
        {
            type: 'text',
            text: '说明',
            style: {
                left: 66,
                top: 1120,
                width: 70,
                fontSize: 24,
                color: '#999',
                textAlign: 'left',
                rows: 1,
                lineHeight: 40,
            }
        },
        {
            type: 'text',
            text: content,
            style: {
                left: 136,
                top: 1120,
                width: 270,
                fontSize: 24,
                color: '#161722',
                textAlign: 'left',
                rows: 2,
                lineHeight: 40,
            }
        }
    ]
}

//小程序码
const parseQRCode = (qrcode) => {
    return [{
        type: 'image',
        imgType: 2,
        src: qrcode,
        style: {
            left: 415,
            top: 900,
            width: 300,
            height: 300,
        }
    }]
}

const posterDraw = () => {
    if (!isInit.value || !posterRef.value) {
        show.value = false
        uni.hideLoading()
        utils.toast('请稍后再试')
        return;
    }
    setPosterJson()
    posterRef.value.draw(posterData, (filePath) => {
        //绘制图片路径
        if (filePath) {
            posterUrl.value = filePath;
            showLandscape.value = true
            uni.hideLoading()
        } else {
            utils.toast('海报生成失败')
        }
    })
}

const onPosterReady = () => {
    if (!isInit.value) {
        isInit.value = true
    }
}

const onClose = () => {
    showLandscape.value = false
}

const onSavePoster = () => {
    if (posterUrl.value === '') {
        utils.toast('还未生成海报')
        return
    }
    saveImageToAlbum(posterUrl.value)
}

onLoad((e) => {
    couponId.value = e.couponId;
    Promise.all([getCoupon()]).then(() => {
        getIssueParam()
    })
    // getIssueParam()
})
</script>


<style scoped>
.image-poster-container {
    text-align: center;
    min-height: 805rpx;
}

.image-poster {
    width: 100%;
    max-width: 400rpx;
    border-radius: 8rpx;
    margin: 20rpx auto;
}

.landscape-poster {
    margin: 30rpx 30rpx 0;
    background-color: transparent;
    border-radius: 20rpx;
    padding: 30rpx;
    width: 480rpx;
    height: auto;
}
</style>
