<template>
    <m-loading v-if="issueParam === undefined"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <view class="tips-card mt-2">
                <text class="tips-title">使用说明</text>
                <view class="tips-item">
                    <text class="tips-text">保存二维码图片，客户使用微信扫一扫即可领取</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">二维码可打印在海报、宣传单等物料上使用</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">支持打印后线下发放，也可在线上图文消息中使用</text>
                </view>
            </view>

            <view class="section section-body mt-2">
                <view class="qrcode-image-container">
                    <image class="qrcode-image" :src="issueParam.qrcode" mode="widthFix" v-if="issueParam.qrcode"></image>
                    <m-loading v-else/>
                </view>
            </view>

        </view>
        <m-submit @click="downloadImage(issueParam.qrcode)">下载领券码</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import {CHANNEL_TYPE} from "@/constants/common";
import utils from "@/utils/utils";
import {downloadImage} from "@/hooks/useFile";

const couponId = ref('');
const issueParam = ref();

const getIssueParam = () => {
    request.post('/seller/coupon/public/issue/create', {couponId: couponId.value, channelType: CHANNEL_TYPE.PUBLIC_QRCODE}).then(res => {
        issueParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    couponId.value = e.couponId;
    getIssueParam()
})
</script>


<style scoped>
.qrcode-image-container{
    text-align: center;
    min-height: 440rpx;
}
/* 二维码样式 */
.qrcode-image {
    width: 100%;
    max-width: 400rpx;
    border-radius: 8rpx;
    margin: 20rpx auto;
}
</style>
