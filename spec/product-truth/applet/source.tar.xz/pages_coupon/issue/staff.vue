<template>
    <m-loading v-if="items === undefined"></m-loading>
    <template v-else-if="is.Array(items)">
        <m-empty v-if="items.length === 0">暂无发券员工</m-empty>
        <view v-else class="container-safety">
            <t-cell-group theme="card" t-class="mt-2">
                <t-cell :arrow="true" v-for="item in items" :key="item.id" :title="item.name" :image="item.avatar"
                        @tap="push('/pages_merchant/staff/detail?staffId=' + item.id)">
                    <template #description>
                        <view class="m-flex mt-1">
                            <t-tag theme="success" variant="light-outline" size="small">{{item.storeName}}</t-tag>
                            <t-tag theme="warning" variant="light" size="small">{{item.roleName}}</t-tag>
                        </view>
                    </template>
                    <template #note>
                        <text class="text-muted" :class="item.status === ISSUE_STAFF_STATUS.VALID ? 'text-success' : 'text-danger'">{{item.statusLabel}}</text>
                    </template>
                </t-cell>
            </t-cell-group>

            <!-- 统计 -->
            <view class="mt-2 p-3 text-center text-muted text-small">
                共 {{ total }} 名发券员工
            </view>
        </view>
    </template>
    <m-submit v-if="items && checkPermission(PERM_COUPON.UPDATE) && couponStatus !== COUPON_STATUS.DISCARDED" @click="push('/pages_coupon/issue/update_staff?couponId=' + couponId)">设置发券员工</m-submit>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh} from '@dcloudio/uni-app';
import {ref} from 'vue'
import request from '@/hooks/request';
import {useLink} from '@/hooks/useLink';
import {useAuth} from '@/hooks/useAuth.js';
import {PERM_COUPON} from '@/constants/permission.js';
import {COUPON_STATUS, ISSUE_STAFF_STATUS} from '@/constants/coupon.js';
import is from "@/hooks/is";
import to from "@/hooks/to";

const {push} = useLink()
const {checkPermission} = useAuth()

const couponId = ref()
const items = ref()
const total = ref(0)
// 加载中（防重复请求）
const loading = ref(false)
const couponStatus = ref(0)

// 获取发券员工列表
const getItems = () => {
    if (loading.value) return
    loading.value = true
    request.get('/seller/coupon/staff/list', {couponId: couponId.value, page: 1, pageSize: 100}).then(res => {
        items.value = to.Array(res.data.items)
        total.value = res.data.total
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    if (e.couponId) {
        couponId.value = e.couponId
    }
    if (e.status !== undefined && e.status !== ''){
        couponStatus.value = Number(e.status)
    }
})

onShow(() => {
    getItems()
})

onPullDownRefresh(() => {
    getItems()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})
</script>

<style scoped>
</style>