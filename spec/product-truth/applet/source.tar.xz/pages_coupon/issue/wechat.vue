<template>
    <m-loading v-if="issueParam === undefined"></m-loading>
    <template v-else>
        <view class="container  container-safety">
            <view class="tips-card mt-2">
                <text class="tips-title">使用说明</text>
                <view class="tips-item">
                    <text class="tips-text">以小程序卡片发放给微信好友或群</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">分享给精准用户群体，转化率更高</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">分享后所有人都可以领取</text>
                </view>
            </view>

            <view class="section section-body mt-2" style="height: 600rpx">
                <m-result style="height: 600rpx" type="success" title="分享链接已生成" description="请将链接分享给微信好友或群"></m-result>
            </view>

        </view>

        <div class="submit">
            <div class="submit-btn">
                <t-button openType="share" block theme="danger" size="large">分享给微信好友/群</t-button>
            </div>
        </div>
    </template>
    <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad, onShareAppMessage} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import {CHANNEL_TYPE} from "@/constants/common";
import utils from "@/utils/utils";

const couponId = ref('');
const issueParam = ref();
const shareTitle = ref("");
const shareCover = ref("");

const getIssueParam = () => {
    request.post('/seller/coupon/public/issue/create', {couponId: couponId.value, channelType: CHANNEL_TYPE.PUBLIC_WECHAT}).then(res => {
        issueParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onShareAppMessage((res) => {
    return {
        title: shareTitle.value,
        imageUrl: shareCover.value,
        path: issueParam.value.appletPath,
    }
})

onLoad((e) => {
    shareTitle.value = e.shareTitle;
    shareCover.value = e.cover;
    couponId.value = e.couponId;
    getIssueParam()
})
</script>

<style scoped>
.submit {
    background: #FFF;
    position: fixed;
    bottom: 0;
    width: 100%;
    z-index: 99;
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
}
.submit-btn {
    padding: 30rpx 30rpx;
}
</style>