<template>
    <m-loading v-if="couponInfo === undefined"></m-loading>
    <m-empty v-else-if="couponInfo === null">领取记录不存在</m-empty>
    <template v-else>
        <view class="container-safety">
            <!-- 优惠券概览 -->
            <view class="container mt-2">
                <view class="coupon">
                    <!-- 头部：券类型 + 状态 -->
                    <view class="coupon-header">
                        <t-tag theme="danger" size="small">{{ couponInfo.couponTypeLabel }}</t-tag>
                        <t-tag :theme="statusTheme[couponInfo.status]" size="small" variant="light-outline">
                            {{ couponInfo.statusLabel }}
                        </t-tag>
                    </view>
                    <view class="coupon-line"></view>
                    <!-- 主体：券名 + 面额 -->
                    <view class="coupon-body">
                        <view class="coupon-content">
                            <view class="coupon-name text-ellipsis-break">{{ couponInfo.couponName }}</view>
                            <view class="coupon-valid">{{ couponInfo.threshold }}</view>
                        </view>
                        <view class="coupon-value">
                            <!-- 代金券、套餐券、满减券、手气券 -->
                            <view class="coupon-face"
                                  v-if="isAmountFace(couponInfo.couponType)">
                                <text class="coupon-face-unit">￥</text>
                                <text class="coupon-face-money">{{ couponInfo.couponAmount }}</text>
                            </view>
                            <!-- 折扣券 -->
                            <view class="coupon-face" v-if="couponInfo.couponType === COUPON_TYPE.DISCOUNT">
                                <text class="coupon-face-money">{{ couponInfo.couponAmount }}</text>
                                <text class="coupon-face-font">折</text>
                            </view>
                            <!-- 兑换券 -->
                            <view class="coupon-face" v-if="couponInfo.couponType === COUPON_TYPE.EXCHANGE">
                                <t-icon name="gift-filled" color="e84c59" size="64rpx"></t-icon>
                            </view>
                        </view>
                    </view>
                    <view class="coupon-line"></view>
                    <!-- 脚部：有效期 -->
                    <view class="coupon-footer">
                        <view class="coupon-footer-label">有效期</view>
                        <view class="coupon-footer-value">{{ validStartDate }} 至 {{ validEndDate }}</view>
                    </view>
                </view>
            </view>
            <!-- /优惠券概览 -->

            <!-- 领取人信息（可跳转客户详情） -->
            <t-cell-group title="领取客户" t-title-class="mt-2" theme="card" v-if="couponInfo.userId">
                <t-cell
                    :image="couponInfo.avatar"
                    :title="couponInfo.nickname || '-'"
                    :description="couponInfo.mobile || '未绑定手机'"
                    arrow
                    hover
                    @tap="onViewCustomer"
                />
            </t-cell-group>

            <!-- 领取信息 -->
            <t-cell-group title="领取信息" t-title-class="mt-2" theme="card">
                <t-cell title="领取渠道" :note="couponInfo.channelTypeLabel"/>
                <t-cell title="领取时间" :note="couponInfo.receivedAt"/>
                <t-cell title="发放门店" :note="couponInfo.issueStoreName || '-'"/>
                <t-cell title="发放员工" :note="couponInfo.issueStaffName || '-'"/>
                <t-cell title="转赠人" :note="couponInfo.transferUserName || '-'" v-if="couponInfo.transferUserName"/>
            </t-cell-group>

            <!-- 核销信息 -->
            <t-cell-group title="核销信息" t-title-class="mt-2" theme="card" v-if="couponInfo.isVerify || couponInfo.status === RECEIVE_STATUS.USED">
                <t-cell title="核销门店" :note="couponInfo.verifyStoreName || '-'"/>
                <t-cell title="核销员工" :note="couponInfo.verifyStaffName || '-'"/>
                <t-cell title="核销时间" :note="couponInfo.verifyAt"/>
                <t-cell v-if="couponInfo.verifyRemark" title="核销备注" :note="couponInfo.verifyRemark"/>
            </t-cell-group>

            <!-- 作废信息 -->
            <t-cell-group title="作废信息" t-title-class="mt-2" theme="card" v-if="couponInfo.status === RECEIVE_STATUS.DISCARDED">
                <t-cell title="作废原因" :note="couponInfo.discardRemark || '-'"/>
                <t-cell title="作废门店" :note="couponInfo.discardStoreName || '-'"/>
                <t-cell title="作废员工" :note="couponInfo.discardStaffName || '-'"/>
                <t-cell title="作废时间" :note="couponInfo.discardAt"/>
            </t-cell-group>

            <!-- 操作设置 -->
            <t-cell-group title="操作设置" t-title-class="mt-2" theme="card"
                          v-if="couponInfo.status === RECEIVE_STATUS.UNUSED && (checkPermission(PERM_COUPON.RECEIVE_DISCARD) || checkPermission(PERM_COUPON.VERIFY))">
                <t-grid :column="4">
                    <t-grid-item v-if="checkPermission(PERM_COUPON.RECEIVE_DISCARD)" text="作废优惠券" icon="delete-time"
                                 @click="discardVisible = true"/>
                    <t-grid-item v-if="checkPermission(PERM_COUPON.VERIFY)" text="核销优惠券" icon="check-circle"
                                 @click="onVerify"/>
                </t-grid>
            </t-cell-group>

            <!-- 作废弹框 -->
            <t-popup placement="bottom" :visible="discardVisible" @visible-change="onDiscardPopupChange">
                <view class="popup-container">
                    <view class="popup-header">
                        <view class="popup-header-title">作废优惠券</view>
                        <view class="popup-header-close">
                            <t-icon name="close" size="24px" @click="discardVisible = false"/>
                        </view>
                    </view>
                    <view class="popup-body">
                        <view class="textarea-wrapper">
                            <t-textarea label="作废原因" v-model:value="discardForm.reason" :custom-style="textareaStyle" :maxlength="32" :indicator="true" :cursor-spacing="120"
                                        placeholder="请输入作废原因"/>
                        </view>
                    </view>
                    <view class="popup-footer">
                        <t-button theme="primary" size="large" block t-class="ml-3" @click="onConfirmDiscard">确认作废</t-button>
                    </view>
                </view>
            </t-popup>
        </view>
    </template>
</template>

<script setup>
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request'
import { RESPONSE_CODE } from '@/constants/code'
import { COUPON_TYPE, RECEIVE_STATUS, isAmountFace } from '@/constants/coupon'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {PERM_COUPON} from '@/constants/permission'
import utils from '@/utils/utils'
import MEmpty from '@/components/m/m-empty/m-empty.vue'

const {push} = useLink()
const {checkPermission} = useAuth()
const couponReceiveId = ref()
const couponInfo = ref()
const loading = ref(false)
const discardVisible = ref(false)
const discardForm = ref({
    reason: ''
})
const textareaStyle = 'height: 360rpx'

// 状态标签主题映射（按 status：1 未使用 / 2 已使用 / 3 已作废 / 4 已过期）
const statusTheme = {
    1: 'success',
    2: 'primary',
    3: 'warning',
    4: 'default'
}

const getDetail = () => {
    request.get('/seller/coupon/receive/detail', { id: couponReceiveId.value }).then(res => {
        couponInfo.value = res.data
        uni.setNavigationBarTitle({ title: res.data.couponName })
    }).catch(err => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            couponInfo.value = null
        }
    })
}

const onRefresh = () => {
    getDetail()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
}

const formatDate = (t) => {
    if (!t) return ''
    return String(t).split(' ')[0].replace(/-/g, '/')
}

const validStartDate = computed(() => formatDate(couponInfo.value?.validStartTime))
const validEndDate = computed(() => formatDate(couponInfo.value?.validEndTime))

// 跳转客户详情
const onViewCustomer = () => {
    if (!couponInfo.value?.userId) {
        return
    }
    push('/pages_merchant/customer/detail?userId=' + couponInfo.value.userId)
}

// 作废弹框显示/隐藏
const onDiscardPopupChange = (val) => {
    if (!val) {
        discardForm.value = {reason: ''}
    }
}

// 确认作废
const onConfirmDiscard = () => {
    loading.value = true
    request.post('/seller/coupon/receive/discard', {
        id: couponReceiveId.value,
        reason: discardForm.value.reason
    }).then(res => {
        utils.toast('作废成功')
        discardVisible.value = false
        getDetail()
    }).catch(err => {
        utils.toast(err.message || '作废失败')
    }).finally(() => {
        loading.value = false
    })
}

// 核销优惠券
const onVerify = () => {
    // 核销需要 verifySign，领券详情页无法获取，跳转到核销页
    // 核销页通过扫码进入，scene 格式: couponReceiveId-verifySign
    utils.toast('请通过扫码核销优惠券')
}

onLoad((e) => {
    console.log(e)
    couponReceiveId.value = e.couponReceiveId
    getDetail()
})

onPullDownRefresh(() => {
    onRefresh()
})
</script>

<style scoped>
.coupon {
    position: relative;
    background: #fff;
    border-radius: 20rpx;
    margin-bottom: 20rpx;
}

/* 头部：券类型 + 状态 */
.coupon-header {
    padding: 32rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

/* 主体 */
.coupon-body {
    padding: 10rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.coupon-content {
    flex: 1;
    min-width: 0;
    padding-right: 16rpx;
}

.coupon-name {
    font-weight: 600;
    font-size: 32rpx;
    color: #181818;
    margin-bottom: 12rpx;
}

.coupon-valid {
    color: #666;
    font-size: 28rpx;
}

.coupon-value {
    max-width: 260rpx;
    flex-shrink: 0;
    overflow: hidden;
    text-align: right;
}

.coupon-face {
    color: #e84c59;
    position: relative;
    display: flex;
    align-items: start;
    justify-content: flex-end;
}

.coupon-face-unit {
    font-weight: 600;
    font-size: 28rpx;
    margin-right: 2rpx;
    margin-top: 6rpx;
}

.coupon-face-font {
    margin-top: 6rpx;
    margin-left: 4rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-face-money {
    font-weight: bold;
    font-size: 56rpx;
}

/* 脚部：有效期 */
.coupon-footer {
    padding: 0 32rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 26rpx;
}

.coupon-footer-label {
    color: #999;
    flex-shrink: 0;
}

.coupon-footer-value {
    color: #999;
    margin-left: 16rpx;
    text-align: right;
}

.popup-body {
    height: 400rpx;
}

.textarea-wrapper {
    border-radius: 16rpx;
    border: 1px solid #f0f0f0;
    margin: 0 24rpx;
}

.textarea-style {
    height: 160rpx;
}

.popup-footer {
    display: flex;
    padding: 24rpx 32rpx;
    gap: 24rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
}

.popup-footer .t-button {
    border-radius: 40rpx;
}

.ml-3 {
    margin-left: 24rpx;
}
</style>
