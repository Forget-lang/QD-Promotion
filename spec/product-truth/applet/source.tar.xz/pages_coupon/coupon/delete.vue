<template>
    <m-loading v-if="coupon === undefined"></m-loading>
    <template v-else>
        <m-result type="info" v-if="coupon.status !== COUPON_STATUS.DISCARDED && coupon.status !== COUPON_STATUS.EXPIRED" title="删除条件不足"
                  description="仅已作废和已过期的优惠券可以删除">
            <template #action>
                <t-button @click="push('/pages_coupon/discard/discard?couponId=' + couponId)" theme="primary">
                    去作废优惠券
                </t-button>
            </template>
        </m-result>
        <m-result type="info" v-if="isCouponFrozen(coupon.status)" title="删除条件不足"
                  description="冻结中的优惠券不可删除"></m-result>
        <view v-if="coupon.status === COUPON_STATUS.DISCARDED || coupon.status === COUPON_STATUS.EXPIRED" class="container-safety">
            <t-cell-group theme="card" t-class="mt-2">
                <t-checkbox-group v-model:value="checks">
                    <t-checkbox
                        :value="1"
                        label="你需确认若当前优惠券为其他券的转赠奖励，将自动解除绑定并关闭转赠奖励。"
                    />
                    <t-checkbox
                        :value="2"
                        label="你需确认当前优惠券未被任何券包引用；若仍被引用将无法删除，需先从券包中移除。"
                    />
                    <t-checkbox
                        :value="3"
                        label="你需确认若当前优惠券配置了企业微信，将自动解除绑定。"
                    />
                    <t-checkbox
                        :value="4"
                        label="着重确认：删除后，此优惠券的全部数据（含客户已领取记录等）都将永久消失，不可恢复。"
                    />
                </t-checkbox-group>
            </t-cell-group>
            <m-submit @click="onDelete" :disabled="checks.length !== 4">删除优惠券</m-submit>
        </view>
    </template>
</template>

<script setup>
import {onLoad, onShow} from "@dcloudio/uni-app";
import {ref, computed} from 'vue';
import request from "@/hooks/request";
import {COUPON_STATUS, isCouponFrozen} from "@/constants/coupon";
import utils from "@/utils/utils";
import MResult from "@/components/m/m-result/m-result.vue";
import MSubmit from "@/components/m/m-submit/m-submit.vue";
import {useLink} from "@/hooks/useLink";

const {push, back} = useLink()
const couponId = ref('')
const coupon = ref()
const checks = ref([])

const getCoupon = () => {
    request.get('/seller/coupon/detail', {id: couponId.value}).then(res => {
        coupon.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

const onDelete = () => {
    if ((coupon.value.status === COUPON_STATUS.DISCARDED || coupon.value.status === COUPON_STATUS.EXPIRED) && checks.value.length !== 4) {
        utils.toast('请确认所有选项')
        return
    }
    request.post('/seller/coupon/delete', {id: couponId.value}).then(res => {
        uni.$emit('onCouponDelete', {id: couponId.value}) //删除卡券后，列表移除此条数据。
        utils.alert('删除成功', () => {
            back(2)
        })
    }).catch(err => {

    })
}


onLoad((e) => {
    couponId.value = e.couponId;
})

onShow(() => {
    getCoupon()
})

</script>

<style scoped>
</style>