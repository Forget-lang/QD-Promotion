<template>
    <!-- 成功反馈 -->
    <m-result v-if="showSuccess" theme="success" title="修改成功" back></m-result>
    <template v-else>
        <!-- 门店选择 -->
        <t-cell-group :title="'当前适用门店'+currentStoreCount+'个'" theme="card">
            <m-store-select
                title="适用门店"
                required
                :multiple="true"
                :show-disabled="true"
                v-model:value="form.storeIds"
            ></m-store-select>
        </t-cell-group>

        <!-- 提交按钮 -->
        <m-submit :loading="loading" :disabled="loading" @click="onSubmit">确认修改</m-submit>

        <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app';
import {ref} from 'vue';
import request from '@/hooks/request.js';
import utils from '@/utils/utils';
import {useLink} from '@/hooks/useLink.js';
import MStoreSelect from '@/components/m/m-store-select/m-store-select.vue';
import MResult from '@/components/m/m-result/m-result.vue';
import MSubmit from '@/components/m/m-submit/m-submit.vue';

const {back} = useLink();

const couponId = ref('');
const form = ref({
    storeIds: []
});
const loading = ref(false);
const showSuccess = ref(false);
const currentStoreCount = ref(0);

// 获取优惠券信息
const getCouponInfo = () => {
    request.get('/seller/coupon/detail', {id: couponId.value}).then((res) => {
        form.value.storeIds = res.data.storeIds || []
        currentStoreCount.value = (res.data.storeIds || []).length
    })
};

// 提交修改
const onSubmit = () => {
    if (!form.value.storeIds || form.value.storeIds.length === 0) {
        utils.toast('请至少选择一个适用门店');
        return;
    }

    loading.value = true;
    request.post('/seller/coupon/update-stores', {
        id: couponId.value,
        storeIds: form.value.storeIds
    }).then(() => {
        showSuccess.value = true
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
};

onLoad((e) => {
    if (!e.couponId) {
        utils.toast('缺少优惠券ID');
        setTimeout(() => {
            back();
        }, 1500);
        return;
    }
    couponId.value = e.couponId;
    getCouponInfo();
});
</script>

<style scoped></style>
