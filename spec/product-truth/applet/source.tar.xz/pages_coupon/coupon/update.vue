<template>
    <m-result
        v-if="isSuccess"
        type="success"
        title="修改成功"
        description="优惠券信息已更新"
        confirmText="查看详情"
        cancelText="返回"
        back
    >
    </m-result>

    <m-loading v-else-if="coupon === undefined"></m-loading>

    <m-empty v-else-if="coupon === null">优惠券不存在</m-empty>

    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view class="input-custom-label-required">封面图片</view>
                <view class="text-small text-success">最多5张，推荐尺寸：5:4</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="form.coverImages"
                    :cropperWidth="300"
                    :cropperHeight="240"
                    :beforeAdd="onBeforeCoverAdd"
                    emitName="couponCover"
                >
                </m-cover-uploader>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="发放方式" required description="创建后不支持修改"
                    :note="form.issueTypeLabel"></t-cell>
            <view class="cell-helper" v-if="form.issueType > 0">
                <text v-if="form.issueType === ISSUE_TYPE.PUBLIC" class="lh-25 text-success">
                    公开领取：支持微信群/好友、二维码、公众号、海报、企微群、企微群助理、企微客户群发等发券渠道，所有人都可领取，适合公开引流活动。
                </text>
                <text v-if="form.issueType === ISSUE_TYPE.PRIVATE" class="lh-25 text-success">
                    私密发放：支持私发微信好友、二维码、企微好友等发券渠道，适合给指定好友发券、储值回馈、消费赠礼、补偿等私密活动。
                </text>
                <text v-if="form.issueType === ISSUE_TYPE.BUNDLE" class="lh-25 text-success">
                    券包：供券包选择，适合多种类型优惠券打包一次发给顾客。
                    <text v-if="form.isAllowWecard">领取券包时，微信卡包暂时不支持一键加入。</text>
                </text>
            </view>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="优惠券类型" :note="form.couponTypeLabel" description="优惠券类型创建后不支持修改"></t-cell>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <t-input
                placeholder="最多18个字，支持表情符号"
                align="right"
                :maxlength="18"
                :disabled="isRuleLocked"
                v-model:value="form.name"
            >
                <template #label>
                    <view class="input-custom-label-required">优惠券名称</view>
                </template>
            </t-input>

            <t-cell title="制作数量" :note="form.totalStock + '张'" description="调整库存请在详情页操作"></t-cell>

            <t-input
                placeholder="满多少元可用，0为无门槛"
                align="right"
                type="digit"
                v-model:value="form.thresholdAmount"
                suffix="元"
                :disabled="isRuleLocked"
            >
                <template #label>
                    <view class="input-custom-label-required">消费门槛</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.CASH || couponType === COUPON_TYPE.PACKAGE"
                type="digit"
                v-model:value="form.originalPrice"
                align="right"
                :disabled="isRuleLocked"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">原价</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.CASH || couponType === COUPON_TYPE.PACKAGE"
                type="digit"
                v-model:value="form.faceAmount"
                align="right"
                :disabled="isRuleLocked"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">券面额</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.REDUCE"
                placeholder="优惠减免金额"
                type="digit"
                align="right"
                v-model:value="form.reduceAmount"
                :disabled="isRuleLocked"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">优惠金额</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.DISCOUNT"
                placeholder="8.5折输入8.5,9折输入9"
                type="digit"
                align="right"
                v-model:value="form.discountAmount"
                :disabled="isRuleLocked"
                suffix="折"
            >
                <template #label>
                    <view class="input-custom-label-required">折扣</view>
                </template>
            </t-input>
            <t-input v-if="couponType === COUPON_TYPE.EXCHANGE"
                     placeholder="例：冷饮一杯，最多10个字"
                     align="right"
                     v-model:value="form.exchangeProduct"
                     :disabled="isRuleLocked"
            >
                <template #label>
                    <view class="input-custom-label-required">兑换内容</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.RANDOM"
                placeholder="必须为整数，最低1元"
                type="digit"
                align="right"
                v-model:value="form.randomMinAmount"
                :disabled="isRuleLocked"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">随机最小金额</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.RANDOM"
                placeholder="必须为整数，最高99元"
                type="digit"
                align="right"
                v-model:value="form.randomMaxAmount"
                :disabled="isRuleLocked"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">随机最大金额</view>
                </template>
            </t-input>
        </t-cell-group>

        <t-cell-group v-if="isReceiveLocked || isWecardLocked" t-class="mt-2" theme="card">
            <t-cell
                v-if="isWecardLocked"
                title="微信卡包"
                description="已同步微信卡包，面额/门槛/折扣/有效期/限领等微信侧规则不可修改"
            >
                <template #note>
                    <text class="flex-shrink">已同步</text>
                </template>
            </t-cell>
            <t-cell
                title="有效期"
                :note="coupon.validLabel"
                :description="isWecardLocked ? '已同步微信卡包，有效期不支持修改' : '优惠券已被领取，有效期不支持修改'"
            ></t-cell>
            <t-cell
                title="可用时段"
                :description="isWecardLocked ? '已同步微信卡包，可用时段不支持修改' : '优惠券已被领取，可用时段不支持修改'"
            >
                <template #note>
                    <text style="max-width: 360rpx;">{{ coupon.validTimeLabel || '-' }}</text>
                </template>
            </t-cell>
        </t-cell-group>
        <t-cell-group v-else t-class="mt-2" theme="card">
            <m-select
                required
                title="有效期类型"
                v-model:value="form.validType"
                :options="validTypeOptions"
            >
            </m-select>
            <t-input
                v-if="form.validType !== VALID_TYPE.CUSTOM"
                :placeholder="validDayPlaceholder"
                type="number"
                align="right"
                v-model:value="form.validDay"
                suffix="天"
            >
                <template #label>
                    <view class="input-custom-label-required">有效期</view>
                </template>
            </t-input>
            <m-datetime-picker
                v-if="form.validType === VALID_TYPE.CUSTOM"
                required
                v-model:value="form.validStartTime"
                format="YYYY-MM-DD"
                title="有效开始时间"
                placeholder="选择开始时间"
                mode="date"
            >
            </m-datetime-picker>
            <m-datetime-picker
                v-if="form.validType === VALID_TYPE.CUSTOM"
                required
                v-model:value="form.validEndTime"
                format="YYYY-MM-DD"
                title="有效结束时间"
                placeholder="选择结束时间"
                mode="date"
            >
            </m-datetime-picker>
            <t-cell title="可用时段" hover description="默认全天可用，可自定义周天及可用时段">
                <template #note>
                    <t-switch v-model:value="form.validRuleTime.isCustom" t-class-label="switch-label" :label="['定制', '全天']"/>
                </template>
            </t-cell>
            <template v-if="form.validRuleTime.isCustom">
                <m-week-picker v-model:value="form.validRuleTime.weekDay"></m-week-picker>
                <view style="background-color: #fff">
                    <m-openhour-picker v-model:value="form.validRuleTime.openHours" :max="2"></m-openhour-picker>
                </view>
            </template>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <m-store-select
                required
                title="适用门店"
                placeholder="请选择适用门店（必选）"
                :multiple="true"
                :show-disabled="true"
                v-model:value="form.storeIds"
            >
            </m-store-select>
            <m-staff-select v-if="form.issueType === ISSUE_TYPE.PUBLIC || form.issueType === ISSUE_TYPE.PRIVATE"
                            required
                            title="发券员工"
                            placeholder="请选择发券员工（必选）"
                            :multiple="true"
                            :show-disabled="true"
                            v-model:value="form.staffIds"
            >
            </m-staff-select>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card"
                      v-if="form.issueType !== ISSUE_TYPE.BUNDLE">
            <t-cell title="限领总量"
                    description="每个客户累计领取的总张数，关闭则不限制">
                <template #note>
                    <t-switch v-model:value="form.isTotalLimit" :disabled="isReceiveLocked"/>
                </template>
            </t-cell>
            <t-input
                v-if="form.isTotalLimit"
                placeholder="最少1张，最多100张"
                type="number"
                align="right"
                :borderless="!isReceiveLocked"
                :disabled="isReceiveLocked"
                v-model:value="form.totalLimitCount" suffix="张"
            >
                <template #label>
                    <view class="input-custom-label-required">每人限领总量</view>
                </template>
            </t-input>
            <view class="cell-helper" v-if="isReceiveLocked">
                <text class="lh-25 text-success">优惠券已被领取，每人限领总量不支持修改</text>
            </view>
            <t-cell description="该商户下从未领过优惠券、券包、次卡的顾客才可领取" :bordered="false">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>仅新客户可领</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_NEW_CUSTOMER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyNewCustomer" :default-value="false"
                              @change="onOnlyNewCustomerChange"/>
                </template>
            </t-cell>
        </t-cell-group>


        <!-- 公开领取设置 -->
        <t-cell-group v-if="form.issueType === ISSUE_TYPE.PUBLIC" title="公开领取设置" theme="card" :bordered="false">
            <t-cell title="自定义领取时间" :bordered="form.isCustomReceiveTime" description="默认不限，有效期截止前均可领取">
                <template #note>
                    <t-switch v-model:value="form.isCustomReceiveTime"/>
                </template>
            </t-cell>
            <m-datetime-picker
                v-if="form.isCustomReceiveTime"
                required
                title="领取开始时间"
                v-model:value="form.receiveStartTime"
            >
            </m-datetime-picker>
            <m-datetime-picker
                v-if="form.isCustomReceiveTime"
                required
                title="领取结束时间"
                v-model:value="form.receiveEndTime"
            >
            </m-datetime-picker>

            <template v-if="!form.isTotalLimit || (form.isTotalLimit && form.totalLimitCount > 1)">
                <t-cell v-if="isReceiveLocked" title="每次领取数量" required description="优惠券已被领取，每次领取数量不支持修改" :note="`${form.publicIssueCount}张`"></t-cell>
                <m-select v-else
                          required
                          title="每次领取数量"
                          v-model:value="form.publicIssueCount"
                          placeholder="最少1张，最多10张"
                          :options="[
                    { label: '1张', value: 1 },
                    { label: '2张', value: 2 },
                    { label: '3张', value: 3 },
                    { label: '4张', value: 4 },
                    { label: '5张', value: 5 },
                    { label: '6张', value: 6 },
                    { label: '7张', value: 7 },
                    { label: '8张', value: 8 },
                    { label: '9张', value: 9 },
                    { label: '10张', value: 10 }
                ]"
                >
                </m-select>

                <t-cell v-if="isReceiveLocked" :title="publicIssueRuleLabel" required description="优惠券已被领取，领取周期不支持修改"
                        :note="`${form.publicIssueRuleCount}张`"></t-cell>
                <template v-else>
                    <m-select
                        title="领取周期"
                        v-model:value="form.publicIssueRule"
                        :options="[
                    { label: '每人每天最多可领', value: 3 },
                    { label: '每人每周最多可领', value: 4 },
                    { label: '每人每月最多可领', value: 5 },
                    { label: '每人每年最多可领', value: 6 }
                    ]"
                    >
                    </m-select>

                    <t-input
                        placeholder="最少1张"
                        type="number"
                        align="right"
                        borderless
                        v-model:value="form.publicIssueRuleCount"
                        suffix="张"
                    >
                        <template #label>
                            <view class="input-custom-label-required">{{ publicIssueRuleLabel }}</view>
                        </template>
                    </t-input>
                </template>
            </template>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="开启每天核销限制">
                <template #note>
                    <t-switch v-model:value="form.isVerifyLimit" :default-value="false"/>
                </template>
            </t-cell>
            <m-select
                v-if="form.isVerifyLimit"
                required
                title="每人每天限核销"
                v-model:value="form.verifyLimitCount"
                placeholder="最少1张，最多10张"
                :options="[
                    { label: '1张', value: 1 },
                    { label: '2张', value: 2 },
                    { label: '3张', value: 3 },
                    { label: '4张', value: 4 },
                    { label: '5张', value: 5 },
                    { label: '6张', value: 6 },
                    { label: '7张', value: 7 },
                    { label: '8张', value: 8 },
                    { label: '9张', value: 9 },
                    { label: '10张', value: 10 }
                ]"
            >
            </m-select>

            <t-cell description="核销后立奖本券一张，直接到账">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启核销后赠券</text>
                        <m-edition-badge :feature="EDITION_FEATURES.VERIFY_REWARD" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isVerifyReward" :default-value="false" @change="onVerifyRewardChange"/>
                </template>
            </t-cell>

            <t-cell description="开启后核销码5分钟刷新一次，可有效减少截屏核销">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启动态核销码</text>
                        <m-edition-badge :feature="EDITION_FEATURES.VERIFY_SIGN" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isVerifySign" @change="onVerifySignChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 转介绍裂变：两开关同卡片平铺展示；开裂变先版本检测再校验转赠前置，关转赠联动关裂变 -->
        <t-cell-group v-if="!form.isAllowWecard" title="转介绍裂变" theme="card" t-title-class="mt-2"
                      :bordered="false">
            <t-cell title="允许转赠" description="开启后顾客可将券转赠给好友">
                <template #note>
                    <t-switch v-model:value="form.isTransfer" :default-value="false" @change="onTransferChange"/>
                </template>
            </t-cell>
            <t-cell description="顾客把券转赠好友，好友到店核销后，自动奖励转赠人一张券，老客帮您带新客"
                    :bordered="!form.isTransferReward">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启转介绍裂变</text>
                        <m-edition-badge :feature="EDITION_FEATURES.TRANSFER_REWARD" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isTransferReward" :default-value="false"
                              @change="onTransferRewardChange"/>
                </template>
            </t-cell>
            <m-coupon-select v-if="form.isTransferReward" required title="转赠奖励券"
                             tip="仅可选择「私密发放」类型的有效优惠券"
                             v-model:value="form.transferRewardCouponId"/>
        </t-cell-group>
        <!-- 同步微信卡包时不支持转赠，仅展示只读提示 -->
        <t-cell-group v-else title="转介绍裂变" theme="card" t-title-class="mt-2" :bordered="false">
            <t-cell title="允许转赠" note="已关闭" description="开启微信卡包后不支持转赠" :bordered="false"/>
        </t-cell-group>

        <t-cell-group v-if="form.issueType !== ISSUE_TYPE.BUNDLE" title="线下收款口令" theme="card" t-title-class="mt-2"
                      :bordered="false">
            <t-cell description="开启后顾客领取须输入口令">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启领取口令</text>
                        <m-edition-badge :feature="EDITION_FEATURES.RECEIVE_CIPHER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch :value="cipherEnabled" @change="onCipherEnableChange"/>
                </template>
            </t-cell>
            <template v-if="cipherEnabled">
                <view class="cipher-type-tabs">
                    <view class="cipher-type-tab"
                          :class="{ active: form.cipherType === CIPHER_TYPE.FIXED }"
                          @click="setCipherType(CIPHER_TYPE.FIXED)">固定口令
                    </view>
                    <view class="cipher-type-tab"
                          :class="{ active: form.cipherType === CIPHER_TYPE.RANDOM }"
                          @click="setCipherType(CIPHER_TYPE.RANDOM)">随机口令
                    </view>
                </view>
                <t-input v-if="form.cipherType === CIPHER_TYPE.FIXED" label="口令" v-model:value="form.cipherCode"
                         align="right" placeholder="请输入5位数字" :maxlength="5" type="number"/>
                <t-cell v-else description="每3分钟变化一次，可手工更新" :bordered="false"/>
            </template>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea
                label="使用须知"
                v-model:value="form.content"
                :maxlength="500"
                :indicator="true"
                placeholder="请输入使用须知"
            >
            </t-textarea>
            <m-cover-uploader
                v-model:value="form.productImages"
                :max="1"
                :beforeAdd="onBeforeProductAdd"
                tip="可上传活动长图、店内环境、菜单等图片"
                emitName="couponProduct"
            >
            </m-cover-uploader>
            <view class="usage-toolbar">
                <view class="usage-toolbar-tip">
                    <t-icon name="lightbulb" size="28rpx" color="var(--td-brand-color)"/>
                    <text class="usage-toolbar-tip-text">不会写？一键套用模版</text>
                </view>
                <view class="usage-toolbar-actions">
                    <t-button theme="primary" variant="text" size="small" @click="onUseContentTemplate(1)">通用模版</t-button>
                    <t-button t-class="ml-2" theme="default" variant="text" size="small" :disabled="!form.content"
                              custom-style="background-color: transparent;" @click="onClearContent">清空
                    </t-button>
                </view>
            </view>
        </t-cell-group>

        <t-cell-group title="团购套餐设置" t-title-class="mt-2" theme="card" :bordered="false">
            <t-cell title="填写套餐组合" :description="isReceiveLocked ? '优惠券已被领取，套餐内容不支持修改' : ''">
                <template #note>
                    <t-switch v-model:value="form.isCombo" :default-value="false"
                              :disabled="isRuleLocked"></t-switch>
                </template>
            </t-cell>
            <template v-if="form.isCombo">
                <!-- 已领取：只读展示套餐组合 -->
                <template v-if="isReceiveLocked">
                    <t-cell v-for="(item, index) in form.combos" :key="index" :title="item.name"
                            :note="item.selectRule"></t-cell>
                </template>
                <m-coupon-combo v-else v-model:value="form.combos"></m-coupon-combo>
            </template>
        </t-cell-group>


        <t-cell-group title="预约设置" theme="card" t-title-class="mt-2" :bordered="false">
            <t-cell title="提前预约" description="开启后，顾客使用前需按说明提前预约">
                <template #note>
                    <t-switch v-model:value="form.isAppt" :default-value="false"/>
                </template>
            </t-cell>
            <t-input
                v-if="form.isAppt"
                label="预约说明"
                v-model:value="form.apptDesc"
                :maxlength="32"
                :indicator="true"
                placeholder="如提前几天、电话、到店时间等"
            />
        </t-cell-group>

        <t-cell-group title="到期提醒" theme="card" t-title-class="mt-2" :bordered="false">
            <t-cell title="到期提醒" description="开启后，顾客订阅了卡券到期提醒时，将收到微信通知">
                <template #note>
                    <t-switch v-model:value="form.isExpireNotice" :default-value="false"/>
                </template>
            </t-cell>
            <m-select
                v-if="form.isExpireNotice"
                title="提前提醒"
                v-model:value="form.expireForwardDay"
                placeholder="请选择"
                :options="expireForwardDayOptions()"
            ></m-select>
        </t-cell-group>

        <t-cell-group v-if="form.issueType !== ISSUE_TYPE.BUNDLE" t-title-class="mt-2" title="领券顾客信息" theme="card"
                      :bordered="false">
            <t-cell :bordered="false">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>填写手机号</text>
                        <m-edition-badge :feature="EDITION_FEATURES.GET_MOBILE" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isGetMobile" :default-value="false" :disabled="form.isMobileLimit" @change="onGetMobileChange"/>
                </template>
            </t-cell>
            <t-cell description="导入可领取手机号，最多500个。" :bordered="!form.isMobileLimit">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>指定手机号可领取</text>
                        <m-edition-badge :feature="EDITION_FEATURES.MOBILE_LIMIT" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isMobileLimit" :default-value="false" @change="onMobileLimitChange"/>
                </template>
            </t-cell>
            <t-cell v-if="form.isMobileLimit" title="可领取手机号" arrow
                    :note="allowMobileCount + ' 个'"
                    @click="allowMobileVisible = true"/>
        </t-cell-group>

        <m-coupon-allow-mobile-panel v-model:visible="allowMobileVisible" v-model="form.allowMobiles"/>

        <t-cell-group title="自定义分享卡片" theme="card" t-title-class="mt-2" :bordered="false">
            <t-input label="分享标题" v-model:value="form.shareTitle" align="right"
                     placeholder="选填，最多32个字。"></t-input>
            <t-cell title="转发封面" :bordered="false" description="请先上传封面图片，默认使用封面图片的第一张">
                <template #note>
                    <t-image v-if="shareCover" :src="shareCover" width="150rpx"
                             height="120rpx" shape="round" mode="aspectFill"/>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 分享与转发设置：仅公开领取时显示 -->
        <t-cell-group v-if="form.issueType === ISSUE_TYPE.PUBLIC" title="分享与转发设置" t-title-class="mt-2" theme="card"
                      :bordered="false">
            <t-cell title="允许分享" :bordered="true">
                <template #note>
                    <t-switch v-model:value="form.isShare" :default-value="false"/>
                </template>
            </t-cell>
            <t-cell
                description="仅微信群生效，企业微信群暂不可用"
                :bordered="false"
            >
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>禁止群内成员转发出群</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_GROUP" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyGroup" :default-value="false" @change="onOnlyGroupChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" :disabled="loading" @click="onSubmit">保存修改</t-button>
        </view>
        <!-- VIP 升级抽屉：门禁 check 确认后经事件打开 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {onLoad, onShow} from '@dcloudio/uni-app';
import {computed, ref, watch} from 'vue';
import request from '@/hooks/request.js';
import { RESPONSE_CODE } from '@/constants/code.js';
import {COUPON_TYPE, CIPHER_TYPE, ISSUE_TYPE, VALID_TYPE} from '@/constants/coupon.js';
import {EDITION_FEATURES, getFeatureQuota} from '@/constants/edition.js';
import utils from '@/utils/utils';
import {useLink} from "@/hooks/useLink.js"
import {useAuth} from "@/hooks/useAuth.js"
import {useVipGuard} from '@/hooks/useVipGuard'

const {replace, back} = useLink()
const {getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()

const isSuccess = ref(false)
const couponId = ref()
const coupon = ref()
const couponType = ref()
const loading = ref(false)
const form = ref({})
const allowMobileVisible = ref(false)

const allowMobileCount = computed(() => (form.value.allowMobiles || []).length)

const validTypeOptions = [
    {label: '固定有效期', value: VALID_TYPE.CUSTOM},
    {label: '自领券日起N天内有效', value: VALID_TYPE.TODAY},
    {label: '自领券次日起N天内有效', value: VALID_TYPE.NEXT_DAY},
]

// 判断优惠券是否已被领取
const isReceiveLocked = computed(() => Number(coupon.value?.receiveCount || 0) > 0)

// 封面图数量上限：按版本档位取值（免费/标准 1 张，专业/企业 5 张）
const coverMax = computed(() => {
    return getFeatureQuota(EDITION_FEATURES.COVER_IMAGE, staffSession.value?.editionId) || 1
})

// 点击添加封面：免费版/标准版仅支持1张，达到上限时检测并提示升级
const onBeforeCoverAdd = () => {
    if (form.value.coverImages.length < coverMax.value) return true
    return check(EDITION_FEATURES.COVER_IMAGE)
}

// 点击添加券内容图片：专业版及以上支持
const onBeforeProductAdd = () => {
    return check(EDITION_FEATURES.PRODUCT_IMAGE)
}
// 已同步微信卡包：面额/有效期/限领等微信侧规则不可改
const isWecardLocked = computed(() => !!(form.value?.isSyncWecard || form.value?.stockId))
const isRuleLocked = computed(() => isReceiveLocked.value || isWecardLocked.value)

// 有效期上限：按版本档位取值，开启/同步微信卡包时受微信侧限制最长 365 天
const validDayMax = computed(() => {
    const quota = getFeatureQuota(EDITION_FEATURES.COUPON_VALID_DAY, staffSession.value?.editionId)
    const wecardLimit = (form.value.isAllowWecard || form.value.isSyncWecard) ? 365 : Infinity
    return Math.min(quota, wecardLimit)
})
// 有效期输入提示（随版本与微信卡包状态动态变化）
const validDayPlaceholder = computed(() => `最少1天，最多${validDayMax.value}天`)

const cipherEnabled = computed(() => Number(form.value?.cipherType || 0) > 0)

// 开启领取口令：先做版本检测，受限则不开启；关闭时清空口令
const onCipherEnableChange = (e) => {
    if (!e.value) {
        form.value.cipherType = CIPHER_TYPE.OFF
        form.value.cipherCode = ''
        return
    }
    check(EDITION_FEATURES.RECEIVE_CIPHER).then((allowed) => {
        if (allowed) {
            form.value.cipherType = CIPHER_TYPE.FIXED
        }
    })
}

const setCipherType = (type) => {
    form.value.cipherType = type
    if (type === CIPHER_TYPE.RANDOM) {
        form.value.cipherCode = ''
    }
}

const validateCipherForm = () => {
    if (Number(form.value.cipherType) === CIPHER_TYPE.FIXED && !/^\d{5}$/.test(String(form.value.cipherCode || ''))) {
        utils.toast('固定口令须为5位数字')
        return false
    }
    return true
}

// 公开领取规则标签
const publicIssueRuleLabel = computed(() => {
    switch (form.value.publicIssueRule) {
        case 3:
            return '每人每天最多可领'
        case 4:
            return '每人每周最多可领'
        case 5:
            return '每人每月最多可领'
        case 6:
            return '每人每年最多可领'
        default:
            return '每人限领'
    }
})

// 到期提醒：提前 0～30 天可选
const expireForwardDayOptions = () => Array.from({length: 31}, (_, i) => ({
    label: i === 0 ? '到期当天' : i + '天',
    value: i,
}))

// 详情赋值后补全表单缺省字段，避免开关/嵌套对象未定义
const normalizeForm = (data) => {
    if (!data.validRuleTime) {
        data.validRuleTime = {
            isCustom: false,
            weekDay: ['1', '2', '3', '4', '5', '6', '0'],
            openHours: [{startTime: '00:00', endTime: '23:59'}],
        }
    }
    // 后端可能返回数字数组，统一转为字符串与组件选项匹配
    if (Array.isArray(data.validRuleTime.weekDay)) {
        data.validRuleTime.weekDay = data.validRuleTime.weekDay.map(String)
    }
    if (data.isAppt == null) data.isAppt = false
    if (data.apptDesc == null) data.apptDesc = ''
    if (data.isExpireNotice == null) data.isExpireNotice = false
    if (data.expireForwardDay == null) data.expireForwardDay = 0
    // 券包发放不支持口令、指定手机号，也不做每人限领、仅新客户可领
    if (Number(data.issueType) === ISSUE_TYPE.BUNDLE) {
        data.isTotalLimit = false
        data.cipherType = CIPHER_TYPE.OFF
        data.cipherCode = ''
        data.isMobileLimit = false
        data.isGetMobile = false
        data.isOnlyNewCustomer = false
        data.allowMobiles = []
    }
    if (Number(data.issueType) !== ISSUE_TYPE.PUBLIC) {
        data.isOnlyGroup = false
    }
    if (data.isMobileLimit == null) data.isMobileLimit = false
    if (data.isOnlyGroup == null) data.isOnlyGroup = false
    if (!Array.isArray(data.allowMobiles)) data.allowMobiles = []
    if (data.cipherType == null) data.cipherType = CIPHER_TYPE.OFF
    if (data.cipherCode == null) data.cipherCode = ''
    return data
}

// 关闭转赠时，联动关闭转赠奖励并清空奖励券
const onTransferChange = (e) => {
    if (!e.value) {
        form.value.isTransferReward = false
        form.value.transferRewardCouponId = undefined
    }
}

// 开启手机号：标准版及以上支持，受限则回退开关
const onGetMobileChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.GET_MOBILE).then((allowed) => {
        if (!allowed) form.value.isGetMobile = false
    })
}

// 开启仅新客户可领：标准版及以上支持，受限则回退开关
const onOnlyNewCustomerChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_NEW_CUSTOMER).then((allowed) => {
        if (!allowed) form.value.isOnlyNewCustomer = false
    })
}

// 开启禁止群内成员转发出群：标准版及以上支持，受限则回退开关
const onOnlyGroupChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_GROUP).then((allowed) => {
        if (!allowed) form.value.isOnlyGroup = false
    })
}

// 开启指定手机号可领取：专业版及以上支持，受限则回退开关并还原被联动强制打开的手机号
const onMobileLimitChange = (e) => {
    if (!e?.value) return
    // 开关开启瞬间 watch 会联动强制 isGetMobile=true，这里先记录用户原本的选择，拦截后还原
    const prevGetMobile = form.value.isGetMobile
    check(EDITION_FEATURES.MOBILE_LIMIT).then((allowed) => {
        if (!allowed) {
            form.value.isMobileLimit = false
            form.value.isGetMobile = prevGetMobile
        }
    })
}

// 开启核销后赠券：标准版及以上支持，受限则回退开关
const onVerifyRewardChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.VERIFY_REWARD).then((allowed) => {
        if (!allowed) form.value.isVerifyReward = false
    })
}

// 开启动态核销码：企业版及以上支持，受限则回退开关
const onVerifySignChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.VERIFY_SIGN).then((allowed) => {
        if (!allowed) form.value.isVerifySign = false
    })
}

// 开启转介绍裂变：先做版本检测（不支持弹升级并回退），再校验须先开启允许转赠（未开启弹框提示）
const onTransferRewardChange = (e) => {
    if (!e?.value) {
        form.value.isTransferReward = false
        form.value.transferRewardCouponId = undefined
        return
    }
    check(EDITION_FEATURES.TRANSFER_REWARD).then((allowed) => {
        if (!allowed) {
            form.value.isTransferReward = false
            return
        }
        if (!form.value.isTransfer) {
            form.value.isTransferReward = false
            uni.showModal({
                title: '提示',
                content: '开启转介绍裂变前，请先开启允许转赠',
                showCancel: false,
            })
            return
        }
        form.value.isTransferReward = true
    })
}

watch(() => form.value?.isMobileLimit, (isMobileLimit) => {
    if (isMobileLimit && form.value) {
        form.value.isGetMobile = true
    }
    if (!isMobileLimit && form.value) {
        form.value.allowMobiles = []
    }
})

// 转发封面
const shareCover = computed(() => {
    if (form.value.coverImages.length > 0) {
        form.value.shareCover = form.value.coverImages[0]
        return form.value.coverImages[0]
    }
    return null
})

// 获取优惠券详情
const getDetail = () => {
    request.get('/seller/coupon/detail', {
        id: couponId.value,
    }).then((res) => {
        coupon.value = res.data
        couponType.value = Number(res.data.couponType)
        form.value = normalizeForm(res.data)
        uni.setNavigationBarTitle({title: '修改' + form.value.couponTypeLabel})
    }).catch((err) => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            coupon.value = null
        }
    })
}

// 提交修改表单
const onSubmit = utils.throttle(() => {
    if (form.value.issueType === ISSUE_TYPE.BUNDLE) {
        form.value.isTotalLimit = false
        form.value.cipherType = CIPHER_TYPE.OFF
        form.value.cipherCode = ''
        form.value.isGetMobile = false
        form.value.isOnlyNewCustomer = false
    }
    if (!validateCipherForm()) return
    loading.value = true
    request.post('/seller/coupon/update', form.value).then(() => {
        return request.get('/seller/coupon/detail', {id: couponId.value})
    }).then(res => {
        uni.$emit('onCouponUpdate', res.data)
        isSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}, 800)

// 套用使用须知模板
const onUseContentTemplate = (templateId) => {
    if (templateId === 1) {
        form.value.content = `● 遗失处理：优惠券仅限本人使用，请勿转借他人。因手机丢失、账号泄露等原因导致券被他人核销，责任由用户自行承担。
● 使用方式：到店消费时，请在结账前主动出示本券电子码（或纸质券），由店员扫码/核销后直接抵扣对应金额，无需额外操作。
● 找零兑现：本券不兑现、不找零，每单限用一张。
● 核销说明：逾期未核销将自动作废，不支持延期或补发；若遇门店临时停业（如装修、节假日调整），有效期不顺延。
● 适用范围：特价商品、团购套餐、礼品卡充值等特殊项目不适用（具体以门店公示为准）。
● 特别说明：严禁通过虚假交易等违规方式使用本券，一经发现，门店有权取消核销资格并追回优惠金额；本券最终解释权归本店所有，如有疑问可联系门店客服
● 最终解释权：在法律允许范围内，本店拥有本次活动最终解释权。`
    }
}

// 一键清空使用须知（二次确认防止误触）
const onClearContent = () => {
    uni.showModal({
        title: '提示',
        content: '确定清空使用须知吗？',
        success: (res) => {
            if (res.confirm) {
                form.value.content = ''
            }
        }
    })
}

// 页面加载时读取优惠券ID并加载详情
onLoad((e) => {
    if (!e.couponId) {
        utils.toast('缺少优惠券ID')
        setTimeout(() => {
            back()
        }, 1500)
        return
    }
    couponId.value = e.couponId
    getDetail()
})

// 每次进入页面刷新员工会话，保证升级后版本信息即时生效（升级成功会跳转订单页，返回时触发）
onShow(() => {
    getSession()
})
</script>

<style>
.cipher-type-tabs {
    display: flex;
    gap: 20rpx;
    padding: 32rpx 32rpx 0;
    background: #fff;
}

.cipher-type-tab {
    flex: 1;
    padding: 18rpx 0;
    text-align: center;
    font-size: 28rpx;
    color: #666;
    background: #fff;
    border-radius: 12rpx;
    border: 2rpx solid #dcdcdc;
    box-sizing: border-box;
}

.cipher-type-tab.active {
    color: #e84c59;
    background: #fff;
    border-color: #e84c59;
    font-weight: 600;
}

.switch-label {
    font-size: 12rpx !important;
}

.share-cover-placeholder {
    display: flex;
    align-items: center;
    justify-content: center;
    width: 160rpx;
    height: 120rpx;
    background-color: #f7f7f7;
    border-radius: 8rpx;
}

/*
 * 自定义样式原因：使用须知工具栏为「灯泡图标引导 + 文字按钮」单行内联组合，
 * app.css 的 .tips-card 是整块提示卡（含标题/多行），不适合单行工具条；TDesign 亦无对应组件。
 * 替代方案：白底融入卡片、细分隔线区隔内容，图标色取 --td-brand-color，仅补缺位视觉层。
 */
.usage-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16rpx 16rpx 16rpx 32rpx;
    background-color: #FFFFFF;
    border-top: 1rpx solid #F0F0F0;
}

.usage-toolbar-tip {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 16rpx;
}

.usage-toolbar-tip-text {
    font-size: 24rpx;
    color: #666;
    margin-left: 8rpx;
}

.usage-toolbar-actions {
    display: flex;
    align-items: center;
    flex-shrink: 0;
}
</style>
