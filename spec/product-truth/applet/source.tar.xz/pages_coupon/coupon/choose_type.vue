<template>
    <view class="container-safety">
        <view class="type-grid container mt-2">
            <view
                v-for="item in typeOptions"
                :key="item.type"
                class="type-card"
                :class="{'type-card--active': selectedType === item.type}"
                @click="onSelectType(item.type)"
            >
                <view class="type-icon" :style="{ backgroundColor: item.iconBg }">
                    <t-icon :name="item.icon" size="40rpx" :color="item.iconColor"/>
                </view>
                <view class="type-card-body">
                    <view class="type-card-title">{{ item.title }}</view>
                    <view class="type-card-desc">{{ item.desc }}</view>
                </view>
                <view v-if="selectedType === item.type" class="type-card-check">✓</view>
            </view>
        </view>

        <t-cell-group title="微信卡包" t-title-class="mt-2" theme="card">
            <t-cell
                :bordered="!checkPermission(PERM_MERCHANT.SETTING)"
                :description="wecardSwitchDisabled ? '套餐券、兑换券、手气券不支持同步' : '仅代金券、满减券、折扣券可开启'"
            >
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>加入微信卡包</text>
                        <m-edition-badge :feature="EDITION_FEATURES.WECARD" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch
                        v-model:value="isAllowWecard"
                        :disabled="wecardSwitchDisabled"
                        @change="onWecardChange"
                    />
                </template>
            </t-cell>
            <t-cell
                v-if="checkPermission(PERM_MERCHANT.SETTING)"
                title="微信卡包设置"
                note="LOGO、封面与主题色"
                arrow
                hover
                :bordered="false"
                @click="push('/pages_merchant/setting/wecard/index')"
            />
        </t-cell-group>

        <t-popup
            v-model:visible="showWecardTips"
            placement="bottom"
            :close-on-overlay-click="false"
        >
            <view class="popup-container">
                <view class="popup-header">
                    <view class="popup-header-title">开启微信卡包须知</view>
                </view>
                <view class="wecard-tips">
                    <view class="wecard-tips-list">
                        <view class="wecard-tips-item wecard-tips-item--lead">以下限制均受微信卡包规则约束，请确认可接受后再开启</view>
                        <view class="wecard-tips-item">仅代金券、满减券、折扣券可同步</view>
                        <view class="wecard-tips-item">代金券同步至微信卡包，显示为「商家满减券」</view>
                        <view class="wecard-tips-item">无门槛优惠券，微信卡包内显示0.01元</view>
                        <view class="wecard-tips-item">有效期最长 365 天</view>
                        <view class="wecard-tips-item">不支持转赠（开启后创建页将隐藏转赠）</view>
                        <view class="wecard-tips-item">领取券包时，暂不支持一键加入微信卡包</view>
                        <view class="wecard-tips-item">卡券创建后，面额/门槛/折扣/有效期/限领等不可再改</view>
                        <view class="wecard-tips-item">每人每券最多同步 100 张，超出部分将无法同步</view>
                    </view>
                    <view class="container mt-3">
                        <t-button theme="primary" block @click="showWecardTips = false">我知道了</t-button>
                    </view>
                </view>
            </view>
        </t-popup>

        <m-submit :disabled="!selectedType" @click="onNext">下一步</m-submit>
        <!-- VIP 升级抽屉：门禁 check 确认后经事件打开 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {onShow} from '@dcloudio/uni-app';
import {computed, ref} from 'vue'
import {COUPON_TYPE} from '@/constants/coupon'
import {EDITION_FEATURES} from '@/constants/edition'
import {PERM_MERCHANT} from '@/constants/permission'
import {useAuth} from '@/hooks/useAuth.js'
import {useLink} from '@/hooks/useLink.js'
import {useVipGuard} from '@/hooks/useVipGuard'
import MSubmit from '@/components/m/m-submit/m-submit.vue'

const {checkPermission, getSession} = useAuth()
const {push} = useLink()
const {check} = useVipGuard()

// 支持同步微信卡包的券类型
const WECARD_TYPES = [COUPON_TYPE.CASH, COUPON_TYPE.REDUCE, COUPON_TYPE.DISCOUNT]

// 六种优惠券类型（白底卡片直铺页面，参考官网能力网格）
const typeOptions = [
    {
        type: COUPON_TYPE.CASH,
        title: '代金券',
        desc: '无门槛80代100',
        icon: 'money',
        iconBg: '#e8f8ef',
        iconColor: '#07c160'
    },
    {
        type: COUPON_TYPE.PACKAGE,
        title: '套餐券',
        desc: '五一欢乐套餐4选3',
        icon: 'gift',
        iconBg: '#fff3e6',
        iconColor: '#ed7b2f'
    },
    {
        type: COUPON_TYPE.REDUCE,
        title: '满减券',
        desc: '消费满100减20',
        icon: 'coupon',
        iconBg: '#fdecee',
        iconColor: '#e34d59'
    },
    {
        type: COUPON_TYPE.DISCOUNT,
        title: '折扣券',
        desc: '消费满50打85折',
        icon: 'discount',
        iconBg: '#f3e8ff',
        iconColor: '#8b5cf6'
    },
    {
        type: COUPON_TYPE.EXCHANGE,
        title: '兑换券',
        desc: '凭券兑换冷饮一杯',
        icon: 'swap',
        iconBg: '#e8f7f7',
        iconColor: '#00a870'
    },
    {
        type: COUPON_TYPE.RANDOM,
        title: '手气券',
        desc: '群里抢券随机金额',
        icon: 'star',
        iconBg: '#e8f3ff',
        iconColor: '#0052d9'
    },
]

// 当前选中的券类型
const selectedType = ref(0)
// 是否开启同步微信卡包
const isAllowWecard = ref(false)
// 是否展示卡包须知弹层
const showWecardTips = ref(false)

// 不支持卡包的类型选中时，开关置灰
const wecardSwitchDisabled = computed(() => {
    return !!selectedType.value && !WECARD_TYPES.includes(selectedType.value)
})

// 选择券类型；不支持卡包的类型会关掉开关
const onSelectType = (couponType) => {
    selectedType.value = couponType
    if (!WECARD_TYPES.includes(couponType)) {
        isAllowWecard.value = false
    }
}

// 开启卡包：先做版本检测，受限则回退开关并弹升级提醒；放行才弹卡包须知
const onWecardChange = (e) => {
    // t-switch change 入参是 { value }，不是裸 boolean
    if (!e?.value) return
    check(EDITION_FEATURES.WECARD).then((allowed) => {
        if (allowed) {
            showWecardTips.value = true
        } else {
            isAllowWecard.value = false
        }
    })
}

// 进入制券页，带上类型与卡包开关
const onNext = () => {
    if (!selectedType.value) return
    const allow = isAllowWecard.value && WECARD_TYPES.includes(selectedType.value) ? 1 : 0
    uni.navigateTo({
        url: `/pages_coupon/coupon/create?couponType=${selectedType.value}&isAllowWecard=${allow}`,
    })
}

onShow(() => {
    getSession()
})

</script>

<style scoped>
.type-grid {
    display: flex;
    flex-wrap: wrap;
    gap: 20rpx;
    box-sizing: border-box;
}

.type-card {
    position: relative;
    box-sizing: border-box;
    width: calc((100% - 20rpx) / 2);
    padding: 28rpx 24rpx;
    border-radius: 24rpx;
    background: #fff;
    border: 2rpx solid transparent;
    display: flex;
    align-items: center;
}

.type-card--active {
    border-color: #e34d59;
    background: #fff8f7;
}

.type-icon {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin-right: 16rpx;
}

.type-card-body {
    flex: 1;
    min-width: 0;
}

.type-card-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #1a1a1a;
    line-height: 1.3;
}

.type-card-desc {
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #8c8c8c;
    line-height: 1.45;
}

.type-card-check {
    position: absolute;
    right: 16rpx;
    top: 16rpx;
    width: 32rpx;
    height: 32rpx;
    border-radius: 50%;
    background: #e34d59;
    color: #fff;
    font-size: 20rpx;
    line-height: 32rpx;
    text-align: center;
}

.wecard-tips {
    padding: 8rpx 0 32rpx;
}

.wecard-tips-list {
    background: #fff;
    border-radius: 16rpx;
    margin: 0 24rpx;
    padding: 12rpx 28rpx;
}

.wecard-tips-item {
    position: relative;
    padding: 22rpx 0 22rpx 28rpx;
    font-size: 28rpx;
    color: #4a4a4a;
    line-height: 1.65;
}

.wecard-tips-item--lead {
    padding-left: 0;
    font-weight: 600;
    color: #1a1a1a;
}

.wecard-tips-item--lead::before {
    display: none;
}

.wecard-tips-item + .wecard-tips-item {
    border-top: 1rpx solid #f0f0f0;
}

.wecard-tips-item::before {
    content: '';
    position: absolute;
    left: 0;
    top: 36rpx;
    width: 10rpx;
    height: 10rpx;
    border-radius: 50%;
    background: #e34d59;
}
</style>
