<template>
    <m-result v-if="isSuccess"
              type="success"
              title="创建成功"
              description="立刻发放我的卡券"
              confirmText="前往发券"
              cancelText="返回"
              @confirm="replace('/pages_coupon/coupon/detail?couponId=' + couponId)"
              @cancel="back()"
    >
    </m-result>
    <m-loading v-else-if="isCopyLoading"></m-loading>
    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view class="input-custom-label-required">封面图片</view>
                <view class="text-small text-success">最多5张，推荐尺寸：5:4</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="form.coverImages"
                    :cropperWidth="300"
                    :cropperHeight="240"
                    :beforeAdd="onBeforeCoverAdd"
                    emitName="couponCover"
                >
                </m-cover-uploader>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="发放方式" required>
                <template #description>
                    <view class="issue-type-hint">请点击选择，创建后不可修改此项。</view>
                    <view class="issue-type-tags">
                        <view
                            v-for="item in issueTypeOptions"
                            :key="item.value"
                            class="issue-type-tag"
                            :class="{ 'is-active': form.issueType === item.value, 'is-disabled': item.disabled }"
                            @click="onSelectIssueType(item.value)"
                        >{{ item.label }}
                        </view>
                    </view>
                </template>
            </t-cell>
            <view class="cell-helper" v-if="form.issueType > 0">
                <text v-if="form.issueType === ISSUE_TYPE.PUBLIC" class="lh-25 text-success">
                    公开领取：支持微信群/好友、二维码、公众号、海报、企微群、企微群助理、企微客户群发等发券渠道，所有人都可领取，适合公开引流活动。
                </text>
                <text v-if="form.issueType === ISSUE_TYPE.PRIVATE" class="lh-25 text-success">
                    私密发放：支持私发微信好友、二维码、企微好友等发券渠道，适合给指定好友发券、储值回馈、消费赠礼、补偿等私密活动。
                </text>
                <text v-if="form.issueType === ISSUE_TYPE.BUNDLE" class="lh-25 text-success">
                    券包：供券包选择，适合多种类型优惠券打包一次发给顾客。
                    <text v-if="form.isAllowWecard">领取券包时，微信卡包暂时不支持一键加入。</text>
                </text>
            </view>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-input
                placeholder="最多18个字，支持表情符号"
                align="right"
                :maxlength="18"
                v-model:value="form.name"
            >
                <template #label>
                    <view class="input-custom-label-required">优惠券名称</view>
                </template>
            </t-input>
            <t-input
                placeholder="最少1张，最多1万张"
                type="number"
                align="right"
                v-model:value="form.totalStock"
                suffix="张"
            >
                <template #label>
                    <view class="input-custom-label-required">制作数量</view>
                </template>
            </t-input>
            <t-input
                placeholder="满多少元可用，0为无门槛"
                align="right"
                type="digit"
                v-model:value="form.thresholdAmount"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">消费门槛</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.CASH || couponType === COUPON_TYPE.PACKAGE"
                :placeholder="originalPlaceholder"
                type="digit"
                v-model:value="form.originalPrice"
                align="right"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">原价</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.CASH || couponType === COUPON_TYPE.PACKAGE"
                :placeholder="faceAmountPlaceholder"
                type="digit"
                v-model:value="form.faceAmount"
                align="right"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">券面额</view>
                </template>
            </t-input>
            <t-input v-if="couponType === COUPON_TYPE.REDUCE"
                     placeholder="优惠减免金额"
                     type="digit"
                     align="right"
                     v-model:value="form.reduceAmount"
                     suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">优惠金额</view>
                </template>
            </t-input>
            <t-input v-if="couponType === COUPON_TYPE.DISCOUNT"
                     placeholder="8.5折输入8.5，9折输入9"
                     type="digit"
                     align="right"
                     v-model:value="form.discountAmount"
                     suffix="折"
            >
                <template #label>
                    <view class="input-custom-label-required">折扣</view>
                </template>
            </t-input>
            <t-input v-if="couponType === COUPON_TYPE.EXCHANGE"
                     placeholder="例：冷饮一杯，最多10个字"
                     align="right"
                     v-model:value="form.exchangeProduct"
            >
                <template #label>
                    <view class="input-custom-label-required">兑换内容</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.RANDOM"
                placeholder="必须为整数，最低1元"
                type="digit"
                align="right"
                v-model:value="form.randomMinAmount"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">随机最小金额</view>
                </template>
            </t-input>
            <t-input
                v-if="couponType === COUPON_TYPE.RANDOM"
                placeholder="必须为整数，最高99元"
                type="digit"
                align="right"
                v-model:value="form.randomMaxAmount"
                suffix="元"
            >
                <template #label>
                    <view class="input-custom-label-required">随机最大金额</view>
                </template>
            </t-input>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-select
                required
                title="有效期类型"
                v-model:value="form.validType"
                :options="validTypeOptions"
            >
            </m-select>
            <t-input
                v-if="form.validType !== VALID_TYPE.CUSTOM"
                :placeholder="validDayPlaceholder"
                type="number"
                align="right"
                v-model:value="form.validDay"
                suffix="天"
            >
                <template #label>
                    <view class="input-custom-label-required">有效期</view>
                </template>
            </t-input>
            <m-datetime-picker
                v-if="form.validType === VALID_TYPE.CUSTOM"
                required
                v-model:value="form.validStartTime"
                format="YYYY-MM-DD"
                title="有效开始时间"
                placeholder="选择开始时间"
                mode="date"
            >
            </m-datetime-picker>
            <m-datetime-picker
                v-if="form.validType === VALID_TYPE.CUSTOM"
                required
                v-model:value="form.validEndTime"
                format="YYYY-MM-DD"
                title="有效结束时间"
                placeholder="选择结束时间"
                mode="date"
            >
            </m-datetime-picker>
            <t-cell title="可用时段" hover description="默认全天可用，可自定义周天及可用时段">
                <template #note>
                    <t-switch v-model:value="form.validRuleTime.isCustom" t-class-label="switch-label"
                              :label="['定制', '全天']"/>
                </template>
            </t-cell>
            <template v-if="form.validRuleTime.isCustom">
                <m-week-picker v-model:value="form.validRuleTime.weekDay"></m-week-picker>
                <view style="background-color: #fff">
                    <m-openhour-picker v-model:value="form.validRuleTime.openHours" :max="2"></m-openhour-picker>
                </view>
            </template>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-store-select
                required
                title="适用门店"
                placeholder="请选择适用门店（必选）"
                :multiple="true"
                :bordered="true"
                :show-disabled="true"
                :auto-selected="true"
                v-model:value="form.storeIds"
            >
            </m-store-select>
            <m-staff-select v-if="form.issueType === ISSUE_TYPE.PUBLIC || form.issueType === ISSUE_TYPE.PRIVATE"
                            required
                            title="发券员工"
                            placeholder="请选择发券员工（必选）"
                            :multiple="true"
                            :show-disabled="true"
                            v-model:value="form.staffIds"
            >
            </m-staff-select>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false"
                      v-if="form.issueType !== ISSUE_TYPE.BUNDLE">
            <t-cell title="限领总量"
                    description="每个客户累计领取的总张数，关闭则不限制">
                <template #note>
                    <t-switch v-model:value="form.isTotalLimit"/>
                </template>
            </t-cell>
            <t-input
                v-if="form.isTotalLimit"
                placeholder="最少1张，最多100张"
                type="number"
                align="right" borderless
                v-model:value="form.totalLimitCount"
                suffix="张"
            >
                <template #label>
                    <view class="input-custom-label-required">每人限领总量</view>
                </template>
            </t-input>
            <t-cell description="该商户下从未领过优惠券、券包、次卡的顾客才可领取" :bordered="false">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>仅新客户可领</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_NEW_CUSTOMER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyNewCustomer" :default-value="false"
                              @change="onOnlyNewCustomerChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 公开发放设置 -->
        <t-cell-group v-if="form.issueType === ISSUE_TYPE.PUBLIC" title="公开领取设置" t-title-class="mt-2" theme="card"
                      :bordered="false">
            <t-cell title="自定义领取时间" :bordered="form.isCustomReceiveTime"
                    description="默认不限，有效期截止前均可领取">
                <template #note>
                    <t-switch v-model:value="form.isCustomReceiveTime" :default-value="false"/>
                </template>
            </t-cell>
            <m-datetime-picker
                v-if="form.isCustomReceiveTime"
                required
                title="领取开始时间"
                v-model:value="form.receiveStartTime"
            >
            </m-datetime-picker>
            <m-datetime-picker
                v-if="form.isCustomReceiveTime"
                required
                title="领取结束时间"
                v-model:value="form.receiveEndTime"
            >
            </m-datetime-picker>
            <template
                v-if="!form.isTotalLimit || (form.isTotalLimit && form.totalLimitCount > 1)">
                <m-select
                    required
                    title="每次领取数量"
                    v-model:value="form.publicIssueCount"
                    placeholder="最少1张，最多10张"
                    :options="[
					{ label: '1张', value: 1 },
					{ label: '2张', value: 2 },
					{ label: '3张', value: 3 },
					{ label: '4张', value: 4 },
					{ label: '5张', value: 5 },
					{ label: '6张', value: 6 },
					{ label: '7张', value: 7 },
					{ label: '8张', value: 8 },
					{ label: '9张', value: 9 },
					{ label: '10张', value: 10 }
				]"
                ></m-select>
                <m-select
                    required
                    title="领取周期"
                    v-model:value="form.publicIssueRule"
                    :options="[
					{ label: '每人每天最多可领', value: 3 },
					{ label: '每人每周最多可领', value: 4 },
					{ label: '每人每月最多可领', value: 5 },
					{ label: '每人每年最多可领', value: 6 }
				]"
                ></m-select>
                <t-input
                    placeholder="最少1张"
                    type="number"
                    align="right"
                    borderless
                    v-model:value="form.publicIssueRuleCount"
                    suffix="张"
                >
                    <template #label>
                        <view class="input-custom-label-required">{{ publicIssueRuleLabel }}</view>
                    </template>
                </t-input>
            </template>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="开启每天核销限制">
                <template #note>
                    <t-switch v-model:value="form.isVerifyLimit" :default-value="false"/>
                </template>
            </t-cell>
            <m-select
                v-if="form.isVerifyLimit"
                title="每人每天限核销"
                v-model:value="form.verifyLimitCount"
                placeholder="最少1张，最多10张"
                :options="[
					{ label: '1张', value: 1 },
					{ label: '2张', value: 2 },
					{ label: '3张', value: 3 },
					{ label: '4张', value: 4 },
					{ label: '5张', value: 5 },
					{ label: '6张', value: 6 },
					{ label: '7张', value: 7 },
					{ label: '8张', value: 8 },
					{ label: '9张', value: 9 },
					{ label: '10张', value: 10 }
				]"
            ></m-select>
            <t-cell description="核销后立奖本券一张，直接到账">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启核销后赠券</text>
                        <m-edition-badge :feature="EDITION_FEATURES.VERIFY_REWARD" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isVerifyReward" :default-value="false" @change="onVerifyRewardChange"/>
                </template>
            </t-cell>
            <t-cell description="开启后核销码5分钟刷新一次，可有效减少截屏核销">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启动态核销码</text>
                        <m-edition-badge :feature="EDITION_FEATURES.VERIFY_SIGN" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isVerifySign" @change="onVerifySignChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 转介绍裂变：两开关同卡片平铺展示；开裂变先版本检测再校验转赠前置，关转赠联动关裂变 -->
        <t-cell-group v-if="!form.isAllowWecard" title="转介绍裂变" theme="card" t-title-class="mt-2"
                      :bordered="false">
            <t-cell title="允许转赠" description="开启后顾客可将券转赠给好友">
                <template #note>
                    <t-switch v-model:value="form.isTransfer" :default-value="false" @change="onTransferChange"/>
                </template>
            </t-cell>
            <t-cell description="顾客把券转赠好友，好友到店核销后，自动奖励转赠人一张券，老客帮您带新客"
                    :bordered="!form.isTransferReward">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启转介绍裂变</text>
                        <m-edition-badge :feature="EDITION_FEATURES.TRANSFER_REWARD" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isTransferReward" :default-value="false"
                              @change="onTransferRewardChange"/>
                </template>
            </t-cell>
            <m-coupon-select v-if="form.isTransferReward" required title="转赠奖励券"
                             tip="仅可选择「私密发放」类型的有效优惠券"
                             v-model:value="form.transferRewardCouponId"/>
        </t-cell-group>
        <!-- 同步微信卡包时不支持转赠，仅展示只读提示 -->
        <t-cell-group v-else title="转介绍裂变" theme="card" t-title-class="mt-2" :bordered="false">
            <t-cell title="允许转赠" note="已关闭" description="开启微信卡包后不支持转赠" :bordered="false"/>
        </t-cell-group>

        <t-cell-group v-if="form.issueType !== ISSUE_TYPE.BUNDLE" title="线下收款口令" theme="card" t-title-class="mt-2"
                      :bordered="false">
            <t-cell description="开启后顾客领取须输入口令">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启领取口令</text>
                        <m-edition-badge :feature="EDITION_FEATURES.RECEIVE_CIPHER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch :value="cipherEnabled" @change="onCipherEnableChange"/>
                </template>
            </t-cell>
            <template v-if="cipherEnabled">
                <view class="cipher-type-tabs">
                    <view class="cipher-type-tab"
                          :class="{ active: form.cipherType === CIPHER_TYPE.FIXED }"
                          @click="setCipherType(CIPHER_TYPE.FIXED)">固定口令
                    </view>
                    <view class="cipher-type-tab"
                          :class="{ active: form.cipherType === CIPHER_TYPE.RANDOM }"
                          @click="setCipherType(CIPHER_TYPE.RANDOM)">随机口令
                    </view>
                </view>
                <t-input v-if="form.cipherType === CIPHER_TYPE.FIXED" label="口令" v-model:value="form.cipherCode"
                         align="right" placeholder="请输入5位数字" :maxlength="5" type="number"/>
                <t-cell v-else description="每3分钟变化一次，可手工更新" :bordered="false"/>
            </template>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea
                label="使用须知"
                v-model:value="form.content"
                :maxlength="500"
                :indicator="true"
                placeholder="请输入使用须知"
            >
            </t-textarea>
            <m-cover-uploader
                v-model:value="form.productImages"
                :max="1"
                :beforeAdd="onBeforeProductAdd"
                tip="可上传活动长图、店内环境、菜单等图片"
                emitName="couponProduct"
            >
            </m-cover-uploader>
            <view class="usage-toolbar">
                <view class="usage-toolbar-tip">
                    <t-icon name="lightbulb" size="28rpx" color="var(--td-brand-color)"/>
                    <text class="usage-toolbar-tip-text">不会写？一键套用模版</text>
                </view>
                <view class="usage-toolbar-actions">
                    <t-button theme="primary" variant="text" size="small" @click="onUseContentTemplate(1)">通用模版</t-button>
                    <t-button t-class="ml-2" theme="default" variant="text" size="small" :disabled="!form.content"
                              custom-style="background-color: transparent;" @click="onClearContent">清空
                    </t-button>
                </view>
            </view>
        </t-cell-group>

        <t-cell-group title="套餐设置" t-title-class="mt-2" theme="card" :bordered="false">
            <t-cell title="填写套餐组合">
                <template #note>
                    <t-switch v-model:value="form.isCombo"></t-switch>
                </template>
            </t-cell>
            <m-coupon-combo v-if="form.isCombo" v-model:value="form.combos"></m-coupon-combo>
        </t-cell-group>

        <t-cell-group title="预约设置" theme="card" t-title-class="mt-2" :bordered="false">
            <t-cell title="提前预约" description="开启后，顾客使用前需按说明提前预约">
                <template #note>
                    <t-switch v-model:value="form.isAppt" :default-value="false"/>
                </template>
            </t-cell>
            <t-input
                v-if="form.isAppt"
                label="预约说明"
                v-model:value="form.apptDesc"
                :maxlength="32"
                :indicator="true"
                placeholder="如提前几天、电话、到店时间等"
            />
        </t-cell-group>

        <t-cell-group title="到期提醒" theme="card" t-title-class="mt-2" :bordered="false">
            <t-cell title="到期提醒" description="开启后，顾客订阅了卡券到期提醒时，将收到微信通知">
                <template #note>
                    <t-switch v-model:value="form.isExpireNotice" :default-value="false"/>
                </template>
            </t-cell>
            <m-select
                v-if="form.isExpireNotice"
                title="提前提醒"
                v-model:value="form.expireForwardDay"
                placeholder="请选择"
                :options="expireForwardDayOptions()"
            ></m-select>
        </t-cell-group>

        <!-- 领券前填写信息 -->
        <t-cell-group v-if="form.issueType !== ISSUE_TYPE.BUNDLE" t-title-class="mt-2" :bordered="false"
                      title="领券顾客信息" theme="card">
            <t-cell :bordered="false">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>填写手机号</text>
                        <m-edition-badge :feature="EDITION_FEATURES.GET_MOBILE" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isGetMobile" :default-value="false" :disabled="form.isMobileLimit" @change="onGetMobileChange"/>
                </template>
            </t-cell>
            <t-cell description="导入可领取手机号，最多500个。" :bordered="!form.isMobileLimit">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>指定手机号可领取</text>
                        <m-edition-badge :feature="EDITION_FEATURES.MOBILE_LIMIT" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isMobileLimit" :default-value="false" @change="onMobileLimitChange"/>
                </template>
            </t-cell>
            <t-cell v-if="form.isMobileLimit" title="可领取手机号" arrow
                    :note="allowMobileCount + ' 个'"
                    @click="allowMobileVisible = true"/>
        </t-cell-group>

        <m-coupon-allow-mobile-panel v-model:visible="allowMobileVisible" v-model="form.allowMobiles"/>

        <t-cell-group title="自定义分享卡片" theme="card" t-title-class="mt-2" :bordered="false">
            <t-input label="分享标题" v-model:value="form.shareTitle" align="right"
                     placeholder="选填，最多32个字。"></t-input>
            <t-cell title="转发封面" :bordered="false" description="请先上传封面图片，默认使用封面图片的第一张">
                <template #note>
                    <t-image v-if="shareCover" :src="shareCover" width="150rpx"
                             height="120rpx" shape="round" mode="aspectFill"/>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 分享与转发设置：仅公开领取时显示 -->
        <t-cell-group v-if="form.issueType === ISSUE_TYPE.PUBLIC" title="分享与转发设置" t-title-class="mt-2" theme="card"
                      :bordered="false">
            <t-cell title="允许分享" :bordered="true">
                <template #note>
                    <t-switch v-model:value="form.isShare" :default-value="false"/>
                </template>
            </t-cell>
            <t-cell
                description="仅微信群生效，企业微信群暂不可用"
                :bordered="false"
            >
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>禁止群内成员转发出群</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_GROUP" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyGroup" :default-value="false" @change="onOnlyGroupChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" :disabled="loading" @click="onSubmit">
                创建优惠券
            </t-button>
        </view>
        <!-- VIP 升级抽屉：门禁 check 确认后经事件打开 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {onLoad, onShow, onUnload} from '@dcloudio/uni-app';
import {computed, ref, watch} from 'vue';
import request from '../../hooks/request.js';
import config from '../../config.js';
import {COUPON_TYPE, CIPHER_TYPE, ISSUE_TYPE, VALID_TYPE} from '@/constants/coupon.js';
import {EDITION_FEATURES, getFeatureQuota} from '@/constants/edition.js';;
import utils from '../../utils/utils';
import {useLink} from "@/hooks/useLink.js"
import {useSessionStore} from "@/stores/session";
import {useAuth} from "@/hooks/useAuth.js"
import {useVipGuard} from '@/hooks/useVipGuard'

const {replace, back} = useLink()
const session = useSessionStore()
const {getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()

const isSuccess = ref(false)
const couponId = ref()
const couponType = ref()
const loading = ref(false)
const form = ref({
    coverImages: [], // 封面图
    validType: 2, // 有效期类型
    isTotalLimit: true,
    issueType: null,
    totalLimitCount: 1, // 每人限领张数
    publicIssueRule: 3, // 公开领取发券规则，按天/周/月领取
    publicIssueCount: 1, // 公开发放每次数量
    publicIssueRuleCount: 1, // 公开发放规则数量
    isVerifyLimit: false, // 是否开启每天核销限制
    verifyLimitCount: 1, // 每人每天限核销张数
    isVerifySign: false, // 是否开启动态核销码
    cipherType: CIPHER_TYPE.OFF,
    cipherCode: '',
    isCombo: false, // 是否开启组合套餐
    combos: [],// 套餐组合数据
    productImages: [],
    shareCover: '', // 转发封面
    isAppt: false, // 是否需提前预约
    apptDesc: '', // 预约说明
    isExpireNotice: true, // 是否开启到期提醒
    expireForwardDay: 0, // 提前 N 天提醒，0 表示到期当天
    staffIds: [], // 发券员工ID列表
    isGetMobile: false, // 是否获取手机号
    isOnlyNewCustomer: false, // 仅新客户可领
    isMobileLimit: false, // 是否指定手机号可领取
    allowMobiles: [], // 可领取手机号
    isShare: false, // 是否允许分享
    isOnlyGroup: false, // 禁止群内成员转发出群
    shareTitle: '', // 分享标题
    isTransfer: false, // 是否允许转赠
    isTransferReward: false, // 是否开启转赠奖励
    transferRewardCouponId: undefined, // 转赠奖励券ID
    isVerifyReward: false, // 是否开启核销奖励
    isAllowWecard: false, // 是否同步微信卡包
    validRuleTime: {
        isCustom: false,
        weekDay: ['1', '2', '3', '4', '5', '6', '0'],
        openHours: [{startTime: '00:00', endTime: '23:59'}]
    },
})
const isCopyLoading = ref(false)
const allowMobileVisible = ref(false)

const allowMobileCount = computed(() => (form.value.allowMobiles || []).length)

const validTypeOptions = [
    {label: '固定有效期', value: VALID_TYPE.CUSTOM},
    {label: '自领取日起N天内有效', value: VALID_TYPE.TODAY},
    {label: '自领取次日起N天内有效', value: VALID_TYPE.NEXT_DAY},
]

// 发放方式选项：积分兑换暂未上线
const issueTypeOptions = computed(() => [
    {label: '公开领取', value: ISSUE_TYPE.PUBLIC},
    {label: '私密发放', value: ISSUE_TYPE.PRIVATE},
    {label: '券包', value: ISSUE_TYPE.BUNDLE},
    {label: '积分兑换', value: ISSUE_TYPE.POINTS, disabled: true},
])

// 切换发放方式
const onSelectIssueType = (value) => {
    if (value === ISSUE_TYPE.POINTS) {
        utils.toast('此功能即将上线')
        return
    }
    form.value.issueType = value
}

// 券包发放不支持领取口令、指定手机号，也不做每人限领、仅新客户可领
watch(() => form.value?.issueType, (issueType) => {
    if (!form.value) return
    if (issueType !== ISSUE_TYPE.PUBLIC) {
        form.value.isOnlyGroup = false
    }
    if (issueType === ISSUE_TYPE.BUNDLE) {
        form.value.isTotalLimit = false
        form.value.cipherType = CIPHER_TYPE.OFF
        form.value.cipherCode = ''
        form.value.isMobileLimit = false
        form.value.isGetMobile = false
        form.value.isOnlyNewCustomer = false
        form.value.allowMobiles = []
    }
})

watch(() => form.value?.isMobileLimit, (isMobileLimit) => {
    if (isMobileLimit && form.value) {
        form.value.isGetMobile = true
    }
    if (!isMobileLimit && form.value) {
        form.value.allowMobiles = []
    }
})

const originalPlaceholder = computed(() => {
    switch (couponType.value) {
        case 1:
            return '如：80代100，则填写100'
        case 2:
            return '请输入原价金额（单位：元）'
    }
})

const faceAmountPlaceholder = computed(() => {
    switch (couponType.value) {
        case 1:
            return '如：80代100，则填写80'
        case 2:
            return '请输入套餐金额（单位：元）'
    }
})

const publicIssueRuleLabel = computed(() => {
    switch (form.value.publicIssueRule) {
        case 3:
            return '每人每天最多可领'
        case 4:
            return '每人每周最多可领'
        case 5:
            return '每人每月最多可领'
        case 6:
            return '每人每年最多可领'
    }
})

const couponTypeLabel = computed(() => {
    const labels = {1: '代金券', 2: '套餐券', 3: '满减券', 4: '折扣券', 5: '兑换券', 6: '手气券'}
    return labels[couponType.value] || ''
})

const cipherEnabled = computed(() => Number(form.value?.cipherType || 0) > 0)

// 开启领取口令：先做版本检测，受限则不开启；关闭时清空口令
const onCipherEnableChange = (e) => {
    if (!e.value) {
        form.value.cipherType = CIPHER_TYPE.OFF
        form.value.cipherCode = ''
        return
    }
    check(EDITION_FEATURES.RECEIVE_CIPHER).then((allowed) => {
        if (allowed) {
            form.value.cipherType = CIPHER_TYPE.FIXED
        }
    })
}

const setCipherType = (type) => {
    form.value.cipherType = type
    if (type === CIPHER_TYPE.RANDOM) {
        form.value.cipherCode = ''
    }
}

const validateCipherForm = () => {
    if (Number(form.value.cipherType) === CIPHER_TYPE.FIXED && !/^\d{5}$/.test(String(form.value.cipherCode || ''))) {
        utils.toast('固定口令须为5位数字')
        return false
    }
    return true
}

// 到期提醒：提前 0～30 天可选
const expireForwardDayOptions = () => Array.from({length: 31}, (_, i) => ({
    label: i === 0 ? '到期当天' : i + '天',
    value: i,
}))

// 转发封面
const shareCover = computed(() => {
    if (form.value.coverImages.length > 0) {
        form.value.shareCover = form.value.coverImages[0]
        return form.value.coverImages[0]
    }
    return null
})

// 关闭转赠时，联动关闭转赠奖励并清空奖励券
const onTransferChange = (e) => {
    if (!e.value) {
        form.value.isTransferReward = false
        form.value.transferRewardCouponId = undefined
    }
}

// 开启填写手机号：标准版及以上支持，受限则回退开关
const onGetMobileChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.GET_MOBILE).then((allowed) => {
        if (!allowed) form.value.isGetMobile = false
    })
}

// 开启仅新客户可领：标准版及以上支持，受限则回退开关
const onOnlyNewCustomerChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_NEW_CUSTOMER).then((allowed) => {
        if (!allowed) form.value.isOnlyNewCustomer = false
    })
}

// 开启禁止群内成员转发出群：标准版及以上支持，受限则回退开关
const onOnlyGroupChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_GROUP).then((allowed) => {
        if (!allowed) form.value.isOnlyGroup = false
    })
}

// 开启指定手机号可领取：专业版及以上支持，受限则回退开关并还原被联动强制打开的填写手机号
const onMobileLimitChange = (e) => {
    if (!e?.value) return
    // 开关开启瞬间 watch 会联动强制 isGetMobile=true，这里先记录用户原本的选择，拦截后还原
    const prevGetMobile = form.value.isGetMobile
    check(EDITION_FEATURES.MOBILE_LIMIT).then((allowed) => {
        if (!allowed) {
            form.value.isMobileLimit = false
            form.value.isGetMobile = prevGetMobile
        }
    })
}

// 开启核销后赠券：标准版及以上支持，受限则回退开关
const onVerifyRewardChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.VERIFY_REWARD).then((allowed) => {
        if (!allowed) form.value.isVerifyReward = false
    })
}

// 开启动态核销码：企业版及以上支持，受限则回退开关
const onVerifySignChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.VERIFY_SIGN).then((allowed) => {
        if (!allowed) form.value.isVerifySign = false
    })
}

// 开启转介绍裂变：先做版本检测（不支持弹升级并回退），再校验须先开启允许转赠（未开启弹框提示）
const onTransferRewardChange = (e) => {
    if (!e?.value) {
        form.value.isTransferReward = false
        form.value.transferRewardCouponId = undefined
        return
    }
    check(EDITION_FEATURES.TRANSFER_REWARD).then((allowed) => {
        if (!allowed) {
            form.value.isTransferReward = false
            return
        }
        if (!form.value.isTransfer) {
            form.value.isTransferReward = false
            uni.showModal({
                title: '提示',
                content: '开启转介绍裂变前，请先开启允许转赠',
                showCancel: false,
            })
            return
        }
        form.value.isTransferReward = true
    })
}

// 有效期上限：按版本档位取值，开启微信卡包时受微信侧限制最长 365 天
const validDayMax = computed(() => {
    const quota = getFeatureQuota(EDITION_FEATURES.COUPON_VALID_DAY, staffSession.value?.editionId)
    const wecardLimit = (form.value.isAllowWecard || form.value.isSyncWecard) ? 365 : Infinity
    return Math.min(quota, wecardLimit)
})
// 有效期输入提示（随版本与微信卡包开关动态变化）
const validDayPlaceholder = computed(() => `最少1天，最多${validDayMax.value}天`)

// 封面图数量上限：按版本档位取值（免费/标准 1 张，专业/企业 5 张）
const coverMax = computed(() => {
    return getFeatureQuota(EDITION_FEATURES.COVER_IMAGE, staffSession.value?.editionId) || 1
})

// 点击添加封面：免费版/标准版仅支持1张，达到上限时检测并提示升级
const onBeforeCoverAdd = () => {
    if (form.value.coverImages.length < coverMax.value) return true
    return check(EDITION_FEATURES.COVER_IMAGE)
}

// 点击添加券内容图片：专业版及以上支持
const onBeforeProductAdd = () => {
    return check(EDITION_FEATURES.PRODUCT_IMAGE)
}

// 提交创建请求（在订阅弹窗 complete 回调中执行，避免异步链调用订阅 API）
const doCreate = () => {
    loading.value = true
    request.post('/seller/coupon/create', form.value).then((res) => {
        isSuccess.value = true
        couponId.value = res.data.couponId
        uni.$emit('onCouponCreate')
        form.value = undefined
        session.clearTempCoupon()
    }).finally(() => {
        loading.value = false
    })
}

// 提交表单：校验通过后在点击同步链中请求订阅商家消息，无论订阅结果均继续创建
const onSubmit = utils.throttle(() => {
    if (form.value.issueType === ISSUE_TYPE.BUNDLE) {
        form.value.isTotalLimit = false
        form.value.staffIds = []
        form.value.cipherType = CIPHER_TYPE.OFF
        form.value.cipherCode = ''
        form.value.isGetMobile = false
        form.value.isOnlyNewCustomer = false
    }
    if (form.value.issueType !== ISSUE_TYPE.PUBLIC) {
        form.value.isOnlyGroup = false
    }
    if (!validateCipherForm()) return
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.sellerMessage,
        complete() {
            doCreate()
        },
    })
}, 800)


const onUseContentTemplate = (templateId) => {
    if (templateId === 1) {
        form.value.content = `● 遗失处理：优惠券仅限本人使用，请勿转借他人。因手机丢失、账号泄露等原因导致券被他人核销，责任由用户自行承担。
● 使用方式：到店消费时，请在结账前主动出示本券电子码（或纸质券），由店员扫码/核销后直接抵扣对应金额，无需额外操作。
● 找零兑现：本券不兑现、不找零，每单限用一张。
● 核销说明：逾期未核销将自动作废，不支持延期或补发；若遇门店临时停业（如装修、节假日调整），有效期不顺延。
● 适用范围：特价商品、团购套餐、礼品卡充值等特殊项目不适用（具体以门店公示为准）。
● 特别说明：严禁通过虚假交易等违规方式使用本券，一经发现，门店有权取消核销资格并追回优惠金额；本券最终解释权归本店所有，如有疑问可联系门店客服
● 最终解释权：在法律允许范围内，本店拥有本次活动最终解释权。`;
    }
}

// 一键清空使用须知（二次确认防止误触）
const onClearContent = () => {
    uni.showModal({
        title: '提示',
        content: '确定清空使用须知吗？',
        success: (res) => {
            if (res.confirm) {
                form.value.content = ''
            }
        }
    })
}

// 详情赋值后补全表单缺省字段，避免开关/嵌套对象未定义
const normalizeForm = (data) => {
    if (!data.validRuleTime) {
        data.validRuleTime = {
            isCustom: false,
            weekDay: ['1', '2', '3', '4', '5', '6', '0'],
            openHours: [{startTime: '00:00', endTime: '23:59'}],
        }
    }
    if (data.isAppt == null) data.isAppt = false
    if (data.apptDesc == null) data.apptDesc = ''
    if (data.isExpireNotice == null) data.isExpireNotice = false
    if (data.expireForwardDay == null) data.expireForwardDay = 0
    if (data.cipherType == null) data.cipherType = CIPHER_TYPE.OFF
    if (data.cipherCode == null) data.cipherCode = ''
    if (!Array.isArray(data.allowMobiles)) data.allowMobiles = []
    return data
}

// 获取优惠券详情
const getDetail = () => {
    isCopyLoading.value = true
    request.get('/seller/coupon/detail', {
        id: couponId.value,
    }).then((res) => {
        isCopyLoading.value = false
        form.value = normalizeForm(res.data)
        setNavigationBarTitle(res.data.couponType)

    }).catch((err) => {
        isCopyLoading.value = false
    })
}

// 保存卡券草稿
const tempAlert = (couponType, tempCoupon) => {
    uni.showModal({
        showCancel: true,
        title: '提醒',
        content: '检测到您当前有未提交的草稿卡券，是否继续编辑？',
        confirmText: '继续编辑',
        cancelText: '放弃编辑',
        success(res) {
            if (res.confirm) {
                form.value = tempCoupon
                setNavigationBarTitle(tempCoupon.couponType)
            } else {
                setNavigationBarTitle(couponType)
            }
            session.clearTempCoupon()
        }
    })
}

// 更新导航栏标题
const setNavigationBarTitle = (type) => {
    couponType.value = parseInt(type)
    form.value.couponType = type
    uni.setNavigationBarTitle({
        title: '制作' + couponTypeLabel.value,
    })
}

onLoad((e) => {
    const tempCoupon = session.tempCoupon
    if (e.couponId) {//复制卡券来创建
        couponId.value = e.couponId
        getDetail()
    } else if (tempCoupon) {
        tempAlert(e.couponType, tempCoupon)
    } else {
        setNavigationBarTitle(e.couponType)
        form.value.isAllowWecard = e.isAllowWecard === '1' || e.isAllowWecard === 'true'
        if (form.value.isAllowWecard) {
            form.value.isTransfer = false
            form.value.isTransferReward = false
            form.value.transferRewardCouponId = undefined
        }
        // 套餐券默认开启套餐组合
        if (Number(e.couponType) === COUPON_TYPE.PACKAGE) {
            form.value.isCombo = true
        }
    }
})

onUnload(() => {
    //页面卸载时，缓存当前优惠券数据
    if (!isSuccess.value && form.value && (form.value.name || form.value.coverImages.length > 0)) {
        session.setTempCoupon(form.value)
    }
})

// 每次进入页面刷新员工会话，保证升级后版本信息即时生效（升级成功会跳转订单页，返回时触发）
onShow(() => {
    getSession()
})

</script>

<style>
/* 筛选弹框 switch */
.cipher-type-tabs {
    display: flex;
    gap: 20rpx;
    padding: 32rpx 32rpx 0;
    background: #fff;
}

.issue-type-hint {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.issue-type-tags {
    display: flex;
    gap: 16rpx;
    margin-top: 20rpx;
}

.issue-type-tag {
    flex: 1;
    height: 68rpx;
    line-height: 64rpx;
    text-align: center;
    font-size: 28rpx;
    font-weight: 600;
    color: #666;
    background: #f5f5f5;
    border: 2rpx solid #dcdcdc;
    border-radius: 12rpx;
    box-sizing: border-box;
}

.issue-type-tag.is-disabled {
    color: #bbb;
    background: #fafafa;
    border-color: #e8e8e8;
}

.issue-type-tag.is-active {
    color: #fff;
    background: #00b359;
    border-color: #00b359;
}

.cipher-type-tab {
    flex: 1;
    padding: 18rpx 0;
    text-align: center;
    font-size: 28rpx;
    color: #666;
    background: #fff;
    border-radius: 12rpx;
    border: 2rpx solid #dcdcdc;
    box-sizing: border-box;
}

.cipher-type-tab.active {
    color: #e84c59;
    background: #fff;
    border-color: #e84c59;
    font-weight: 600;
}

.switch-label {
    font-size: 12rpx !important;
    color: #333 !important;
}

/*
 * 自定义样式原因：使用须知工具栏为「灯泡图标引导 + 文字按钮」单行内联组合，
 * app.css 的 .tips-card 是整块提示卡（含标题/多行），不适合单行工具条；TDesign 亦无对应组件。
 * 替代方案：白底融入卡片、细分隔线区隔内容，图标色取 --td-brand-color，仅补缺位视觉层。
 */
.usage-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16rpx 16rpx 16rpx 32rpx;
    background-color: #FFFFFF;
    border-top: 1rpx solid #F0F0F0;
}

.usage-toolbar-tip {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 16rpx;
}

.usage-toolbar-tip-text {
    font-size: 24rpx;
    color: #666;
    margin-left: 8rpx;
}

.usage-toolbar-actions {
    display: flex;
    align-items: center;
    flex-shrink: 0;
}
</style>
