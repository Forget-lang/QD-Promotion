<template>
    <m-loading v-if="loading"></m-loading>
    <m-empty v-else-if="stores.length === 0">暂无适用门店</m-empty>
    <view v-else class="container-safety">
        <view class="container">
            <!-- 门店列表 -->
            <view class="section mt-2">
                <view
                    v-for="(store, index) in stores"
                    :key="index"
                    class="store-item p-3 top-line"
                >
                    <view class="store-info d-flex align-items-center">
                        <image class="store-logo" :src="store.logo" mode="aspectFill"></image>
                        <view class="store-detail flex-fill ml-3">
                            <view class="store-name text-line">{{ store.name }}</view>
                            <view class="store-address text-muted text-small mt-1">
                                <t-icon name="location" size="24rpx" color="#999"></t-icon>
                                <text class="ml-1">{{ store.address }}</text>
                            </view>
                        </view>
                    </view>
                </view>
            </view>

            <!-- 统计信息 -->
            <view class="mt-2 p-3 text-center text-muted text-small">
                共 {{ stores.length }} 家适用门店
            </view>
        </view>
    </view>
    <m-submit v-if="stores && checkPermission(PERM_COUPON.UPDATE) && couponStatus !== COUPON_STATUS.DISCARDED"  @click="onAddStore">修改适用门店</m-submit>
</template>

<script setup>
import {onPullDownRefresh, onLoad, onShow} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {STORE_STATUS} from '@/constants/merchant'
import {COUPON_STATUS} from '@/constants/coupon'
import {useAuth} from "@/hooks/useAuth";
import {PERM_COUPON} from "@/constants/permission";
import {useLink} from '@/hooks/useLink'

const {checkPermission} = useAuth()
const {push} = useLink()
const couponId = ref('')
const stores = ref([])
const loading = ref(true)
const couponStatus = ref(0)

// 获取适用门店列表
const getStoreList = () => {
    loading.value = true
    request.get('/seller/coupon/stores', {
        couponId: couponId.value
    }).then(res => {
        stores.value = res.data.items
    }).catch(err => {
        stores.value = []
    }).finally(() => {
        loading.value = false
    })
}

// 跳转到修改适用门店页面
const onAddStore = () => {
    push('/pages_coupon/coupon/update_stores?couponId=' + couponId.value)
}

onLoad((e) => {
    if (e.couponId) {
        couponId.value = e.couponId
    }
    if (e.status !== undefined && e.status !== ''){
        couponStatus.value = Number(e.status)
    }
})

onShow(() => {
    getStoreList()
})

onPullDownRefresh(() => {
    getStoreList()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})
</script>

<style scoped>
.store-item {
    background-color: #fff;
}

.store-item:first-child {
    border-top: none;
}

.store-info {
    gap: 20rpx;
}

.store-logo {
    width: 100rpx;
    height: 100rpx;
    border-radius: 12rpx;
    flex-shrink: 0;
}

.store-detail {
    min-width: 0;
}

.store-name {
    font-size: 30rpx;
    color: #333;
    font-weight: 500;
}

.store-address {
    display: flex;
    align-items: center;
}

.store-status {
    flex-shrink: 0;
    font-size: 24rpx;
    padding: 8rpx 16rpx;
    border-radius: 8rpx;
    background-color: #f5f5f5;
}
</style>
