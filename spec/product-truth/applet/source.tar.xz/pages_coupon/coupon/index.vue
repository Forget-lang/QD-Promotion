<template>
    <t-tabs v-model:value="currentTab" bottom-line-mode="auto" @change="onTabChange">
        <t-tab-panel label="可用券" :value="1"></t-tab-panel>
        <t-tab-panel label="失效券" :value="2"></t-tab-panel>
    </t-tabs>

    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">
                {{ currentTab === 1 ? '暂无可用优惠券，点击下方制作' : '暂无失效优惠券' }}
            </m-empty>
            <template v-else>
                <view class="coupon" v-for="item in items" :key="item.id"
                      @tap="push('/pages_coupon/coupon/detail?couponId='+item.id)">
                    <view class="coupon-body">
                        <view class="coupon-content">
                            <view class="coupon-name">{{ item.name }}</view>
                            <view class="coupon-tag">
                                <t-tag theme="danger" size="small">{{ item.couponTypeLabel }}</t-tag>
                            </view>
                            <view class="coupon-valid">{{ item.validLabel }}</view>
                        </view>
                        <view class="coupon-value">
                            <!-- 代金券、套餐券 -->
                            <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.CASH || item.couponType === COUPON_TYPE.PACKAGE">
                                <text class="coupon-face-unit">￥</text>
                                <text class="coupon-face-money">{{ item.faceAmount }}</text>
                            </view>
                            <!-- 满减券 -->
                            <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.REDUCE">
                                <text class="coupon-face-unit">￥</text>
                                <text class="coupon-face-money">{{ item.reduceAmount }}</text>
                            </view>
                            <!-- 折扣券 -->
                            <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                <text class="coupon-face-money">{{ item.discountAmount }}</text>
                                <text class="coupon-face-font">折</text>
                            </view>
                            <!-- 兑换券 -->
                            <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                <t-icon name="gift-filled" color="e84c59" size="64rpx"></t-icon>
                            </view>
                            <!-- 手气券 -->
                            <view class="coupon-face" v-if="item.couponType === COUPON_TYPE.RANDOM">
                                <text class="coupon-face-unit">￥</text>
                                <text class="coupon-face-money">{{ item.randomMinAmount }}~{{ item.randomMaxAmount }}</text>
                            </view>
                            <view class="coupon-threshold">{{ item.threshold }}</view>
                        </view>
                    </view>
                    <view class="coupon-line"></view>
                    <view class="coupon-footer">
                        <t-tag theme="danger" variant="light-outline">{{ item.issueTypeLabel }}</t-tag>
                        <view class="coupon-stats">
                            <text>共 {{ item.totalStock }} 张</text>
                            <text>/</text>
                            <text>领 {{ item.receiveCount }} 张</text>
                            <text>/</text>
                            <text>核 {{ item.verifyCount }} 张</text>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
    <m-submit v-if="checkPermission(PERM_COUPON.CREATE)" @click="push('/pages_coupon/coupon/choose_type')">制作卡券</m-submit>
</template>

<script setup>
import {onLoad, onUnload, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE} from '@/constants/coupon'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from "@/hooks/useAuth";
import {PERM_COUPON} from "@/constants/permission";
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth();
// 当前 Tab（1可用/2失效）
const currentTab = ref(1)
// 列表查询筛选参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: 1,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取优惠券列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/coupon/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 切换 Tab 筛选
const onTabChange = (e) => {
    search.value.status = e.value
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 刷新列表（事件监听复用）
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

//注册全局事件监听，修改卡券、删除卡券，同步列表卡券数据
const registerEvent = () => {
    //卡券修改后更新列表对应卡券信息
    uni.$on('onCouponUpdate', (e) => {
        if (!e?.id || !items.value?.length) return
        const editIndex = items.value.findIndex(item => item.id === e.id)
        if (editIndex >= 0) {
            items.value.splice(editIndex, 1, e)
        }
    })
    //卡券删除后从列表移除
    uni.$on('onCouponDelete', (e) => {
        if (e.id) {
            const deleteIndex = items.value.findIndex((item, index) => item.id === e.id);
            if (deleteIndex >= 0) {
                items.value.splice(deleteIndex, 1)
            }
        }
    })
    //卡券作废后从可用TAB列表移除
    uni.$on('onCouponDiscard', (e) => {
        if (!e?.id || !items.value?.length) return
        if (currentTab.value !== 1) return
        const index = items.value.findIndex(item => item.id === e.id)
        if (index >= 0) {
            items.value.splice(index, 1)
        }
    })
    //制作卡券成功后刷新可用优惠券列表
    uni.$on('onCouponCreate', () => {
        if (currentTab.value !== 1) return
        onRefresh()
    })
}

onLoad(() => {
    registerEvent()
    getItems()
})

onUnload(() => {
    uni.$off('onCouponUpdate')
    uni.$off('onCouponDelete')
    uni.$off('onCouponDiscard')
    uni.$off('onCouponCreate')
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.coupon {
    margin-bottom: 20rpx;
    position: relative;
    background: #fff;
    border-radius: 20rpx;
}


.coupon-body {
    padding: 32rpx 32rpx 10rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.coupon-name {
    font-weight: 600;
    font-size: 32rpx;
    margin-bottom: 12rpx;;
}

.coupon-threshold {
    color: #e84c59;
    font-size: 28rpx;
}

.coupon-valid {
    color: #666;
    font-size: 28rpx;
    margin-top: 10rpx;
}


.coupon-value {
    order: 1; /* 设置更大的 order 值，把它挤到最后 */
    max-width: 230rpx;
    flex-shrink: 0;
    overflow: hidden;
    text-align: right;
}

.coupon-face {
    color: #e84c59;
    position: relative;
    display: flex;
    align-items: start;
    justify-content: flex-end;
}

.coupon-face-unit {
    font-weight: 600;
    font-size: 28rpx;
    margin-right: 2rpx;
    margin-top: 6rpx;
}

.coupon-face-font {
    margin-top: 6rpx;
    margin-left: 4rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-face-money {
    font-weight: bold;
    font-size: 56rpx;
}

.coupon-footer {
    padding: 0 32rpx 32rpx 32rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
    font-size: 24rpx;
    color: #666;
    order: 3;
    flex: 0 0 100%;
}

.coupon-stats {
    display: flex;
    align-items: center;
    gap: 20rpx;
    color: #999;
    font-size: 24rpx;
}
</style>
