<template>
    <m-loading v-if="coupon === undefined"></m-loading>
    <m-empty v-else-if="coupon === null">优惠券不存在</m-empty>
    <view class="container-safety" v-else>
        <t-cell-group title="封面图片" theme="card">
            <view class="bg-white">
                <scroll-view class="cover-scroll" scroll-x :show-scrollbar="false">
                    <image
                        v-for="(img, index) in coupon.coverImages"
                        :key="index"
                        class="cover-image"
                        :src="img"
                        mode="aspectFill"
                    />
                </scroll-view>
            </view>
        </t-cell-group>

        <t-cell-group title="基本信息" theme="card">
            <t-cell title="优惠券名称" :note="coupon.name || '-'"/>
            <t-cell title="优惠券类型" :note="coupon.couponTypeLabel || '-'"/>
            <t-cell title="发放状态" :note="coupon.statusLabel || '-'"/>
            <t-cell title="消费门槛" :note="coupon.threshold || '-'"/>
            <t-cell
                v-if="coupon.isAllowWecard"
                title="微信卡包"
                description="已同步微信卡包，面额/门槛/折扣/有效期/限领等微信侧规则不可修改"
            >
                <template #note>
                    <text class="flex-shrink">已同步</text>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group title="优惠规则" theme="card">
            <t-cell v-if="coupon.couponType === COUPON_TYPE.CASH || coupon.couponType === COUPON_TYPE.PACKAGE" title="原价" :note="coupon.originalPrice + '元'"/>
            <t-cell v-if="coupon.couponType === COUPON_TYPE.CASH || coupon.couponType === COUPON_TYPE.PACKAGE" title="券面额" :note="coupon.faceAmount + '元'"/>
            <t-cell v-if="coupon.couponType === COUPON_TYPE.REDUCE" title="优惠金额" :note="coupon.reduceAmount + '元'"/>
            <t-cell v-if="coupon.couponType === COUPON_TYPE.DISCOUNT" title="折扣" :note="coupon.discountAmount + '折'"/>
            <t-cell v-if="coupon.couponType === COUPON_TYPE.EXCHANGE" title="兑换内容" :note="coupon.exchangeProduct"/>
            <t-cell v-if="coupon.couponType === COUPON_TYPE.RANDOM" title="随机金额" :note="coupon.randomMinAmount + '元 ~ ' + coupon.randomMaxAmount + '元'"/>
        </t-cell-group>

        <t-cell-group title="库存" theme="card">
            <t-cell title="制作数量" :note="coupon.totalStock + '张'"/>
            <t-cell title="剩余库存" :note="coupon.remainStock + '张'"/>
            <t-cell title="已领取" :note="coupon.receiveCount + '张'"/>
            <t-cell title="已核销" :note="coupon.verifyCount + '张'"/>
        </t-cell-group>

        <t-cell-group title="有效期" theme="card">
            <t-cell title="有效期" :note="coupon.validLabel || '-'"/>
            <t-cell title="可用时段">
                <template #note>
                    <text style="max-width: 360rpx;">{{ coupon.validTimeLabel || '-' }}</text>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 限领总量 -->
        <t-cell-group title="限领总量" theme="card">
            <t-cell title="每人限领总量" :note="coupon.isTotalLimit ? coupon.totalLimitCount + '张' : '不限制'"/>
            <t-cell v-if="coupon.issueType !== ISSUE_TYPE.BUNDLE" title="仅新客户可领"
                    :note="coupon.isOnlyNewCustomer ? '是' : '否'"/>
        </t-cell-group>

        <!-- 发放方式 -->
        <t-cell-group title="发放方式" theme="card">
            <t-cell title="发放方式" :note="coupon.issueTypeLabel"></t-cell>
            <view class="cell-helper" v-if="coupon.issueType > 0">
                <text v-if="coupon.issueType === ISSUE_TYPE.PUBLIC" class="lh-25 text-success">
                    公开领取：支持微信群/好友、二维码、公众号、海报、企微群、企微群助理、企微客户群发等发券渠道，所有人都可领取，适合公开引流活动。
                </text>
                <text v-if="coupon.issueType === ISSUE_TYPE.PRIVATE" class="lh-25 text-success">
                    私密发放：支持私发微信好友、二维码、企微好友等发券渠道，适合给指定好友发券、储值回馈、消费赠礼、补偿等私密活动。
                </text>
                <text v-if="coupon.issueType === ISSUE_TYPE.BUNDLE" class="lh-25 text-success">
                    券包：供券包选择，适合多种类型优惠券打包一次发给顾客。
                </text>
            </view>
        </t-cell-group>

        <!-- 公开发放设置 -->
        <t-cell-group v-if="coupon.issueType === ISSUE_TYPE.PUBLIC" title="公开领取设置" theme="card">
            <template v-if="coupon.isCustomReceiveTime">
                <t-cell title="领取开始时间" :note="coupon.receiveStartTime || '-'"/>
                <t-cell title="领取结束时间" :note="coupon.receiveEndTime || '-'"/>
            </template>
            <template v-else>
                <t-cell title="领取时间" note="有效期截止前均可领取"/>
            </template>
            <template v-if="!coupon.isTotalLimit || (coupon.isTotalLimit && coupon.totalLimitCount > 1)">
                <t-cell title="每次领取数量" :note="coupon.publicIssueCount + '张'"/>
                <t-cell :title="publicIssueRuleLabel" :note="coupon.publicIssueRuleCount + '张'"/>
            </template>
        </t-cell-group>

        <t-cell-group title="核销设置" theme="card">
            <t-cell
                title="每天核销限制"
                :note="coupon.isVerifyLimit ? '每人每天限核销' + coupon.verifyLimitCount + '张' : '未限制'"
            />
            <t-cell
                title="核销奖励"
                description="核销后立奖本券一张，直接到账"
                :note="coupon.isVerifyReward ? '已开启' : '未开启'"
            />
            <t-cell
                title="动态核销码"
                :note="coupon.isVerifySign ? '已开启' : '未开启'"
            />
            <t-cell v-if="coupon.issueType !== ISSUE_TYPE.BUNDLE" title="领取口令" :note="cipherTypeLabel"/>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2">
            <t-cell
                title="适用门店"
                :note="(coupon.storeIds && coupon.storeIds.length) ? coupon.storeIds.length + ' 家' : '0 家'"
                :arrow="checkPermission(PERM_COUPON.UPDATE)"
                :hover="checkPermission(PERM_COUPON.UPDATE)"
                @click="onStoresClick"
            />
            <t-cell
                v-if="coupon.issueType !== ISSUE_TYPE.BUNDLE"
                title="发券员工"
                :note="coupon.staffIds.length + ' 人'"
                :arrow="checkPermission(PERM_COUPON.UPDATE)"
                :hover="checkPermission(PERM_COUPON.UPDATE)"
                @click="onIssueStaffClick"
            />
        </t-cell-group>

        <t-cell-group title="使用说明" theme="card">
            <t-cell title="使用须知" :note="coupon.content ? '' : '未填写'">
                <template #description v-if="coupon.content">
                    <view class="cell-text">{{ coupon.content }}</view>
                </template>
            </t-cell>
            <t-cell v-if="!coupon.productImages || !coupon.productImages.length" title="说明图片" note="未设置"/>
            <view v-else class="product-images-wrap">
                <image
                    v-for="(img, index) in coupon.productImages"
                    :key="index"
                    class="product-image"
                    :src="img"
                    mode="widthFix"
                />
            </view>
        </t-cell-group>

        <t-cell-group title="套餐设置" theme="card">
            <t-cell title="套餐组合" :note="coupon.isCombo ? '已开启' : '未开启'"/>
            <template v-if="coupon.isCombo && coupon.combos && coupon.combos.length">
                <t-cell
                    v-for="(combo, index) in coupon.combos"
                    :key="index"
                    :title="combo.name || '套餐' + (index + 1)"
                    :note="combo.selectRule || '-'"
                />
            </template>
        </t-cell-group>

        <t-cell-group title="预约设置" theme="card">
            <t-cell title="提前预约" :note="coupon.isAppt ? '是' : '否'"/>
            <t-cell v-if="coupon.isAppt" title="预约说明">
                <template #description>
                    <view class="cell-text">{{ coupon.apptDesc || '-' }}</view>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group title="到期提醒" theme="card">
            <t-cell
                title="到期提醒"
                :note="coupon.isExpireNotice ? (coupon.expireForwardDay === 0 ? '到期当天提醒' : '提前' + coupon.expireForwardDay + '天提醒') : '未开启'"
            />
        </t-cell-group>

        <t-cell-group v-if="coupon.issueType !== ISSUE_TYPE.BUNDLE" title="领券顾客信息" theme="card">
            <t-cell title="填写手机号" :note="coupon.isGetMobile ? '是' : '否'"/>
            <t-cell title="指定手机号可领取" :note="coupon.isMobileLimit ? '是' : '否'"/>
            <t-cell v-if="coupon.isMobileLimit" title="已录入手机号" :note="(coupon.allowMobileCount || 0) + ' 个'"/>
        </t-cell-group>

        <t-cell-group title="自定义分享卡片" theme="card">
            <t-cell title="分享标题" :note="coupon.shareTitle || '默认'"/>
            <t-cell v-if="coupon.shareCover" title="转发封面">
                <template #note>
                    <image class="share-cover" :src="coupon.shareCover" mode="aspectFill"/>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group title="分享与转赠" theme="card">
            <t-cell v-if="coupon.issueType === ISSUE_TYPE.PUBLIC" title="允许分享"
                    :note="coupon.isShare ? '是' : '否'"/>
            <t-cell v-if="coupon.issueType === ISSUE_TYPE.PUBLIC" title="禁止群内成员转发出群"
                    :note="coupon.isOnlyGroup ? '是' : '否'"
                    description="仅微信群生效，企业微信群暂不可用"/>
            <t-cell title="允许转赠" :note="coupon.isTransfer ? '是' : '否'"/>
            <t-cell v-if="coupon.isTransfer" title="开启转赠奖励" :note="coupon.isTransferReward ? '是' : '否'"/>
            <t-cell v-if="coupon.isTransferReward" title="转赠奖励券" :note="coupon.transferRewardCouponName"/>
        </t-cell-group>
    </view>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import { RESPONSE_CODE } from '@/constants/code'
import {COUPON_TYPE, CIPHER_TYPE, ISSUE_TYPE} from '@/constants/coupon'
import utils from '@/utils/utils'
import {useAuth} from '@/hooks/useAuth'
import {PERM_COUPON} from '@/constants/permission'
import {useLink} from '@/hooks/useLink'

const {checkPermission} = useAuth()
const {push} = useLink()

const couponId = ref('')
const coupon = ref()

// 公开领取规则标签
const publicIssueRuleLabel = computed(() => {
    switch (coupon.value.publicIssueRule) {
        case 3:
            return '每人每天最多可领'
        case 4:
            return '每人每周最多可领'
        case 5:
            return '每人每月最多可领'
        case 6:
            return '每人每年最多可领'
        default:
            return '每人限领'
    }
})

const cipherTypeLabel = computed(() => {
    if (!coupon.value) return '未开启'
    if (Number(coupon.value.cipherType) === CIPHER_TYPE.FIXED) return '固定口令'
    if (Number(coupon.value.cipherType) === CIPHER_TYPE.RANDOM) return '随机口令'
    return '未开启'
})

// 跳转修改适用门店
const onStoresClick = () => {
    if (checkPermission(PERM_COUPON.UPDATE)) {
        push('/pages_coupon/coupon/update_stores?couponId=' + couponId.value)
    }
}

// 跳转发券员工设置
const onIssueStaffClick = () => {
    if (checkPermission(PERM_COUPON.UPDATE)) {
        push('/pages_coupon/issue/staff?couponId=' + couponId.value)
    }
}

// 拉取优惠券详情（与详情页同一接口）
const getDetail = () => {
    request.get('/seller/coupon/detail', {id: couponId.value}).then((res) => {
        coupon.value = res.data
        uni.setNavigationBarTitle({title: '优惠券信息'})
    }).catch((err) => {
        if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
            coupon.value = null
        }
    })
}

onLoad((e) => {
    if (!e.couponId) {
        utils.toast('缺少优惠券ID')
        setTimeout(() => uni.navigateBack(), 1500)
        return
    }
    couponId.value = e.couponId
})

onShow(() => {
    getDetail()
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})
</script>

<style scoped>
.cover-scroll {
    white-space: nowrap;
    padding: 24rpx 32rpx 32rpx;
    box-sizing: border-box;
}

.cover-image {
    display: inline-block;
    width: 240rpx;
    height: 192rpx;
    border-radius: 12rpx;
    margin-right: 16rpx;
    vertical-align: top;
}

.product-images-wrap {
    padding: 24rpx 32rpx 32rpx;
    background: #fff;
}

.product-image {
    display: block;
    width: 100%;
    border-radius: 12rpx;
}

.product-image + .product-image {
    margin-top: 16rpx;
}

.share-cover {
    width: 150rpx;
    height: 120rpx;
    border-radius: 8rpx;
}

.cell-text {
    color: #666;
    font-size: 28rpx;
    line-height: 1.6;
    white-space: pre-wrap;
    word-break: break-all;
}
</style>
