<template>
    <m-loading v-if="coupon === undefined"></m-loading>
    <m-empty v-else-if="coupon === null">优惠券不存在</m-empty>
    <view class="container-safety" v-else>
        <view class="detail-header">
            <view class="container">

                <!-- 优惠券卡片 -->
                <view class="coupon" @click="push('/pages_coupon/coupon/info?couponId=' + couponId)">
                    <view class="coupon-main">
                        <view class="coupon-header">
                            <view class="coupon-face">
                                <!-- 手气券 -->
                                <view class="coupon-face" v-if="coupon.couponType === COUPON_TYPE.RANDOM">
                                    <text class="coupon-face-unit">￥</text>
                                    <text class="coupon-face-money">{{
                                            coupon.randomMinAmount
                                        }}~{{ coupon.randomMaxAmount }}
                                    </text>
                                </view>
                                <!-- 兑换券 -->
                                <template v-else-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                                    <t-icon name="gift-filled" color="#e84c59" size="64rpx"></t-icon>
                                </template>
                                <!-- 折扣券 -->
                                <template v-else-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                                    <text class="coupon-face-money">{{ coupon.discountAmount }}</text>
                                    <text class="coupon-face-font">折</text>
                                </template>
                                <template v-else-if="coupon.couponType === COUPON_TYPE.REDUCE">
                                    <text class="coupon-face-unit">￥</text>
                                    <text class="coupon-face-money">{{ coupon.reduceAmount }}</text>
                                </template>
                                <template v-else>
                                    <text class="coupon-face-unit">￥</text>
                                    <text class="coupon-face-money">{{ coupon.faceAmount }}</text>
                                </template>
                            </view>
                            <view class="coupon-threshold">{{ coupon.threshold }}</view>
                        </view>
                        <view class="coupon-body">
                            <view class="coupon-name">{{ coupon.name }}</view>
                            <view class="coupon-tag">
                                <t-tag theme="danger" size="small">{{ coupon.couponTypeLabel }}</t-tag>
                            </view>
                            <view class="coupon-valid">{{ coupon.validLabel }}</view>
                        </view>
                    </view>
                    <view class="coupon-line detail-coupon-line"></view>
                    <view class="coupon-footer">
                        <view class="d-flex flex-gap-1">
                            <t-tag theme="danger" variant="light-outline">
                                {{ coupon.issueTypeLabel }}
                            </t-tag>
                            <t-tag :theme="coupon.status === COUPON_STATUS.ISSUING ? 'success' : 'warning'" variant="light-outline">
                                {{ coupon.statusLabel }}
                            </t-tag>
                        </view>
                        <view class="coupon-footer-tags">
                            <t-tag v-if="coupon.isAppt" theme="default" variant="outline">需预约</t-tag>
                            <t-tag theme="default" variant="outline">
                                {{ coupon.isShare ? '可分享' : '不可分享' }}
                            </t-tag>
                            <t-tag theme="default" variant="outline">
                                {{ coupon.isTransfer ? '可转赠' : '不可转赠' }}
                            </t-tag>
                        </view>
                    </view>
                </view>
                <!-- /优惠券卡片 -->

                <view class="section">

                    <!-- 数据统计概要 -->
                    <view class="row col-3 mt-2">
                        <view class="stat">
                            <view class="stat-value">{{ coupon.receiveCount }}</view>
                            <view class="stat-label">已领取</view>
                        </view>
                        <view class="stat">
                            <view class="stat-value">{{ coupon.verifyCount }}</view>
                            <view class="stat-label">已核销</view>
                        </view>
                        <view class="stat">
                            <view class="stat-value">{{ verifyRate }}</view>
                            <view class="stat-label">核销率</view>
                        </view>
                    </view>
                    <!-- /数据统计概要 -->

                    <t-divider/>

                    <!-- 库存展示和调整 -->
                    <view class="container">
                        <view class="d-flex justify-content-between align-items-center">
                            <view>
                                <view class="text-muted text-small mb-2">剩余库存</view>
                                <view>
                                    <text style="font-size:42rpx">{{ coupon.remainStock }}</text>
                                    /
                                    <text class="text-muted">{{ coupon.totalStock }}张</text>
                                </view>
                            </view>
                            <view>
                                <view v-if="checkPermission(PERM_COUPON.UPDATE) && coupon.status !== COUPON_STATUS.DISCARDED" class="button-gold"
                                      @click="push('/pages_coupon/coupon/update_stock?couponId=' + couponId)">调整库存
                                </view>
                            </view>
                        </view>
                        <t-progress :percentage="Number(remainPercent)" :show-info="false" :stroke-width="6"
                                    color="#00c553"/>
                    </view>
                    <!-- /库存展示和调整 -->

                    <t-divider/>

                    <t-grid :column="4">
                        <t-grid-item v-if="checkPermission(PERM_COUPON.RECEIVE_LIST)" text="领取明细" icon="task"
                                     :url="'/pages_coupon/receive/list?couponId=' + couponId"/>
                        <t-grid-item v-if="checkPermission(PERM_COUPON.VERIFY_LIST)" text="核销明细" icon="assignment"
                                     :url="'/pages_coupon/verify/list?couponId=' + couponId"/>
                        <t-grid-item v-if="checkPermission(PERM_COUPON.DISCARD_LIST)" text="作废明细" icon="delete-time"
                                     :url="'/pages_coupon/discard/list?couponId=' + couponId"/>
                        <t-grid-item text="数据统计" icon="chart-analytics"
                                     :url="'/pages_coupon/stat/home?couponId=' + couponId"/>
                    </t-grid>
                </view>
            </view>
        </view>

        <t-cell-group title="操作设置" t-title-class="mt-2" theme="card">
            <t-grid :column="4">
                <t-grid-item v-if="checkPermission(PERM_COUPON.UPDATE) && coupon.status === COUPON_STATUS.ISSUING" text="暂停发放" icon="pause-circle-stroke"
                             @click="pauseVisible = true"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.UPDATE) && coupon.status === COUPON_STATUS.PAUSED" text="恢复发放" icon="play-circle-stroke"
                             @click="startVisible = true"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.DISCARD) && coupon.status !== COUPON_STATUS.DISCARDED" text="作废此券" icon="delete-time"
                             @click="checkPermission(PERM_COUPON.DISCARD) && push('/pages_coupon/discard/discard?couponId=' + couponId)"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.DELETE)" text="删除此券" icon="delete"
                             @click="push('/pages_coupon/coupon/delete?couponId=' + couponId)"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.UPDATE)  && coupon.status !== COUPON_STATUS.DISCARDED" text="修改此券" icon="edit-2"
                             @click="push('/pages_coupon/coupon/update?couponId=' + couponId)"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.VIEW)" text="优惠券详情" icon="certificate-1"
                             @click="push('/pages_coupon/coupon/info?couponId=' + couponId)"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.CREATE)" text="复制此券" icon="copy" @click="onCopyCoupon"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.UPDATE) && coupon.issueType !== ISSUE_TYPE.BUNDLE" text="发券员工" icon="user-setting"
                             @click="push('/pages_coupon/issue/staff?couponId=' + couponId + '&status=' + coupon.status)"/>
                <t-grid-item v-if="checkPermission(PERM_COUPON.UPDATE)" text="适用门店" icon="store"
                             @click="push('/pages_coupon/coupon/store_list?couponId=' + couponId + '&status=' + coupon.status)"/>
            </t-grid>
        </t-cell-group>

        <view class="submit-bar" v-if="coupon">
            <view v-if="coupon.cipherType > 0 && coupon.issueType !== ISSUE_TYPE.BUNDLE"
                  class="button-gold submit-bar-cipher" @click="cipherVisible = true">
                <t-icon name="lock-on" :size="16"/>
                <text>收款口令码</text>
            </view>
            <view class="submit-bar-main">
                <t-button v-if="coupon.issueType !== ISSUE_TYPE.BUNDLE && coupon.hasIssuePermission"
                          theme="danger" size="large" block
                          :disabled="coupon.status !== COUPON_STATUS.ISSUING"
                          @click="issuePopupVisible = true">
                    发放优惠券
                    <template v-if="coupon.status === COUPON_STATUS.PAUSED"> [已暂停]</template>
                </t-button>
                <t-button v-else-if="coupon.issueType === ISSUE_TYPE.BUNDLE" theme="danger" size="large" block
                          disabled>请在券包中添加此券
                </t-button>
                <t-button v-else theme="danger" size="large" block disabled>您没有发券权限</t-button>
            </view>
        </view>

        <m-coupon-cipher-panel v-model:visible="cipherVisible" :coupon-id="couponId"
                               :coupon-name="coupon?.name || ''" @updated="onCipherUpdated"/>

        <!-- 发放面板 -->
        <t-popup placement="bottom" v-model:visible="issuePopupVisible">
            <template v-if="coupon.issueType === ISSUE_TYPE.PUBLIC">
                <view class="popup-header">
                    <view class="popup-header-title">公开领取</view>
                    <view class="popup-header-close">
                        <t-icon name="close" @click="issuePopupVisible = false" :size="20"></t-icon>
                    </view>
                </view>
                <view class="text-center text-muted text-small">适合开放式发券活动，看到的客户都可领取。</view>
                <t-divider/>
                <t-grid :column="4">
                    <t-grid-item text="微信好友/群"
                                 image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2nl4lbp0mqcs77du0.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.PUBLIC_WECHAT)"/>
                    <t-grid-item text="二维码" image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2o2slbp0mqcs77dug.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.PUBLIC_QRCODE)"/>
                    <t-grid-item text="公众号"
                                 image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2oeclbp0mqcs77dv0.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.PUBLIC_OFFICIAL)"/>
                    <t-grid-item text="海报"
                                 image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2onclbp0mqcs77dvg.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.PUBLIC_POSTER)"/>
                    <t-grid-item v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" text="企微进群发券"
                                 image="https://cdn.lenmy.com/quandao/2026/06/24/d8thrbdb4ek0dhdbngag.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.WECOM_GROUP_JOIN)"/>
                    <t-grid-item v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" text="企微群助理"
                                 image="https://cdn.lenmy.com/quandao/2026/06/24/d8thrgtb4ek0dhdbngb0.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.WECOM_BOT)"/>
                    <t-grid-item v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" text="企微客户群发"
                                 image="https://cdn.lenmy.com/quandao/2026/06/24/d8thrkdb4ek0dhdbngbg.png"
                                 @click="goPublicConfig(CHANNEL_TYPE.WECOM_BATCH)"/>
                </t-grid>
            </template>

            <template v-else-if="coupon.issueType === ISSUE_TYPE.PRIVATE">
                <view class="popup-header">
                    <view class="popup-header-title">私密发放</view>
                    <view class="popup-header-close">
                        <t-icon name="close" @click="issuePopupVisible = false" :size="20"></t-icon>
                    </view>
                </view>
                <view class="text-center text-muted text-small">适合一对一/储值回馈/消费奖励/给指定客户</view>
                <t-divider/>
                <t-grid :column="3">
                    <t-grid-item text="微信好友/群"
                                 image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2nl4lbp0mqcs77du0.png"
                                 @click="goPrivateConfig(CHANNEL_TYPE.PRIVATE_WECHAT)"/>
                    <t-grid-item text="面对面二维码"
                                 image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2o2slbp0mqcs77dug.png"
                                 @click="goPrivateConfig(CHANNEL_TYPE.PRIVATE_QRCODE)"/>
                    <t-grid-item v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" text="企微加好友自动发券"
                                 image="https://cdn.lenmy.com/quandao/2026/06/24/d8thsq5b4ek0dhdbngc0.png"
                                 @click="goPrivateConfig(CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT)"/>
                </t-grid>
            </template>
            <view class="popup-bottom-cancel mt-5" @click="issuePopupVisible = false">取消</view>
        </t-popup>
        <!-- 发放面板 -->

        <!-- 暂停发放 -->
        <t-action-sheet :visible="pauseVisible" :items="[{ label: '确定暂停发券' }]" @selected="onPauseSelected"
                        @cancel="pauseVisible = false"></t-action-sheet>
        <!-- 恢复发放 -->
        <t-action-sheet :visible="startVisible" :items="[{ label: '确定恢复发券' }]" @selected="onStartSelected"
                        @cancel="startVisible = false"></t-action-sheet>

        <!-- 版本升级抽屉：一键复制等受限跳转承接 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {onLoad, onShow, onUnload, onPullDownRefresh} from "@dcloudio/uni-app";
import {ref, computed} from "vue";
import request from "@/hooks/request";
import { RESPONSE_CODE } from "@/constants/code";
import {COUPON_TYPE, COUPON_STATUS, CIPHER_TYPE, ISSUE_TYPE} from "@/constants/coupon";
import { CHANNEL_TYPE } from "@/constants/common";
import utils from "@/utils/utils";
import {useLink} from "@/hooks/useLink";
import {useAuth} from "@/hooks/useAuth";
import {useVipGuard} from "@/hooks/useVipGuard";
import {EDITION_FEATURES} from "@/constants/edition";
import {PERM_COUPON, PERM_WECOM} from "@/constants/permission";

const {push} = useLink()
const {checkPermission, getSession} = useAuth();
const {check} = useVipGuard()

// 一键复制此券：标准版及以上支持，检测通过后进入创建页（携带券ID回填）
const onCopyCoupon = () => {
    check(EDITION_FEATURES.COUPON_COPY).then((allowed) => {
        if (allowed) {
            push('/pages_coupon/coupon/create?couponId=' + couponId.value)
        }
    })
}
const couponId = ref("");
const coupon = ref();

const pauseVisible = ref(false);
const startVisible = ref(false);
const issuePopupVisible = ref(false);
const cipherVisible = ref(false);
// 是否已删除（收到删除通知后标记，避免 onShow 再次请求）
const isDeleted = ref(false);

// 计算核销率（已核销 / 已领取）
const verifyRate = computed(() => {
    if (!coupon.value || !coupon.value.receiveCount) return '0%'
    return utils.formatPercent(coupon.value.verifyCount / coupon.value.receiveCount) + '%'
})

// 计算优惠券剩余百分比
const remainPercent = computed(() => {
    if (!coupon.value || !coupon.value.totalStock) return 0
    return utils.formatPercent(coupon.value.remainStock / coupon.value.totalStock)
})

// 口令更新后同步详情
const onCipherUpdated = (data) => {
    if (coupon.value) {
        coupon.value.cipherType = data.cipherType
        coupon.value.cipherCode = data.cipherType === CIPHER_TYPE.FIXED ? data.cipherCode : ''
    }
}

// 暂停发放
const onPauseSelected = (e) => {
    request.post("/seller/coupon/pause", {
        id: couponId.value,
    }).then((res) => {
        utils.toast("优惠券已暂停");
        pauseVisible.value = false;
        getDetail();
    })
        .catch((err) => {
            utils.toast(err.message);
        });
};

// 恢复发放
const onStartSelected = (e) => {
    request.post("/seller/coupon/start", {
        id: couponId.value,
    }).then((res) => {
        utils.toast("优惠券已恢复");
        startVisible.value = false;
        getDetail();
    })
        .catch((err) => {
            utils.toast(err.message);
        });
}

// 获取详情
const getDetail = () => {
    request.get("/seller/coupon/detail", {
        id: couponId.value,
    }).then((res) => {
        coupon.value = res.data;
        uni.setNavigationBarTitle({title: res.data.name});
    })
        .catch((err) => {
            if (err.code === RESPONSE_CODE.RESOURCE_DELETED) {
                // 优惠券不存在
                coupon.value = null;
            }
        })
        .finally(() => {
            setTimeout(() => {
                uni.stopPullDownRefresh()
            }, 300)
        });
}

// 公开发放跳转页面
const goPublicConfig = (channelType) => {
    if (coupon.value.issueType !== ISSUE_TYPE.PUBLIC) {
        utils.toast("本券不支持公开领取");
        return
    }
    issuePopupVisible.value = false
    if (channelType === CHANNEL_TYPE.PUBLIC_WECHAT) {//公开发放--微信好友/群 -- 小程序卡片分享
        const shareTitle = coupon.value.shareTitle || coupon.value.name
        push('/pages_coupon/issue/wechat?couponId=' + couponId.value + '&shareTitle=' + shareTitle + '&cover=' + coupon.value.cover + '&channelType=' + channelType)
    } else if (channelType === CHANNEL_TYPE.PUBLIC_QRCODE) {//公开发放--二维码
        push('/pages_coupon/issue/qrcode?couponId=' + couponId.value)
    } else if (channelType === CHANNEL_TYPE.PUBLIC_POSTER) {//公开发放--海报
        push('/pages_coupon/issue/poster?couponId=' + couponId.value)
    } else if (channelType === CHANNEL_TYPE.PUBLIC_OFFICIAL) {//公开发放--公众号
        push('/pages_coupon/issue/official?couponId=' + couponId.value)
    } else if (channelType === CHANNEL_TYPE.WECOM_GROUP_JOIN) { // 进企微群自动发
        push('/pages_wecom/group/list?productType=1&productId=' + couponId.value)
    } else if (channelType === CHANNEL_TYPE.WECOM_BOT) { // 企微群助理
        push('/pages_coupon/issue/wecom_bot?couponId=' + couponId.value + '&shareTitle=' + coupon.value.shareTitle + '&cover=' + coupon.value.cover + '&channelType=' + channelType)
    } else if (channelType === CHANNEL_TYPE.WECOM_BATCH) { // 企微客户群发
        push('/pages_coupon/issue/wecom_batch?couponId=' + couponId.value + '&shareTitle=' + coupon.value.shareTitle + '&cover=' + coupon.value.cover + '&channelType=' + channelType)
    }
}

// 私密发放跳转页面
const goPrivateConfig = (channelType) => {
    if (coupon.value.issueType !== ISSUE_TYPE.PRIVATE) {
        utils.toast("本券不支持私密发放");
        return
    }
    issuePopupVisible.value = false
    if (channelType === CHANNEL_TYPE.PRIVATE_WECHAT) {//私密发放--微信好友/群
        push('/pages_coupon/issue/private?couponId=' + couponId.value + '&shareTitle=' + coupon.value.shareTitle + '&cover=' + coupon.value.cover + '&channelType=' + channelType)
    } else if (channelType === CHANNEL_TYPE.PRIVATE_QRCODE) {//私密发放--二维码
        push('/pages_coupon/issue/private?couponId=' + couponId.value + '&shareTitle=' + coupon.value.shareTitle + '&cover=' + coupon.value.cover + '&channelType=' + channelType)
    } else if (channelType === CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT) {
        push('/pages_wecom/staff/list?productType=1&productId=' + couponId.value)
    }
}

// 优惠券删除事件回调：标记已删除，导航由 delete.vue 统一处理
const onCouponDelete = (e) => {
    if (e?.id && e.id === couponId.value) {
        isDeleted.value = true
    }
}

onLoad((e) => {
    couponId.value = e.couponId;
    uni.$on('onCouponDelete', onCouponDelete)
})

onUnload(() => {
    uni.$off('onCouponDelete', onCouponDelete)
})

onShow(() => {
    // 已删除的券不再请求，避免报"优惠券不存在"
    if (isDeleted.value) return
    getDetail();
    getSession();
})

onPullDownRefresh(() => {
    // 已删除的券不再请求
    if (isDeleted.value) {
        uni.stopPullDownRefresh()
        return
    }
    getDetail()
})


</script>

<style scoped>
.detail-header {
    padding-top: 20rpx;
    min-height: 400px;
    background: url("https://cdn.lenmy.com/quanketuan/2024/09/23/crodj1ide1heuifummd0.png") repeat-x;
}

.detail-header :deep(.detail-coupon-line)::before,
.detail-header :deep(.detail-coupon-line)::after {
    background-color: #e2453d;
    background-image: url("https://cdn.lenmy.com/quanketuan/2024/09/23/crodj1ide1heuifummd0.png");
    background-repeat: repeat-x;
    background-position: center top;
    background-size: auto 400px;
}

.coupon {
    margin-bottom: 30rpx;
    background: #fff;
    border-radius: 20rpx;
    overflow: hidden;
}

.coupon-main {
    display: flex;
    align-items: center;
    padding: 32rpx 32rpx 10rpx;
}

.coupon-header {
    order: 1;
    max-width: 230rpx;
    flex-shrink: 0;
    overflow: hidden;
    text-align: right;
}

.coupon-face {
    color: #e84c59;
    position: relative;
    display: flex;
    align-items: start;
    justify-content: flex-end;
}

.coupon-face-unit {
    font-weight: 600;
    font-size: 28rpx;
    margin-right: 2rpx;
    margin-top: 6rpx;
}

.coupon-face-font {
    margin-top: 6rpx;
    margin-left: 4rpx;
    font-weight: 600;
    font-size: 24rpx;
}

.coupon-face-money {
    font-weight: bold;
    font-size: 60rpx;
}

.coupon-body {
    flex: 1;
    margin-left: 20rpx;
}

.coupon-name {
    font-weight: 600;
    font-size: 32rpx;
    margin-bottom: 12rpx;;
}

.coupon-threshold {
    color: #e84c59;
    font-size: 28rpx;
}

.coupon-valid {
    color: #666;
    font-size: 28rpx;
    margin-top: 10rpx;
}

.coupon-footer {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16rpx;
    padding: 8rpx 32rpx 24rpx;
    font-size: 24rpx;
    color: #666;
}

.coupon-footer-tags {
    display: flex;
    flex-wrap: wrap;
    justify-content: flex-end;
    gap: 12rpx;
}

.menu-item:hover .menu-item-icon {
    width: 80rpx;
    height: 80rpx;
}

.submit-bar {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    z-index: 99;
    display: flex;
    gap: 20rpx;
    padding: 30rpx;
    padding-bottom: calc(30rpx + constant(safe-area-inset-bottom));
    padding-bottom: calc(30rpx + env(safe-area-inset-bottom));
    background: #fff;
}

.submit-bar-cipher {
    flex: 0 0 auto;
    min-width: 160rpx;
    padding: 24rpx 28rpx;
    font-size: 28rpx;
    gap: 8rpx;
}

.submit-bar-main {
    flex: 1;
    min-width: 0;
}

</style>
