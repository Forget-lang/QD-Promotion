<template>
    <!-- 成功反馈 -->
    <m-result v-if="showSuccess" type="success" title="调整成功" back></m-result>
    <view v-if="!showSuccess">
        <!-- 库存信息展示 -->
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="当前制作数量" :note="currentStock + ' 张'"/>
            <t-input label="增加库存" placeholder="只能增加，不能减少" type="number" align="right"
                     v-model:value="adjustStock" suffix="张"></t-input>
        </t-cell-group>

        <!-- 调整后库存展示 -->
        <t-cell-group t-class="mt-2" theme="card" v-if="adjustStock > 0">
            <t-cell title="调整后制作数量">
                <template #note>
                    <view class="after-stock">
                        <text class="original-stock">{{ currentStock }}</text>
                        <text class="arrow ml-1 mr-1">+</text>
                        <text class="adjust-num">{{ adjustStock }}</text>
                        <text class="equal ml-1 mr-1">=</text>
                        <text class="text-success">{{ afterStock }}</text>
                        <text class="unit ml-1">张</text>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 提交按钮 -->
        <m-submit :loading="loading" :disabled="loading || adjustStock <= 0" @click="onSubmit">确认调整库存</m-submit>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app';
import {ref, computed} from 'vue';
import request from '@/hooks/request.js';
import utils from '@/utils/utils';
import {useLink} from '@/hooks/useLink.js';

const {back} = useLink();

const couponId = ref('');
const currentStock = ref(0);
const adjustStock = ref();
const loading = ref(false);
const showSuccess = ref(false);

// 计算调整后的库存
const afterStock = computed(() => {
    return currentStock.value + parseInt(adjustStock.value || 0);
});

// 获取优惠券信息
const getCouponInfo = () => {
    request.get('/seller/coupon/detail', {id: couponId.value}).then((res) => {
        currentStock.value = res.data.totalStock || 0
    })
};

// 提交调整
const onSubmit = () => {
    if (adjustStock.value <= 0) {
        utils.toast('请输入要增加的库存数量');
        return;
    }

    loading.value = true;
    request.post('/seller/coupon/update-stock', {
        id: couponId.value,
        addStock: parseInt(adjustStock.value)
    }).then((res) => {
        showSuccess.value = true
        currentStock.value = afterStock.value
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
};

onLoad((e) => {
    if (!e.couponId) {
        utils.toast('缺少优惠券ID');
        setTimeout(() => {
            back();
        }, 1500);
        return;
    }
    couponId.value = e.couponId;
    getCouponInfo();
});
</script>

<style scoped></style>
