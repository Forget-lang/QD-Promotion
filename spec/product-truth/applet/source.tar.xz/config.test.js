// 测试环境 APPID：wx14592cb9c6a96167

let config = {
    // apiUrl: 'http://127.0.0.1:14000', // 接口本地地址，注意：结尾请勿添加： /
    apiUrl: 'https://qosolvdy.lenmy.com/api', // 接口测试地址，注意：结尾请勿添加： /
    appSecret: 'AVyuDXSEWC1McxHVsoR6IS7KC09VvI25', // 应用秘钥
    version: '3.8.0', // 当前版本
    default: {
        avatar: 'https://cdn.lenmy.com/img/avatar.png',
        cover: 'https://cdn.lenmy.com/quandao/assets/home-hero-default.jpg',
    },
    // 企业微信客服
    customerService: {
        appId: 'wwa50712d31a77adb5',
        url: 'https://work.weixin.qq.com/kfid/kfc7ef2efc710e321fa',
    },
    // 订阅消息（测试环境）
    subscribeMessage: {
        feedback: [''], // [反馈结果通知]
        pendingAudit: [''], // [进店申请审核通知]
        couponReceive: ['piVBve2PcsBTxEkQS-Dku6Z6rUQ1Hj4JJDyRRJWbjmI', 'cKywTyo_XYmw2emZb2jtTxivBTLiJ0623ocvyAeGsfg'], // [卡券领取成功通知,卡券到期提醒]
        upgrade: [''], // [版本更新通知]
        sellerMessage: ['-zSwk6DMdePqGXcMORl6G1k98sNISqI7mkoNxpS7cBQ'], // [商家站内消息]
        merchantAuth: [''], // [商家认证通知]
        massComplete: ['SD2CNlcBQtYV_fiORJsR8vKWTK-lp2tQcgC0WvHjwPo'], // [群发任务完成提醒]
        invoice: ['x8fGqaKpZUiwmND2-Hfurr6CQTSVfd3JZdDnwc_07bU'], // [电子发票开具成功通知]
        pointChange: ['vuKxs_xDgnGPIvzEmMUix2Txj7zu04t6XEx0TRpOc2w'], // [积分变更通知]
    },
    //广告位
    adUnit: {
        merchantHome: 'adunit-a550674cafbcc9cd', // 商家主页
        cardDetail: 'adunit-7be1e24ffde82ed9', // 次卡详情页
        couponDetail: 'adunit-b1295f43965c4e1c', // 优惠券详情页
        verify: 'adunit-c9460ae402db588a', // 核销页
        couponReceivePrivate: 'adunit-c59c3cc697d7a470', // 私密领券页
        couponReceivePublic: 'adunit-2dc820312ef2c89a', // 公开领券页
        couponHome: 'adunit-155bccc4f89cb052', // 我的卡包主页
    }
}

export default config
