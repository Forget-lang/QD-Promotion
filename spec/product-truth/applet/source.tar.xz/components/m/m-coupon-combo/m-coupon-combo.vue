<template>
    <view class="coupon-combo-wrapper">
        <template v-for="(item, index) in combos" :key="index">
            <!-- 回显套餐组合 -->
            <view class="combo-item" @click="showCreate = true">
                <view class="combo-item-name">{{ item.name }}</view>
                <view class="combo-item-rule">{{ item.selectRule }}</view>
            </view>
        </template>
        <!-- 添加套餐组合 -->
        <view class="add-wrap">
            <t-tag theme="success" variant="outline" @click="showCreate = true">添加套餐</t-tag>
        </view>
    </view>

    <!-- 创建套餐弹窗 -->
    <t-popup placement="bottom" v-model:visible="showCreate" :close-on-overlay-click="false" :z-index="10000"
             :overlay-props="{ zIndex: 9999 }">
        <view class="combo-popup-container">
            <view class="combo-popup-header">
                <view class="combo-popup-title">创建套餐</view>
                <view class="combo-popup-close">
                    <t-icon name="close" size="50rpx" @click="showCreate = false"/>
                </view>
            </view>
            <scroll-view class="combo-scroll-body" scroll-y :show-scrollbar="false">
                <!-- 商品组列表 -->
                <view class="container mt-2">
                    <view v-for="(group, groupIndex) in comboGroups" :key="groupIndex" class="section mb-3">
                        <!-- 商品组头部 -->
                        <view class="section-header">
                            <view class="group-title d-flex align-items-center">
                                <text class="group-name">{{ group.name }}</text>
                                <t-icon name="edit" size="28rpx" color="#999" class="ml-1"
                                        @click="onEditGroupName(groupIndex)"></t-icon>
                            </view>
                            <t-icon name="close" size="28rpx" color="#999" @click="onRemoveGroup(groupIndex)"></t-icon>
                        </view>

                        <!-- 商品列表 -->
                        <view class="product-list">
                            <view
                                v-for="(product, productIndex) in group.products"
                                :key="productIndex"
                                class="product-item p-3 top-line"
                            >
                                <view class="product-info d-flex align-items-center">
                                    <view class="product-name flex-fill">{{ product.name }}</view>
                                    <view class="product-quantity">{{ product.quantity }}{{ product.unit }}</view>
                                    <view class="product-price">￥{{ product.price }}</view>
                                    <t-icon name="delete" size="32rpx" color="#999" class="ml-2"
                                            @click="onRemoveProduct(groupIndex, productIndex)"></t-icon>
                                </view>
                            </view>
                        </view>

                        <!-- 添加商品 -->
                        <view class="container p-3">
                            <t-tag theme="primary" variant="outline" @click="onAddProduct(groupIndex)">添加商品</t-tag>
                        </view>

                        <!-- 选择规则 -->
                        <view class="section-footer d-flex justify-content-between">
                            <view class="select-rule d-flex align-items-center" @click="onSelectRule(groupIndex)">
                                <template v-if="group.selectRule">
                                    <text class="text-info">
                                        {{ group.selectRule }}
                                    </text>
                                    <t-icon name="chevron-down" size="28rpx" color="#007AFF" class="ml-1"></t-icon>
                                </template>
                                <template v-else>
                                    <text class="text-small text-danger">
                                        请选择可选范围
                                    </text>
                                    <t-icon name="chevron-down" size="28rpx" color="#EB0909" class="ml-1"></t-icon>
                                </template>
                            </view>
                            <view class="product-count text-muted">共{{ group.products.length }}项</view>
                        </view>
                    </view>

                    <!-- 添加商品组按钮 -->
                    <view class="add-group-btn section text-center" @click="onAddGroup">
                        <t-icon name="add" size="50rpx" color="#999"></t-icon>
                        <text class="ml-1 text-muted">添加商品组</text>
                    </view>
                </view>
            </scroll-view>
            <!-- 底部保存按钮 -->
            <view class="container flex-shrink">
                <t-button theme="primary" size="large" block @click="onSave">保存</t-button>
            </view>
        </view>
    </t-popup>

    <!-- 选择规则弹窗 -->
    <t-picker v-model:visible="selectRuleVisible" v-model:value="tempGroup.selectRule" title="选择可选范围"
              :z-index="11000"
              @change="onSelectRuleChange"
              @cancel="selectRuleVisible = false">
        <t-picker-item :options="selectRuleOptions"/>
    </t-picker>

    <!-- 商品编辑弹窗 -->
    <t-popup placement="bottom" v-model:visible="productVisible" :close-on-overlay-click="false" :z-index="11000"
             :overlay-props="{ zIndex: 10999 }">
        <view class="popup-container">
            <view class="popup-header">
                <text class="popup-header-cancel" @click="onCancelProduct">取消</text>
                <text class="popup-header-title">添加商品</text>
                <text class="popup-header-confirm" @click="onConfirmProduct">确定</text>
            </view>
            <scroll-view class="popup-body" scroll-y :show-scrollbar="true">
                <t-cell-group theme="card" t-class="mt-2">
                    <t-input label="商品名称" placeholder="请输入商品名称" align="right" :required="true"
                             v-model:value="tempProduct.name"></t-input>
                    <t-cell title="数量">
                        <template #note>
                            <t-stepper v-model:value="tempProduct.quantity" default-value="1"/>
                        </template>
                    </t-cell>
                    <m-select title="单位" placeholder="请选择单位" v-model:value="tempProduct.unit"
                              :options="[{value: '个', label: '个'}, {value: '件', label: '件'}, {value: '份', label: '份'}, {value: '套', label: '套'}, {value: '包', label: '包'}, {value: '瓶', label: '瓶'}, {value: '盒', label: '盒'}, {value: '斤', label: '斤'},]"></m-select>
                    <t-input label="价格" placeholder="请输入价格" type="number" align="right" :cursor-spacing="30"
                             suffix="元" v-model:value="tempProduct.price"></t-input>
                </t-cell-group>
            </scroll-view>
            <view class="popup-bottom-action"></view>
        </view>
    </t-popup>
</template>

<script setup>
import {ref, onMounted} from 'vue';
import utils from '@/utils/utils'

const combos = defineModel('value', {
    type: Array,
    default: () => {
        return []
    }
})

// 弹窗显示状态
const showCreate = ref(false)

// 商品组数据
const comboGroups = ref([
    {
        name: '主食',
        selectRule: '必选',
        products: [
            {name: '刀削面', quantity: 1, price: 16, unit: '份'}
        ]
    },
    {
        name: '荤菜',
        selectRule: '2选1',
        products: [
            {name: '红烧鱼', quantity: 1, price: 50, unit: '份'},
            {name: '东坡肉', quantity: 1, price: 40, unit: '份'}
        ]
    }
])

// 初始化商品组数据
const initComboGroups = () => {
    if (combos.value && combos.value.length > 0) {
        comboGroups.value = combos.value.map(item => ({
            name: item.name || '',
            selectRule: item.selectRule || '',
            products: item.products || []
        }))
    }
}

// 添加商品组
const onAddGroup = () => {
    comboGroups.value.push({
        name: '商品组',
        selectRule: '',
        products: []
    })
}

// 删除商品组
const onRemoveGroup = (index) => {
    uni.showModal({
        title: '提示',
        content: '确定要删除此商品组吗？',
        success: (res) => {
            if (res.confirm) {
                comboGroups.value.splice(index, 1)
            }
        }
    })
}

// 编辑商品组名称
const onEditGroupName = (index) => {
    uni.showModal({
        title: '修改商品组名称',
        editable: true,
        placeholderText: '请输入商品组名称',
        content: comboGroups.value[index].name,
        success: (res) => {
            if (res.confirm && res.content) {
                // 检查是否包含禁止的字样
                if (res.content.includes('任选') || res.content.includes('选')) {
                    utils.toast('商品组名称中不可出现"任选N""X选N"字样')
                    return
                }
                comboGroups.value[index].name = res.content
            }
        }
    })
}

// 添加商品
const productVisible = ref(false)
const groupIndex = ref(0)
const tempProduct = ref({
    name: '',
    quantity: 1,
    unit: '份',
    price: null
})
const onAddProduct = (index) => {
    groupIndex.value = index
    tempProduct.value = {
        name: '',
        quantity: 1,
        unit: '份',
        price: null
    }
    productVisible.value = true
}
const onCancelProduct = () => {
    productVisible.value = false
    tempProduct.value = {
        name: '',
        quantity: 1,
        unit: '份',
        price: null
    }
}
const onConfirmProduct = () => {
    if (!tempProduct.value.name) {
        utils.toast('请输入商品名称')
        return
    }
    if (!tempProduct.value.price) {
        utils.toast('请输入价格')
        return
    }
    if (!tempProduct.value.unit) {
        utils.toast('请选择单位')
        return
    }

    const productData = {
        name: tempProduct.value.name,
        quantity: tempProduct.value.quantity,
        unit: tempProduct.value.unit,
        price: tempProduct.value.price
    }
    comboGroups.value[groupIndex.value].products.push(productData)
    productVisible.value = false
    tempProduct.value = {
        name: '',
        quantity: 1,
        unit: '份',
        price: null
    }
    if (comboGroups.value[groupIndex.value].products.length > 1 && comboGroups.value[groupIndex.value].selectRule === '必选') {
        comboGroups.value[groupIndex.value].selectRule = ''
    }
}
// 删除商品
const onRemoveProduct = (groupIndex, productIndex) => {
    comboGroups.value[groupIndex].products.splice(productIndex, 1)
}

const selectRuleVisible = ref(false)
const selectRuleOptions = ref([])
const tempGroup = ref({
    selectRule: [],
    index: 0
})

// 选择规则
const onSelectRule = (index) => {
    groupIndex.value = index
    const productCount = comboGroups.value[index].products.length

    // 如果没有商品，提示用户先添加商品
    if (productCount === 0) {
        utils.toast('请先添加商品')
        return
    }
    // 根据商品数量生成可选范围选项
    const options = []
    if (productCount === 1) {
        options.push({
            label: `必选`,
            value: `必选`
        })
        comboGroups.value[index].selectRule = "必选"
    } else {
        for (let i = 1; i <= productCount; i++) {
            options.push({
                label: `${productCount}选${i}`,
                value: `${productCount}选${i}`
            })
        }
    }
    selectRuleOptions.value = options
    tempGroup.value = {
        selectRule: comboGroups.value[index].selectRule ? [comboGroups.value[index].selectRule] : [],
        index: index
    }
    selectRuleVisible.value = true
}

// 选择了使用范围
const onSelectRuleChange = ({value}) => {
    comboGroups.value[tempGroup.value.index].selectRule = value[0]
    selectRuleVisible.value = false
}

// 保存
const onSave = () => {
    // 校验是否添加了商品组
    if (comboGroups.value.length === 0) {
        utils.toast('请至少添加一个商品组')
        return
    }

    // 校验必填项
    for (let i = 0; i < comboGroups.value.length; i++) {
        const group = comboGroups.value[i]
        if (!group.name) {
            utils.toast(`第${i + 1}个商品组名称不能为空`)
            return
        }
        if (!group.selectRule) {
            utils.toast(`请选择第${i + 1}个商品组的可选范围`)
            return
        }
        if (group.products.length === 0) {
            utils.toast(`第${i + 1}个商品组请至少添加一个商品`)
            return
        }
    }

    // 把数据回调上层页面
    combos.value = comboGroups.value
    showCreate.value = false
}

onMounted(() => {
    initComboGroups()
})


</script>

<style scoped>
.add-wrap {
    text-align: center;
    padding: 32rpx;
    background-color: #fff;
}

.combo-popup-container {
    border-radius: 24rpx 24rpx 0 0;
    background-color: #f5f5f5;
    overflow: hidden;
}

.combo-popup-header {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 32rpx 32rpx 24rpx;
    border-radius: 24rpx 24rpx 0 0;
    background-color: #f2f2f2;
}

.combo-popup-close {
    position: absolute;
    top: 32rpx;
    right: 32rpx;
    cursor: pointer;
}

.combo-popup-title {
    font-size: 30rpx;
    color: #333;
    font-weight: 600;
    text-align: center;
}

.combo-scroll-body {
    height: 70vh;
    padding-bottom: 30rpx;
    background-color: #f2f2f2;
}

.combo-item {
    background-color: #fff;
    padding: 24rpx;
    margin-bottom: 2rpx;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.combo-item-name {
    font-size: 28rpx;
    color: #333;
    font-weight: 600;
}

.combo-item-rule {
    font-size: 24rpx;
    color: #007AFF;
}

.group-title {
    flex: 1;
}

.group-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.product-item {
    background-color: #f8f8f8;
    margin: 20rpx 24rpx;
    border-radius: 12rpx;
}

.product-info {
    gap: 20rpx;
}

.product-name {
    font-size: 28rpx;
    color: #333;
}

.product-quantity {
    font-size: 24rpx;
    color: #666;
    padding: 8rpx 16rpx;
    border-radius: 8rpx;
    flex-shrink: 0;
}

.product-price {
    font-size: 24rpx;
    color: #666;
    padding: 8rpx 16rpx;
    border-radius: 8rpx;
    flex-shrink: 0;
}

.product-count {
    font-size: 24rpx;
}

.add-group-btn {
    background-color: #fff;
    cursor: pointer;
    border: 2rpx dashed #ddd;
    padding: 30rpx 0;
    margin: 20rpx 0;
}

.add-group-btn:active {
    background-color: #f0f0f0;
}
</style>
