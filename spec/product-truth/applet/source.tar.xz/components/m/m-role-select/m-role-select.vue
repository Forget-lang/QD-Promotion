<template>
    <t-cell :title="props.title" :required="required" :borderd="false" arrow hover @click="showPopup = true">
        <template #note>
            <text class="text-black lh-24" v-if="valueLabel">{{ valueLabel }}</text>
            <text class="lh-24" v-else>{{ placeholder }}</text>
        </template>
    </t-cell>
    <t-picker v-model:visible="showPopup" :value="pickerValue" :keys="{label:'name',value:'id'}" :title="props.title" cancel-btn="取消"
              confirm-btn="确认" @change="onChange"
              @cancel="showPopup = false">
        <t-picker-item :options="options"></t-picker-item>
    </t-picker>
</template>

<script setup>
	import { ref, computed, onMounted } from 'vue'
	import request from "@/hooks/request.js"
    import to from "@/hooks/to.js"

    const emits = defineEmits(["change"]);
	const props = defineProps({
		title: {
			type: String,
			default: '角色',
		},
		required: {
			type: Boolean,
			default: false,
		},
		placeholder: {
			type: String,
			default: '点击选择角色',
		},
		disabled: {
			type: Boolean,
			default: false
		}
	})

    // 弹窗显示状态
    const showPopup = ref(false);

	const modelValue = defineModel('value', {
		type: String,
		default:null
	})

	// 角色选项列表
	const options = ref([])

	// 当前选中角色名称（按 id 匹配回显，to.String 容错 id 类型不一致）
	const valueLabel = computed(() => {
		if (!modelValue.value) return ''
		const option = options.value.find(item => to.String(item.id) === to.String(modelValue.value))
		return option ? option.name : ''
	})

	// 弹窗选中值（取匹配选项自身 id，规避 t-picker 严格比较下的类型不一致）
	const pickerValue = computed(() => {
		const option = options.value.find(item => to.String(item.id) === to.String(modelValue.value))
		return option ? [option.id] : []
	})

	// 获取角色列表
	const getItems = () => {
		request.get('/seller/role/list').then(res => {
			options.value = to.Array(res.data.items)
		})
	}

	// 确认选择角色
    const onChange = (e) => {
        modelValue.value = e.value[0]
        emits('change', e)
    }

	onMounted(() => {
		getItems()
	})
</script>

<style scoped>
</style>