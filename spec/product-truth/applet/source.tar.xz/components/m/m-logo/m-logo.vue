<template>
	<view class="logo-container">
		<view class="w-100" v-if="cover && cover !== ''">
			<image class="cover-img" :src="cover" @tap="onPreView" mode="widthFix" />
		</view>
		<view v-else class="cover-add-container" @tap="chooseImage">
			<view class="cover-add">
                <image class="cover-add-icon" src="/static/img/3-add.png" mode="widthFix"/>
                <view class="cover-add-name">上传门店LOGO（选填）</view>
                <view class="cover-add-tip">不上传将使用默认LOGO</view>
			</view>
		</view>

		<view v-if="cover && props.replace" class="img-replace" @click="chooseImage">
			<t-icon custom-style="margin-right: 6rpx;" name="swap" size="28rpx" color="#fff"></t-icon>
			<text>更换Logo</text>
		</view>
	</view>
	<m-compress v-model:show="showCompress" v-model:tempFile="compressFile" @compress="onCompress"></m-compress>
</template>

<script setup>
	import { ref, onBeforeUnmount, onMounted, } from 'vue'
	import { useLink } from "@/hooks/useLink.js"
	import utils from '@/utils/utils';
	import config from '@/config';
    import {getUploadHeader} from '@/utils/upload';

	const { push } = useLink();

	const props = defineProps({
		maxSize: { //最大上传限制，单位M
			type: Number,
			default: () => {
				return 5
			}
		},
		replace: {
			type: Boolean,
			default: true
		},
		interceptReplace: {
			type: Boolean,
			default: false
		},
		replaceLink: {
			type: String,
			default: ''
		},
		//注册回调方法名儿，防止多次触发回调
		emitName: {
			type: String,
			default: ''
		}
	})
	const cover = defineModel('value', {
		type: String,
		default: ''
	})
	const showCompress = ref(false)
	const compressFile = ref('')

	const uploadCover = (file) => {
		utils.showLoading()
		let timestamp = utils.getUnixTime()
		let sign = utils.signParam({}, config.appSecret, timestamp)
		uni.uploadFile({
			url: config.apiUrl + '/seller/object/upload?sign=' + sign + '&timestamp=' + timestamp,
			filePath: file,
			name: 'file',
            header: getUploadHeader(),
			success: (uploadFileRes) => {
				//uploadFile将真实返回结果为Json字符串，封装到data字段中
				utils.hideLoading()
                let result
                try {
                    result = JSON.parse(uploadFileRes.data)
                } catch (e) {
                    utils.toast('上传响应异常')
                    return
                }
				if (result.code === 0) {
					if (result.data.isSuccess){
                        cover.value = result.data.url
                    } else {
                        utils.alert(result.data.failReason)
                    }
				} else { //上传错误时，使用接口返回的错误信息
					utils.alert(result.message)
				}
			},
			fail: (err) => {
				utils.hideLoading()
                utils.toast('图片上传失败' + err.errMsg)
			}
		});
	}

	onMounted(() => {
		uni.$on(props.emitName, (file) => {
			compressFile.value = file
			showCompress.value = true
		})
	})
	onBeforeUnmount(() => {
		uni.$off(props.emitName)
	})
	const chooseImage = () => {
		if (props.interceptReplace) {
			push(props.replaceLink)
			return
		}
		uni.chooseImage({
			count: 1,
			success: function(e) {
				let size = e.tempFiles[0].size;
				if (props.maxSize * 1024 * 1024 < size) {
					let err = '单张图片大小不能超过：' + props.maxSize + 'MB'
					utils.toast(err)
				} else {
					let tempPath = e.tempFilePaths[0]
					push('/pages_merchant/media/cropper?path=' + tempPath + '&width=300&height=300&emitName=' + props.emitName, props.needLogin)
				}
			},
			fail: function(e) {
				console.log(e)
				if (e.errMsg == 'chooseImage:fail cancel') {
					utils.toast('您取消了操作')
				} else {
					utils.toast('图片选择失败，请稍后再试。' + e.errMsg)
				}
			}
		})
	}
	const onPreView = () => {
		if (!cover.value) {
			return
		}
		let images = []
		images.push(cover.value)
		uni.previewImage({
			current: 0,
			loop: true,
			urls: images
		})
	}
	const onCompress = () => {
		uploadCover(compressFile.value)
	}
</script>

<style scoped>
	.logo-container {
		width: 100%;
		min-height: 260rpx;
		display: flex;
		background-color: #ffffff;
		align-items: center;
		justify-content: center;
		position: relative;
		transition: all 0.3s linear;
	}

	.cover-img {
		width: 180rpx;
		height: 180rpx;
		display: block;
		border-radius: 16rpx;
		margin: auto;
	}

	.cover-add-container {
		width: 100%;
		min-height: 260rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.cover-add {
		margin: auto;
		text-align: center;
	}

	.cover-add-icon {
		width: 80rpx;
		height: 72rpx;
	}

	.file-del {
		position: absolute;
		top: -20rpx;
		right: -20rpx;
		display: inline-block;
		width: 25px;
		height: 25px;
	}

	.cover-add-name {
		font-size: 24rpx;
		color: #777;
	}

    .cover-add-tip {
        margin-top: 8rpx;
        font-size: 22rpx;
        color: #999;
    }

	.cover-tips {
		width: 100%;
		text-align: center;
		position: absolute;
		left: 0;
		bottom: 0;
		font-size: 22rpx;
		color: #999;
	}

	.img-replace {
		position: absolute;
		background-color: #00000050;
		border-radius: 6rpx;
		right: 16rpx;
		bottom: 16rpx;
		font-size: 22rpx;
		line-height: 42rpx;
		color: #fff;
		width: 130rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
</style>