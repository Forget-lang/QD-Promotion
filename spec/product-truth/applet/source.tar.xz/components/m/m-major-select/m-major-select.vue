<template>
	<t-input class="major-input" v-model:value="modelValue[index]"  v-for="(item, index) in modelValue" :key="index" placeholder="输入主营产品,每个最多12个字" :maxlength="12" >
		<template #extra>
			<t-tag theme="danger" variant="outline" @click="removeMajor(index)">删除</t-tag>
		</template>
	</t-input>
	
	<view class="d-flex justify-content-center p-2" v-if="modelValue.length < max" @click="addMajor">
		<t-tag theme="success" variant="outline">添加主营产品</t-tag>
	</view>
	
	<view v-else class="max-hint">
		<text>已达最大主营产品限制 ({{ max }}个)</text>
	</view>
</template>

<script setup>
	import {
		ref,
	} from 'vue';

	const props = defineProps({
		max: {
			type: Number,
			default: 3
		},
	});

	const modelValue = defineModel('value', {
		default: () => []
	})

	// 添加主营产品
	const addMajor = () => {
		if (modelValue.value.length < props.max) {
			modelValue.value.push('');
		}
	}
	
	// 移除主营产品
	const removeMajor = (index) => {
		modelValue.value.splice(index, 1);
	}
</script>

<style scoped>
	.max-hint {
		text-align: center;
		margin:20rpx 0;
		color: #999;
		font-size: 24rpx;
	}
</style>