<template>
	<div class="submit">
		<div class="submit-btn">
			<t-button theme="danger" size="large" block :loading="props.loading" :disabled="props.disabled" height="100rpx" @click="onTap">
				<slot></slot>
			</t-button>
		</div>
	</div>
</template>

<script setup>
	import utils from "/utils/utils"

	const emits = defineEmits(['click'])
	const props = defineProps({
		loading: {
			type: Boolean,
			default: false,
		},
		disabled: {
			type: Boolean,
			default: false,
		}
	})

	const onTap = utils.debounce(() => {
		emits('click', true)
	})
</script>

<style scoped>
	.submit {
        background: #FFF;
		position: fixed;
		bottom: 0;
		width: 100%;
		z-index: 99;
		padding-bottom: constant(safe-area-inset-bottom);
		padding-bottom: env(safe-area-inset-bottom);
	}

	.submit-btn {
		padding: 30rpx 30rpx;
	}
</style>