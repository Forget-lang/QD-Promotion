<template>
    <view>
        <view class="coupon-select-wrapper">
            <view class="coupon-select-header">
                <view>
                    <text class="title" v-if="props.title">{{ props.title }}</text>
                    <text class="required" v-if="props.required">*</text>
                    <view v-if="description" class="coupon-select-description">{{ description }}</view>
                </view>
                <text class="add-btn" @click="onAdd">+ 添加</text>
            </view>
            <view class="coupon-list">
                <view class="coupon-item" v-for="(item, index) in selectedCoupons" :key="index">
                    <view class="coupon-left">
                        <view class="coupon-name">{{ item.couponName }}</view>
                        <view class="coupon-meta">
                            <text class="meta-tag type-tag">{{ getCouponTypeLabel(item.couponType) }}</text>
                            <text class="meta-text">剩余 {{ item.remainStock }}</text>
                        </view>
                    </view>
                    <view class="coupon-right">
                        <t-icon name="delete" size="18px" class="delete-btn" @click="onRemove(index)"/>
                    </view>
                </view>
                <view v-if="selectedCoupons.length === 0" class="empty-text">请添加优惠券</view>
            </view>
        </view>

        <t-popup v-model:visible="showPopup" placement="bottom">
            <view class="popup-container pb-3">
                <view class="popup-header">
                    <view class="popup-header-cancel" @click="onCancel">取消</view>
                    <view class="popup-header-title">请选择优惠券</view>
                    <view class="popup-header-confirm" @click="onConfirm">确定</view>
                </view>
                <view class="popup-search-bar">
                    <view class="input-search">
                        <t-input
                            :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                            placeholder="搜索优惠券名称"
                            v-model:value="searchName"
                            borderless
                            @clear="onSearchClear"
                            @enter="onSearch"
                        />
                        <view class="input-search-actions">
                            <t-button theme="default" variant="text" icon="search" @click="onSearch"></t-button>
                        </view>
                    </view>
                </view>
                <view class="container">
                    <view class="section mt-2" v-if="tip">
                        <view class="section-header bottom-line">
                            <view class="h3">{{ tip }}</view>
                        </view>
                        <scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
                            <t-checkbox-group v-model:value="tempValue" v-if="couponList.length > 0">
                                <t-checkbox v-for="(item, index) in couponList" :key="index" :value="item.id"
                                            placement="right">
                                    <template #label>
                                        <view class="checkbox-label">
                                            <view class="checkbox-name">{{ item.name }}</view>
                                            <view class="checkbox-extra">
                                                <text>{{ getCouponTypeLabel(item.couponType) }}</text>
                                                <text>剩余：{{ item.remainStock }}</text>
                                            </view>
                                        </view>
                                    </template>
                                </t-checkbox>
                            </t-checkbox-group>
                            <m-empty v-else>
                                <view>您还没有创建优惠券</view>
                                <!-- 没有可选优惠券时引导创建 -->
                                <view class="d-flex flex-column align-items-center justify-content-center mt-5">
                                    <t-button theme="primary" size="medium" @click="push('/pages_coupon/coupon/choose_type')">创建优惠券</t-button>
                                    <view class="d-flex align-items-center justify-content-center text-wechat mt-2" @tap="onRefresh">
                                        <t-loading v-if="refreshing" theme="circular" size="18px" inherit-color custom-style="margin-right: 4rpx;"/>
                                        <text>{{ refreshing ? '刷新中...' : '刷新列表' }}</text>
                                    </view>
                                </view>
                            </m-empty>
                        </scroll-view>
                    </view>
                </view>
                <view class="popup-bottom-action" v-if="couponList.length > 0">
                    <view class="popup-footer-count">已选 {{ tempValue.length }} 个优惠券</view>
                    <view class="popup-footer-right">
                        <t-button theme="primary" size="extra-small" @click="onSelectAll">全选</t-button>
                    </view>
                </view>
            </view>
        </t-popup>
    </view>
</template>

<script setup>
import {ref, computed} from 'vue'
import request from "@/hooks/request.js"
import {useLink} from '@/hooks/useLink.js'

const {push} = useLink()

const props = defineProps({
    gateway: {
        type: String,
        default: '/seller/activity-poster/coupon/list'
    },
    title: {
        type: String,
        default: '优惠券列表'
    },
    description: {
        type: String,
    },
    tip: {
        type: String,
        default: '仅可选择有效的公开领取优惠券'
    },
    required: {
        type: Boolean,
        default: false
    }
})

const modelValue = defineModel('value', {
    type: Array,
    default: () => []
})

const showPopup = ref(false)
const tempValue = ref([])
const couponList = ref([])
const searchName = ref('')
// 刷新列表加载中（点击「刷新列表」时置位，getCoupons 完成后复位）
const refreshing = ref(false)

const selectedCoupons = computed(() => {
    return modelValue.value || []
})

const getCouponTypeLabel = (type) => {
    const typeMap = {
        1: '代金券',
        2: '套餐券',
        3: '满减券',
        4: '折扣券',
        5: '兑换券',
        6: '手气券'
    }
    return typeMap[type] || '未知类型'
}

const onAdd = () => {
    tempValue.value = (modelValue.value || []).map(item => item.couponId)
    searchName.value = ''
    showPopup.value = true
    getCoupons()
}

// 手动刷新优惠券列表（带加载状态）
const onRefresh = () => {
    if (refreshing.value) return
    refreshing.value = true
    getCoupons()
}

// 加载优惠券列表（打开选择器 / 搜索 / 清空 / 手动刷新共用）
const getCoupons = (name = '') => {
    const params = {}
    if (name) {
        params.name = name
    }
    return request.get(props.gateway, params).then(res => {
        couponList.value = res.data.items || []
    }).finally(() => {
        setTimeout(() => {
            refreshing.value = false
        }, 800)
    })
}

const onSearch = () => {
    getCoupons((searchName.value || '').trim())
}

const onSearchClear = () => {
    searchName.value = ''
    getCoupons()
}

const onCancel = () => {
    showPopup.value = false
}

const onConfirm = () => {
    const selectedIds = tempValue.value
    const newCoupons = []

    selectedIds.forEach(id => {
        const existing = modelValue.value.find(item => item.couponId == id)
        if (existing) {
            newCoupons.push(existing)
        } else {
            const coupon = couponList.value.find(item => item.id == id)
            if (coupon) {
                newCoupons.push({
                    couponId: coupon.id,
                    couponName: coupon.name,
                    couponType: coupon.couponType,
                    remainStock: coupon.remainStock
                })
            }
        }
    })

    modelValue.value = newCoupons
    showPopup.value = false
}

const onSelectAll = () => {
    tempValue.value = couponList.value.map(item => item.id)
}

const onRemove = (index) => {
    const newCoupons = [...modelValue.value]
    newCoupons.splice(index, 1)
    modelValue.value = newCoupons
}
</script>

<style scoped>
.popup-search-bar {
    padding: 16rpx 24rpx 0;
}

.coupon-select-wrapper {
    background: #fff;
    padding: 32rpx;
}

.coupon-select-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 20rpx;
}

.coupon-select-header .title {
    font-size: 28rpx;
    color: #333;
    font-weight: 600;
}

.coupon-select-header .required {
    color: #e84c59;
    margin-left: 4rpx;
}

.coupon-select-header .add-btn {
    font-size: 28rpx;
    color: #1989fa;
}

.coupon-select-description {
    margin-top: 8rpx;
    font-size: 24rpx;
    line-height: 1.5;
    color: #999;
}

.coupon-list {
    margin-top: 20rpx;
    display: flex;
    flex-direction: column;
    gap: 16rpx;
}

.coupon-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 24rpx;
    background: #f8f9fa;
    border-radius: 12rpx;
    border: 1rpx solid #eee;
}

.coupon-left {
    flex: 1;
    min-width: 0;
    margin-right: 24rpx;
}

.coupon-name {
    font-size: 28rpx;
    color: #333;
    font-weight: 500;
    line-height: 1.4;
    margin-bottom: 10rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-meta {
    display: flex;
    align-items: center;
    gap: 12rpx;
    flex-wrap: nowrap;
}

.meta-tag {
    display: inline-block;
    font-size: 22rpx;
    padding: 2rpx 12rpx;
    border-radius: 4rpx;
    background: #e8f5e9;
    color: #2e7d32;
    flex-shrink: 0;
    line-height: 1.6;
}

.meta-text {
    font-size: 22rpx;
    color: #999;
    flex-shrink: 0;
    white-space: nowrap;
}

.coupon-right {
    display: flex;
    align-items: center;
    gap: 12rpx;
    flex-shrink: 0;
}

.delete-btn {
    color: #999;
    padding: 8rpx;
}

.empty-text {
    text-align: center;
    padding: 40rpx;
    color: #999;
    font-size: 28rpx;
}

.checkbox-label {
    display: flex;
    flex-direction: column;
    gap: 8rpx;
}

.checkbox-name {
    font-size: 28rpx;
    color: #333;
}

.checkbox-extra {
    display: flex;
    gap: 20rpx;
    font-size: 24rpx;
    color: #999;
}

.popup-footer-count {
    font-size: 28rpx;
    color: #999;
}

.popup-footer-right {
    display: flex;
    align-items: center;
    gap: 20rpx;
}
</style>
