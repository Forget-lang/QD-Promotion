<template>
    <view class="text-nomore">没有更多了</view>
</template>

<script>
</script>

<style scoped>
.text-nomore {
    text-align: center;
    color: #999999;
    font-size: 24rpx;
    padding: 40rpx 0;
}
</style>