<template>
    <t-popup placement="bottom" :visible="visible" @visible-change="onVisibleChange">
        <view class="popup-header">
            <view class="popup-header-title">收款口令码</view>
            <view class="popup-header-close">
                <t-icon name="close" :size="20" @click="close"/>
            </view>
        </view>

        <view class="cipher-panel-body">
            <m-loading v-if="loading"/>
            <template v-else-if="cipher">
                <view v-if="canEdit" class="cipher-type-tabs">
                    <view class="cipher-type-tab"
                          :class="{ active: isFixed, disabled: saving }"
                          @click="setCipherType(CIPHER_TYPE.FIXED)">固定口令码
                    </view>
                    <view class="cipher-type-tab"
                          :class="{ active: !isFixed, disabled: saving }"
                          @click="setCipherType(CIPHER_TYPE.RANDOM)">随机变化口令码
                    </view>
                </view>

                <view class="cipher-display" :class="{ 'cipher-display--tap': canCopy }" @click="copyCode">
                    {{ displayCode }}
                </view>
                <view v-if="canCopy" class="cipher-copy-hint">点击口令码复制</view>

                <view v-if="isFixed && canEdit" class="cipher-edit">
                    <view class="cipher-input-wrap">
                        <t-input label="修改口令" v-model:value="editCode" align="right"
                                 placeholder="输入新的5位数字口令"
                                 :maxlength="5" type="number" borderless :line-left="false"
                                 custom-style="padding: 26rpx 30rpx;"/>
                    </view>
                    <t-button class="cipher-btn" theme="primary" size="large" block :loading="saving"
                              :disabled="!canSave" @click="onSave">保存口令
                    </t-button>
                </view>

                <view v-if="!isFixed && cipher.cipherExpireAt > 0 && !cipherExpired" class="cipher-countdown">
                    <text>{{ countdownText }}后刷新</text>
                </view>
                <view v-if="!isFixed && cipherExpired" class="cipher-expired-tip">口令码已过期，请点击更新</view>

                <view v-if="!isFixed && canEdit" class="cipher-actions">
                    <t-button v-if="cipherExpired" class="cipher-btn cipher-btn-update" theme="primary" size="large"
                              block :loading="refreshing" @click="onRefresh">更新口令码
                    </t-button>
                    <t-button v-else class="cipher-btn" theme="primary" size="large" block :loading="refreshing"
                              @click="onRefresh">手动刷新
                    </t-button>
                </view>

                <view v-if="canCopy" class="cipher-share-wrap">
                    <t-button class="cipher-btn-share" size="large" block @click="openShareDialog">
                        复制口令码文案分享给顾客
                    </t-button>
                </view>
            </template>
        </view>

        <view class="popup-bottom-cancel" @click="close">取消</view>
    </t-popup>

    <t-dialog :visible="shareDialogVisible" title="内容复制提醒" cancel-btn="取消" confirm-btn="确定"
              :z-index="shareDialogZIndex" :overlay-props="{ zIndex: shareDialogOverlayZIndex }"
              @confirm="onShareConfirm" @cancel="closeShareDialog" @close="closeShareDialog">
        <template #content>
            <text class="cipher-share-dialog-text">{{ shareText }}</text>
        </template>
    </t-dialog>
</template>

<script setup>
import {computed, ref, watch, onBeforeUnmount} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {CIPHER_TYPE} from '@/constants/coupon'
import {useAuth} from '@/hooks/useAuth'
import {PERM_COUPON} from '@/constants/permission'

const {checkPermission} = useAuth()

const visible = defineModel('visible', {type: Boolean, default: false})
const props = defineProps({
    couponId: {type: String, default: ''},
    couponName: {type: String, default: ''},
})

const emit = defineEmits(['updated'])

const loading = ref(false)
const saving = ref(false)
const refreshing = ref(false)
const cipher = ref(null)
const editCode = ref('')
const countdownText = ref('')
const cipherExpired = ref(false)
const shareDialogVisible = ref(false)
const shareDialogZIndex = 12000
const shareDialogOverlayZIndex = 11999
let countdownTimer = null

const canEdit = computed(() => checkPermission(PERM_COUPON.UPDATE))
const isFixed = computed(() => Number(cipher.value?.cipherType) === CIPHER_TYPE.FIXED)
const displayCode = computed(() => cipher.value?.cipherCode || '------')
const canCopy = computed(() => /^\d{5}$/.test(String(cipher.value?.cipherCode || '')))
const canSave = computed(() => /^\d{5}$/.test(String(editCode.value || '')))

const shareText = computed(() => {
    const name = String(props.couponName || '').trim()
    const code = cipher.value?.cipherCode || ''
    if (!name || !canCopy.value) return ''
    if (isFixed.value) {
        return `${name}线下收款口令码：${code}，领取时在页面输入该口令码即可完成领取。`
    }
    const validity = !cipherExpired.value && countdownText.value
        ? `${countdownText.value}内有效（约3分钟），`
        : ''
    return `${name}线下收款口令码：${code}，${validity}领取时在页面输入该口令码即可完成领取。`
})

const syncCipherExpired = () => {
    if (isFixed.value || !cipher.value?.cipherExpireAt) {
        cipherExpired.value = false
        return
    }
    cipherExpired.value = cipher.value.cipherExpireAt * 1000 <= Date.now()
}

const clearCountdownTimer = () => {
    if (countdownTimer) {
        clearInterval(countdownTimer)
        countdownTimer = null
    }
}

const tickCountdown = () => {
    if (!cipher.value?.cipherExpireAt || isFixed.value) {
        countdownText.value = ''
        cipherExpired.value = false
        return
    }
    const remain = cipher.value.cipherExpireAt * 1000 - Date.now()
    if (remain <= 0) {
        countdownText.value = ''
        cipherExpired.value = true
        clearCountdownTimer()
        return
    }
    cipherExpired.value = false
    const minutes = Math.floor(remain / 60000)
    const seconds = Math.floor((remain % 60000) / 1000)
    countdownText.value = `${minutes}分${seconds}秒`
}

const startCountdownTimer = () => {
    clearCountdownTimer()
    syncCipherExpired()
    if (!visible.value || isFixed.value || !cipher.value?.cipherExpireAt || cipherExpired.value) return
    tickCountdown()
    countdownTimer = setInterval(tickCountdown, 1000)
}

const loadCipher = () => {
    if (!props.couponId) return
    loading.value = true
    request.get('/seller/coupon/cipher', {id: props.couponId}).then(res => {
        cipher.value = res.data
        editCode.value = ''
        startCountdownTimer()
    }).catch(err => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

watch(visible, (val) => {
    if (val) {
        loadCipher()
        return
    }
    clearCountdownTimer()
    editCode.value = ''
    closeShareDialog()
})

watch(isFixed, () => {
    if (visible.value) startCountdownTimer()
})

onBeforeUnmount(clearCountdownTimer)

const onVisibleChange = (e) => {
    visible.value = e.visible
}

const close = () => {
    visible.value = false
}

const copyCode = () => {
    if (!canCopy.value) return
    utils.copyClipboard(cipher.value.cipherCode, '口令码已复制')
}

const openShareDialog = () => {
    if (!shareText.value) return
    shareDialogVisible.value = true
}

const closeShareDialog = () => {
    shareDialogVisible.value = false
}

const onShareConfirm = () => {
    if (!shareText.value) return
    utils.copyClipboard(shareText.value, '收款口令码复制成功')
    closeShareDialog()
}

const applyCipherRes = (data) => {
    cipher.value = data
    editCode.value = ''
    startCountdownTimer()
    emit('updated', data)
}

const saveCipherType = (nextType, code = '') => {
    if (saving.value) return
    saving.value = true
    request.post('/seller/coupon/cipher/save', {
        id: props.couponId,
        cipherType: nextType,
        cipherCode: code,
    }).then(res => {
        applyCipherRes(res.data)
    }).catch(err => utils.toast(err.message)).finally(() => {
        saving.value = false
    })
}

const setCipherType = (type) => {
    if (!canEdit.value || saving.value || Number(cipher.value?.cipherType) === type) return
    if (type === CIPHER_TYPE.FIXED) {
        editCode.value = ''
        saveCipherType(type, cipher.value?.cipherCode || '')
        return
    }
    saveCipherType(type, '')
}

const onSave = utils.debounce(() => {
    const code = String(editCode.value || '')
    if (!/^\d{5}$/.test(code)) {
        utils.toast('固定口令须为5位数字')
        return
    }
    saving.value = true
    request.post('/seller/coupon/cipher/save', {
        id: props.couponId,
        cipherType: CIPHER_TYPE.FIXED,
        cipherCode: code,
    }).then(res => {
        utils.toast('口令已保存')
        applyCipherRes(res.data)
    }).catch(err => utils.toast(err.message)).finally(() => {
        saving.value = false
    })
})

const onRefresh = utils.debounce(() => {
    refreshing.value = true
    request.post('/seller/coupon/cipher/refresh', {id: props.couponId}).then(res => {
        utils.toast(cipherExpired.value ? '口令码已更新' : '口令已刷新')
        applyCipherRes(res.data)
    }).catch(err => utils.toast(err.message)).finally(() => {
        refreshing.value = false
    })
})
</script>

<style scoped>
.cipher-panel-body {
    padding: 24rpx 32rpx 32rpx;
    background: #fff;
}

.cipher-type-tabs {
    display: flex;
    gap: 20rpx;
    margin-bottom: 32rpx;
    background: #fff;
}

.cipher-type-tab {
    flex: 1;
    padding: 18rpx 0;
    text-align: center;
    font-size: 28rpx;
    color: #666;
    background: #fff;
    border-radius: 12rpx;
    border: 2rpx solid #dcdcdc;
    box-sizing: border-box;
}

.cipher-type-tab.active {
    color: #e84c59;
    background: #fff;
    border-color: #e84c59;
    font-weight: 600;
}

.cipher-type-tab.disabled {
    opacity: 0.6;
}

.cipher-display {
    margin-bottom: 12rpx;
    text-align: center;
    font-size: 72rpx;
    font-weight: 700;
    letter-spacing: 12rpx;
    color: #e84c59;
}

.cipher-display--tap:active {
    opacity: 0.7;
}

.cipher-copy-hint {
    margin-bottom: 32rpx;
    text-align: center;
    font-size: 24rpx;
    color: #999;
}

.cipher-input-wrap {
    margin-bottom: 20rpx;
    border-radius: 12rpx;
    --td-input-bg-color: #f5f5f5;
    --td-input-label-min-width: 140rpx;
    overflow: hidden;
}

.cipher-edit {
    margin-bottom: 24rpx;
}

.cipher-btn {
    --td-button-large-height: 88rpx;
    --td-button-large-font-size: 30rpx;
    --td-button-border-radius: 12rpx;
}

.cipher-btn-update {
    --td-button-primary-bg-color: #07c160;
    --td-button-primary-border-color: #07c160;
    --td-button-primary-active-bg-color: #06ad56;
    --td-button-primary-active-border-color: #06ad56;
}

.cipher-countdown {
    margin-bottom: 24rpx;
    text-align: center;
    font-size: 28rpx;
    color: #666;
}

.cipher-expired-tip {
    margin-bottom: 24rpx;
    text-align: center;
    font-size: 24rpx;
    color: #e84c59;
}

.cipher-actions {
    display: flex;
    flex-direction: column;
    gap: 20rpx;
    margin-bottom: 20rpx;
}

.cipher-share-wrap {
    margin-top: 4rpx;
}

.cipher-btn-share {
    --td-button-large-height: 88rpx;
    --td-button-large-font-size: 30rpx;
    --td-button-border-radius: 12rpx;
    --td-button-default-bg-color: #f5f5f5;
    --td-button-default-color: #1a1a1a;
    --td-button-default-border-color: #f5f5f5;
    --td-button-default-active-bg-color: #ebebeb;
    --td-button-default-active-border-color: #ebebeb;
}

.cipher-share-dialog-text {
    font-size: 28rpx;
    color: #333;
    line-height: 1.6;
}
</style>
