<template>
    <view class="store-panel" v-if="theme === 'cell' && stores.length === 1">
        <view class="d-flex justify-content-between align-items-center mt-2">
            <view class="store-panel-name">
                <text>{{ stores[0].name }}</text>
                <image src="https://cdn.lenmy.com/quandao/2026/05/21/d87d6cslbp0t6seglkt0.png" class="audit-icon"></image>
            </view>
            <view class="d-flex align-items-center flex-shrink">
                <view class="menu-item-wrap" @tap="openLocation(stores[0])">
                    <t-icon name="location" size="28rpx"/>
                </view>
                <view class="menu-item-wrap" @tap="utils.makePhoneCall(stores[0].servicePhone)">
                    <t-icon name="call" size="28rpx"/>
                </view>
            </view>
        </view>

        <view class="store-panel-address">
            <text @tap="openLocation(stores[0])">{{ stores[0].address }}</text>
        </view>
    </view>

    <template v-if="theme === 'note'">
        <view class="cell-note" v-if="stores.length > 1" @click="isShowStore = true">
            <view class="cell-note-label">可用门店</view>
            <view class="cell-note-value">
                <text class="cell-note-light">{{ stores.length }}家门店可用</text>
                <text class="dotted">•</text>
                <template v-if="stores[0].distance > 0">
                    <text>最近{{ (stores[0].distance / 1000).toFixed(1) }}km</text>
                    <text class="dotted">•</text>
                    <text>{{ stores[0].address }}</text>
                </template>
                <text v-else>点击查看距离及地址</text>
            </view>
            <t-icon t-class="flex-shrink" name="chevron-right" size="32rpx" color="#999"/>
        </view>
    </template>

    <template v-else-if="theme === 'cell'">
        <t-cell v-if="stores.length > 1" title="适用门店" @click="isShowStore = true" arrow>
            <template #note>
                <text class="text-muted">{{ stores.length }}家适用门店</text>
            </template>
        </t-cell>

    </template>

    <!-- list：门店列表 -->
    <template v-else-if="theme === 'list'">
        <view class="store-list-warp">
            <view v-if="(lat === 0 || lng === 0)" class="location-tip">
                <text class="location-tip-text">查看距离您最近的门店，</text>
                <text class="location-tip-link" @tap="getLocation(true)">开启定位</text>
            </view>
            <m-usage-stores :stores="stores"/>
        </view>
    </template>

    <t-popup v-if="stores.length > 0" v-model:visible="isShowStore" placement="bottom">
        <view class="popup-header flex-column mt-2">
            <text class="popup-header-title">{{ stores.length }}家适用门店</text>
            <view v-if="(lat === 0 || lng === 0)" class="mt-1">
                <text class="text-muted">查看距离您最近的门店，</text>
                <text class="text-muted text-wechat" @tap="getLocation(true)">开启定位</text>
            </view>
        </view>
        <scroll-view class="popup-body mt-3" style="height: 65vh" scroll-y :show-scrollbar="false">
            <m-usage-stores :stores="stores"/>
        </scroll-view>
    </t-popup>

</template>

<script setup>
import {onMounted, ref, watch} from 'vue'
import utils from '@/utils/utils'
import request from '@/hooks/request'

const props = defineProps({
    cardId: {
        type: String,
        default: ''
    },
    theme: {
        type: String,
        default: 'note'
    }
})

const stores = defineModel('stores', {
    type: Array,
    default: []
})

const lat = ref(0)
const lng = ref(0)
const isShowStore = ref(false)

const openLocation = (store) => {
    if (store.lat > 0 && store.lng > 0) {
        wx.openLocation({
            latitude: store.lat,
            longitude: store.lng,
            scale: 8,
            name: store.name,
            address: store.address,
            fail(e) {
                uni.showToast({
                    icon: 'none',
                    title: e
                })
            }
        })
    } else {
        uni.showToast({
            icon: 'none',
            title: '尚未设置门店地图位置，无法导航'
        })
    }
}

const checkLocationAuth = () => {
    wx.getSetting({
        success(res) {
            if (res.authSetting['scope.userLocation']) {
                getLocation()
            } else {
                getStores()
            }
        },
        fail() {
            utils.toast('前往小程序设置，开启定位权限后，查看距离您最近的门店')
            getStores()
        }
    })
}

const getLocation = () => {
    wx.getLocation({
        type: 'gcj02',
        success(res) {
            lat.value = res.latitude
            lng.value = res.longitude
            getStores()
        },
        fail(error) {
            if (error.errMsg === 'getLocation:fail auth deny') {
                onSettingLocation()
            } else {
                utils.toast('获取定位失败，请稍后重试')
            }
        },
    })
}

const onSettingLocation = () => {
    wx.openSetting({
        success(res) {
            if (res.authSetting['scope.userLocation'] === true) {
                getLocation()
            }
        },
        fail() {
            utils.toast('前往小程序设置，开启定位权限后，查看距离您最近的门店')
        }
    })
}

const getStores = () => {
    if (!props.cardId) {
        return
    }
    request.get('/card/stores', {
        cardId: props.cardId,
        lat: lat.value,
        lng: lng.value
    }, {
        showLoading: false
    }).then(res => {
        stores.value = res.data.items
    })
}

watch(() => props.cardId, (value) => {
    if (value) {
        checkLocationAuth()
    }
})

onMounted(() => {
    if (props.cardId) {
        checkLocationAuth()
    }
})
</script>

<style scoped>
.store-panel {
    padding: 12rpx 32rpx 0 32rpx;
}

.store-panel-name {
    display: flex;
    font-weight: 600;
    align-content: center;
    font-size: 32rpx;
}

.store-panel-address {
    font-size: 28rpx;
    margin-top: 20rpx;
}

.menu-item-wrap {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #eeeeee;
    border-radius: 50%;
    width: 56rpx;
    height: 56rpx;
    margin-left: 20rpx;
}

.cell-note {
    display: flex;
    align-items: center;
    flex: 1;
    margin: 32rpx;
}

.cell-note-label {
    width: 130rpx;
    font-size: 28rpx;
    color: #78797f;
    margin-right: 5rpx;
}

.cell-note-value {
    color: #161722;
    flex: 1;
    overflow: hidden;
    font-style: normal;
    font-size: 28rpx;
    font-weight: normal;
    -webkit-line-clamp: 1;
    text-overflow: ellipsis;
    display: inline-block !important;
    word-break: normal !important;
    white-space: nowrap !important;
}

.cell-note-light {
    font-weight: 500;
    color: #ef8b3c;
}

.dotted {
    margin: 0 12rpx;
}

/* list 模式样式 */
.location-tip {
    display: flex;
    align-items: center;
    background: linear-gradient(135deg, #f8fcff 0%, #f0f7ff 100%);
    border-radius: 12rpx;
    padding: 16rpx 24rpx;
    margin: 0 24rpx 20rpx;
}

.location-tip-text {
    font-size: 24rpx;
    color: #666;
}

.location-tip-link {
    font-size: 24rpx;
    color: #07c160;
    font-weight: 500;
}
</style>
