<template>
    <t-cell :title="props.title" :required="required" :description="description" :borderd="false" arrow hover
            @click="showPopup = true">
		<template #note>
			<text class="text-black lh-24" v-if="valueLabel">{{valueLabel}}</text>
			<text class="lh-24" v-else>{{placeholder}}</text>
		</template>
	</t-cell>
    <t-picker v-model:visible="showPopup" :value="pickerValue" :title="props.title" cancel-btn="取消"
              confirm-btn="确认" @change="onPickerChange"
              @cancel="showPopup = false">
		<t-picker-item :options="props.options"></t-picker-item>
	</t-picker>
</template>

<script setup>
import {ref, computed} from 'vue'

const emits = defineEmits(['change'])
const props = defineProps({
    required:{
        type:Boolean,
        default: false,
    },
    title: {
        type: String,
        default: '',
    },
    description: {
        type: String,
        default: '',
    },
    options: {
        type: Array,
        default: () => {
            return []
        }
    },
    placeholder: {
        type: String,
        default: '请选择',
    },
})

const modelValue = defineModel('value', {
    type: [String, Number],
    default: null,
})
const getLabelByValue = (val) => {
    if (val !== null && val !== undefined) {
        const option = props.options.find(item => item.value === val)
        return option ? option.label : ''
    }
    return ''
}
const valueLabel = computed(() => getLabelByValue(modelValue.value))
const showPopup = ref(false)

const pickerValue = computed(() => {
    return modelValue.value !== null && modelValue.value !== undefined ? [modelValue.value] : []
})

const onPickerChange = ({value}) => {
    const selectedValue = value[0]
    const selectedOption = props.options.find(item => item.value === selectedValue)
    modelValue.value = selectedValue
    showPopup.value = false
    emits('change', {
        label: selectedOption ? selectedOption.label : '',
        value: selectedValue
    })
}


</script>

<style scoped>
	
</style>