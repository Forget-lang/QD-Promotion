<template>
	<t-popup :visible="show" placement="bottom">
		<view class="m-confirm-title">{{props.title}}</view>
		<view class="m-confirm-content">
			<slot></slot>
		</view>
		<view class="m-row">
			<view class="m-col">
				<t-button type="gray" class="flex-fill" @click="onCancel">{{props.cancelText}}</t-button>
			</view>
			<view class="m-col">
				<t-button class="flex-fill" @click="onConfirm">{{props.confirmText}}</t-button>
			</view>
		</view>
	</t-popup>
</template>

<script setup>
	import { ref } from 'vue'
	const emits = defineEmits(['cancel', 'confirm'])
	const props = defineProps({
		title: {
			type: String
		},
		cancelText: {
			type: String,
			default: '取消'
		},
		confirmText: {
			type: String,
			default: '确定'
		}
	})
	const show = defineModel('show', {
		type: Boolean,
		default: false
	})

	const onCancel = () => {
		show.value = false
		emits('cancel', true)
	}

	const onConfirm = () => {
		show.value.false
		emits('confirm', true)
	}
</script>

<style scoped>
	.m-row {
		display: flex;
		flex-wrap: wrap;
		margin-left: -20rpx;
	}

	.m-col {
		flex-grow: 1;
		font-size: 30rpx;
		display: flex;
		align-items: center;
		margin-left: 20rpx;
	}

	.m-confirm-title {
		text-align: center;
		font-size: 36rpx;
		font-weight: bold;
		margin-bottom: 40rpx;
	}

	.m-confirm-content {
		min-height: 100rpx;
		margin-bottom: 40rpx;
	}
</style>