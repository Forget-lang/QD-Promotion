<template>
	<view class="empty" :style="{height:props.height+'rpx'}">
		<view style="width: 50%;">
			<image style="width:60%" src="@/static/img/empty.png" mode="widthFix" />
			<view class="desc">
				<slot></slot>
			</view>
		</view>
	</view>
</template>

<script setup>
	const props = defineProps({
		height: {
			type: Number,
			default: 500,
		}
	})
</script>

<style scoped>
	.empty {
		text-align: center;
		display: flex;
		align-items: center;
		justify-content: center;
	}

	.empty .desc {
		margin-top: 20rpx;
		color: #ccc;
		font-size: 24rpx;
	}
</style>