<template>
    <view class="card-item-editor">
        <view class="editor-header">
            <text class="editor-title">{{ title }}</text>
            <text class="editor-tip" v-if="tip">{{ tip }}</text>
        </view>

        <view
            v-for="(item, index) in list"
            :key="index"
            class="item-card"
            @click="openEdit(index)"
        >
            <view class="item-sort">{{ index + 1 }}</view>
            <view class="item-body">
                <view class="item-label">{{ formatBenefitLabel(item) }}</view>
                <view class="item-desc text-ellipsis" v-if="item.benefitDescription">{{
                        item.benefitDescription
                    }}
                </view>
                <view class="item-desc item-desc-empty" v-else>未填写优惠说明</view>
            </view>
            <view class="item-remove" @click.stop="removeItem(index)">
                <t-icon name="delete" size="36rpx" color="#e34d59"/>
            </view>
        </view>

        <view class="add-wrap" v-if="list.length < max">
            <t-tag theme="primary" variant="outline" @click="openAdd">添加优惠项（{{ list.length }}/{{ max }}）</t-tag>
        </view>
    </view>

    <t-popup placement="bottom" v-model:visible="popupVisible" :close-on-overlay-click="false" :z-index="10000"
             :overlay-props="{ zIndex: 9999 }">
        <view class="item-popup-container">
            <view class="item-popup-header">
                <view class="item-popup-title">{{ editIndex >= 0 ? '编辑优惠项' : '添加优惠项' }}</view>
                <view class="item-popup-close">
                    <t-icon name="close" size="50rpx" @click="closePopup"/>
                </view>
            </view>
            <scroll-view class="item-popup-body" scroll-y :show-scrollbar="false">
                <t-cell-group theme="card" t-class="mt-2">
                    <m-select
                        title="优惠类型"
                        v-model:value="tempItem.benefitType"
                        :options="benefitTypeOptions"
                        @change="onTypeChange"
                    />
                    <t-input
                        v-if="tempItem.benefitType === BENEFIT_TYPE.AMOUNT"
                        placeholder="优惠金额"
                        type="digit"
                        align="right"
                        v-model:value="tempItem.amountValue"
                        suffix="元"
                    >
                        <template #label>
                            <view class="input-custom-label-required">优惠金额</view>
                        </template>
                    </t-input>
                    <t-input
                        v-if="tempItem.benefitType === BENEFIT_TYPE.DISCOUNT"
                        placeholder="如 8.5 表示 8.5 折"
                        type="digit"
                        align="right"
                        v-model:value="tempItem.discountAmount"
                        suffix="折"
                    >
                        <template #label>
                            <view class="input-custom-label-required">折扣</view>
                        </template>
                    </t-input>
                    <t-input
                        v-if="tempItem.benefitType === BENEFIT_TYPE.SERVICE"
                        placeholder="如：免费洗剪吹一次"
                        align="right"
                        v-model:value="tempItem.serviceName"
                        :maxlength="18"
                        :cursor-spacing="120"
                    >
                        <template #label>
                            <view class="input-custom-label-required">服务内容</view>
                        </template>
                    </t-input>
                    <t-textarea
                        label="优惠说明"
                        placeholder="如：仅限工作日使用"
                        v-model:value="tempItem.benefitDescription"
                        :maxlength="60"
                        :cursor-spacing="120"
                        indicator
                    />
                </t-cell-group>
            </scroll-view>
            <view class="container flex-shrink mt-3 mb-4">
                <t-button theme="primary" size="large" block @click="onSave">保存</t-button>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
import {computed, ref} from 'vue'
import {BENEFIT_TYPE} from '@/constants/card'
import utils from '@/utils/utils'

const props = defineProps({
    title: {type: String, default: '优惠内容'},
    tip: {type: String, default: '按核销顺序依次使用，最多30项'},
    max: {type: Number, default: 30},
    value: {type: Array, default: () => []},
})

const emit = defineEmits(['update:value'])

const benefitTypeOptions = [
    {label: '金额', value: BENEFIT_TYPE.AMOUNT},
    {label: '折扣', value: BENEFIT_TYPE.DISCOUNT},
    {label: '服务', value: BENEFIT_TYPE.SERVICE},
]

const defaultItem = () => ({
    sort: 1,
    benefitType: BENEFIT_TYPE.AMOUNT,
    amountValue: undefined,
    discountAmount: undefined,
    serviceName: '',
    benefitDescription: '',
})

const popupVisible = ref(false)
const editIndex = ref(-1)
const tempItem = ref(defaultItem())

const list = computed(() => props.value || [])

const formatBenefitLabel = (item) => {
    if (!item) return ''
    if (Number(item.benefitType) === BENEFIT_TYPE.AMOUNT) {
        return item.amountValue ? `¥${item.amountValue}` : '金额'
    }
    if (Number(item.benefitType) === BENEFIT_TYPE.DISCOUNT) {
        return item.discountAmount ? `${item.discountAmount}折` : '折扣'
    }
    return item.serviceName || '服务'
}

const syncSort = (items) => {
    items.forEach((item, index) => {
        item.sort = index + 1
    })
}

const cloneItem = (item) => ({
    sort: item.sort,
    benefitType: item.benefitType,
    amountValue: item.amountValue,
    discountAmount: item.discountAmount,
    serviceName: item.serviceName || '',
    benefitDescription: item.benefitDescription || '',
})

const openAdd = () => {
    const current = props.value || []
    if (current.length >= props.max) return
    editIndex.value = -1
    tempItem.value = defaultItem()
    popupVisible.value = true
}

const openEdit = (index) => {
    editIndex.value = index
    tempItem.value = cloneItem((props.value || [])[index])
    popupVisible.value = true
}

const closePopup = () => {
    popupVisible.value = false
}

const onTypeChange = () => {
    tempItem.value.amountValue = undefined
    tempItem.value.discountAmount = undefined
    tempItem.value.serviceName = ''
}

const validateItem = (item) => {
    if (Number(item.benefitType) === BENEFIT_TYPE.AMOUNT) {
        if (!item.amountValue && item.amountValue !== 0) {
            utils.toast('请填写优惠金额')
            return false
        }
    } else if (Number(item.benefitType) === BENEFIT_TYPE.DISCOUNT) {
        if (!item.discountAmount && item.discountAmount !== 0) {
            utils.toast('请填写折扣')
            return false
        }
    } else if (Number(item.benefitType) === BENEFIT_TYPE.SERVICE) {
        if (!item.serviceName?.trim()) {
            utils.toast('请填写服务内容')
            return false
        }
        if (item.serviceName.length > 18) {
            utils.toast('服务内容最多18字')
            return false
        }
    } else {
        utils.toast('请选择优惠类型')
        return false
    }
    if (item.benefitDescription && item.benefitDescription.length > 200) {
        utils.toast('优惠说明最多200字')
        return false
    }
    return true
}

const onSave = () => {
    if (!validateItem(tempItem.value)) return

    const item = cloneItem(tempItem.value)
    const current = props.value || []
    let items
    if (editIndex.value >= 0) {
        items = current.map((row, i) => i === editIndex.value ? item : {...row})
    } else {
        items = [...current, item]
    }
    syncSort(items)
    emit('update:value', items)
    popupVisible.value = false
}

const removeItem = (index) => {
    uni.showModal({
        title: '提示',
        content: '确定删除此优惠项吗？',
        success: (res) => {
            if (!res.confirm) return
            const items = (props.value || []).filter((_, i) => i !== index)
            syncSort(items)
            emit('update:value', items)
        }
    })
}
</script>

<style scoped>
.card-item-editor {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
}

.editor-header {
    margin-bottom: 20rpx;
}

.editor-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
}

.editor-title::before {
    content: '*';
    color: #e34d59;
    margin-right: 4rpx;
}

.editor-tip {
    display: block;
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.item-card {
    display: flex;
    align-items: flex-start;
    margin-bottom: 16rpx;
    padding: 24rpx;
    background: #fafafa;
    border-radius: 12rpx;
}

.item-sort {
    width: 48rpx;
    height: 48rpx;
    line-height: 48rpx;
    text-align: center;
    border-radius: 50%;
    background: #fff3e8;
    color: #e84c59;
    font-size: 24rpx;
    font-weight: 600;
    flex-shrink: 0;
    margin-right: 16rpx;
}

.item-body {
    flex: 1;
    min-width: 0;
}

.item-label {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
}

.item-desc {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.item-desc-empty {
    color: #ccc;
}

.item-remove {
    padding: 8rpx 0 8rpx 12rpx;
    flex-shrink: 0;
}

.add-wrap {
    text-align: center;
    padding: 16rpx 0 8rpx;
}

.item-popup-container {
    border-radius: 24rpx 24rpx 0 0;
    background-color: #f5f5f5;
    overflow: hidden;
}

.item-popup-header {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 32rpx 32rpx 24rpx;
    background-color: #f2f2f2;
    position: relative;
}

.item-popup-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.item-popup-close {
    position: absolute;
    top: 32rpx;
    right: 32rpx;
}

.item-popup-body {
    height: 55vh;
}
</style>
