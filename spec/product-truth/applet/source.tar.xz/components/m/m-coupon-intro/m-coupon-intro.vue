<template>
    <view class="cell-note" v-if="coupon.apptDesc && coupon.isAppt" @click="isShowNote = true">
        <view class="cell-note-label">预约说明</view>
        <view class="cell-note-value">{{ coupon.apptDesc }}</view>
        <t-icon t-class="flex-shrink" name="chevron-right" size="32rpx" color="#999"/>
    </view>
    <view class="cell-note" @click="isShowNote = true">
        <view class="cell-note-label">可用时间</view>
        <view class="cell-note-value">{{ coupon.validLabel }}，{{ coupon.validTimeLabel }}</view>
        <t-icon t-class="flex-shrink" name="chevron-right" size="32rpx" color="#999"/>
    </view>
    <view class="cell-note" v-if="coupon.content" @click="isShowNote = true">
        <view class="cell-note-label">使用须知</view>
        <view class="cell-note-value">{{ coupon.content }}</view>
        <t-icon t-class="flex-shrink" name="chevron-right" size="32rpx" color="#999"/>
    </view>
    <t-popup v-if="coupon" v-model:visible="isShowNote" placement="bottom">
        <view class="popup-header">
            <text class="popup-header-title">使用须知</text>
            <view class="popup-header-close">
                <t-icon name="close" size="24px" @click="isShowNote = false"/>
            </view>
        </view>
        <scroll-view class="popup-body" style="height: 65vh" scroll-y :show-scrollbar="false">
            <view class="container py-3">

                <view class="intro-row">
                    <text class="intro-label">可用时间</text>
                    <text class="intro-value">{{ coupon.validLabel }}，{{ coupon.validTimeLabel }}</text>
                </view>
                <view class="intro-row">
                    <text class="intro-label">使用门槛</text>
                    <text class="intro-value">{{ coupon.threshold }}</text>
                </view>
                <!-- 每人限领 -->
                <view class="intro-row" v-if="coupon.isTotalLimit">
                    <text class="intro-label">领取限制</text>
                    <text class="intro-value">每人限领{{ coupon.totalLimitCount }}张</text>
                </view>
                <view class="intro-row" v-if="coupon.isOnlyNewCustomer">
                    <text class="intro-label">领取对象</text>
                    <text class="intro-value">仅新客户可领</text>
                </view>
                <!-- 已开启每人限领：仅限领多张时展示每天限用，限领 1 张隐藏 -->
                <template v-if="coupon.isTotalLimit">
                    <template v-if="to.Int(coupon.totalLimitCount) > 1">
                        <view class="intro-row" v-if="coupon.isVerifyLimit">
                            <text class="intro-label">使用限制</text>
                            <text class="intro-value">每天限用{{ coupon.verifyLimitCount }}张</text>
                        </view>
                    </template>
                </template>
                <!-- 未开启每人限领：开启核销限制即展示每天限用 -->
                <template v-else>
                    <view class="intro-row" v-if="coupon.isVerifyLimit">
                        <text class="intro-label">使用限制</text>
                        <text class="intro-value">每天限用{{ coupon.verifyLimitCount }}张</text>
                    </view>
                </template>
                <view class="intro-row" v-if="coupon.isVerifyReward">
                    <text class="intro-label">核销奖励</text>
                    <text class="intro-value">到店核销后可再得本券一张</text>
                </view>
                <view class="intro-row" v-if="coupon.isTransfer">
                    <text class="intro-label">支持转赠</text>
                    <text class="intro-value">领后支持转赠送给好友使用</text>
                </view>
                <view class="intro-row" v-if="coupon.isTransfer && coupon.isTransferReward">
                    <text class="intro-label">转赠奖励</text>
                    <text class="intro-value">转赠给好友，且好友到店核销后，可获得转赠奖励</text>
                </view>
                <t-divider v-if="coupon.isAppt || coupon.content" />
                <view class="explain-row" v-if="coupon.isAppt">
                    <view class="explain-label">预约规则：</view>
                    <text class="explain-value">{{ coupon.apptDesc }}</text>
                </view>
                <view class="explain-row" v-if="coupon.content">
                    <view class="explain-label">使用说明：</view>
                    <text class="explain-value">{{coupon.content}}</text>
                </view>
            </view>
        </scroll-view>
        <view class="popup-bottom-cancel" @click="isShowNote = false">关闭</view>
    </t-popup>

</template>

<script setup>
import {ref} from 'vue';
import to from '@/hooks/to'

const props = defineProps({
    coupon: {
        type: Object,
        default: {}
    }
})

const isShowNote = ref(false)

</script>

<style scoped>
.cell-note {
    display: flex;
    align-items: center;
    flex: 1;
    margin: 32rpx;
}

.cell-note-label {
    width: 130rpx;
    font-size: 28rpx;
    color: #78797f;
    margin-right:5rpx;
}

.cell-note-value {
    color: #161722;
    flex: 1;
    overflow: hidden;
    font-style: normal;
    font-size: 28rpx;
    font-weight: normal;
    -webkit-line-clamp: 1;
    text-overflow: ellipsis;
    display: inline-block !important;
    word-break: normal !important;
    white-space: nowrap !important;
}

.intro-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 30rpx;
    font-size: 28rpx;
}

.intro-label {
    flex-shrink: 0;
    width: 140rpx;
    color: #78797f;
}

.intro-value {
    flex: 1;
    text-align: right;
}

.explain-row {
    font-size: 28rpx;
    margin-top: 30rpx;
}

.explain-label {
    margin-bottom: 16rpx;
    color: #78797f;
}
.explain-value{
    line-height: 50rpx;
}

</style>