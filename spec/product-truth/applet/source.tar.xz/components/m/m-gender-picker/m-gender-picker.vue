<template>
	<view>
		<t-cell t-class="mb-16" title="选择性别" :bordered="false" :note="valueLabel || props.placeholder" arrow hover @click="showPopup = true">
		</t-cell>

		<!-- 选择弹窗 -->
		<t-action-sheet v-model:visible="showPopup" description="选择角色" :items="options" @selected="onChange" @cancel="showPopup = false" />
		<!-- 选择则弹框 -->
	</view>
</template>

<script setup>
	import { ref, computed, onMounted } from 'vue'
	
	const props = defineProps({
		placeholder:{
			type:String,
			default:'请选择性别',
		}
	})

	const value = defineModel('value', {
		type: String,
		default:''
	})
	const showPopup = ref(false)

	const options = ref([{label:'男',value:'男'},{label:'女',value:'女'}])

	const valueLabel = computed(() => {
		if (value.value) {
			const option = options.value.find(item => item.value === value.value)
			return option ? option.label : ''
		}
		return ''
	})

	const onChange = (e) => {
		value.value = e.selected.value
		showPopup.value = false
	}
</script>

<style scoped>
</style>