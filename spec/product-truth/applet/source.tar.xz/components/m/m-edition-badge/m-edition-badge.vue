<template>
    <view v-if="label" class="m-edition-badge">
        <view class="icon-vip"/>
        <view class="edition-badge" :class="badgeClass">{{ label }}</view>
    </view>
</template>

<script setup>
import {computed} from 'vue'
import {EDITION_BADGE_CLASS, EDITION_NAMES} from '@/constants/edition'

const props = defineProps({
    // EDITION_FEATURES 中的功能配置（优先取 requiredEdition）
    feature: {type: Object, default: null},
    // 直接指定版本 ID
    editionId: {type: [String, Number], default: null},
})

const resolvedId = computed(() => {
    if (props.feature?.requiredEdition != null) {
        return String(props.feature.requiredEdition)
    }
    if (props.editionId != null && props.editionId !== '') {
        return String(props.editionId)
    }
    return ''
})

const label = computed(() => EDITION_NAMES[resolvedId.value] || '')
const badgeClass = computed(() => EDITION_BADGE_CLASS[resolvedId.value] || '')
</script>

<style scoped>
.m-edition-badge {
    display: inline-flex;
    flex-direction: row;
    align-items: center;
    flex-shrink: 0;
}

.m-edition-badge .edition-badge {
    margin-left: 8rpx;
}
</style>
