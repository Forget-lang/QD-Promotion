<template>
    <view class="bundle-coupon-editor">
        <view class="editor-header">
            <view>
                <text class="editor-title">
                    <text class="required" v-if="required">*</text>
                    {{ title }}
                </text>
                <text class="editor-tip" v-if="tip">{{ tip }}</text>
                <view v-if="description" class="editor-tip">{{ description }}</view>
            </view>
        </view>

        <view
            v-for="(item, index) in list"
            :key="item.couponId"
            class="item-card"
        >
            <view class="item-sort">{{ index + 1 }}</view>
            <view class="item-body">
                <view class="item-label">{{ item.couponName }}</view>
                <view class="item-desc">
                    <text class="meta-tag">{{ item.couponTypeLabel || getCouponTypeLabel(item.couponType) }}</text>
                    <text class="meta-text">每包 {{ item.issueCount }} 张</text>
                </view>
            </view>
            <view class="item-remove" @click.stop="onRemove(index)">
                <t-icon name="delete" size="36rpx" color="#e34d59"/>
            </view>
        </view>

        <view class="add-wrap" v-if="list.length < max">
            <t-tag theme="primary" variant="outline" @click="openAdd">
                添加优惠券（{{ list.length }}/{{ max }}）
            </t-tag>
        </view>
        <view v-else class="add-wrap text-muted text-small">已达上限 {{ max }} 种</view>
    </view>

    <!-- 外层：添加优惠券（选择器入口 + 张数） -->
    <t-popup
        placement="bottom"
        v-model:visible="popupVisible"
        :close-on-overlay-click="false"
        :z-index="10000"
        :overlay-props="{ zIndex: 9999 }"
    >
        <view class="item-popup-container">
            <view class="item-popup-header">
                <view class="item-popup-title">添加优惠券</view>
                <view class="item-popup-close">
                    <t-icon name="close" size="50rpx" @click="closePopup"/>
                </view>
            </view>
            <scroll-view class="item-popup-body" scroll-y :show-scrollbar="false">
                <t-cell-group theme="card" t-class="mt-2">
                    <t-cell
                        title="优惠券"
                        required
                        arrow
                        hover
                        :note="tempCoupon?.name || '请选择'"
                        @click="openCouponPicker"
                    />
                    <t-cell title="发放张数" :description="`领取时该券发放张数，${issueCountRangeText}`"
                            :bordered="false">
                        <template #note>
                            <t-stepper
                                v-model:value="tempIssueCount"
                                :min="BUNDLE_COUPON_LIMIT.MIN_ISSUE_COUNT_PER_TYPE"
                                :max="BUNDLE_COUPON_LIMIT.MAX_ISSUE_COUNT_PER_TYPE"
                                :default-value="BUNDLE_COUPON_LIMIT.MIN_ISSUE_COUNT_PER_TYPE"
                            />
                        </template>
                    </t-cell>
                </t-cell-group>
            </scroll-view>
            <view class="container flex-shrink mt-2 mb-3">
                <t-button theme="primary" size="large" block @click="onConfirm">确定</t-button>
            </view>
        </view>
    </t-popup>

    <!-- 内层：优惠券选择器 -->
    <t-popup
        placement="bottom"
        v-model:visible="pickerVisible"
        :close-on-overlay-click="false"
        :z-index="11000"
        :overlay-props="{ zIndex: 10999 }"
    >
        <view class="popup-container pb-3">
            <view class="popup-header">
                <view class="popup-header-cancel" @click="closeCouponPicker">取消</view>
                <view class="popup-header-title">请选择优惠券</view>
                <view class="popup-header-confirm" @click="onPickerConfirm">确定</view>
            </view>
            <view class="popup-search-bar">
                <view class="input-search">
                    <t-input
                        :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                        placeholder="搜索优惠券名称"
                        v-model:value="searchName"
                        borderless
                        @clear="onSearchClear"
                        @enter="onSearch"
                    />
                    <view class="input-search-actions">
                        <t-button theme="default" variant="text" icon="search" @click="onSearch"></t-button>
                    </view>
                </view>
            </view>
            <view class="container">
                <view class="section mt-2">
                    <scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
                        <t-radio-group
                            v-if="availableCoupons.length > 0"
                            v-model:value="pickerCouponId"
                            @change="onPickerRadioChange"
                        >
                            <t-radio
                                v-for="item in availableCoupons"
                                :key="item.id"
                                :value="item.id"
                                placement="right"
                            >
                                <template #label>
                                    <view class="checkbox-label">
                                        <view class="checkbox-name">{{ item.name }}</view>
                                        <view class="checkbox-extra">
                                            <text>{{ getCouponTypeLabel(item.couponType) }}</text>
                                            <text>剩余：{{ item.remainStock }}</text>
                                        </view>
                                    </view>
                                </template>
                            </t-radio>
                        </t-radio-group>
                        <m-empty v-else>
                            <view>{{ couponList.length ? '可选的「券包」优惠券已全部添加完' : '您还没有创建「券包」优惠券' }}</view>
                            <!-- 没有可选「券包」优惠券时引导创建 -->
                            <view class="d-flex flex-column align-items-center justify-content-center mt-5">
                                <t-button theme="primary" size="small" @click="push('/pages_coupon/coupon/choose_type')">创建优惠券</t-button>
                                <view class="d-flex align-items-center justify-content-center text-wechat mt-2" @tap="onRefresh">
                                    <t-loading v-if="refreshing" theme="circular" size="18px" inherit-color custom-style="margin-right: 4rpx;"/>
                                    <text>{{ refreshing ? '刷新中...' : '刷新列表' }}</text>
                                </view>
                            </view>
                        </m-empty>
                    </scroll-view>
                </view>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
import {computed, ref} from 'vue'
import {BUNDLE_COUPON_LIMIT} from '@/constants/bundle.js'
import request from '@/hooks/request.js'
import utils from '@/utils/utils.js'
import {useLink} from '@/hooks/useLink.js'

const {push} = useLink()

const props = defineProps({
    gateway: {
        type: String,
        default: '/seller/bundle/coupon/list',
    },
    title: {
        type: String,
        default: '券包内容',
    },
    description: {
        type: String,
        default: '',
    },
    tip: {
        type: String,
        default: '',
    },
    required: {
        type: Boolean,
        default: false,
    },
    max: {
        type: Number,
        default: BUNDLE_COUPON_LIMIT.MAX_TYPE_COUNT,
    },
    // 添加前置拦截（异步函数，返回 false 不打开选择器），用于版本档位检测
    beforeAdd: {
        type: Function,
        default: null,
    },
})

const modelValue = defineModel('value', {
    type: Array,
    default: () => [],
})

const popupVisible = ref(false)
const pickerVisible = ref(false)
const couponList = ref([])
const searchName = ref('')
const tempCoupon = ref(null)
const tempIssueCount = ref(1)
const pickerCouponId = ref('')
// 刷新列表加载中（点击「刷新列表」时置位，getCoupons 完成后复位）
const refreshing = ref(false)

const list = computed(() => modelValue.value || [])

const issueCountRangeText = computed(() => {
    const {MIN_ISSUE_COUNT_PER_TYPE, MAX_ISSUE_COUNT_PER_TYPE} = BUNDLE_COUPON_LIMIT
    return `${MIN_ISSUE_COUNT_PER_TYPE}～${MAX_ISSUE_COUNT_PER_TYPE}`
})

const selectedIdSet = computed(() => {
    const set = new Set()
    list.value.forEach((item) => {
        if (item?.couponId != null) {
            set.add(String(item.couponId))
        }
    })
    return set
})

const availableCoupons = computed(() => {
    return (couponList.value || []).filter((item) => !selectedIdSet.value.has(String(item.id)))
})

const getCouponTypeLabel = (type) => {
    const typeMap = {
        1: '代金券',
        2: '套餐券',
        3: '满减券',
        4: '折扣券',
        5: '兑换券',
        6: '手气券',
    }
    return typeMap[type] || '未知类型'
}

// 手动刷新优惠券列表（带加载状态）
const onRefresh = () => {
    if (refreshing.value) return
    refreshing.value = true
    getCoupons()
}

// 加载优惠券列表（打开选择器 / 搜索 / 清空 / 手动刷新共用）
const getCoupons = (name = '') => {
    const params = {}
    if (name) {
        params.name = name
    }
    return request.get(props.gateway, params).then((res) => {
        couponList.value = res.data.items || []
    }).finally(() => {
        setTimeout(() => {
            refreshing.value = false
        }, 800)
    })
}

const openAdd = async () => {
    if (list.value.length >= props.max) {
        utils.toast(`最多添加${props.max}种优惠券`)
        return
    }
    // 版本档位拦截：beforeAdd 返回 false 时不打开选择器
    if (props.beforeAdd && !(await props.beforeAdd())) return
    tempCoupon.value = null
    tempIssueCount.value = 1
    popupVisible.value = true
}

const closePopup = () => {
    popupVisible.value = false
}

const openCouponPicker = () => {
    searchName.value = ''
    pickerCouponId.value = tempCoupon.value ? String(tempCoupon.value.id) : ''
    pickerVisible.value = true
    getCoupons()
}

const closeCouponPicker = () => {
    pickerVisible.value = false
}

const onSearch = () => {
    getCoupons((searchName.value || '').trim())
}

const onSearchClear = () => {
    searchName.value = ''
    getCoupons()
}

const applyPickedCoupon = (id) => {
    const coupon = availableCoupons.value.find((item) => String(item.id) === String(id))
    if (!coupon) return
    tempCoupon.value = coupon
    pickerCouponId.value = String(coupon.id)
    pickerVisible.value = false
}

const onPickerRadioChange = (e) => {
    applyPickedCoupon(e?.value ?? e)
}

const onPickerConfirm = () => {
    if (!pickerCouponId.value) {
        utils.toast('请选择优惠券')
        return
    }
    applyPickedCoupon(pickerCouponId.value)
}

const onConfirm = () => {
    if (!tempCoupon.value) {
        utils.toast('请选择优惠券')
        return
    }
    const count = Number(tempIssueCount.value) || 0
    const {MIN_ISSUE_COUNT_PER_TYPE, MAX_ISSUE_COUNT_PER_TYPE} = BUNDLE_COUPON_LIMIT
    if (count < MIN_ISSUE_COUNT_PER_TYPE || count > MAX_ISSUE_COUNT_PER_TYPE) {
        utils.toast(`包内张数须为${MIN_ISSUE_COUNT_PER_TYPE}～${MAX_ISSUE_COUNT_PER_TYPE}`)
        return
    }
    if (selectedIdSet.value.has(String(tempCoupon.value.id))) {
        utils.toast('该优惠券已添加')
        return
    }
    if (list.value.length >= props.max) {
        utils.toast(`最多添加${props.max}种优惠券`)
        return
    }
    const coupon = tempCoupon.value
    modelValue.value = [
        ...list.value,
        {
            couponId: coupon.id,
            couponName: coupon.name,
            couponType: coupon.couponType,
            couponTypeLabel: getCouponTypeLabel(coupon.couponType),
            issueCount: count,
            remainStock: coupon.remainStock,
        },
    ]
    popupVisible.value = false
}

const onRemove = (index) => {
    uni.showModal({
        title: '提示',
        content: '确定删除此优惠券吗？',
        success: (res) => {
            if (!res.confirm) return
            const next = [...list.value]
            next.splice(index, 1)
            modelValue.value = next
        },
    })
}
</script>

<style scoped>
.bundle-coupon-editor {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx 32rpx;
}

.editor-header {
    margin-bottom: 20rpx;
}

.editor-title {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
}

.required {
    color: #e34d59;
    margin-right: 4rpx;
}

.editor-tip {
    display: block;
    margin-top: 8rpx;
    font-size: 24rpx;
    line-height: 1.5;
    color: #999;
}

.item-card {
    display: flex;
    align-items: flex-start;
    margin-bottom: 16rpx;
    padding: 24rpx;
    background: #fafafa;
    border-radius: 12rpx;
}

.item-sort {
    width: 48rpx;
    height: 48rpx;
    line-height: 48rpx;
    text-align: center;
    border-radius: 50%;
    background: #fff3e8;
    color: #e84c59;
    font-size: 24rpx;
    font-weight: 600;
    flex-shrink: 0;
    margin-right: 16rpx;
}

.item-body {
    flex: 1;
    min-width: 0;
}

.item-label {
    font-size: 30rpx;
    font-weight: 600;
    color: #333;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.item-desc {
    margin-top: 8rpx;
    display: flex;
    align-items: center;
    gap: 12rpx;
}

.meta-tag {
    display: inline-block;
    font-size: 22rpx;
    padding: 2rpx 12rpx;
    border-radius: 4rpx;
    background: #e8f5e9;
    color: #2e7d32;
    line-height: 1.6;
}

.meta-text {
    font-size: 24rpx;
    color: #999;
}

.item-remove {
    padding: 8rpx 0 8rpx 12rpx;
    flex-shrink: 0;
}

.add-wrap {
    text-align: center;
    padding: 16rpx 0 8rpx;
}

.item-popup-container {
    border-radius: 24rpx 24rpx 0 0;
    background-color: #f5f5f5;
    overflow: hidden;
}

.item-popup-header {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 32rpx 32rpx 24rpx;
    background-color: #f2f2f2;
    position: relative;
}

.item-popup-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.item-popup-close {
    position: absolute;
    top: 32rpx;
    right: 32rpx;
}

.item-popup-body {
    height: 55vh;
}

.popup-search-bar {
    padding: 16rpx 24rpx 0;
}

.checkbox-label {
    display: flex;
    flex-direction: column;
    gap: 8rpx;
}

.checkbox-name {
    font-size: 28rpx;
    color: #333;
}

.checkbox-extra {
    display: flex;
    gap: 20rpx;
    font-size: 24rpx;
    color: #999;
}
</style>
