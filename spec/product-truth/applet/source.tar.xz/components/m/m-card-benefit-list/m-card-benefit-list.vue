<template>
    <view class="benefit-wrapper">
        <!-- 次卡权益项内容 -->
        <scroll-view
            class="benefit-scroll"
            scroll-x
            :show-scrollbar="false"
            :scroll-with-animation="true"
            :scroll-into-view="scrollToId"
        >
            <view class="benefit-list">
                <view
                    class="benefit-card"
                    :class="getBenefitStatus(item)"
                    v-for="(item, index) in items"
                    :key="index"
                    :id="'card-' + index"
                    :style="{ '--theme-color': themeColor, 'animation-delay': (index * 50) + 'ms' }"
                >
                    <!-- 主题色顶部区域 -->
                    <view class="benefit-head">
                        <view class="benefit-head-left">
                            <t-icon v-if="item.isVerified" name="check" size="40rpx" color="#fff" style="font-weight: bold;" />
                            <t-icon v-else-if="item.isDiscarded" name="close" size="40rpx" color="#fff"
                                    style="font-weight: bold;"/>
                            <text v-else class="benefit-index">{{ padSort(item.sort ?? (index + 1)) }}</text>
                            <text class="benefit-tag">权益项</text>
                        </view>
                        <!-- 装饰圆形 -->
                        <view class="deco-circle"></view>
                    </view>

                    <!-- 内容区域 -->
                    <view class="benefit-body">
                        <text class="benefit-title">{{ getBenefitLabel(item) }}</text>
                        <view class="benefit-divider"></view>
                        <text class="benefit-desc">{{ item.benefitDescription || '暂无说明' }}</text>
                    </view>

                    <!-- 底部状态栏（仅详情页显示，私密领取页隐藏） -->
                    <view v-if="showStatus" class="benefit-status-bar" :class="getBenefitStatus(item)" @click.stop="onShowDetail(item)">
                        <text class="status-text">
                            <template v-if="item.isCurrent">当前可使用</template>
                            <template v-else-if="item.isVerified">已核销</template>
                            <template v-else-if="item.isDiscarded">已作废</template>
                            <template v-else>待使用</template>
                        </text>
                        <view v-if="item.isVerified || item.isDiscarded" class="status-more">
                            <t-icon name="chevron-right" size="32rpx" :color="themeColor" />
                        </view>
                    </view>
                </view>
            </view>
        </scroll-view>

        <!-- 核销/作废详情抽屉 -->
        <t-popup placement="bottom" v-model:visible="showDetail">
            <view class="popup-container">
                <view class="popup-header">
                    <text class="popup-header-title">{{ detailTitle }}</text>
                    <view class="popup-header-close" @click="showDetail = false">
                        <t-icon name="close" size="40rpx" color="#999"/>
                    </view>
                </view>
                <view class="popup-body" v-if="currentItem">
                    <t-cell-group theme="card">
                        <t-cell title="优惠内容" :note="getBenefitLabel(currentItem)"></t-cell>
                        <t-cell :title="detailStoreTitle" :note="currentItem.verifyStoreName || '-'"></t-cell>
                        <t-cell :title="detailStaffTitle" :note="currentItem.verifyStaffName || '-'"></t-cell>
                        <t-cell :title="detailRemarkTitle" :note="currentItem.verifyRemark || '-'"></t-cell>
                        <t-cell :title="detailTimeTitle" :note="currentItem.verifiedAt || '-'"></t-cell>
                    </t-cell-group>
                </view>
            </view>
        </t-popup>
    </view>
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import { BENEFIT_TYPE } from '@/constants/card'
import { getTheme } from '@/utils/theme'

const props = defineProps({
    // 权益项列表
    items: {
        type: Array,
        default: () => []
    },
    // 主题（1-6）
    theme: {
        type: [Number, String],
        default: 1
    },
    // 是否显示底部状态栏（默认 true：详情页显示；私密领取页传 false 隐藏）
    showStatus: {
        type: Boolean,
        default: true
    }
})

// 主题色
const themeColor = computed(() => {
    return getTheme(Number(props.theme) || 1).color
})

// 滚动到当前可使用项
const scrollToId = ref('')

// 核销/作废详情抽屉
const showDetail = ref(false)
const currentItem = ref(null)

const isDiscardDetail = computed(() => !!currentItem.value?.isDiscarded)

const detailTitle = computed(() => (isDiscardDetail.value ? '作废详情' : '核销详情'))
const detailStoreTitle = computed(() => (isDiscardDetail.value ? '作废门店' : '核销门店'))
const detailStaffTitle = computed(() => (isDiscardDetail.value ? '作废员工' : '核销员工'))
const detailRemarkTitle = computed(() => (isDiscardDetail.value ? '作废原因' : '核销备注'))
const detailTimeTitle = computed(() => (isDiscardDetail.value ? '作废时间' : '核销时间'))

// 打开详情抽屉（已核销 / 已作废）
const onShowDetail = (item) => {
    if (item.isVerified || item.isDiscarded) {
        currentItem.value = item
        showDetail.value = true
    }
}

// 权益项状态：使用后端返回字段判断
const getBenefitStatus = (item) => {
    if (item.isVerified) return 'verified'
    if (item.isDiscarded) return 'discarded'
    if (item.isCurrent) return 'current'
    return 'default'
}

// 格式化排序号（01, 02, 03...）
const padSort = (num) => {
    return String(num ?? 0).padStart(2, '0')
}

// 获取权益名称
const getBenefitLabel = (item) => {
    if (!item) return ''
    if (item.benefitLabel) return item.benefitLabel
    if (Number(item.benefitType) === BENEFIT_TYPE.AMOUNT) {
        return item.amountValue ? `¥${item.amountValue}` : '金额'
    }
    if (Number(item.benefitType) === BENEFIT_TYPE.DISCOUNT) {
        return item.discountAmount ? `${item.discountAmount}折` : '折扣'
    }
    return item.serviceName || '权益'
}

// 查找当前可使用的索引
const findCurrentIndex = () => {
    if (!props.items?.length) return -1
    return props.items.findIndex(item => item.isCurrent)
}

// 监听数据变化，自动滚动到当前可使用位置
// 注意：仅当 currentIndex > 0 时才滚动，避免第一个元素被遮挡
watch(() => props.items, (newItems) => {
    const currentIndex = findCurrentIndex()
    if (newItems?.length > 0 && currentIndex > 0 && currentIndex < newItems.length) {
        // 延迟执行确保 DOM 渲染完成
        setTimeout(() => {
            // 滚动到前一个元素，让当前可用项显示在偏中间/靠右的视野内，避免左侧贴边被遮挡
            scrollToId.value = 'card-' + (currentIndex - 1)
        }, 300)
    }
}, { immediate: true })

onMounted(() => {
    const currentIndex = findCurrentIndex()
    // 组件挂载后也尝试滚动（仅当不是第一个时）
    if (props.items?.length > 0 && currentIndex > 0) {
        setTimeout(() => {
            // 滚动到前一个元素，避免当前项左侧被遮挡
            scrollToId.value = 'card-' + (currentIndex - 1)
        }, 300)
    }
})
</script>

<style scoped>
.benefit-wrapper {
    width: 100%;
}

/* ===== 次卡内容横向滑动卡片 ===== */
.benefit-scroll {
    width: 100%;
    white-space: nowrap;
    box-sizing: border-box;
}

.benefit-list {
    display: inline-flex;
    gap: 20rpx;
}

.benefit-card {
    width: 248rpx;
    border-radius: 20rpx;
    background: #fff;
    overflow: hidden;
    flex-shrink: 0;
    display: inline-flex;
    flex-direction: column;
    position: relative;
    transition: transform 300ms ease-out, opacity 300ms ease-out, box-shadow 300ms ease-out;
}

/* 卡片入场动画 */
@keyframes cardSlideIn {
    from {
        opacity: 0.3;
        transform: translateX(30rpx);
    }
    to {
        opacity: 1;
        transform: translateX(0);
    }
}

/* 当前高亮状态 */
.benefit-card.current {
    z-index: 10;
    animation: cardSlideIn 400ms ease-out forwards;
}

/* 已核销 / 已作废：降低整体透明度 */
.benefit-card.verified,
.benefit-card.discarded {
    opacity: 0.7;
    animation: cardSlideIn 350ms ease-out backwards;
}

/* 待使用状态卡片动画 */
.benefit-card.default {
    animation: cardSlideIn 300ms ease-out backwards;
}

/* 卡片顶部主题色区域 */
.benefit-head {
    background: var(--theme-color);
    padding: 20rpx 18rpx;
    position: relative;
    overflow: hidden;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.benefit-head-left {
    display: flex;
    align-items: center;
    gap: 8rpx;
    position: relative;
    z-index: 1;
}

.benefit-index {
    font-size: 36rpx;
    font-weight: 800;
    color: #fff;
}

.benefit-tag {
    display: inline-block;
    font-size: 18rpx;
    color: rgba(255, 255, 255, 0.9);
    background: rgba(255, 255, 255, 0.2);
    padding: 4rpx 14rpx;
    border-radius: 14rpx;
    backdrop-filter: blur(4rpx);
}

/* 装饰圆形光晕 */
.deco-circle {
    position: absolute;
    right: -24rpx;
    top: -24rpx;
    width: 90rpx;
    height: 90rpx;
    background: rgba(255, 255, 255, 0.1);
    border-radius: 50%;
}

/* 卡片内容区域 - 纵向布局 */
.benefit-body {
    padding: 18rpx;
    display: flex;
    flex-direction: column;
}

/* ===== 底部状态栏（主题色深浅区分版） ===== */
.benefit-status-bar {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 18rpx 20rpx;
    position: relative;
    margin-top: auto;
    border-radius: 0 0 20rpx 20rpx;
}

.status-text {
    font-size: 24rpx;
    font-weight: 600;
    letter-spacing: 1rpx;
    position: relative;
    z-index: 1;
}

/* ========== 当前可使用：最深主题色背景 + 最亮文字 ========== */
.benefit-status-bar.current::before {
    content: '';
    position: absolute;
    left: 0; top: 0; right: 0; bottom: 0;
    background: var(--theme-color);
    opacity: 0.15;
    z-index: 0;
}

.benefit-status-bar.current .status-text {
    color: var(--theme-color);
    font-weight: 700;
    font-size: 25rpx;
}

/* ========== 已核销 / 已作废：最淡主题色背景 + 暗淡文字 ========== */
.benefit-status-bar.verified::before,
.benefit-status-bar.discarded::before {
    content: '';
    position: absolute;
    left: 0; top: 0; right: 0; bottom: 0;
    background: var(--theme-color);
    opacity: 0.06;
    z-index: 0;
}

.benefit-status-bar.verified .status-text,
.benefit-status-bar.discarded .status-text {
    color: var(--theme-color);
    opacity: 0.4;
}

/* ========== 待使用：浅主题色背景 + 中等亮度文字 ========== */
.benefit-status-bar.default::before {
    content: '';
    position: absolute;
    left: 0; top: 0; right: 0; bottom: 0;
    background: var(--theme-color);
    opacity: 0.08;
    z-index: 0;
}

.benefit-status-bar.default .status-text {
    color: var(--theme-color);
    opacity: 0.5;
}

.benefit-title {
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    overflow: hidden;
    text-overflow: ellipsis;
    line-height: 1.4;
}

.benefit-divider {
    width: 40rpx;
    height: 4rpx;
    background: linear-gradient(90deg, var(--theme-color), transparent);
    margin: 12rpx 0;
    border-radius: 2rpx;
    flex-shrink: 0;
}

.benefit-desc {
    font-size: 22rpx;
    color: #999;
    line-height: 1.6;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    overflow: hidden;
    text-overflow: ellipsis;
}

/* ===== 已核销/已作废状态栏：更多图标 ===== */
.status-more {
    position: absolute;
    right: 14rpx;
    top: 50%;
    transform: translateY(-50%);
    z-index: 2;
    display: flex;
    align-items: center;
    opacity: 0.5;
}

.benefit-status-bar.verified .status-more,
.benefit-status-bar.discarded .status-more {
    position: static;
    transform: none;
    margin-left: 4rpx;
    opacity: 0.4;
}
</style>
