<template>
    <t-upload
        :media-type="props.mediaType"
        v-model:files="files"
        :max="props.max"
        :size-limit="{ size: props.maxSize, unit: 'MB', message: '图片大小不超过'+props.maxSize+' MB' }"
        :grid-config="props.gridConfig"
        :request-method="uploadFile"
        @success="onUploadSuccess"
        @remove="onUploadRemove"
    ></t-upload>
</template>

<script setup>
import utils from '@/utils/utils';
import config from '@/config.js'
import {useSessionStore} from '@/stores/session';

const session = useSessionStore()

const emits = defineEmits(['change'])
const props = defineProps({
    max: {
        type: Number,
        default: 1,
    },
    mediaType: {
        type: Array,
        default: () => {
            return ['image']
        }
    },
    gridConfig: {
        type: Object,
        default: () => {
            return {column: 4, width: 160, height: 160}
        }
    },
    maxSize: {
        type: Number,
        default: 5, //MB
    }
})
const files = defineModel('value', {
    type: Array,
    default: () => {
        return []
    }
})

const onUploadSuccess = ({files}) => {
    emits('change', files)
}

const onUploadRemove = ({index}) => {
    files.value.splice(index, 1);
    emits('change', files)
}

// 自定义上传到服务器（request-method 接收文件数组）
const uploadFile = (files) => {
    const tasks = files.map(file => {
        return new Promise((resolve, reject) => {
            const timestamp = utils.getUnixTime()
            const sign = utils.signParam({}, config.appSecret, timestamp)
            uni.uploadFile({
                url: config.apiUrl + '/user/object/upload?sign=' + sign + '&timestamp=' + timestamp,
                filePath: file.url,
                name: 'file',
                header: {
                    'Authorization': session.token,
                    'App-Name': 'applet',
                    'Version': config.version,
                },
                success: (res) => {
                    console.log(res)
                    let result
                    try {
                        result = JSON.parse(res.data)
                    } catch (e) {
                        utils.toast('上传响应异常')
                        reject(e)
                        return
                    }
                    if (result.code === 0) {
                        file.url = result.data.url
                        resolve({status: 'success', response: {url: result.data.url}})
                    } else {
                        utils.toast(result.message)
                        reject(result.message)
                    }
                },
                fail: (err) => {
                    console.log(err)
                    utils.toast('图片上传失败：' + err.errMsg)
                    reject(err)
                }
            })
        })
    })
    return Promise.all(tasks)
}
</script>

<style scoped>

</style>