<template>
	<!-- 
    mode="region" 是微信小程序原生支持的省市区选择模式
    :value 绑定选中索引，实现回显
    @change 处理选择结果
  -->
  <!-- picker 包裹整个 t-cell，保证点击 cell 任意位置都能唤起地区选择 -->
  <picker class="area-picker" mode="region" :value="innerValue" @change="onChange">
    <t-cell hover arrow>
        <template v-slot:title>
            <span class="flex-shrink">选择地区</span>
        </template>
        <template #note>
            <slot>
                <!-- 默认插槽：如果不传内容，显示默认样式 -->
                <view class="area-picker-default">
                    <view class="area-picker-placeholder" v-if="displayText === ''">{{placeholder}}</view>
                    <view v-else class="text-black">{{ displayText}}</view>
                </view>
            </slot>
        </template>
    </t-cell>
  </picker>
	
</template>

<script setup>
	import {
		ref,
		computed
	} from 'vue';

	// 1. 接收 props
	const props = defineProps({
		placeholder: {
			type: String,
			default: '请选择省市区'
		}
	});

	// 2. 定义 emit
	const emit = defineEmits(['change']);

	const area = defineModel('value')

	// 3. 计算属性：用于显示文本
	const displayText = computed(() => {
		if (area.value && area.value.length === 3) {
			return area.value.join(' ');
		}
		return '';
	});

	// 4. 计算属性：用于绑定 picker 的 value (实现回显)
	// 微信小程序 picker mode="region" 的 value 需要是 [省索引, 市索引, 区索引]
	// 但原生组件比较智能，如果传入 ['广东省', '广州市', '天河区'] 也能自动匹配，
	// 为了保险，我们直接透传 modelValue
	// 使用 defineModel('value') 返回的 area ref，确保回显时 picker 能定位到已选地区
	const innerValue = computed(() => area.value);

	// 5. 处理选择变化
	const onChange = (e) => {
		area.value = e.detail.value; // 微信原生返回的是 [省, 市, 区] 字符串数组

		// 同时触发 change 事件，方便父组件做其他操作
		emit('change', area.value);
	};
</script>

<style scoped>
	/* picker 默认 inline 布局，需撑满整行才能保证整行可点击 */
	.area-picker {
		display: block;
	}
	.area-picker-default{
		display: flex;
		justify-content: space-between;
		align-items: center;
	}
	.area-picker-placeholder {
		color: rgba(0, 0, 0, 0.4);
	}
</style>