<template>
	<view>
		<t-input :label="props.label" v-model:value="smsCode" placeholder="请输入验证码" type="digit" :disabled="props.disabled" :maxlength="6"
			:required="props.required">
			<template #extra>
				<t-count-down size="small" v-if="isCountDown" :auto-start="true" format="ss秒" :time="60000" @finish="onCountDownFinish" />
				<t-button theme="danger" v-else :maxcharacter="10" :disabled="props.disabled" size="extra-small" @click="showCaptcha">发送</t-button>
			</template>
		</t-input>
		<m-captcha ref="captchaRef" @success="onCaptchaSuccess" @fail="onCaptchaFail" />
	</view>
</template>

<script setup>
	import { ref, watch } from 'vue'
	import utils from '@/utils/utils.js'
	import request from '@/hooks/request'

	const props = defineProps({
		gateway: {
			type: String,
			default: '/seller/sms/send'
		},
		label: {
			type: String,
			default: () => {
				return ''
			}
		},
		disabled: {
			type: Boolean,
			default: () => {
				return false
			}
		},
		required: {
			type: Boolean,
			default: () => {
				return false
			}
        },
        // 发给当前超管等服务端自取号码的场景，不校验前端手机号
        requireMobile: {
            type: Boolean,
            default: true
		}
	})
	const mobile = defineModel('mobile', {
		type: [String, Number],
		default: () => {
			return null
		}
	})
	const smsCode = defineModel('value', {
		type: [String, Number],
		default: () => {
			return null
		}
	})
	const loading = ref(false)
	const isCountDown = ref(false)

	const captchaRef = ref(null)
	const captchaToken = ref('')

	// 监听 mobile 字段变化
	watch(() => mobile.value, (newMobile, oldMobile) => {
		if (newMobile !== oldMobile) {
			// 当手机号码变化时，重置验证码状态
			isCountDown.value = false
			captchaToken.value = ''
		}
	})

	// 当倒计时结束时
	const onCountDownFinish = () => {
		isCountDown.value = false
		reset()
	}

	const showCaptcha = () => {
        if (props.requireMobile && !mobile.value) {
			utils.toast('请输入手机号')
			return
		}
		captchaRef.value?.show()
	}

	// 验证通过回调函数
	const onCaptchaSuccess = (result) => {
		captchaToken.value = result.token
		onSendVcode()
	}
	// 验证不通过回调函数
	const onCaptchaFail = () => {
		captchaToken.value = ''
	}

	const onSendVcode = () => {
        const params = {
            captchaToken: captchaToken.value,
            captchaVerifyParam: captchaToken.value,
        }
        if (mobile.value) {
            params.mobile = mobile.value
        }
		request.post(props.gateway, params).then(res => {
			isCountDown.value = true
			utils.toast('验证码发送成功')
		}).catch(err => {
			captchaToken.value = ''
		})
	}


</script>

<style scoped>

</style>