<template>
	<t-cell title="所在行业" arrow hover @click="visible = true">
        <template #note>
            <text class="text-black lh-24" v-if="modelLabel">{{modelLabel}}</text>
            <text class="lh-24" v-else>{{placeholder}}</text>
        </template>
    </t-cell>
	<t-cascader :keys="{ label: 'name', value: 'id'}" v-model:visible="visible" :value="selectedId" :options="options" title="请选择行业" @change="onChange" />
</template>

<script setup>
import { ref, computed, watch, onMounted } from 'vue'
import request from '@/hooks/request.js'

const emit = defineEmits(['change'])
const props = defineProps({
    placeholder: {
        type: String,
        default: '请选择',
    },
})

const modelValue = defineModel('value')
const visible = ref(false);
const options = ref([])
// 已选行业的叶子节点 ID（用于级联选择器回显定位）
const selectedId = ref(null)

// 已选行业的显示文本
const modelLabel = computed(() => {
	if (!modelValue.value || modelValue.value.length === 0) return ''
	return modelValue.value.join(' / ')
})

// 根据名称路径在树中查找对应的叶子节点 ID
const resolveNamePathToId = (namePath, tree) => {
	if (!namePath || namePath.length === 0 || !tree || tree.length === 0) return null
	let currentLevel = tree
	for (let i = 0; i < namePath.length; i++) {
		const name = namePath[i]
		const found = currentLevel.find(item => item.name === name)
		if (!found) return null
		if (i === namePath.length - 1) return found.id
		currentLevel = found.children || []
	}
	return null
}

// 同步 selectedId，确保级联选择器能定位到已选行业
watch([modelValue, options], () => {
	if (modelValue.value && modelValue.value.length > 0 && options.value.length > 0) {
		selectedId.value = resolveNamePathToId(modelValue.value, options.value)
	} else {
		selectedId.value = null
	}
}, { immediate: true })

const onChange = (e) => {
	const { selectedOptions } = e
	modelValue.value = selectedOptions.map((item) => item.name)
	visible.value = false;
}

const getTree = () => {
	request.get('/industry/tree').then((res) => {
		options.value = res.data.tree
	})
}

onMounted(() => {
	getTree()
})
</script>
