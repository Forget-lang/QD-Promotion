<template>
    <view class="container">
        <template v-for="(item, k) in stores" :key="k">
            <view class="media mb-3">
                <view class="media-header">
                    <image class="store-cover" :src="item.logo" mode="aspectFill"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="store-name-warp">
                            <t-tag v-if="k === 0 && item.distance > 0" theme="warning" size="small"
                                   :custom-style="{ padding: '0 8rpx', height: '32rpx', lineHeight: '32rpx' }">
                                最近
                            </t-tag>
                            <text class="store-name">{{ item.name }}</text>
                        </view>
                        <view class="store-open-hours">
                            <t-tag v-if="item.isOpen || item.isAlwaysOpen" variant="light" theme="success" size="small"
                                   :custom-style="{ padding: '0 8rpx', height: '32rpx', lineHeight: '32rpx' }">
                                营业中
                            </t-tag>
                            <t-tag v-else variant="light" theme="default" size="small"
                                   :custom-style="{ padding: '0 8rpx', height: '32rpx', lineHeight: '32rpx' }">
                                已打烊
                            </t-tag>
                            <text v-if="item.isAlwaysOpen" class="store-hours">全天营业</text>
                            <text v-else class="store-hours" v-for="(time, j) in item.openHour"
                                  :key="j">{{ time.startTime }}~{{ time.endTime }}
                            </text>
                        </view>
                        <view class="store-address-wrap">
                            <text class="address-text">
                                <text v-if="item.distance > 0">
                                    距你{{ (item.distance / 1000).toFixed(1) }}km ·
                                </text>
                                <text>{{ item.address }}</text>
                            </text>
                        </view>
                    </view>
                    <view class="media-action flex-gap-2 justify-content-center">
                        <view class="store-action-btn" @click.stop="openLocation(item)">
                            <image src="https://cdn.lenmy.com/quandao/2026/07/25/d9i7gtdb4ekd482ulmgg.png"
                                   style="width:36rpx" mode="widthFix"/>
                        </view>
                        <view class="store-action-btn" @click.stop="utils.makePhoneCall(item.servicePhone)">
                            <image src="https://cdn.lenmy.com/quandao/2026/07/25/d9i7hntb4ekd482ulmh0.png"
                                   style="width:36rpx" mode="widthFix"/>

                        </view>
                    </view>
                </view>
            </view>
        </template>
    </view>
</template>

<script setup>
// 可用门店列表组件
import utils from '@/utils/utils'

const props = defineProps({
    stores: {
        type: Array,
        default: () => []
    }
})

const openLocation = (store) => {
    if (store.lat > 0 && store.lng > 0) {
        wx.openLocation({
            latitude: store.lat, // 纬度，范围为-90~90，负数表示南纬
            longitude: store.lng, // 经度，范围为-180~180，负数表示西经
            scale: 8, // 缩放比例
            name: store.name,
            address: store.address,
            success: function (r) {
            },
            fail: function (e) {
                uni.showToast({
                    icon: 'none',
                    title: e
                })
            }
        })
    } else {
        uni.showToast({
            icon: 'none',
            title: '尚未设置门店地图位置，无法导航'
        })
    }
}

</script>

<style scoped>

.store-cover {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    background: #f5f5f5;
}

.store-name-warp {
    display: flex;
    align-items: center;
    gap: 10rpx;
}

.store-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #1e1e1e;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.store-open-hours {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    margin-top: 8rpx;
    gap: 10rpx;
}

.store-hours {
    font-size: 24rpx;
    color: #333;
}

.store-address-wrap {
    display: flex;
    align-items: center;
    margin-top: 8rpx;
    gap: 10rpx;
}

.address-text {
    font-size: 24rpx;
    color: #333;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    overflow: hidden;
}

.store-action-btn {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.store-action-text {
    font-size: 20rpx;
    color: #181818;
    margin-top: 5rpx;
}

</style>
