<template>
    <view>
        <!-- 已选时间段列表 -->
        <t-cell-group>
            <t-cell v-for="(item, index) in modelValue" :key="index" :bordered="index < modelValue.length - 1">
                <template #title>
                    <text class="time-text">{{ item.startTime }} - {{ item.endTime }} </text>
                </template>
                <template #note>
                    <t-tag theme="danger" variant="outline" @click="removeItem(index)">删除 </t-tag>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- 添加按钮 -->
        <view class="d-flex justify-content-center p-2" v-if="modelValue.length < max" @click="openPicker">
            <t-tag theme="success" variant="outline">添加时间段</t-tag>
        </view>

        <!-- 达到上限提示 -->
        <view v-else class="max-hint">
            <text>已达最大时间段限制 ({{ max }}个)</text>
        </view>

        <!-- 底部弹窗：选择时间范围 -->
        <t-popup v-model:visible="showPopup" placement="bottom">
            <view class="popup-header">
                <text class="popup-header-cancel" @click="showPopup = false">取消</text>
                <text class="popup-header-title">设置时间段</text>
                <text class="popup-header-confirm" @click="onConfirm">确定</text>
            </view>
            <view class="popup-body bg-gray">
                <t-cell-group t-class="mt-2" theme="card">
                    <t-cell title="开始时间" :note="tempSlot.startTime" arrow @click="startDateVisible = true"></t-cell>
                    <t-cell title="结束时间" :note="tempSlot.endTime" arrow @click="endDateVisible = true"></t-cell>
                </t-cell-group>
            </view>
        </t-popup>
    </view>
    <!-- 年月日 -->
    <t-date-time-picker v-model:visible="startDateVisible" auto-close v-model:value="tempSlot.startTime" title="选择时间段" :start="dayjs().startOf('day').format('YYYY-MM-DD HH:mm')" :mode="['null', 'minute']" format="HH:mm" :popup-props="{ zIndex: 50000, overlayProps: { zIndex: 11501 } }" @change="onConfirmStartTime" />
    <t-date-time-picker v-model:visible="endDateVisible" auto-close v-model:value="tempSlot.endTime" title="选择时间段" :start="dayjs().startOf('day').format('YYYY-MM-DD HH:mm')" :mode="['null', 'minute']" format="HH:mm" :popup-props="{ zIndex: 50000, overlayProps: { zIndex: 11501 } }" @change="onConfirmEndTime" />
</template>

<script setup>
import dayjs from "dayjs";
import { ref } from "vue";

const startDateVisible = ref(false);
const endDateVisible = ref(false);

const props = defineProps({
    // 最大时间段数量，默认为 3
    max: {
        type: Number,
        default: 3,
    },
});

// 使用 defineModel 实现双向绑定
const modelValue = defineModel("value", {
    type: Array,
    default: () => [],
});

// 内部状态
const showPopup = ref(false);

// 临时存储正在编辑的时间段
const tempSlot = ref({
    startTime: "09:00",
    endTime: "22:00",
});

// 删除时间段
const removeItem = (index) => {
    const newList = [...modelValue.value];
    newList.splice(index, 1);
    modelValue.value = newList;
};

// 打开弹窗
const openPicker = () => {
    tempSlot.value = {
        startTime: "09:00",
        endTime: "22:00",
    };
    showPopup.value = true;
};

const onConfirmStartTime = (e) => {
    tempSlot.value.startTime = e.value;
};

const onConfirmEndTime = (e) => {
    tempSlot.value.endTime = e.value;
};

// 确认添加
const onConfirm = () => {
    // 校验：结束时间必须晚于开始时间
    if (tempSlot.value.startTime >= tempSlot.value.endTime) {
        uni.showToast({
            title: "结束时间必须晚于开始时间",
            icon: "none",
        });
        return;
    }

    // 添加到列表（创建新数组以触发响应式更新）
    modelValue.value = [...modelValue.value, tempSlot.value];

    // 关闭弹窗
    showPopup.value = false;
};
</script>

<style scoped>
/* 达到上限的提示文本 */
.max-hint {
    text-align: center;
    padding: 16px 0;
    color: #999;
    font-size: 14px;
}
</style>
