<template>
    <view class="t-loading-container">
        <t-loading :t-class="props.size" theme="circular" size="40rpx" :text="props.text"></t-loading>
    </view>
</template>

<script setup>
const props = defineProps({
    size: {
        type: String,
        default: () => 'medium'
    },
    text: {
        type: String,
        default: () => '加载中...'
    }
})
</script>

<style scoped>
.t-loading-container {
    display: flex;
    align-items: center;
    justify-content: center;
    color: #000;
    height: 260rpx;
}
</style>