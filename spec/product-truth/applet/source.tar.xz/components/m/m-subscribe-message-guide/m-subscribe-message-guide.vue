<template>
    <t-popup v-model:visible="visible" placement="bottom">
        <view class="subscr-containter">
            <view class="subscr-header">
                <view class="close-icon" @tap="visible = false">
                    <t-icon name="close" size="46rpx" color="#828282"></t-icon>
                </view>
                <view class="tip-body">
                    <t-icon name="info-circle-filled" color="#E6483F" size="28rpx"></t-icon>
                    <text class="font-size-12 ml-1">检测到你未开启「消息提醒」</text>
                </view>
                <view class="h3 mt-2">将无法提醒你一些重要消息通知</view>
            </view>
            <view class="subscr-step">
                <view class="h5">开启通知教程</view>
                <view class="d-flex flex-column mt-2">
                    <view class="d-flex align-items-center">
                        <view class="step-index">1</view>
                        <text class="text-muted ml-1">点击【通知管理】或【订阅消息】</text>
                    </view>
                    <image class="step-image mt-2"
                           src="https://cdn.lenmy.com/quandao/2026/06/14/d8nccatb4ek3godrad0g.jpg"
                           mode="widthFix"/>
                </view>
                <view class="d-flex flex-column mt-2">
                    <view class="d-flex align-items-center">
                        <view class="step-index">2</view>
                        <text class="text-muted ml-1">将通知均调整为【接收】</text>
                    </view>
                    <image class="step-image mt-2"
                           src="https://cdn.lenmy.com/quandao/2026/06/14/d8nccitb4ek3godrad10.jpg"
                           mode="widthFix"/>
                </view>
                <view class="subscribe-bottom-action">
                    <view class="subscribe-bottom-item">
                        <t-button block custom-style="height: 92rpx;font-size: 28rpx; border-radius: 12rpx; color: #1a1a1a;" @click="onCancel">暂不订阅</t-button>
                    </view>
                    <view class="subscribe-bottom-item">
                        <t-button block theme="primary" custom-style="height: 92rpx; font-size: 28rpx; border-radius: 12rpx;" @click="onOpenSetting">去允许通知</t-button>
                    </view>
                </view>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
const emit = defineEmits(['cancel'])
const visible = defineModel('visible', {
    type: Boolean,
    default: false
})

// 去设置页开启订阅消息
const onOpenSetting = () => {
    uni.openSetting({
        withSubscriptions: true,
        complete() {
            visible.value = false
        }
    })
}

// 暂不订阅
const onCancel = () => {
    visible.value = false
    emit('cancel')
}
</script>

<style scoped>
.subscr-header {
    position: relative;
    background-color: #FFF4E7;
    padding: 40rpx 40rpx 30rpx;
}

.close-icon {
    position: absolute;
    top: 30rpx;
    right: 30rpx;
    width: 50rpx;
    height: 50rpx;
    display: flex;
    align-items: center;
    justify-content: center;

}

.tip-body {
    display: flex;
    align-items: center;
    color: #BA6A5F;
}

.subscr-step {
    padding: 40rpx;
}

.step-index {
    background-color: #03a456;
    color: #ffffff;
    font-size: 24rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32rpx;
    height: 32rpx;
    border-radius: 16rpx;
}

.step-image {
    width: 400rpx;
    height: auto;
    margin: 20rpx auto 0;
}

.subscribe-bottom-action {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 90rpx;
    gap: 20rpx;
}

.subscribe-bottom-item {
    width: 226rpx;
}
</style>