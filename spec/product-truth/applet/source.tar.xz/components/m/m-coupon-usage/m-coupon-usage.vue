<template>
    <view class="section mt-2 pb-3 " v-if="coupon.isCombo || coupon.productImages.length > 0">
        <view class="section-header">
            <view class="section-title" v-if="coupon.isCombo">套餐组合</view>
            <view class="section-title" v-else-if="coupon.productImages.length > 0">详情</view>
        </view>
        <view class="container">
            <!-- 套餐组合详情 -->
            <view class="usage-groups" v-if="coupon.isCombo && coupon.combos.length > 0">
                <view class="usage-group" v-for="(group, j) in coupon.combos" :key="j">
                    <view class="group-header">
                        <text class="group-name">{{ group.name }}</text>
                        <text class="group-rule">{{ group.selectRule }}</text>
                    </view>
                    <view class="group-products">
                        <view class="product-row" v-for="(product, k) in group.products" :key="k">
                            <text class="product-name">· {{ product.name }} x{{ product.quantity }}{{ product.unit }}</text>
                            <text class="product-price">¥{{ product.price }}</text>
                        </view>
                    </view>
                </view>
            </view>
            <view class="usage-images" v-if="coupon.productImages.length > 0">
                <image :src="coupon.productImages[0]" mode="widthFix" class="image full" />
            </view>
        </view>
    </view>

    <view class="section mt-2 pb-3">
        <view class="section-header">
            <view class="section-title">使用须知</view>
        </view>
        <view class="container pt-1">
            <!-- 使用须知 -->
            <view class="intro-row">
                <text class="intro-label">可用时间</text>
                <text class="intro-value">{{ coupon.validLabel }}，{{ coupon.validTimeLabel }}</text>
            </view>
            <view class="intro-row">
                <text class="intro-label">使用门槛</text>
                <text class="intro-value">{{ coupon.threshold }}</text>
            </view>
            <!-- 每人限领 -->
            <view class="intro-row" v-if="coupon.isTotalLimit">
                <text class="intro-label">领取限制</text>
                <text class="intro-value">每人限领{{ coupon.totalLimitCount }}张</text>
            </view>
            <view class="intro-row" v-if="coupon.isOnlyNewCustomer">
                <text class="intro-label">领取对象</text>
                <text class="intro-value">仅新客户可领</text>
            </view>
            <!-- 已开启每人限领：仅限领多张时展示每天限用，限领 1 张隐藏 -->
            <template v-if="coupon.isTotalLimit">
                <template v-if="to.Int(coupon.totalLimitCount) > 1">
                    <view class="intro-row" v-if="coupon.isVerifyLimit">
                        <text class="intro-label">使用限制</text>
                        <text class="intro-value">每天限用{{ coupon.verifyLimitCount }}张</text>
                    </view>
                </template>
            </template>
            <!-- 未开启每人限领：开启核销限制即展示每天限用 -->
            <template v-else>
                <view class="intro-row" v-if="coupon.isVerifyLimit">
                    <text class="intro-label">使用限制</text>
                    <text class="intro-value">每天限用{{ coupon.verifyLimitCount }}张</text>
                </view>
            </template>
            <view class="intro-row" v-if="coupon.isVerifyReward">
                <text class="intro-label">核销奖励</text>
                <text class="intro-value">到店核销后，可获得核销奖励</text>
            </view>
            <view class="intro-row" v-if="coupon.isTransfer">
                <text class="intro-label">支持转赠</text>
                <text class="intro-value">领后支持转赠送给好友使用</text>
            </view>
            <view class="intro-row" v-if="coupon.isTransfer && coupon.isTransferReward">
                <text class="intro-label">转赠奖励</text>
                <text class="intro-value">转赠给好友，且好友到店核销后，可获得转赠奖励</text>
            </view>
            <t-divider v-if="coupon.isAppt || coupon.content" />
            <view class="explain-row" v-if="coupon.isAppt">
                <view class="explain-label">预约规则：</view>
                <text class="explain-value">{{ coupon.apptDesc }}</text>
            </view>
            <view class="explain-row" v-if="coupon.content">
                <view class="explain-label">使用说明：</view>
                <text class="explain-value">{{coupon.content}}</text>
            </view>
        </view>
    </view>

</template>

<script setup>
import to from '@/hooks/to'

const props = defineProps({
    coupon: {
        type: Object,
        default: {}
    }
})
</script>

<style scoped>

.usage-title {
    font-size: 30rpx;
    margin-bottom: 32rpx;
}

.usage-groups {
    margin-bottom: 24rpx;
}

.usage-group {
    margin-bottom: 32rpx;
}

.usage-group:last-child {
    margin-bottom: 0;
}

.group-header {
    display: flex;
    align-items: center;
    gap: 15rpx;
    margin-bottom: 16rpx;
    font-size: 28rpx;
    color: #8e8e8e;
}

.product-row {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 12rpx 0;
    font-size: 28rpx;
}

.usage-images {
    border-radius: 20rpx;
    overflow: hidden;
}

.intro-row {
    display: flex;
    justify-content: space-between;
    align-items: flex-start;
    margin-bottom: 30rpx;
    font-size: 28rpx;
}

.intro-label {
    flex-shrink: 0;
    width: 140rpx;
    color: #78797f;
}

.intro-value {
    flex: 1;
    text-align: right;
}

.explain-row {
    font-size: 28rpx;
    margin-top: 30rpx;
}

.explain-label {
    margin-bottom: 16rpx;
    color: #78797f;
}
.explain-value{
    line-height: 50rpx;
}

</style>
