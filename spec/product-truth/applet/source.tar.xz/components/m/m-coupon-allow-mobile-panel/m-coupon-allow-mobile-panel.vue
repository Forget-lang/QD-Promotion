<template>
    <t-popup placement="bottom" :visible="visible" :round="true" @visible-change="onVisibleChange">
        <view class="allow-mobile-popup">
            <view class="popup-header">
                <view class="popup-header-title">可领取手机号</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="50rpx" @click="close"/>
                </view>
            </view>

            <view class="panel-body">
                <view class="panel-tip text-muted text-small">
                    仅输入的手机号可领取此券。每行一个手机号，最多{{ ALLOW_MOBILE_MAX }}个。
                </view>
                <view class="textarea-wrap">
                    <t-textarea
                        v-model:value="draftText"
                        placeholder="每行一个手机号"
                        :maxlength="-1"
                        :disable-default-padding="true"
                        :custom-style="textareaStyle"
                    />
                </view>
            </view>

            <view class="panel-footer">
                <view class="panel-footer-tip">
                    <t-icon name="file-copy" size="28rpx" color="var(--td-brand-color)"/>
                    <text class="panel-footer-tip-text">可批量复制粘贴</text>
                </view>
                <view class="panel-footer-actions">
                    <t-button class="panel-footer-btn" theme="primary" variant="text" size="small"
                              custom-style="background-color: transparent;" @click="onConfirm">确定
                    </t-button>
                    <t-button class="panel-footer-btn" theme="default" variant="text" size="small"
                              custom-style="background-color: transparent;" @click="onClear">清空
                    </t-button>
                </view>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
import {ref, watch} from 'vue'
import utils from '@/utils/utils'

const props = defineProps({
    visible: {type: Boolean, default: false},
    modelValue: {type: Array, default: () => []},
})

const emit = defineEmits(['update:visible', 'update:modelValue'])

const textareaStyle = 'height: 100%; min-height: 100%; box-sizing: border-box; padding: 24rpx 32rpx; font-size: 28rpx; line-height: 1.6; background: #F5F5F5;'

const draftText = ref('')

const ALLOW_MOBILE_MAX = 500

const MOBILE_RE = /^1\d{10}$/

const validateAndParseMobiles = (text) => {
    const lines = String(text || '').split(/\r?\n/)
    const seen = new Set()
    const mobiles = []
    for (let i = 0; i < lines.length; i++) {
        const lineNo = i + 1
        const line = lines[i].trim()
        if (!line) continue
        if (/[\s,，;；|]/.test(line)) {
            return {error: `第 ${lineNo} 行只能填写一个手机号`}
        }
        if (!MOBILE_RE.test(line)) {
            return {error: `第 ${lineNo} 行手机号格式不正确`}
        }
        if (seen.has(line)) continue
        seen.add(line)
        mobiles.push(line)
    }
    if (mobiles.length === 0) {
        return {error: '请输入手机号'}
    }
    if (mobiles.length > ALLOW_MOBILE_MAX) {
        return {error: `最多录入 ${ALLOW_MOBILE_MAX} 个手机号`}
    }
    return {mobiles}
}

const close = () => {
    emit('update:visible', false)
}

const onVisibleChange = (e) => {
    emit('update:visible', e.visible)
}

const onConfirm = () => {
    const result = validateAndParseMobiles(draftText.value)
    if (result.error) {
        utils.toast(result.error)
        return
    }
    emit('update:modelValue', result.mobiles)
    close()
}

const onClear = () => {
    draftText.value = ''
}

watch(() => props.visible, (val) => {
    if (val) {
        draftText.value = (props.modelValue || []).join('\n')
    }
})
</script>

<style scoped>
.allow-mobile-popup {
    display: flex;
    flex-direction: column;
    height: 80vh;
    max-height: 80vh;
    background: #fff;
    border-radius: 24rpx 24rpx 0 0;
    overflow: hidden;
    padding-bottom: calc(30rpx + env(safe-area-inset-bottom));
}

.panel-body {
    flex: 1;
    min-height: 0;
    display: flex;
    flex-direction: column;
    overflow: hidden;
    padding: 0 32rpx;
}

.panel-tip {
    flex-shrink: 0;
    margin-bottom: 20rpx;
}

.textarea-wrap {
    flex: 1;
    min-height: 0;
    background: #F5F5F5;
    overflow: hidden;
    box-sizing: border-box;
    /* 左右留白：不写 width:100%，交给 flex 交叉轴 stretch 自动扣除 margin，避免整体右溢出 */
    margin-bottom: 32rpx;
    border-radius: 8rpx;
}

.panel-footer {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16rpx 32rpx 8rpx;
    background-color: #FFFFFF;
    border-top: 1rpx solid #F0F0F0;
}

.panel-footer-tip {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 16rpx;
}

.panel-footer-tip-text {
    font-size: 24rpx;
    color: #666;
    margin-left: 8rpx;
}

.panel-footer-actions {
    display: flex;
    align-items: center;
    flex-shrink: 0;
}

.panel-footer-btn {
    margin-left: 24rpx;
}
</style>
