<template>
    <view>
        <m-loading v-if="items === undefined"></m-loading>
        <template v-else-if="theme === 2">
            <view v-if="items.length" class="position-list">
                <view
                    v-for="(item, index) in items"
                    :key="item.url || index"
                    class="position-card section"
                    @tap="utils.openPosition(item)"
                >
                    <view class="position-cover-wrap">
                        <image
                            v-if="item.thumb"
                            class="position-cover"
                            :src="item.thumb"
                            mode="aspectFill"
                        />
                        <view v-if="splitTags(item.tag).length" class="position-tags">
                            <view
                                v-for="(tag, tagIndex) in splitTags(item.tag)"
                                :key="tagIndex"
                                class="position-tag"
                            >{{ tag }}
                            </view>
                        </view>
                    </view>
                    <view class="position-body">
                        <view v-if="item.title || typeIcon(item.recommendType)" class="position-title-row">
                            <image
                                v-if="typeIcon(item.recommendType)"
                                class="position-type-icon"
                                :src="typeIcon(item.recommendType)"
                                mode="aspectFit"
                            />
                            <view v-if="item.title" class="position-title">{{ item.title }}</view>
                        </view>
                        <view v-if="item.description" class="position-desc">{{ item.description }}</view>
                    </view>
                </view>
            </view>
        </template>
        <template v-else>
            <view
                v-for="(item, index) in items"
                :key="index"
                class="section section-body mt-2"
            >
                <view class="media">
                    <view class="media-header">
                        <t-image :src="item.thumb" mode="aspectFill" width="36" height="36"/>
                    </view>
                    <view class="media-body">
                        <view class="media-content">
                            <view class="media-title">{{ item.title }}</view>
                            <view class="media-desc">{{ item.description }}</view>
                        </view>
                        <view class="media-action">
                            <view class="button-gold" @click="utils.openPosition(item)">预览</view>
                        </view>
                    </view>
                </view>
            </view>
        </template>
    </view>
</template>

<script setup>
import {ref, watch} from 'vue'
import request from '@/hooks/request.js'
import to from '@/hooks/to.js'
import utils from '@/utils/utils'
import {RECOMMEND_TYPE} from '@/constants/common.js'

const props = defineProps({
    // 推荐位 ID（/position 的 id）
    id: {
        type: [Number, String],
        default: '',
    },
    // 排版：1 独立卡片（默认） / 2 上下图文列表（无推荐位标题）
    theme: {
        type: Number,
        default: 1,
    },
})

// undefined 加载中 / [] 空 / 有数据
const items = ref()

const TYPE_ICON = {
    [RECOMMEND_TYPE.VIDEO_CHANNEL]: '/static/img/channel.png',
    [RECOMMEND_TYPE.OFFICIAL_ACCOUNT]: '/static/img/wechat.png',
    [RECOMMEND_TYPE.MINI_PROGRAM_PAGE]: '/static/img/weapp.png',
}

const typeIcon = (recommendType) => TYPE_ICON[recommendType] || ''

// 标签字段支持英文逗号、中文逗号分隔
const splitTags = (tag) => {
    const raw = String(tag || '').trim()
    if (!raw) return []
    return raw.split(/[,，]/).map((s) => s.trim()).filter(Boolean)
}

const getItems = () => {
    if (!props.id) {
        items.value = []
        return
    }
    items.value = undefined
    request.get('/position', {id: props.id}, {showLoading: false}).then((res) => {
        items.value = to.Array(res.data?.items)
    }).catch(() => {
        items.value = []
    })
}

watch(() => props.id, () => {
    getItems()
}, {immediate: true})
</script>

<style scoped>
.position-list {
    display: flex;
    flex-direction: column;
    gap: 24rpx;
}

.position-card {
    overflow: hidden;
    padding: 0;
}

.position-cover-wrap {
    position: relative;
    width: 100%;
    height: 360rpx;
    background: #f5f5f5;
}

.position-cover {
    display: block;
    width: 100%;
    height: 100%;
}

.position-tags {
    position: absolute;
    left: 20rpx;
    right: 20rpx;
    bottom: 20rpx;
    display: flex;
    flex-wrap: wrap;
    gap: 12rpx;
    z-index: 1;
}

.position-tag {
    padding: 8rpx 18rpx;
    border-radius: 8rpx;
    background: rgba(0, 0, 0, 0.62);
    color: #fff;
    font-size: 24rpx;
    font-weight: 600;
    line-height: 1.3;
}

.position-body {
    padding: 28rpx 32rpx 32rpx;
}

.position-title-row {
    display: flex;
    align-items: center;
    gap: 12rpx;
}

.position-type-icon {
    flex-shrink: 0;
    width: 40rpx;
    height: 40rpx;
}

.position-title {
    flex: 1;
    min-width: 0;
    font-size: 32rpx;
    font-weight: 600;
    color: #1a1a1a;
    line-height: 1.4;
}

.position-desc {
    margin-top: 12rpx;
    font-size: 26rpx;
    color: #888;
    line-height: 1.55;
}
</style>
