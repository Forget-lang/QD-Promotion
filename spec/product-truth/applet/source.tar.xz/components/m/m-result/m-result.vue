<template>
    <view class="result-container">
        <view class="result-body">
            <template v-if="showIcon">
                <t-icon v-if="props.type === 'success'" name="check-circle-filled" color="#07c160" :size="60"></t-icon>
                <t-icon v-if="props.type === 'info'" name="info-circle-filled" color="#368df1" :size="60"></t-icon>
                <t-icon v-if="props.type === 'danger'" name="info-circle-filled" color="#fa5151" :size="60"></t-icon>
            </template>
            <view v-if="props.title !== ''" class="result-title">{{ props.title }}</view>
            <view v-if="props.description !== ''" class="result-desc">{{ props.description }}</view>
            <slot></slot>
            <view class="result-action">
                <view style="width: 312rpx;" v-if="back">
                    <t-button block @click="onBack">返回</t-button>
                </view>
                <template v-else>
                    <view style="width: 312rpx;" v-if="props.confirmText !== ''">
                        <t-button theme="primary" block @click="onConfirm">{{ props.confirmText }}</t-button>
                    </view>
                    <view class="mt-3" style="width: 312rpx;" v-if="props.cancelText !== ''">
                        <text class="text-wechat" @click="onCancel">{{ props.cancelText }}</text>
                    </view>
                </template>
                <slot name="actions"></slot>
                <text v-if="props.tip !== ''" class="text-muted mt-3">{{ props.tip }}</text>
            </view>
        </view>
    </view>
</template>

<script setup>
import {computed, ref, onMounted} from 'vue'

const emits = defineEmits(['confirm', 'cancel'])
const props = defineProps({
    showIcon: {
        type: Boolean,
        default: true,
    },
    title: {
        type: String,
        default: '',
    },
    description: {
        type: String,
        default: () => {
            return ''
        }
    },
    tip: {
        type: String,
        default: () => {
            return ''
        }
    },
    type: { //'info' | 'success' | 'warning' | 'danger'
        type: String,
        default: () => {
            return 'success'
        }
    },
    confirmText: {
        type: String,
        default: '',
    },
    cancelText: {
        type: String,
        default: '',
    },
    back: {
        type: Boolean,
        default: false
    }
})

const name = computed(() => {
    if (props.type === 'success') {
        return 'success'
    } else if (props.type === 'error') {
        return 'close-fill'
    } else if (props.type === 'info') {
        return 'info-filled'
    } else if (props.type === 'warning') {
        return 'warning'
    }
})

const color = computed(() => {
    if (props.type === 'success') {
        return uni.$tui.color.primary
    } else if (props.type === 'error') {
        return uni.$tui.color.danger
    } else if (props.type === 'info') {
        return uni.$tui.color.blue
    } else if (props.type === 'warning') {
        return uni.$tui.color.warning
    }
})

const onConfirm = () => {
    emits('confirm')
}

const onCancel = () => {
    emits('cancel')
}

const onBack = () => {
    uni.navigateBack()
}
</script>

<style scoped>
.result-container {
    position: relative;
    text-align: center;
}

.result-body {
    padding: 108rpx 40rpx 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.result-title {
    color: #191919;
    font-size: 38rpx;
    font-weight: bold;
    margin-top: 60rpx;
}

.result-desc {
    color: #666;
    font-size: 28rpx;
    margin-top: 30rpx;
}

.result-action {
    margin-top: 200rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    padding: 0 40rpx 160rpx;
}
</style>