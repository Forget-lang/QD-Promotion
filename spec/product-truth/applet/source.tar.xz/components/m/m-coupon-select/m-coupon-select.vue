<template>
	<view>
        <t-cell :required="props.required" :title="props.title" :description="description" :bordered="false" arrow hover
                @click="onOpen">
			<template #note>
				<text class="text-black lh-24" v-if="valueLabel">{{valueLabel}}</text>
				<text class="lh-24" v-else>{{placeholder}}</text>
			</template>
		</t-cell>

		<!-- 选择弹框 -->
		<t-popup v-model:visible="showPopup" placement="bottom">
            <view class="popup-container pb-3">
                <view class="popup-header">
                    <view class="popup-header-cancel" @click="onCancel">取消</view>
                    <view class="popup-header-title">请选择优惠券</view>
                    <view class="popup-header-confirm" @click="onConfirm">确定</view>
                </view>
                <view class="popup-search-bar">
                    <view class="input-search">
                        <t-input
                            :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                            placeholder="搜索优惠券名称"
                            v-model:value="searchName"
                            borderless
                            @clear="onSearchClear"
                            @enter="onSearch"
                        />
                        <view class="input-search-actions">
                            <t-button theme="default" variant="text" icon="search" @click="onSearch"></t-button>
                        </view>
                    </view>
                </view>
                <view class="container">
                    <view class="section mt-2" v-if="tip">
                        <view class="section-header bottom-line">
                            <view class="h3">
                                {{ tip }}
                            </view>
                        </view>
                        <scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
                            <!-- 单选模式 -->
                            <t-radio-group v-model:value="tempRadioValue" v-if="couponList.length > 0"
                                           @change="onRadioChange">
                                <t-radio v-for="(item,index) in couponList" :key="index" :value="item.id"
                                         :label="item.name" placement="right"/>
                            </t-radio-group>
                            <m-empty v-else>
                                <view>暂无优惠券</view>
                                <!-- 没有优惠券时引导创建 -->
                                <view class="d-flex flex-column align-items-center justify-content-center mt-5">
                                    <t-button theme="primary" size="small" @click="push('/pages_coupon/coupon/choose_type')">创建优惠券</t-button>
                                    <view class="d-flex align-items-center justify-content-center text-wechat mt-2" @tap="onRefresh">
                                        <t-loading v-if="refreshing" theme="circular" size="18px" inherit-color custom-style="margin-right: 4rpx;"/>
                                        <text>{{ refreshing ? '刷新中...' : '刷新列表' }}</text>
                                    </view>
                                </view>
                            </m-empty>
                        </scroll-view>
                    </view>
                </view>
            </view>
		</t-popup>
	</view>
</template>

<script setup>
	import { ref, computed, onMounted } from 'vue'
	import request from "@/hooks/request.js"
	import { useLink } from '@/hooks/useLink.js'

	// 页面跳转（引导创建优惠券）
	const { push } = useLink()

	const props = defineProps({
		gateway: {
			type: String,
            default: '/seller/coupon/private/list'
		},
		title: {
			type: String,
			default: '优惠券'
		},
        description: {
            type: String,
        },
        tip: {
            type: String,
            default: ''
        },
		placeholder: {
			type: String,
			default: '请选择优惠券'
		},
		required: {
			type: Boolean,
			default: false
		}
	})

	const emit = defineEmits(['labelChange'])

	const modelValue = defineModel('value', {
		type: String,
		default: ''
	})
	const showPopup = ref(false)
	const tempRadioValue = ref('')
    const searchName = ref('')

	const couponList = ref([])

	// 刷新列表加载中（点击「刷新列表」时置位，getItems 完成后复位）
	const refreshing = ref(false)

	const valueLabel = computed(() => {
		if (modelValue.value) {
			const coupon = couponList.value.find(item => String(item.id) === String(modelValue.value))
			return coupon ? coupon.name : ''
		}
		return ''
	})

    // 手动刷新优惠券列表（带加载状态）
    const onRefresh = () => {
        if (refreshing.value) return
        refreshing.value = true
        getItems()
    }

    // 加载优惠券列表（打开弹框 / 搜索 / 清空 / 手动刷新共用）
    const getItems = (name = '') => {
        const params = {}
        if (name) {
            params.name = name
        }
        return request.get(props.gateway, params).then(res => {
            couponList.value = res.data.items || []
        }).finally(() => {
            setTimeout(() => {
                refreshing.value = false
            }, 800)
        })
    }

    const onSearch = () => {
        getItems((searchName.value || '').trim())
    }

    const onSearchClear = () => {
        searchName.value = ''
        getItems()
    }

	// 打开弹框，将当前值复制到临时值
	const onOpen = () => {
		tempRadioValue.value = typeof modelValue.value === 'string' ? modelValue.value : ''
        searchName.value = ''
		showPopup.value = true
        getItems()
	}

	// 单选变更时直接确认关闭
	const onRadioChange = (e) => {
		tempRadioValue.value = e.value
		modelValue.value = e.value
		showPopup.value = false
		const item = couponList.value.find(s => String(s.id) === String(e.value))
		emit('labelChange', item ? item.name : '')
	}

	// 取消：关闭弹框，不保存
	const onCancel = () => {
		showPopup.value = false
	}

	// 确定：将临时值同步到modelValue
	const onConfirm = () => {
		modelValue.value = tempRadioValue.value || ''
		showPopup.value = false
		emit('labelChange', valueLabel.value)
	}

    defineExpose({
        onOpen
    })

	onMounted(() => {
		getItems()
	})
</script>

<style scoped>
.popup-search-bar {
    padding: 16rpx 24rpx 0;
}

.coupon-select-tip {
    padding: 16rpx 24rpx 0;
    font-size: 24rpx;
    line-height: 1.5;
    color: #999;
}

	.popup-footer-count {
		font-size: 28rpx;
		color: #999;
	}

	.popup-footer-right {
		display: flex;
		align-items: center;
		gap: 20rpx;
	}
</style>
