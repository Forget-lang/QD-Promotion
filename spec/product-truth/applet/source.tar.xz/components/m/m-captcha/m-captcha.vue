<template>
    <view class="slider-captcha-mask" v-if="visible">
        <view class="slider-captcha-panel">
            <view class="slider-captcha-header">
                <text class="slider-captcha-title">安全验证</text>
                <text class="slider-captcha-close" @click="close">✕</text>
            </view>

            <view class="slider-captcha-image-wrap">
                <view
                    v-if="loading"
                    class="slider-captcha-skeleton"
                    :style="{ width: canvasWidth + 'px', height: canvasHeight + 'px' }"
                ></view>
                <view v-else class="slider-captcha-content">
                    <image
                        class="slider-captcha-bg"
                        :src="bgImage"
                        :style="{ width: canvasWidth + 'px', height: canvasHeight + 'px' }"
                        mode="scaleToFill"
                    />
                    <image
                        v-if="pieceImage"
                        class="slider-captcha-piece"
                        :src="pieceImage"
                        :style="pieceStyle"
                        mode="scaleToFill"
                    />
                    <view class="slider-captcha-refresh" @click="refresh">
                        <text class="slider-captcha-refresh-icon">↻</text>
                    </view>
                </view>

                <view v-if="captchaReady" class="slider-captcha-track">
                    <view class="slider-captcha-track-bg">
                        <view class="slider-captcha-track-fill" :style="{ width: sliderX + 'px' }"/>
                    </view>
                    <view
                        class="slider-captcha-thumb"
                        :style="{ left: sliderX + 'px' }"
                        @touchstart.prevent="onTouchStart"
                        @touchmove.prevent="onTouchMove"
                        @touchend="onTouchEnd"
                    >
                        <text class="slider-captcha-thumb-icon">»</text>
                    </view>
                    <text v-if="!sliding && sliderX === 0" class="slider-captcha-hint">
                        向右滑动完成验证
                    </text>
                </view>

                <view v-if="resultTip" :class="['slider-captcha-result', resultSuccess ? 'success' : 'fail']">
                    <text>{{ resultTip }}</text>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
/**
 * 滑动验证码组件 - UniApp 版
 *
 * 使用方式：
 *   <SliderCaptcha ref="captchaRef" apiBase="https://your-api.com" @success="onSuccess" />
 *   captchaRef.value?.show()
 *
 * 后端接口（GoFrame 2.10）：
 *   GET  /api/captcha/generate  → { token, bgImage, pieceImage, y }
 *   POST /api/captcha/verify    → { token, x } → { success: bool }
 */
import {ref, computed, nextTick} from 'vue'
import request from "@/hooks/request";

const props = defineProps({
    apiBase: {type: String, default: ''},
    canvasWidth: {type: Number, default: 310},
    canvasHeight: {type: Number, default: 155},
    tolerance: {type: Number, default: 5},
    pieceOffset: {type: Number, default: 9}
})

const emit = defineEmits(['success', 'fail'])

const visible = ref(false)
const loading = ref(false)
const token = ref('')
const bgImage = ref('')
const pieceImage = ref('')
const pieceY = ref(0)
const sliderX = ref(0)
const sliding = ref(false)
const resultTip = ref('')
const resultSuccess = ref(false)
const verifying = ref(false)

let touchStartX = 0

// 拼图块尺寸（拼图边长 + 上下左右外扩偏移）
const pieceSize = computed(() => 44 + props.pieceOffset * 2)
// 验证码图片是否就绪（加载完成且背景图存在时才显示滑块）
const captchaReady = computed(() => !loading.value && !!bgImage.value)

const pieceStyle = computed(() => ({
    width: pieceSize.value + 'px',
    height: pieceSize.value + 'px',
    left: (sliderX.value - props.pieceOffset) + 'px',
    top: (pieceY.value - props.pieceOffset) + 'px',
    position: 'absolute'
}))

function show() {
    visible.value = true
    nextTick(() => {
        reset();
        loadCaptcha()
    })
}

function close() {
    visible.value = false
    reset()
}

function reset() {
    sliderX.value = 0
    sliding.value = false
    resultTip.value = ''
    resultSuccess.value = false
    token.value = ''
    bgImage.value = ''
    pieceImage.value = ''
    pieceY.value = 0
    verifying.value = false
    loading.value = false
}

function refresh() {
    reset()
    loadCaptcha()
}

/**
 * 将 base64 data URI 写入临时文件，返回本地路径
 */
function base64ToTempFile(base64Data, prefix) {
    return new Promise((resolve, reject) => {
        const base64 = base64Data.replace(/^data:image\/\w+;base64,/, '')
        // 文件名加时间戳，避免小程序缓存导致图片不刷新
        const filePath = `${wx.env.USER_DATA_PATH}/${prefix}_${Date.now()}.png`
        wx.getFileSystemManager().writeFile({
            filePath,
            data: base64,
            encoding: 'base64',
            success: () => resolve(filePath),
            fail: (err) => {
                console.error('[SliderCaptcha] 临时文件写入失败:', err)
                reject(err)
            }
        })
    })
}

async function loadCaptcha() {
    try {
        loading.value = true
        const res = await request.get('/captcha/generate')

        console.log('[SliderCaptcha] 接口返回:', JSON.stringify({
            token: res.data.token,
            bgImageLen: res.data.bgImage?.length,
            pieceImageLen: res.data.pieceImage?.length,
            y: res.data.y
        }))
        token.value = res.data.token
        pieceY.value = res.data.y

        // base64 写入临时文件，<image> 加载本地路径
        const [bg, piece] = await Promise.all([
            base64ToTempFile(res.data.bgImage, 'captcha_bg'),
            base64ToTempFile(res.data.pieceImage, 'captcha_piece')
        ])
        bgImage.value = bg
        pieceImage.value = piece
        console.log('[SliderCaptcha] 图片路径设置完成: bg=', bg, 'piece=', piece)

    } catch (e) {
        uni.showToast({title: '加载失败，请重试', icon: 'none'})
        console.error('[SliderCaptcha] loadCaptcha error:', e)
    } finally {
        loading.value = false
    }
}

function onTouchStart(e) {
    if (verifying.value) return
    sliding.value = true
    touchStartX = e.touches[0].clientX
    resultTip.value = ''
}

function onTouchMove(e) {
    if (!sliding.value || verifying.value) return

    const currentX = e.touches[0].clientX
    let offsetX = currentX - touchStartX

    const maxX = props.canvasWidth - 44 - props.pieceOffset * 2
    if (offsetX < 0) offsetX = 0
    if (offsetX > maxX) offsetX = maxX

    sliderX.value = offsetX
}

async function onTouchEnd() {
    if (!sliding.value || verifying.value) return
    sliding.value = false

    if (sliderX.value < 5) {
        resultTip.value = '请向右滑动滑块'
        resultSuccess.value = false
        sliderX.value = 0
        return
    }

    verifying.value = true
    try {
        const res = await request.post('/captcha/verify', {
            token: token.value,
            x: Math.round(sliderX.value)
        })
        if (res.data.success) {
            resultTip.value = '验证成功'
            resultSuccess.value = true
            emit('success', {token: token.value})
            setTimeout(() => close(), 600)
        } else {
            resultTip.value = '验证失败，请重试'
            resultSuccess.value = false
            emit('fail')
            setTimeout(() => refresh(), 1000)
        }
    } catch (e) {
        resultTip.value = '验证出错，请重试'
        resultSuccess.value = false
        emit('fail')
        console.error('[SliderCaptcha] verify error:', e)
    } finally {
        verifying.value = false
    }
}

defineExpose({show, close, reset, refresh})
</script>

<style scoped>
.slider-captcha-mask {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0, 0, 0, 0.5);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 9999;
}

.slider-captcha-panel {
    width: 340px;
    background-color: #fff;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 8px 30px rgba(0, 0, 0, 0.15);
}

.slider-captcha-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 14px 16px;
    border-bottom: 1px solid #f0f0f0;
}

.slider-captcha-title {
    font-size: 16px;
    font-weight: 600;
    color: #333;
}

.slider-captcha-close {
    font-size: 18px;
    color: #999;
    padding: 4px 8px;
}

.slider-captcha-image-wrap {
    padding: 15px 15px 0 15px;
}

.slider-captcha-content {
    border-radius: 6px;
    display: block;
    position: relative;
    overflow: hidden;
}

.slider-captcha-skeleton {
    border-radius: 6px;
    background: linear-gradient(90deg, #f0f0f0 25%, #e0e0e0 50%, #f0f0f0 75%);
    background-size: 200% 100%;
    animation: skeleton-loading 1.5s infinite;
}

@keyframes skeleton-loading {
    0% {
        background-position: 200% 0;
    }
    100% {
        background-position: -200% 0;
    }
}

.slider-captcha-bg {
    display: block;
}

.slider-captcha-piece {
    display: block;
    position: absolute;
    z-index: 2;
}

.slider-captcha-refresh {
    position: absolute;
    top: 10px;
    right: 10px;
    width: 30px;
    height: 30px;
    background-color: rgba(0, 0, 0, 0.45);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.slider-captcha-refresh-icon {
    color: #fff;
    font-size: 18px;
}

.slider-captcha-result {
    text-align: center;
    padding: 6px 16px;
    border-radius: 12px;
    font-size: 12px;
    margin-bottom: 8px;
    position: relative;
    z-index: 3;
}

.slider-captcha-result.success {
    background-color: rgba(82, 196, 26, 0.85);
    color: #fff;
}

.slider-captcha-result.fail {
    background-color: rgba(255, 77, 79, 0.85);
    color: #fff;
}

.slider-captcha-track {
    position: relative;
    height: 44px;
    margin: 16px 0;
    background-color: #f5f5f5;
    border-radius: 22px;
    overflow: hidden;
}

.slider-captcha-track-fill {
    height: 100%;
    background: linear-gradient(90deg, #a8e6cf, #52c41a);
    border-radius: 22px 0 0 22px;
}

.slider-captcha-thumb {
    position: absolute;
    top: 2px;
    width: 40px;
    height: 40px;
    background-color: #fff;
    border-radius: 50%;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 2;
}

.slider-captcha-thumb-icon {
    font-size: 18px;
    color: #52c41a;
    font-weight: bold;
}

.slider-captcha-hint {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    font-size: 13px;
    color: #bbb;
    white-space: nowrap;
    z-index: 1;
}
</style>