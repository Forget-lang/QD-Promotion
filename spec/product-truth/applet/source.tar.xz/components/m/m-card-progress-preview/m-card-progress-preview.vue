<template>
    <view class="card-progress" v-if="steps.length > 0">
        <scroll-view scroll-x class="progress-scroll" :show-scrollbar="false">
            <view class="progress-track">
                <view
                    v-for="(step, index) in steps"
                    :key="index"
                    class="progress-step"
                    :class="{
                        'is-active': index === props.usedCount,
                        'is-done': index < props.usedCount,
                        'is-selected': index === selectedIndex
                    }"
                    @click="selectItem(index)"
                >
                    <view class="step-dot">{{ index < props.usedCount ? '✓' : index + 1 }}</view>
                    <view class="step-label">{{ step.label }}</view>
                    <view class="step-line" v-if="index < steps.length - 1"></view>
                </view>
            </view>
        </scroll-view>

        <view class="benefit-desc-box" @click="onDescBoxClick">
            <view class="benefit-desc-head">
                <text class="benefit-desc-title">优惠说明</text>
                <t-icon v-if="selectedDescription" name="chevron-right" size="32rpx" color="#999"/>
            </view>
            <view class="benefit-desc-text" :class="{ 'is-placeholder': !selectedDescription }">
                {{ selectedDescription || '暂无优惠说明' }}
            </view>
        </view>
    </view>

    <t-popup placement="bottom" v-model:visible="descPopupVisible">
        <view class="popup-header">
            <view class="popup-header-title">第{{ selectedIndex + 1 }}次 · {{ selectedStepLabel }}</view>
            <view class="popup-header-close">
                <t-icon name="close" @click="descPopupVisible = false" :size="20"/>
            </view>
        </view>
        <scroll-view scroll-y class="popup-body">
            <view class="container">
                <text class="desc-popup-text">{{ selectedDescription }}</text>
            </view>
        </scroll-view>
    </t-popup>
</template>

<script setup>
import {computed, ref, watch} from 'vue'
import {BENEFIT_TYPE} from '@/constants/card'

const props = defineProps({
    items: {type: Array, default: () => []},
    usedCount: {type: Number, default: 0},
})

const selectedIndex = ref(0)
const descPopupVisible = ref(false)

const benefitLabel = (item) => {
    if (!item) return ''
    if (item.benefitLabel) return item.benefitLabel
    if (Number(item.benefitType) === BENEFIT_TYPE.AMOUNT) {
        return item.amountValue ? `¥${item.amountValue}` : '金额'
    }
    if (Number(item.benefitType) === BENEFIT_TYPE.DISCOUNT) {
        return item.discountAmount ? `${item.discountAmount}折` : '折扣'
    }
    return item.serviceName || '服务'
}

const steps = computed(() => {
    return (props.items || []).map(item => ({
        label: benefitLabel(item),
        description: item.benefitDescription || '',
    }))
})

const defaultSelectedIndex = computed(() => {
    const count = props.items?.length || 0
    if (count === 0) return 0
    if (props.usedCount >= count) return count - 1
    return props.usedCount
})

watch([() => props.items, () => props.usedCount], () => {
    selectedIndex.value = defaultSelectedIndex.value
}, {immediate: true})

const selectedDescription = computed(() => steps.value[selectedIndex.value]?.description || '')
const selectedStepLabel = computed(() => steps.value[selectedIndex.value]?.label || '')

const selectItem = (index) => {
    selectedIndex.value = index
}

const onDescBoxClick = () => {
    if (!selectedDescription.value) return
    descPopupVisible.value = true
}
</script>

<style scoped>
.card-progress {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
}

.progress-scroll {
    width: 100%;
    white-space: nowrap;
    box-sizing: border-box;
}

.progress-track {
    display: inline-flex;
    min-width: max-content;
}

.progress-step {
    position: relative;
    display: inline-flex;
    flex-direction: column;
    align-items: center;
    min-width: 120rpx;
    padding: 0 8rpx;
}

.step-dot {
    width: 54rpx;
    height: 54rpx;
    line-height: 54rpx;
    text-align: center;
    border-radius: 50%;
    background: #f5f5f5;
    color: #999;
    font-size: 28rpx;
    font-weight: 600;
    z-index: 1;
    transition: all 0.2s ease;
}

/* 选中状态 - 黄底深字 */
.progress-step.is-selected .step-dot {
    background: #ffedaa;
    color: #965e30;
}

.step-label {
    margin-top: 12rpx;
    font-size: 28rpx;
    color: #666;
    text-align: center;
    max-width: 120rpx;
    word-break: break-all;
}

/* 选中状态 label */
.progress-step.is-selected .step-label {
    color: #965e30;
    font-weight: 600;
}

.step-line {
    position: absolute;
    top: 24rpx;
    left: calc(50% + 36rpx);
    width: calc(100% - 72rpx);
    height: 2rpx;
    background: #e8e8e8;
    z-index: 0;
}

.benefit-desc-box {
    margin-top: 24rpx;
    padding: 24rpx;
    background: #f5f5f5;
    border-radius: 16rpx;
}

.benefit-desc-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 12rpx;
}

.benefit-desc-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.benefit-desc-text {
    font-size: 26rpx;
    line-height: 1.6;
    color: #666;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
    white-space: pre-wrap;
    word-break: break-all;
}

.benefit-desc-text.is-placeholder {
    color: #bbb;
}

.desc-popup-text {
    font-size: 28rpx;
    line-height: 1.8;
    color: #666;
    white-space: pre-wrap;
}
</style>
