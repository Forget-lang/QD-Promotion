<template>
    <t-popup v-model:visible="visible" placement="bottom" :closeOnOverlayClick="status === 'profile' || status === 'success' || status === 'failed'">
        <view class="popup-profile-container">
            <!-- 关闭按钮 -->
            <view class="popup-header-close" v-if="status === 'profile' || status === 'success' || status === 'failed' || (status === 'loading' && canCloseLoading)" @click="onClose">
                <t-icon name="close" size="24px" />
            </view>

            <!-- 检测中 -->
            <template v-if="status === 'checking'">
                <view class="popup-loading-wrap">
                    <t-loading :loading="true" size="56rpx" layout="vertical">
                        <template #text>
                            <text style="font-size: 30rpx; font-weight: 600; color: #1a1a1a">正在准备中</text>
                        </template>
                    </t-loading>
                </view>
            </template>

            <!-- 领取中 -->
            <template v-else-if="status === 'loading'">
                <view class="popup-loading-wrap">
                    <t-loading :loading="true" size="56rpx" layout="vertical">
                        <template #text>
                            <text style="font-size: 30rpx; font-weight: 600; color: #1a1a1a">领取中</text>
                        </template>
                    </t-loading>
                </view>
                <view class="popup-steps-wrap">
                    <t-steps :current="1" layout="horizontal" readonly>
                        <t-step-item>
                            <template #content>
                                <text class="steps-content-text">资料已提交</text>
                            </template>
                        </t-step-item>
                        <t-step-item icon="chart-ring-1-filled">
                            <template #content>
                                <text class="steps-content-text">领券中</text>
                            </template>
                        </t-step-item>
                        <t-step-item icon="round-filled">
                            <template #content>
                                <text class="steps-content-text">领取成功</text>
                            </template>
                        </t-step-item>
                    </t-steps>
                </view>
            </template>

            <!-- 领取成功 -->
            <template v-else-if="status === 'success'">
                <view class="popup-receive-result">
                    <t-icon name="check-circle-filled" color="var(--td-brand-color)" size="96rpx"></t-icon>
                    <text class="popup-result-title text-success">领取成功</text>
                    <text>打开小程序 [ 券到卡包 ]，查看已领取的卡券</text>
                    <template v-if="signInfo && signInfo.isAllowWecard">
                        <send-coupon
                            class="mt-3"
                            @sendcoupon="onSendCoupon"
                            @userconfirm="onWecardConfirm"
                            :suggest_immediate_use="true"
                            :send_coupon_params="signInfo.sendCouponParams"
                            :sign="signInfo.sign"
                            :send_coupon_merchant="signInfo.sendCouponMerchant"
                        >
                            <button class="wecard-button" type="default">同步至微信卡包</button>
                        </send-coupon>
                        <t-button theme="default"
                                  custom-style="width: 356rpx; font-size: 32rpx; border-radius: 12rpx; margin-top: 24rpx;"
                                  @click="onHome">打开卡包
                        </t-button>
                    </template>
                    <t-button v-else theme="primary"
                              custom-style="width: 356rpx; font-size: 32rpx; border-radius: 12rpx; margin-top: 85rpx;"
                              @click="onHome">打开卡包
                    </t-button>
                </view>
            </template>

            <!-- 领取失败 -->
            <template v-else-if="status === 'failed'">
                <view class="popup-receive-result">
                    <t-icon name="info-circle-filled" color="#ffc000" size="96rpx"></t-icon>
                    <text class="popup-result-title">领取失败</text>
                    <text>{{ errMsg }}</text>
                    <t-button theme="default"
                              custom-style="width: 356rpx; font-size: 32rpx; border-radius: 12rpx; margin-top: 85rpx;"
                              @click="onClose">确定
                    </t-button>
                </view>
            </template>

            <!-- 完善信息/授权登录 -->
            <template v-else>
                <view class="profile-merchant-header">
                    <view class="profile-merchant-warp">
                        <image class="profile-merchant-logo" :src="merchant.logo" mode="aspectFill"/>
                        <text class="profile-merchant-name">{{ merchant.name }}</text>
                        <text class="profile-merchant-name">申请</text>
                    </view>
                    <!-- 需要完善信息 -->
                    <template v-if="showMobileInput">
                        <text class="profile-auth-info mt-3">获取你的手机号</text>
                        <text class="text-muted mt-1">卡券领取成功后商家可查看和导出授权信息</text>
                    </template>
                    <!-- 需要授权登录 -->
                    <template v-else-if="needAuthLogin">
                        <text class="profile-auth-info mt-3">一键授权登录</text>
                        <text class="text-muted mt-1">商家可查看和导出授权信息</text>
                    </template>
                </view>

                <template v-if="showMobileInput">
                    <view class="profile-input-wrap mt-2">
                        <t-input label="手机号" v-model:value="profileForm.mobile" placeholder="请输入手机号" :maxlength="11" type="number" borderless :cursor-spacing="120" custom-style="padding: 26rpx 30rpx;"/>
                    </view>
                </template>

                <template v-if="showCipherInput">
                    <view class="profile-input-wrap mt-2">
                        <t-input label="领取口令" v-model:value="profileForm.cipherCode" placeholder="请输入5位数字口令"
                                 :maxlength="5" type="number" borderless :cursor-spacing="120"
                                 custom-style="padding: 26rpx 30rpx;"/>
                    </view>
                </template>

                <!-- 底部按钮：需要授权登录时显示get-user-info -->
                <template v-if="needAuthLogin">
                    <view class="profile-bottom-action flex-column" style="margin: 0 46rpx">
                        <view class="w-100">
                            <get-user-info @success="onGetUserInfoSuccess">
                                <button class="button-normal profile-login" :disabled="disabled">微信一键授权登录</button>
                            </get-user-info>
                        </view>
                        <text class="text-muted text-wechat" @click="onClose">取消</text>
                    </view>
                </template>
                <template v-else>
                    <view class="profile-bottom-action">
                        <view class="profile-bottom-item">
                            <t-button block custom-style="height: 92rpx;font-size: 28rpx; border-radius: 12rpx; color: #1a1a1a;" @click="onClose">取消</t-button>
                        </view>
                        <view class="profile-bottom-item">
                            <t-button block theme="primary" custom-style="height: 92rpx; font-size: 28rpx; border-radius: 12rpx;" :disabled="disabled" @click="onConfirm">同意并领券</t-button>
                        </view>
                    </view>
                </template>
            </template>
        </view>
    </t-popup>
</template>

<script setup>
import {ref, computed, watch} from 'vue'
import {useAuth} from "@/hooks/useAuth";
import {useLink} from "@/hooks/useLink.js"
import utils from "@/utils/utils"
import request from "@/hooks/request";
import {REGISTER_TYPE} from "@/constants/merchant";

const {login, isLoggedIn} = useAuth()
const {reLaunch} = useLink()

const visible = defineModel('visible', {
    type: Boolean,
    default: false
})

const props = defineProps({
    merchant: {
        type: Object,
        default: () => ({})
    },
    profileOption: {
        type: Object,
        default: () => ({})
    },
    onReceive: {
        type: Function,
        required: true
    }
})

// 状态：profile | loading | success | failed
const status = ref('profile')
const profileForm = ref({
    mobile: '',
    cipherCode: '',
})
const errMsg = ref('')
const loadingTimedOut = ref(false)
const signInfo = ref(null)
const couponReceiveIds = ref([])

const notifyAddWecard = (ids) => {
    const list = (ids || []).filter(Boolean)
    if (!list.length) return
    request.post('/user/coupon/receive/wecard', {ids: list}).catch(() => {
    })
}

// 用户检测状态
const checkResult = ref({
    isInputMobile: false,
    isWechatAuth: false
})

// loading超过10秒允许用户关闭弹窗
const canCloseLoading = computed(() => {
    return status.value === 'loading' && loadingTimedOut.value
})

// 是否需要微信一键授权登录（微信授权注册且用户未微信授权过）
const needAuthLogin = computed(() => {
    return props.profileOption.registerType === REGISTER_TYPE.WECHAT && !checkResult.value.isWechatAuth
})

// 是否显示手机号输入框（指定手机号领取须每次提交；否则仅未留过手机号时展示）
const showMobileInput = computed(() => {
    if (props.profileOption.isMobileLimit || props.profileOption.isGetMobile) {
        return true
    }
    return false
})

// 是否显示领取口令输入框（cipherType 非关闭态即展示）
const showCipherInput = computed(() => {
    return Number(props.profileOption.cipherType || 0) > 0
})

const disabled = computed(() => {
    if (showMobileInput.value && (!profileForm.value.mobile || profileForm.value.mobile.length !== 11)) return true
    if (showCipherInput.value && !/^\d{5}$/.test(String(profileForm.value.cipherCode || ''))) return true
    return false
})

const userCheck = () => {
    return new Promise((resolve, reject) => {
        uni.login({
            provider: 'weixin',
            timeout: 10000,
            success: (loginRes) => {
                if (!loginRes.code) {
                    uni.showToast({
                        title: '获取登录凭证失败',
                        icon: 'none'
                    })
                    reject(new Error('获取登录凭证失败'))
                    return
                }
                request.get('/user/check', {
                    loginCode: loginRes.code,
                    merchantId: props.merchant.id
                }).then(res => {
                    checkResult.value = {
                        //不再使用isInputMobile来判断是否显示手机号输入框，开启：手机号领券/指定手机号领券，则必须输入手机号；这里只赋值，但不使用
                        isInputMobile: res.data.isInputMobile || false,
                        isWechatAuth: res.data.isWechatAuth || false
                    }
                    resolve(res.data)
                }).catch(reject)
            },
            fail: (err) => {
                uni.showToast({
                    title: '微信登录接口调用失败',
                    icon: 'none'
                })
                reject(err)
            }
        })
    })
}

// 弹窗打开时重置状态并判断是否自动领券
watch(visible, async (val) => {
    if (!val) return
    // 重置状态
    status.value = 'profile'
    errMsg.value = ''
    signInfo.value = null
    couponReceiveIds.value = []
    checkResult.value = { isInputMobile: false, isWechatAuth: false }
    profileForm.value.mobile = ''
    profileForm.value.cipherCode = ''

    const option = props.profileOption

    // 不需要手机号、不需要口令、无需微信授权 + 匿名登录 → 直接自动领券
    if (!showMobileInput.value && !showCipherInput.value && !needAuthLogin.value && option.registerType === REGISTER_TYPE.ANONYMOUS) {
        await handleAutoReceive()
        return
    }

    // 需要检测用户状态（需要手机号 或 需要微信授权）
    status.value = 'checking'
    try {
        await userCheck()
        // 检测完成，按结果决定下一步
        handleCheckComplete()
    } catch (e) {
        // 检测失败，checkResult 保持默认值（视为未填手机号、未授权），按设置项决定下一步
        handleCheckComplete()
    }
})

// 检测完成后的统一处理
const handleCheckComplete = () => {
    if (showMobileInput.value || showCipherInput.value || needAuthLogin.value) {
        // 需要用户操作（填手机号、口令或授权）
        status.value = 'profile'
    } else {
        // 不需要任何操作 → 直接进入领取中状态
        handleAutoReceive()
    }
}

// 自动领券处理
const handleAutoReceive = async () => {
    if (!isLoggedIn.value) {
        // 未登录，静默登录后领券
        try {
            await login()
            doReceive()
        } catch (e) {
            status.value = 'profile'
            visible.value = false
        }
    } else {
        doReceive()
    }
}

// 执行领券
const doReceive = () => {
    status.value = 'loading'
    loadingTimedOut.value = false
    // loading超过10秒允许用户关闭弹窗
    setTimeout(() => {
        loadingTimedOut.value = true
    }, 10000)
    props.onReceive(profileForm.value).then((res) => {
        const data = res?.data || res || {}
        signInfo.value = data.signInfo || null
        couponReceiveIds.value = data.couponReceiveIds || []
        status.value = 'success'
    }).catch((err) => {
        status.value = 'failed'
        errMsg.value = err?.message || ''
    })
}

const onSendCoupon = (e) => {
    // 插件回调：发券结果（可能多张）
    const list = e?.detail?.send_coupon_result || []
    const okIds = list
        .filter((item) => item.code === 'SUCCESS' || item.code === 'DUPREQUEST')
        .map((item) => item.coupon_code)
        .filter(Boolean)
    if (okIds.length) {
        notifyAddWecard(okIds)
        if (signInfo.value) {
            signInfo.value = {...signInfo.value, isAllowWecard: false}
        }
    }
}

const onWecardConfirm = () => {
    notifyAddWecard(couponReceiveIds.value)
    if (signInfo.value) {
        signInfo.value = {...signInfo.value, isAllowWecard: false}
    }
}

// 同意并领券
const onConfirm = utils.debounce(() => {
    if (!isLoggedIn.value) {
        // 未登录，静默登录后领券
        status.value = 'loading'
        login().then(() => {
            doReceive()
        }).catch(() => {
            status.value = 'profile'
            visible.value = false
        })
    } else {
        doReceive()
    }
})

// 微信授权登录成功
const onGetUserInfoSuccess = (e) => {
    status.value = 'loading'
    login({
        nickname: e.detail.userInfo.nickName,
        avatar: e.detail.userInfo.avatarUrl,
    }).then(() => {
        doReceive()
    }).catch(() => {
        status.value = 'profile'
        visible.value = false
    })
}

// 关闭弹窗
const onClose = () => {
    if ((status.value === 'loading' || status.value === 'checking') && !loadingTimedOut.value) return
    visible.value = false
}

// 打开卡包
const onHome = () => {
    visible.value = false
    reLaunch('/pages/index/index')
}
</script>

<style scoped>
.popup-profile-container {
    background: #fff;
    padding: 46rpx;
    position: relative;
    border-radius: 24rpx 24rpx 0 0;
    height: 690rpx;
    display: flex;
    flex-direction: column;
}

.popup-header-close {
    position: absolute;
    top: 30rpx;
    right: 30rpx;
    z-index: 1;
}

.popup-loading-wrap {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    margin: 70rpx 0 50rpx;
}

.popup-steps-wrap {
    --td-loading-text-font: var(--td-font-body-medium);
    margin: 40rpx 0 120rpx;
}

.steps-content-text {
    font-size: 20rpx;
    color: #999;
}

.popup-receive-result {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    gap: 10rpx;
    font-size: 24rpx;
    color: #959595;
    margin: 70rpx 0 70rpx;
}

.popup-result-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #232323;
    margin-top: 25rpx;
    margin-bottom: 18rpx;
}

.profile-merchant-header {
    display: flex;
    flex-direction: column;
    margin-bottom: 76rpx;
}

.profile-merchant-warp {
    display: flex;
    align-items: center;
    gap: 16rpx;
}

.profile-merchant-logo {
    width: 64rpx;
    height: 64rpx;
    border-radius: 50%;
}

.profile-merchant-name {
    font-size: 28rpx;
    font-weight: 600;
    color: #1a1a1a;
}

.profile-auth-info {
    color: #1a1a1a;
    font-weight: 600;
    font-size: 32rpx;
}

.profile-input-wrap {
    border-radius: 10rpx;
    --td-input-bg-color: #f7f7f7;
    --td-input-label-min-width: 100rpx;
    overflow: hidden;
}

.profile-bottom-action {
    position: absolute;
    bottom: 60rpx;
    left: 0;
    right: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 20rpx;
}

.profile-bottom-item {
    width: 226rpx;
}

.profile-login {
    background-color: var(--td-brand-color);
    color: #fff;
    height: 98rpx;
    border-radius: 20rpx;
}

/* 与 t-button primary disabled 样式保持一致 */
.profile-login[disabled] {
    background-color: var(--td-brand-color-disabled) !important;
    color: #fff !important;
    opacity: 1 !important;
}

.profile-login[disabled]::after {
    border-color: var(--td-brand-color-disabled) !important;
}

.wecard-button {
    width: 356rpx;
    height: 80rpx;
    line-height: 80rpx;
    padding: 0;
    margin-top: 40rpx;
    border: none;
    border-radius: 12rpx;
    background: #07C160;
    color: #fff;
    font-size: 32rpx;
}

.wecard-button::after {
    border: none;
}
</style>
