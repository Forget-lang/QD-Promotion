<template>
    <view class="product-theme-select">
        <view class="product-theme-header" v-if="title">
            <text class="product-theme-title">{{ title }}</text>
            <text class="product-theme-required" v-if="required">*</text>
        </view>
        <view class="product-theme-desc" v-if="description">{{ description }}</view>
        <view class="product-theme-grid">
            <view
                class="product-theme-item"
                v-for="item in themes"
                :key="item.value"
                :class="{ active: modelValue === item.value }"
                @click="onSelect(item.value)"
            >
                <view class="product-theme-swatch" :style="{ background: item.color }">
                    <t-icon v-if="modelValue === item.value" name="check" size="28rpx" color="#fff"/>
                </view>
                <view class="product-theme-name">{{ item.label }}</view>
                <view class="product-theme-tip">{{ item.desc }}</view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {themes} from '@/utils/theme.js'

defineProps({
    title: {
        type: String,
        default: '主题色',
    },
    description: {
        type: String,
        default: '搭配封面使用，影响顾客领取页背景与按钮区域',
    },
    required: {
        type: Boolean,
        default: true,
    },
})

const modelValue = defineModel('value', {
    type: Number,
    default: 1,
})

// 选择主题色
const onSelect = (value) => {
    modelValue.value = value
}
</script>

<style scoped>
.product-theme-select {
    margin: 0 24rpx;
    border-radius: 18rpx;
    background: #fff;
    padding: 32rpx;
    overflow: hidden;
}

.product-theme-header {
    display: flex;
    align-items: center;
    gap: 4rpx;
    margin-bottom: 8rpx;
}

.product-theme-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.product-theme-required {
    color: #e84c59;
}

.product-theme-desc {
    font-size: 24rpx;
    color: #999;
    line-height: 1.5;
    margin-bottom: 24rpx;
}

.product-theme-grid {
    display: grid;
    grid-template-columns: repeat(3, 1fr);
    gap: 20rpx;
}

.product-theme-item {
    border-radius: 16rpx;
    padding: 16rpx 12rpx;
    background: #fafafa;
    text-align: center;
}

.product-theme-item.active {
    background: #f0faf4;
    box-shadow: 0 0 0 2rpx #07c160;
}

.product-theme-swatch {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    margin: 0 auto 12rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    box-shadow: inset 0 0 0 2rpx rgba(255, 255, 255, 0.35);
}

.product-theme-name {
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
}

.product-theme-tip {
    margin-top: 6rpx;
    font-size: 20rpx;
    line-height: 1.4;
    color: #999;
    min-height: 56rpx;
}
</style>
