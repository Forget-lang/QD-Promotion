<template>
    <view class="merchant-card">
        <view class="merchant-card__body">
            <view class="merchant-card__header">
                <view class="merchant-card__name-row">
                    <view class="merchant-card__name text-ellipsis">{{ merchant.name }}</view>
                    <view v-if="merchant.authStatus != null"
                          class="merchant-card__tag"
                          :class="merchant.authStatus === AUTH_STATUS.SUCCESS ? 'merchant-card__tag--verified' : 'merchant-card__tag--unverified'">
                        {{ merchant.authStatus === AUTH_STATUS.SUCCESS ? '已认证' : '未认证' }}
                    </view>
                </view>
                <view class="merchant-card__menu" @tap.stop="">
                    <t-icon name="ellipsis" size="40rpx" color="#fff"/>
                </view>
            </view>

            <!-- 客服电话 -->
            <view class="merchant-card__contact text-ellipsis"
                  @tap.stop="utils.makePhoneCall(merchant.servicePhone, '')">{{ merchant.servicePhone || '暂无' }}
            </view>

            <!-- 地址 -->
            <view class="merchant-card__address text-ellipsis">{{ merchant.address }}</view>

            <!-- 底部标签 -->
            <view class="merchant-card__footer">
                <view class="merchant-card__pills">
                    <view v-for="tag in industryTags" :key="tag" class="merchant-card__pill">{{ tag }}</view>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {computed} from 'vue'
import {AUTH_STATUS} from '@/constants/merchant'
import utils from '@/utils/utils'

const props = defineProps({
    merchant: {
        type: Object,
        default: () => ({})
    },
})

// industry 字符串按 / 拆为多个主营标签
const industryTags = computed(() => {
    const ind = props.merchant.industry
    if (!ind) return []
    return ind.split('/').map(s => s.trim()).filter(Boolean)
})

</script>

<style scoped>
.merchant-card {
    position: relative;
    overflow: hidden;
    border-radius: 16rpx;
    height: 240rpx;
    color: #fff;
    background: #212f99;
}

/* 装饰元素 */
.merchant-card__deco {
    position: absolute;
    pointer-events: none;
}

.merchant-card__deco--logo {
    top: 50%;
    right: 32rpx;
    width: 220rpx;
    height: 220rpx;
    transform: translateY(-50%);
    opacity: 0.1;
    display: flex;
    align-items: center;
    justify-content: center;
}

.merchant-card__deco-img {
    width: 100%;
    height: auto;
}

/* 卡片内容 */
.merchant-card__body {
    position: relative;
    z-index: 1;
    padding: 24rpx 28rpx;
    height: 100%;
    box-sizing: border-box;
    display: flex;
    flex-direction: column;
    justify-content: space-between;
}

.merchant-card__header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12rpx;
}

.merchant-card__name-row {
    display: flex;
    align-items: center;
    gap: 8rpx;
    flex: 1;
    min-width: 0;
    overflow: hidden;
}

.merchant-card__name {
    font-size: 34rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.2;
    letter-spacing: 1rpx;
    min-width: 0;
    text-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.18);
}

.merchant-card__tag {
    display: inline-flex;
    align-items: center;
    padding: 2rpx 10rpx;
    font-size: 18rpx;
    font-weight: 500;
    line-height: 1.4;
    border-radius: 999px;
    flex-shrink: 0;
    white-space: nowrap;
    letter-spacing: 0.5rpx;
}

.merchant-card__tag--verified {
    background: rgba(95, 224, 160, 0.22);
    color: #5FE0A0;
    box-shadow: inset 0 0 0 1rpx rgba(95, 224, 160, 0.35);
}

.merchant-card__tag--unverified {
    background: rgba(255, 255, 255, 0.12);
    color: rgba(255, 255, 255, 0.65);
    box-shadow: inset 0 0 0 1rpx rgba(255, 255, 255, 0.18);
}

.merchant-card__menu {
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    padding: 4rpx 6rpx;
    margin: -4rpx -6rpx;
}

.merchant-card__contact {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.95);
    line-height: 1.4;
    margin-top: 4rpx;
}

.merchant-card__address {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.7);
    line-height: 1.4;
    margin-top: 2rpx;
}

/* 行业标签 */
.merchant-card__footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.merchant-card__pills {
    display: flex;
    align-items: center;
    gap: 12rpx;
    flex: 1;
    overflow: hidden;
    min-width: 0;
}

.merchant-card__pill {
    display: inline-flex;
    align-items: center;
    padding: 6rpx 18rpx;
    font-size: 22rpx;
    border-radius: 999px;
    background: rgba(255, 255, 255, 0.2);
    color: #fff;
    white-space: nowrap;
    flex-shrink: 0;
}

</style>
