<template>
	<text>{{ text }}</text>
</template>

<script setup>
	import dayjs from 'dayjs';
	import { computed } from 'vue';
	
	const props = defineProps({
		value: String,
		type: {
		    type: String,
		    default: 'date',
		},
		format: {
			type: String,
			default: 'YYYY年MM月DD日'
		}
	})
	
	const text = computed(() => {
		if (props.value === '') {
		    return '-'
		}
		if (dayjs(props.value).isValid() && dayjs(props.value).year() === 1900) {
		    return '-'
		}
		if (dayjs(props.value).isValid() && dayjs(props.value).year() === 2100) {
		    return '永久'
		}
		if (props.value === undefined) {
		    return '-'
		}
		if (dayjs(props.value).isValid()) {
		    if (props.type === 'date') {
		        return dayjs(props.value).format(props.format)
		    } else if (props.type === 'datetime') {
		        return dayjs(props.value).format(props.format + ' HH:mm:ss')
		    }
		}
		return '-'
	})
	
</script>

<style scoped>
	
</style>