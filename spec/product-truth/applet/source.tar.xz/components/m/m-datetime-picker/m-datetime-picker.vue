<template>
	<t-cell :title="props.title" hover :required="props.required" arrow data-mode="datetime" t-class="panel-item"
		@click="datetimeVisible = true">
		<template #note>
			<text class="text-black lh-24" v-if="datetime">{{datetime}}</text>
			<text class="lh-24" v-else>{{placeholder}}</text>
		</template>
		
	</t-cell>

	<!-- 年月日时分 -->
	<t-date-time-picker 
		:visible="datetimeVisible" 
		:title="title" 
		:mode="props.mode" 
		:start="computedStart" 
		:end="computedEnd"
		v-model:value="datetime"
		:format="props.format"
        :popup-props="props.popupProps"
		@cancel="datetimeVisible = false" 
		@change="onConfirm" 
	/>
</template>

<script setup>
	import {
		ref,
		computed
	} from 'vue'
	import dayjs from 'dayjs'
	
	const emits = defineEmits(['change'])

	const props = defineProps({
		title: {
			type: String,
			default: '选择时间'
		},
		required: {
			type: Boolean,
			default: false
		},
		format: {
			type: String,
			default: 'YYYY-MM-DD HH:mm:00'
		},
		mode: {
			type: String,
			default: 'minute'
		},
		placeholder: {
			type: String,
			default: '请选择时间',
		},
		// 开始时间限制模式: 'today'(当天开始,默认) | 'fixed'(固定日期)
		startMode: {
			type: String,
			default: 'today'
		},
		// 当 startMode 为 'fixed' 时，指定的固定开始日期
		startDate: {
			type: String,
			default: ''
		},
		// 结束时间限制模式: 'beforeToday'(今天以前) | 'unlimited'(不限制,默认)
		endMode: {
			type: String,
			default: 'unlimited'
		},
        // 透传 popup 属性（用于在嵌套 popup 中调整 z-index 等）
        popupProps: {
            type: Object,
            default: () => ({})
        },
	})

	const datetimeVisible = ref(false)
	const datetime = defineModel('value')

	// 计算开始时间
	const computedStart = computed(() => {
		if (props.startMode === 'fixed' && props.startDate) {
			return props.startDate
		}
		// 默认从当天开始
		return dayjs().format('YYYY-MM-DD')
	})

	// 计算结束时间
	const computedEnd = computed(() => {
		if (props.endMode === 'beforeToday') {
			return dayjs().format('YYYY-MM-DD')
		}
		// 默认不限制，给一个较远的未来日期
		return dayjs().add(1, 'year').format('YYYY-MM-DD')
	})

	const onConfirm = (e) => {
		console.log(e)
		datetimeVisible.value = false
		emits('change', e)
	}
</script>

<style>
</style>