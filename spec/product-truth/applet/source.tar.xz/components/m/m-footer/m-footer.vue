<template>
    <view class="footer">
        <view class="footer-meta" :style="{ color: isWhite ? '#fff' : '#ababab' }">
            <span @tap="onFeedbackVisible(2)">意见反馈</span>
            <span class="split">|</span>
            <span @tap="showTip = true">免责声明</span>
            <span class="split">|</span>
            <span @tap="onFeedbackVisible(3)">我要投诉</span>
        </view>
        <view class="footer-slogan" :style="{ color: isWhite ? '#fff' : '#ccc' }" @click="goMerchant">
            <view>
                <span class="footer-line">——</span>
                <span class="footer-brand">券到卡包</span>
                <span class="footer-line">——</span>
            </view>
            <view class="footer-desc">
                实体店优惠券/券包/次卡免费制作工具
            </view>
            <view class="footer-desc">
                {{ config.version }}
            </view>
        </view>
    </view>
    <t-popup placement="bottom" v-model:visible="feedbackVisible">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-title">
                    {{ form.feedbackType === 2 ? '意见反馈' : '我要投诉' }}
                </view>
                <view class="popup-header-close">
                    <t-icon name="close" size="50rpx" @click="feedbackVisible = false"></t-icon>
                </view>
            </view>
            <view class="popup-body" style="min-height: 1120rpx">
                <m-result v-if="showSuccess" title="提交成功"
                          description="我们会在三个工作日内做出回复，请您耐心等待。"></m-result>
                <template v-else>
                    <t-cell-group theme="card" t-class="mt-2" v-if="form.feedbackType === 3">
                        <t-input
                            label="卡券编号"
                            v-model:value="form.voucherId"
                            align="right"
                            placeholder="请粘贴卡券编号"
                        />
                    </t-cell-group>
                    <t-cell-group theme="card" t-class="mt-2">
                        <t-input label="联系方式" v-model:value="form.mobile" align="right"
                                 placeholder="填写您的手机号"/>
                    </t-cell-group>
                    <t-cell-group theme="card" t-class="mt-2">
                        <t-textarea label="反馈内容" v-model:value="form.content" placeholder="请输入内容"/>
                        <view class="p-2 bg-white">
                            <m-upload :max="4" v-model:value="form.files"/>
                        </view>
                    </t-cell-group>
                    <t-cell-group theme="card" t-class="mt-2">
                        <t-button block theme="primary" @click="onSubmit">提交</t-button>
                    </t-cell-group>
                </template>
            </view>
        </view>
    </t-popup>
    <t-popup placement="bottom" v-model:visible="showTip">
        <view class="popup-header">
            <view class="popup-header-title">免责声明</view>
            <view class="popup-header-close">
                <t-icon name="close" size="50rpx" @click="showTip = false"></t-icon>
            </view>
        </view>
        <view class="popup-body lh-30 container">
            <view>
                我们仅提供制作卡券的工具，不对第三方发起人行为承担责任，所有卡券均由商家自行制作并自行发放;
            </view>
            <view>
                本工具会在法律范围内尽可能地规范、督促用户遵守相关法律和平台使用规则，营造一个良好的有效的卡券制作平台。
            </view>
        </view>
        <view class="popup-bottom-cancel" @click="showTip = false">好的</view>
    </t-popup>
</template>

<script setup>
import {ref} from 'vue'
import config from '@/config'
import {useLink} from "@/hooks/useLink";
import request from "@/hooks/request";
import MUpload from "@/components/m/m-upload/m-upload.vue";
import utils from "@/utils/utils";
import MResult from "@/components/m/m-result/m-result.vue";

const {switchTab} = useLink();

const MERCHANT_SOURCE_KEY = 'merchant_source'

const goMerchant = () => {
    uni.setStorageSync(MERCHANT_SOURCE_KEY, '券到卡包')
    switchTab('/pages/merchant/index')
}

const props = defineProps({
    systemId: {
        type: Number,
        default: 3, // 2:商家端；3：用户端
    },
    isWhite: {
        type: Boolean,
        default: false
    },
})

const showTip = ref(false)
const feedbackVisible = ref(false)
const showSuccess = ref(false)

const form = ref({
    feedbackType: null,
    mobile: '',
    content: '',
    voucherId: '',
    files: []
})

const createUrl = () => {
    return Number(props.systemId) === 2 ? '/seller/feedback/create' : '/user/feedback/create'
}

const onFeedbackVisible = (t) => {
    showSuccess.value = false
    form.value = {
        feedbackType: t,
        mobile: '',
        content: '',
        voucherId: '',
        files: []
    }
    feedbackVisible.value = true
}

const submitFeedback = (subscribeStatus) => {
    const payload = {
        feedbackType: form.value.feedbackType,
        mobile: form.value.mobile,
        content: form.value.content,
        files: form.value.files,
        voucherId: form.value.voucherId || undefined,
        subscribeStatus: subscribeStatus || {},
    }
    if (Number(props.systemId) !== 2) {
        payload.systemId = props.systemId
    }
    request.post(createUrl(), payload).then(() => {
        showSuccess.value = true
    })
}

const onSubmit = () => {
    if (!form.value.mobile) {
        utils.toast('请填写手机号')
        return
    }
    if (!form.value.content) {
        utils.toast('请填写反馈内容')
        return
    }
    if (form.value.feedbackType === 3 && !form.value.voucherId) {
        utils.toast('请粘贴卡券编号')
        return
    }
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.feedback,
        complete(e) {
            submitFeedback(e || {})
        }
    })
}
</script>

<style scoped>
.footer {
    padding: 80rpx 0 80rpx 0;
}

.footer-meta {
    display: flex;
    align-items: center;
    font-size: 28rpx;
    justify-content: center;
}

.footer-meta .split {
    margin: 0 20rpx;
}

.footer-slogan {
    margin-top: 40rpx;
    text-align: center;
}

.footer-brand {
    font-size: 32rpx;
    font-weight: 600;
    letter-spacing: 2px;
    margin: 0 30rpx;
}

.footer-desc {
    font-size: 24rpx;
    margin-top: 10rpx;
}
</style>
