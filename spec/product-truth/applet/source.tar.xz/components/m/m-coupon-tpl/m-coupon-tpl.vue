<template>
    <view class="coupon">
        <!-- 内容 -->
        <view class="coupon-body">
            <view class="coupon-name">
                <view class="coupon-count" v-if="receiveCount > 1">{{ receiveCount }}张</view>
                <view class="text-ellipsis-break">{{ coupon.name }}</view>
            </view>
            <view v-if="coupon.couponType === COUPON_TYPE.EXCHANGE" class="coupon-exchange text-ellipsis-break">{{
                    coupon.exchangeProduct
                }}
            </view>
            <view v-else class="coupon-valid text-ellipsis-break">{{ coupon.validLabel }}</view>
        </view>

        <!-- 金额 -->
        <view class="coupon-fee">
            <!-- 代金券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.CASH">
                <view class="coupon-amount">
                    <text class="coupon-amount-unit">¥</text>
                    <text class="coupon-amount-money">{{ coupon.faceAmount }}</text>
                </view>
            </template>

            <!-- 套餐券 -->
            <template v-else-if="coupon.couponType === COUPON_TYPE.PACKAGE">
                <view class="coupon-amount">
                    <text class="coupon-amount-unit">¥</text>
                    <text class="coupon-amount-money">{{ coupon.faceAmount }}</text>
                </view>
            </template>

            <!-- 满减券 -->
            <template v-else-if="coupon.couponType === COUPON_TYPE.REDUCE">
                <view class="coupon-amount">
                    <text class="coupon-amount-unit">¥</text>
                    <text class="coupon-amount-money">{{ coupon.reduceAmount }}</text>
                </view>
            </template>

            <!-- 折扣券 -->
            <template v-else-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                <view class="coupon-amount">
                    <text class="coupon-amount-money">{{ coupon.discountAmount }}</text>
                    <text class="coupon-amount-discount">折</text>
                </view>
            </template>

            <!-- 兑换券 -->
            <template v-else-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                <view class="coupon-amount">
                    <img class="exchange-icon" src="/static/img/exchange.png" alt="">
                </view>
            </template>

            <!-- 手气券 -->
            <template v-else-if="coupon.couponType === COUPON_TYPE.RANDOM">
                <view class="coupon-amount">
                    <text class="coupon-amount-unit">¥</text>
                    <text class="coupon-amount-money">{{ coupon.randomMinAmount }}~{{ coupon.randomMaxAmount }}</text>
                </view>
            </template>
            <view class="coupon-threshold">{{ coupon.threshold }}</view>
        </view>
    </view>
</template>

<script setup>
import {COUPON_TYPE} from '@/constants/coupon'

const props = defineProps({
    coupon: {
        type: Object,
        default: () => ({})
    },
    receiveCount: {
        type: Number,
        default: 0
    }
})



</script>

<style scoped>

.coupon {
    position: relative;
    background: #fff;
    border-radius: 20rpx;
    padding: 32rpx 32rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.coupon-fee {
    max-width: 230rpx;
    text-align: right;
}

.coupon-amount {
    display: flex;
    align-items: flex-start;
    justify-content: flex-end;
    color: #f14752;
    gap: 5rpx;
}

.coupon-amount-money {
    font-size: 64rpx;
    font-weight: 600;
}

.coupon-amount-unit {
    font-size: 28rpx;
    font-weight: 600;
    margin-right: 4rpx;
    margin-top: 12rpx;
}

.coupon-amount-discount {
    margin-left: 4rpx;
    font-size: 28rpx;
    font-weight: 600;
    line-height: 30rpx;
    margin-top: 12rpx;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    font-size: 24rpx;
    color: #e2443d;
    margin-top: 6rpx;
}

.coupon-body {
    flex: 1;
    padding-right: 48rpx;
    display: flex;
    flex-direction: column;
    justify-content: center;
    margin-top: 8rpx;
}

.coupon-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #272727;
    margin-bottom: 28rpx;
    display: flex;
    align-items: center;
    gap: 10rpx;
}

.coupon-count {
    width: 58rpx;
    flex-shrink: 0;
    font-size: 20rpx;
    background: #e2443d;
    color: #fff;
    border-radius: 10rpx;
    padding: 4rpx 0;
    text-align: center;
    font-weight: normal;
}

.coupon-valid {
    color: #78797f;
}

.coupon-exchange {
    color: #78797f;
    margin-bottom: 10rpx;
}
</style>
