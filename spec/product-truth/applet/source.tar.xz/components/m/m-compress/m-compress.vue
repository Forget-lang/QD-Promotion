<template>
    <view v-if="show" class="canvas-container">
        <canvas id="Canvas" ref="canvasRef" :style="{ width: cWidth + 'px', height:cHeight + 'px'}" class="canvas-positon"
                type="2d"></canvas>
    </view>
</template>

<script setup>

import {ref, watch, getCurrentInstance} from "vue";
import utils from "@/utils/utils";

const {proxy} = getCurrentInstance()
const emits = defineEmits(['compress'])
const props = defineProps({
    maxSize: {//超过1.5M压缩
        type: Number,
        default: 1,
    }
})
const show = defineModel('show', {
    type: Boolean,
    default: false
})
const tempFile = defineModel('tempFile', {
    type: String
})
const cWidth = ref(320)
const cHeight = ref(320)
const sizeLimit = ref(1280)//缩到的最大边的px数
const imageSize = ref(0)//图片的大小，单位M

const onEmits = () => {
    emits('compress')
    show.value = false
}

const checkFileSize = (size) => {
    imageSize.value = size / 1024 / 1024
    console.log('压缩前的图片大小', size / 1024 / 1024)
    return imageSize.value <= props.maxSize
}

const getFileInfo = (filePath) => {
    uni.getFileSystemManager().getFileInfo({
        filePath: filePath,
        success(res) {
            if (checkFileSize(res.size)) {
                //未超过限制，不压缩
                onEmits()
            } else {
                //超过，去压缩
                canvasImage(filePath)
            }
        },
        fail(err) {
            canvasImage(filePath)
            utils.toast('图片读取失败' + err.errMsg)
        }
    })
}

watch(
    () => show.value,
    () => {
        if (show.value) {
            getFileInfo(tempFile.value)
        }
    }
)

const compressImage = (filePath) => {
    uni.compressImage({
        src: filePath,
        quality: 50,
        success: function (res) {
            tempFile.value = res.tempFilePath
            onEmits()
        },
        fail: function (err) {
            utils.toast('图片压缩失败' + err.errMsg)
            onEmits()
        }
    })
}

const canvasImage = (imagePath) => {
    const query = proxy.createSelectorQuery()
    query.select('#Canvas').fields({
        node: true,
        size: true
    }).exec(function (res) {
        const canvas = res[0].node;
        const ctx = canvas.getContext('2d');
        let image = canvas.createImage();
        image.src = imagePath;
        image.onload = function () {
            let styleWidth = image.width; //单位px
            let styleHeight = image.height; //单位px
            let quality = 0.9
            let scale = 0.9
            // const dpr = uni.getWindowInfo().pixelRatio; //获取设备像素比，物理像素和逻辑像素的比值

            //单位px，逻辑像素，欲压缩到的最大边的px数
            if (Math.max(styleWidth, styleHeight) > sizeLimit.value) {
                var percent = sizeLimit.value / Math.max(styleWidth, styleHeight);
                styleWidth = Math.trunc(styleWidth * percent)
                styleHeight = Math.trunc(styleHeight * percent)
            }

            canvas.width = styleWidth * scale
            canvas.height = styleHeight * scale
            cWidth.value = styleWidth * scale
            cHeight.value = styleHeight * scale

            ctx.clearRect(0, 0, cWidth.value, cHeight.value);
            ctx.drawImage(image, 0, 0, cWidth.value, cHeight.value);

            // console.log('压缩后的图片宽 高 质量 宽高缩放比', cWidth.value, cHeight.value, quality, scale)

            //生成临时文件路径
            wx.canvasToTempFilePath({
                canvas: canvas,
                width: cWidth.value,
                height: cHeight.value,
                destWidth: cWidth.value,
                destHeight: cHeight.value,
                fileType: 'jpg',
                quality: quality,
                success(res) {
                    tempFile.value = res.tempFilePath
                    onEmits()

                    // //打印数据使用
                    // uni.getFileSystemManager().getFileInfo({
                    // 	filePath: tempFile.value,
                    // 	success(res) {
                    // 		console.log('压缩后的图片大小', res.size / 1024 / 1024)
                    // 	},

                    // })

                },
                fail(error) {
                    compressImage(imagePath)
                    utils.toast('图片压缩出错了' + error.errMsg)
                }
            })
        }
    })
}
</script>

<style scoped>

.canvas-positon {
    position: absolute;
    left: -5000px;
    top: -5000px;
}

</style>