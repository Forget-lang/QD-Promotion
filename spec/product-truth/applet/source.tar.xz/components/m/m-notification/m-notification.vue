<template>
	<view class="notification-bar" @click="handleClick">
		<view class="notification-content">
			<t-icon class="notification-icon" type="info" size="40rpx" color="#ff7900"></t-icon>
			<view>{{ content }}</view>
		</view>
		<t-icon type="right" size="32rpx" color="#999"></t-icon>
	</view>
</template>

<script setup>
	import { defineProps, defineEmits } from 'vue'

	const props = defineProps({
		content: {
			type: String,
			default: ''
		}
	})

	const emit = defineEmits(['click'])

	const handleClick = () => {
		emit('click')
	}
</script>

<style scoped>
	.notification-bar {
		background-color: #fdf7e7;
		color: #726c5c;
		padding: 16rpx 20rpx;
		display: flex;
		align-items: center;
		font-size: 28rpx;
		margin: 20rpx 0;
		justify-content: space-between;
		border-radius: 8rpx;
	}

	.notification-content {
		display: flex;
		align-items: center;
		flex: 1;
	}

	.notification-icon {
		margin-right: 12rpx;
	}
</style>