<template>
	<view class="help-link-container text-wechat" :class="props.center ? 'text-center':''" @tap="onLinkClick">
		<text class="help-link-wrap">{{props.text}}</text>
		<t-icon v-if="props.arrow" class="help-link-wrap" name="chevron-right" size="16"></t-icon>
	</view>
</template>

<script setup>
	import { useLink } from "@/hooks/useLink.js"
	const { push } = useLink();
	const props = defineProps({
		text: {
			type: String,
			default: '帮助'
		},
		link: {
			type: String,
			default: ''
		},
		arrow: {
			type: Boolean,
			default: true
		},
		center: {
			type: Boolean,
			default: false
		}
	})
	const onLinkClick = () => {
		if (props.link) {
			push(props.link)
		}
	}
</script>

<style scoped>
	.help-link-container {
		align-items: center;
		font-size: 24rpx;
		display: flex;
	}

	.help-link-wrap {
		height: 40rpx;
		line-height: 40rpx;
		align-items: center;
		vertical-align: middle;
	}
</style>