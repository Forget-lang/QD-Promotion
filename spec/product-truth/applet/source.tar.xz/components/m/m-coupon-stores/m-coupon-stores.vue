<template>
    <view class="store-panel" v-if="stores.length === 1">
        <view class="d-flex justify-content-between align-items-center mt-2">
            <view class="store-panel-name">
                <text>{{ stores[0].name }}</text>
                <image src="https://cdn.lenmy.com/quandao/2026/05/21/d87d6cslbp0t6seglkt0.png" class="audit-icon"></image>
            </view>
            <view class="d-flex align-items-center flex-shrink">
                <view class="menu-item-wrap" @tap="openLocation(stores[0])">
                    <t-icon name="location" size="28rpx"/>
                </view>
                <view class="menu-item-wrap" @tap="utils.makePhoneCall(stores[0].servicePhone)">
                    <t-icon name="call" size="28rpx"/>
                </view>
            </view>
        </view>

        <view class="store-panel-address">
            <text @tap="openLocation(stores[0])">{{ stores[0].address }}</text>
        </view>
    </view>

    <template v-if="theme === 'note'">
        <view class="cell-note" v-if="stores.length > 1" @click="isShowStore = true">
            <view class="cell-note-label">可用门店</view>
            <view class="cell-note-value">
                <text class="cell-note-light">{{ stores.length }}家门店可用</text>
                <text class="dotted">•</text>
                <template v-if="stores[0].distance > 0">
                    <text>最近{{ (stores[0].distance / 1000).toFixed(1) }}km</text>
                    <text class="dotted">•</text>
                    <text>{{ stores[0].address }}</text>
                </template>
                <text v-else>点击查看距离及地址</text>
            </view>
            <t-icon t-class="flex-shrink" name="chevron-right" size="32rpx" color="#999"/>
        </view>
    </template>
    <template v-else-if="theme === 'cell'">
        <t-cell v-if="stores.length > 1" title="适用门店" @click="isShowStore = true" arrow>
            <template #note>
                <text class="text-muted">{{ stores.length }}家适用门店</text>
            </template>
        </t-cell>

    </template>

    <t-popup v-if="stores.length > 0" v-model:visible="isShowStore" placement="bottom">
        <view class="popup-stores-header">
            <text class="popup-header-title">{{ stores.length }}家适用门店</text>
            <view v-if="lat === 0 || lng === 0" class="popup-stores-header-tip">
                <text>查看距离您最近的门店，</text>
                <text class="text-wechat" @tap="getLocation(true)">开启定位</text>
            </view>
            <view class="popup-header-close" @click="isShowStore = false">
                <t-icon name="close" size="50rpx" color="#999"/>
            </view>
        </view>
        <scroll-view class="popup-body mt-2" style="height: 65vh" scroll-y :show-scrollbar="false">
            <m-usage-stores :stores="stores"/>
        </scroll-view>
    </t-popup>

</template>

<script setup>
import {onMounted, ref} from 'vue';
import utils from '@/utils/utils';
import request from "@/hooks/request";

const props = defineProps({
    couponId: {
        type: String,
        default: ''
    },
    theme: {//'cell', 'note'
        type: String,
        default: 'note'
    }
})

const stores = defineModel('stores', {
    type: Array,
    default: []
})

const lat = ref(0)
const lng = ref(0)
const isShowStore = ref(false)

const openLocation = (store) => {
    if (store.lat > 0 && store.lng > 0) {
        wx.openLocation({
            latitude: store.lat, // 纬度，范围为-90~90，负数表示南纬
            longitude: store.lng, // 经度，范围为-180~180，负数表示西经
            scale: 8, // 缩放比例
            name: store.name,
            address: store.address,
            success: function (r) {
            },
            fail: function (e) {
                uni.showToast({
                    icon: 'none',
                    title: e
                })
            }
        })
    } else {
        uni.showToast({
            icon: 'none',
            title: '尚未设置门店地图位置，无法导航'
        })
    }
}

const checkLocationAuth = () => {
    wx.getSetting({
        success(res) {
            let authSetting = res.authSetting
            if (authSetting['scope.userLocation']) {
                //开启了定位权限
                getLocation()
            } else {
                getStores()
            }
        },
        fail() {
            utils.toast('前往小程序设置，开启定位权限后，查看距离您最近的门店')
            getStores()
        }
    })
}

const getLocation = () => {
    wx.getLocation({
        type: 'gcj02',
        success(res) {
            lat.value = res.latitude
            lng.value = res.longitude
            getStores()
        },
        fail(error) {
            if (error.errMsg === 'getLocation:fail auth deny') {
                //拒绝了开启权限
                onSettingLocation()
            } else {
                utils.toast('获取定位失败，请稍后重试')
            }
        },
    })
}

const onSettingLocation = () => {
    wx.openSetting({
        success(res) {
            if (res.authSetting['scope.userLocation'] === true) {
                getLocation(true)
            }
        },
        fail(error) {
            utils.toast('前往小程序设置，开启定位权限后，查看距离您最近的门店')
        }
    })
}

const getStores = () => {
    request.get('/coupon/stores', {
        couponId: props.couponId,
        lat: lat.value,
        lng: lng.value
    }, {
        showLoading: false
    }).then(res => {
        stores.value = res.data.items

    })
}

onMounted(() => {
    checkLocationAuth()
})

</script>

<style scoped>
.store-panel{
    padding: 12rpx 32rpx 0 32rpx;
}
.store-panel-name{
    display: flex;
    font-weight: 600;
    align-content: center;
    font-size:32rpx;
}
.store-panel-address{
    font-size:28rpx;
    margin-top:20rpx;
}
.menu-item-wrap {
    display: flex;
    align-items: center;
    justify-content: center;
    background-color: #eeeeee;
    border-radius: 50%;
    width: 56rpx;
    height: 56rpx;
    margin-left: 20rpx;
}

.cell-note {
    display: flex;
    align-items: center;
    flex: 1;
    margin: 32rpx;
}

.cell-note-label {
    width: 130rpx;
    font-size: 28rpx;
    color: #78797f;
    margin-right: 5rpx;
}

.cell-note-value {
    color: #161722;
    flex: 1;
    overflow: hidden;
    font-style: normal;
    font-size: 28rpx;
    font-weight: normal;
    -webkit-line-clamp: 1;
    text-overflow: ellipsis;
    display: inline-block !important;
    word-break: normal !important;
    white-space: nowrap !important;
}

.cell-note-light {
    font-weight: 500;
    color: #ef8b3c;
}

.dotted {
    margin: 0 12rpx;
}

/*
 * 自定义样式原因：app.css 的 .popup-header 固定 100rpx 高，无法容纳「标题 + 定位提示」两行结构。
 * 替代方案：复用 .popup-header-title / .popup-header-close，仅补缺位容器与提示行样式。
 */
.popup-stores-header {
    position: relative;
    display: flex;
    flex-direction: column;
    padding: 32rpx 96rpx 20rpx 32rpx;
}

.popup-stores-header-tip {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

</style>