<template>
    <view
        v-if="name"
        class="member-level-badge"
        :class="{'member-level-badge-sm': size === 'sm'}"
        :style="badgeStyle"
        @tap.stop="onTap"
    >
        <t-icon
            class="member-level-badge-icon"
            :name="tdIcon"
            :size="iconSize"
            :color="fgColor"
        />
        <text class="member-level-badge-name" :style="nameStyle">{{ name }}</text>
    </view>
</template>

<script setup>
import {computed} from 'vue'
import {getMemberLevelTdIcon, getMemberLevelBadgeColors} from '@/constants/memberLevel'

const props = defineProps({
    name: {type: String, default: ''},
    iconKey: {type: String, default: 'crown'},
    color: {type: String, default: '#d09a45'},
    size: {type: String, default: 'md'}, // sm | md
})

const emit = defineEmits(['click'])

const palette = computed(() => getMemberLevelBadgeColors(props.color))
const fgColor = computed(() => palette.value.fg)
const tdIcon = computed(() => getMemberLevelTdIcon(props.iconKey))
const iconSize = computed(() => (props.size === 'sm' ? '22rpx' : '28rpx'))

const badgeStyle = computed(() => ({
    backgroundColor: palette.value.bg,
}))

const nameStyle = computed(() => ({
    color: fgColor.value,
}))

const onTap = () => emit('click')
</script>

<style scoped>
.member-level-badge {
    display: inline-flex;
    flex-direction: row;
    align-items: center;
    max-width: 280rpx;
    padding: 8rpx 18rpx 8rpx 12rpx;
    border-radius: 12rpx;
    box-sizing: border-box;
}

.member-level-badge-sm {
    padding: 4rpx 12rpx 4rpx 8rpx;
}

.member-level-badge-icon {
    flex-shrink: 0;
}

.member-level-badge-sm .member-level-badge-icon {
    margin-right: 6rpx;
}

.member-level-badge-name {
    font-size: 24rpx;
    line-height: 1.2;
    font-weight: 600;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    margin-left: 10rpx;
}

.member-level-badge-sm .member-level-badge-name {
    font-size: 20rpx;
}
</style>
