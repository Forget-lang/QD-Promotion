<template>
    <view>
        <t-cell t-class="mb-16" :title="props.title" :bordered="false" arrow hover @click="showPopup = true">
            <template #note>
                <text class="text-black lh-24" v-if="valueLabel">{{valueLabel}}</text>
                <text class="lh-24" v-else>{{placeholder}}</text>
            </template>
        </t-cell>

        <!-- 选择弹框 -->
        <t-popup v-model:visible="showPopup" placement="bottom">
            <view class="popup-header">
                <view class="popup-header-cancel" @click="onCancel">取消</view>
                <view class="popup-header-title">{{ props.title }}</view>
                <view class="popup-header-confirm" @click="onConfirm">确定</view>
            </view>
            <scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
                <!-- 多选模式 -->
                <t-checkbox-group v-model:value="tempValue" v-if="props.multiple" @change="onMultipleChange">
                    <t-checkbox v-for="(item,index) in weekOptions" :key="index" :value="item.value" :label="item.label" placement="right" />
                </t-checkbox-group>
                <!-- 单选模式 -->
                <t-radio-group v-model:value="tempRadioValue" v-else @change="onRadioChange">
                    <t-radio v-for="(item,index) in weekOptions" :key="index" :value="item.value" :label="item.label" placement="right" />
                </t-radio-group>
            </scroll-view>
        </t-popup>
    </view>
</template>

<script setup>
import { ref, computed, onMounted } from 'vue'

const props = defineProps({
    title: {
        type: String,
        default: '可用周天',
    },
    placeholder: {
        type: String,
        default: '请选择周期'
    },
    multiple: {
        type: Boolean,
        default: true
    }
})

const weekOptions = [{
        label: '周一',
        value: '1',
    },
    {
        label: '周二',
        value: '2',
    },
    {
        label: '周三',
        value: '3',
    },
    {
        label: '周四',
        value: '4',
    },
    {
        label: '周五',
        value: '5',
    },
    {
        label: '周六',
        value: '6',
    },
    {
        label: '周日',
        value: '0',
    }
]

const modelValue = defineModel('value', {
    type: [String, Array],
    default: ''
})
const showPopup = ref(false)
const tempValue = ref([]) // 多选临时值
const tempRadioValue = ref('') // 单选临时值

const valueLabel = computed(() => {
    if (props.multiple) {
        if (Array.isArray(tempValue.value) && tempValue.value.length > 0) {
            if (tempValue.value.length === 7) {
                return '周一至周日'
            }
            return weekOptions.filter(item => tempValue.value.includes(item.value)).map(item => item.label).join(',')
        }
    } else {
        if (modelValue.value) {
            const week = weekOptions.find(item => String(item.value) === String(modelValue.value))
            return week ? week.label : ''
        }
    }
    return ''
})

// 将当前值复制到临时值
const onInit = () => {
    if (props.multiple) {
        tempValue.value = Array.isArray(modelValue.value) ? [...modelValue.value] : []
    } else {
        tempRadioValue.value = typeof modelValue.value === 'string' ? modelValue.value : ''
    }
}

//多选变更
const onMultipleChange = (e) => {

}

// 单选变更时直接确认关闭
const onRadioChange = (e) => {
    tempRadioValue.value = e.value
    modelValue.value = e.value
    showPopup.value = false
}

// 取消：关闭弹框，不保存
const onCancel = () => {
    showPopup.value = false
}

// 确定：将临时值同步到modelValue
const onConfirm = () => {
    if (props.multiple) {
        modelValue.value = [...tempValue.value]
    } else {
        modelValue.value = tempRadioValue.value || ''
    }
    showPopup.value = false
}

// 全选
const onSelectAll = () => {
    tempValue.value = weekOptions.map(item => item.value)
}

// 清除
const onClear = () => {
    tempValue.value = []
}

onMounted(() => {
    onInit()
})

</script>

<style scoped>
.popup-footer-count {
    font-size: 28rpx;
    color: #999;
}

.popup-footer-right {
    display: flex;
    align-items: center;
    gap: 20rpx;
}
</style>