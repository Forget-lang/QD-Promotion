<template>
    <view class="coupon-flash">
        <view class="coupon-flash-price">
            <!-- 代金券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.CASH">
                <view class="coupon-flash-unit">￥</view>
                <view class="coupon-flash-money">{{ coupon.faceAmount }}</view>
                <view class="coupon-flash-delete">抵用￥{{coupon.originalPrice }}</view>
            </template>
            <!-- 套餐券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.PACKAGE">
                <view class="coupon-flash-unit">￥</view>
                <view class="coupon-flash-money">{{ coupon.faceAmount }}</view>
                <view class="coupon-flash-delete text-decoration">原价￥{{coupon.originalPrice }}</view>
            </template>
            <!-- 满减券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.REDUCE">
                <view class="coupon-flash-unit">￥</view>
                <view class="coupon-flash-money">{{ coupon.reduceAmount }}</view>
                <view class="coupon-flash-delete">{{ coupon.threshold }}</view>
            </template>
            <!-- 折扣券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.DISCOUNT">
                <view class="coupon-flash-money">{{ coupon.discountAmount }}</view>
                <view class="coupon-flash-unit ml-1" style="font-size: 32rpx;">折</view>
                <view class="coupon-flash-delete">{{ coupon.threshold }}</view>
            </template>
            <!-- 兑换券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.EXCHANGE">
                <view class="coupon-flash-money text-ellipsis-break" style="max-width: 320rpx;font-size: 36rpx">{{ coupon.exchangeProduct }}</view>
            </template>
            <!-- 手气券 -->
            <template v-if="coupon.couponType === COUPON_TYPE.RANDOM">
                <view class="coupon-flash-unit">￥</view>
                <view class="coupon-flash-money">{{ coupon.randomMinAmount }}~{{ coupon.randomMaxAmount }}</view>
                <view class="coupon-flash-delete">{{ coupon.threshold }}</view>
            </template>
            <view class="coupon-flash-type">
                <t-icon name="gift-filled" color="#ff3a0b" size="30rpx"></t-icon>
                <text class="ml-1">{{coupon.couponTypeLabel}}</text>
            </view>
        </view>
        <view class="coupon-flash-meta">
            <view class="coupon-flash-tag">{{coupon.isAppt?'需预约':'无需预约'}}</view>
            <view class="coupon-flash-tag ml-1">{{coupon.isTransfer?'可转赠':'不可转赠'}}</view>
            <view class="coupon-flash-tag ml-1" v-if="coupon.isVerifyReward">核销有奖</view>
            <view class="coupon-flash-tag ml-1" v-if="coupon.isTransferReward">转赠有奖</view>
        </view>
    </view>

</template>

<script setup>
import {COUPON_TYPE} from '@/constants/coupon'

const props = defineProps({
    coupon: {
        type: Object,
        default: () => ({})
    }
})

</script>

<style scoped>
.coupon-flash {
    border-radius: 32rpx 32rpx 0 0;
    margin-top: -30rpx;
    padding: 32rpx;
    background: #ff3a0b url("https://cdn.lenmy.com/quandao/2026/05/21/d87cnr4lbp0t6seglksg.png") no-repeat right bottom;
    background-size: 50%;
    position: relative;
    color: #fff;
}

.coupon-flash-price {
    display: flex;
    align-items: center;
}

.coupon-flash-unit {
    font-size: 48rpx;
}

.coupon-flash-money {
    font-size: 64rpx;
    font-weight: 600;
}
.coupon-flash-delete {
    color: rgba(255,255,255,0.8);
    margin-left: 20rpx;
    font-size: 24rpx;
}
.coupon-flash-type {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    margin-left: 20rpx;
    background: #fff;
    font-size:22rpx;
    border-radius: 8rpx;
    padding:5rpx 16rpx;
    color:#ff3a0b;
    font-weight: 600;
}
.coupon-flash-meta{
    margin-top:10rpx;
    display: flex;
    align-items: center;
}
.coupon-flash-tag{
    font-size:24rpx;
    color:#fff;
    background: rgba(255,255,255,0.3);
    border-radius: 8rpx;
    padding:5rpx 16rpx;
}
</style>
