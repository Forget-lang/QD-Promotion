<template>
    <t-grid :column="props.column">
        <t-grid-item t-class="m-tag-select" v-for="item in props.options" :key="item.value">
            <template>
                <view
                    :class="['tag-item', modelValue === item.value ? 'tag-item-active' : '']"
                    @click="onSelect(item)"
                >
                    {{ item.label }}
                </view>
            </template>
        </t-grid-item>
    </t-grid>
</template>

<script setup>
import { ref } from 'vue'

defineOptions({
    options:{
        styleIsolation: 'shared',
    }
})

const props = defineProps({
    options: {
        type: Array,
        default: () => []
    },
    column: {
        type: Number,
        default: 4
    },
})

const emit = defineEmits(['change'])
const modelValue = defineModel('value')

const onSelect = (item) => {
    modelValue.value = item.value
    emit('change', item.value)
}
</script>
<style>
.m-tag-select {
    --td-grid-item-padding:0;
}
</style>
<style scoped>
.tag-item {
    min-width: 84rpx;
    background-color: #f5f5f580;
    border-radius: 10rpx;
    font-size: 26rpx;
    text-align: center;
    color: #666;
    padding: 8rpx 12rpx;
}
.tag-item-active {
    background-color: #00c352;
    color: #fff;
}
</style>
