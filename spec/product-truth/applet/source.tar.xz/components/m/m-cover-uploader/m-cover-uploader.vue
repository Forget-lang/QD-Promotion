<template>
    <view class="cover-container">
        <template v-if="covers.length > 0">
            <view class="image-gride-item" v-for="(media, index) in covers" :key="index"
                  :style="{width: props.width + 'rpx',height: props.height + 'rpx', borderRadius:props.radius + 'rpx'}">
                <image class="item-img" :style="{borderRadius:props.radius + 'rpx'}" :src="media" mode="aspectFill"
                       @tap="onPreView(index)"></image>
                <view class="item-img-del" @tap.stop="onRemove(index)"/>
            </view>
        </template>
        <view v-if="props.max > covers.length || covers.length === 0" class="image-gride-item"
              :style="{width: props.width+'rpx',height: props.height+'rpx',borderRadius:props.radius+'rpx'}">
            <view class="image-upload-add" @tap="onAddTap"
                  :style="{width:props.width+'rpx',height:props.height+'rpx',borderRadius:props.radius+'rpx'}">
                <image style="width: 52rpx;height: 52rpx;" src="@/static/img/camara.png" mode="widthFix"></image>
            </view>
        </view>
    </view>

    <t-popup :visible="uploaderVisible" placement="bottom" :close-on-overlay-click="false">
        <view class="uploader-popup">
            <!-- 顶部标题栏 -->
            <view class="uploader-popup-header">
                <view class="d-flex flex-column align-items-center">
                    <view class="uploader-popup-title">上传后点击图片选择</view>
                    <view class="text-muted mt-1">{{ props.tip }}</view>
                </view>
                <view class="uploader-popup-close">
                    <t-icon name="close" size="50rpx" @click="uploaderVisible = false"/>
                </view>
            </view>

            <!-- 上传选项 -->
            <view class="uploader-options">
                <view class="uploader-option" @click="chooseFromAlbum()">
                    <view class="uploader-option-icon">
                        <t-icon name="image" size="48rpx" color="#333"/>
                    </view>
                    <text class="uploader-option-text">从相册选择</text>
                </view>
                <view class="uploader-option" @click="takePhoto()">
                    <view class="uploader-option-icon">
                        <t-icon name="camera" size="48rpx" color="#333"/>
                    </view>
                    <text class="uploader-option-text">拍照</text>
                </view>
            </view>

            <!-- 图库 -->
            <view class="online-gallery" v-if="props.showAlbum">
                <view class="online-gallery-header">
                    <view class="d-flex align-items-center">
                        <text class="online-gallery-title" @click="onRefresh">媒体图库</text>
                        <t-loading
                            v-if="loading"
                            theme="dots"
                            size="40rpx"
                            t-class="wrapper"
                        />
                    </view>

                    <view class="online-gallery-more">
                        {{ bucketUsed }} / {{ bucketLimit }}MB (已使用{{
                            ((bucketUsed / bucketLimit) * 100).toFixed(1)
                        }}%)
                    </view>
                </view>
                <scroll-view class="uploader-popup-scroll-body" scroll-y :show-scrollbar="false"
                             @scrolltolower="loadMore">
                    <t-row :gutter="16">
                        <t-col v-for="(item, index) in assets" :key="index" :span="8">
                            <view class="online-gallery-item" @click="selectAsset(item)">
                                <image class="online-gallery-image" :src="item.url" mode="aspectFill"/>
                                <text v-if="item.status === MEDIA_AUDIT_STATUS.AUDITING" class="online-gallery-tag tag-review">审核中</text>
                                <text v-if="item.status === MEDIA_AUDIT_STATUS.REJECTED" class="online-gallery-tag tag-violation">违规</text>
                                <view class="online-gallery-delete" @click.stop="deleteAsset(item, index)">
                                    <t-icon name="close" size="28rpx" color="#fff"/>
                                </view>
                            </view>
                        </t-col>
                    </t-row>
                    <view class="load-more-tip" v-if="assets.length > 0">
                        <t-loading v-if="loading" size="40rpx" theme="circular" text="加载中..." />
                        <view v-else-if="isCompleted" class="text-muted">没有更多了</view>
                    </view>
                    <m-empty v-if="assets.length === 0">图库是空的</m-empty>
                </scroll-view>
            </view>
        </view>
    </t-popup>
    <m-compress v-model:show="showCompress" v-model:tempFile="compressFile" @compress="onCompress"></m-compress>
</template>

<script setup>
import {ref, onBeforeUnmount, onMounted, watch} from 'vue'
import {useLink} from "@/hooks/useLink.js"
import utils from '@/utils/utils';
import config from '@/config';
import request from '@/hooks/request';
import {MEDIA_AUDIT_STATUS} from '@/constants/media';
import {getUploadHeader} from '@/utils/upload';

const {push} = useLink();

const emits = defineEmits(['change'])
const props = defineProps({
    width: { //单位rpx
        type: Number,
        default: 120
    },
    height: { //单位rpx
        type: Number,
        default: 120
    },
    radius: { //单位rpx
        type: Number,
        default: 8
    },
    tip: {
        type: String,
        default: '建议图片尺寸300x240px'
    },
    maxSize: { //最大上传限制，单位M
        type: Number,
        default: () => {
            return 5
        }
    },
    max: { //最大数量
        type: Number,
        default: 5
    },
    cropperWidth: { //是否需要裁剪, 单位px, 封面图300*240
        type: Number,
        default: 0
    },
    cropperHeight: { //是否需要裁剪, 单位px，封面图300*240
        type: Number,
        default: 0
    },
    //注册回调方法名儿，防止多次触发回调
    emitName: {
        type: String,
        default: ''
    },
    showAlbum: {
        type: Boolean,
        default: true
    },
    beforeAdd: { //点击添加的前置检测，返回 false 阻止打开选择器（如版本功能受限提示），支持异步
        type: Function,
        default: null
    }
})

const uploaderVisible = ref(false)

// 点击添加入口：配置了 beforeAdd 时先执行检测（支持异步），未通过则不打开选择器
const onAddTap = async () => {
    if (props.beforeAdd && !(await props.beforeAdd())) return
    uploaderVisible.value = true
}
const covers = defineModel('value', {
    type: Array,
    default: []
})

watch(() => uploaderVisible.value, () => {
    if (uploaderVisible.value) {
        page.value = 1
        getAssets()
    }
})

const page = ref(1)
const pageSize = ref(60)
const totalCount = ref(0)
const isCompleted = ref(false)
const loading = ref(false)
const assets = ref([])
const bucketLimit = ref() // 存储空间限制
const bucketUsed = ref() // 商家存储空间使用量
const showCompress = ref(false)
const compressFile = ref('')

// 从相册选择
const chooseFromAlbum = () => {
    chooseImage('album')
}

// 拍照
const takePhoto = () => {
    chooseImage('camera')
}

const onRemove = (e) => {
    covers.value.splice(e, 1)
    emits('change', covers.value)
}

const selectAsset = (item) => {
    if (item.status === MEDIA_AUDIT_STATUS.PASSED) { //审核成功
        covers.value.push(item.url)
        uploaderVisible.value = false
        emits('change', covers.value)
    } else if (item.status === MEDIA_AUDIT_STATUS.AUDITING) { //审核中
        utils.toast('图片正在审核中, 稍后刷新再试')
    } else if (item.status === MEDIA_AUDIT_STATUS.REJECTED) { //审核失败
        utils.toast('图片违规，不可选择')
    }
}

// 删除资源
const deleteAsset = (item, index) => {
    uni.showModal({
        title: '提示',
        content: '确定删除该图片吗？',
        success: (res) => {
            if (res.confirm) {
                request.post('/seller/object/delete', {
                    id: item.id
                }).then(res => {
                    assets.value.splice(index, 1)
                    totalCount.value--
                    utils.toast('删除成功')
                }).catch(err => {
                    utils.toast('删除失败')
                })
            }
        }
    })
}

// 预览图片
const onPreView = (index) => {
    uni.previewImage({
        current: index,
        loop: true,
        urls: covers
    })
}

// 裁切成功之后的回调，上传裁切后的图片
const onCompress = () => {
    uploadCover(compressFile.value)
}

const uploadCover = (file) => {
    utils.showLoading()
    let timestamp = utils.getUnixTime()
    let sign = utils.signParam({}, config.appSecret, timestamp)
    uni.uploadFile({
        url: config.apiUrl + '/seller/object/upload?sign=' + sign + '&timestamp=' + timestamp,
        filePath: file,
        name: 'file',
        header: getUploadHeader(),
        success: (uploadFileRes) => {
            //uploadFile将真实返回结果为Json字符串，封装到data字段中
            utils.hideLoading()
            let result
            try {
                result = JSON.parse(uploadFileRes.data)
            } catch (e) {
                utils.toast('上传响应异常')
                return
            }
            if (result.code === 0) {
                page.value = 1
                setTimeout(() => {
                    getAssets()
                }, 800)
            } else { //上传错误时，使用接口返回的错误信息
                utils.alert(result.message)
            }
        },
        fail: (err) => {
            utils.hideLoading()
            utils.toast('图片上传失败' + err.errMsg)
        }
    });
}

// 选择图片
const chooseImage = (type) => {
    uni.chooseImage({
        count: 1,
        sourceType: [type],
        success: function (e) {
            let size = e.tempFiles[0].size;
            if (props.maxSize * 1024 * 1024 < size) {
                let err = '单张图片大小不能超过：' + props.maxSize + 'MB'
                utils.toast(err)
            } else {
                let tempPath = e.tempFilePaths[0]
                if (props.cropperWidth === 0 || props.cropperHeight === 0) {
                    //不需要裁剪，直接上传
                    compressFile.value = tempPath
                    showCompress.value = true
                } else {
                    //需要裁剪
                    push('/pages_merchant/media/cropper?path=' + tempPath + '&width=' + props.cropperWidth + '&height=' + props.cropperHeight + '&emitName=' + props.emitName)
                }
            }
        },
        fail: function (e) {
            console.log(e)
            if (e.errMsg === 'chooseImage:fail cancel') {
                utils.toast('您取消了操作')
            } else {
                utils.toast('图片选择失败，请稍后再试。' + e.errMsg)
            }
        }
    })
}

// 刷新资源列表
const onRefresh = () => {
    page.value = 1
    assets.value = []
    getAssets()
}

// 获取资源列表
const getAssets = () => {
    //加载更多
    loading.value = true
    request.get('/seller/object/list', {
        page: page.value,
        pageSize: pageSize.value
    }, {
        showLoading: false,
    }).then(res => {
        if (page.value === 1) {
            assets.value = []
        }
        if (res.data.items && res.data.items.length > 0) {
            if (utils.checkLoadMoreData(assets.value, res.data.items, 'id')) {
                assets.value = assets.value.concat(res.data.items)
            }
        }
        bucketLimit.value = res.data.bucketLimit
        bucketUsed.value = res.data.bucketUsed
        totalCount.value = res.data.total
        isCompleted.value = res.data.total === assets.value.length
    }).catch(() => {

    }).finally(() => {
        loading.value = false
    })
}

// 加载更多
const loadMore = () => {
    if (loading.value || isCompleted.value) return
    page.value++
    getAssets()
}

onMounted(() => {
    uni.$on(props.emitName, (file) => {
        compressFile.value = file
        showCompress.value = true
    })

})

onBeforeUnmount(() => {
    uni.$off(props.emitName)
})


</script>

<style scoped>
.cover-container {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    background-color: #ffffff;
    position: relative;
    transition: all 0.3s linear;
}

.image-gride-item {
    position: relative;
    padding: 16rpx;
    justify-content: center;
    text-align: center;
}

.item-img {
    width: 100%;
    height: 100%;
    border-radius: 8rpx;
}

.item-img-del {
    width: 36rpx;
    height: 36rpx;
    position: absolute;
    right: 0;
    top: 0;
    border-radius: 50%;
    color: white;
    font-size: 34rpx;
    z-index: 5;
    background-color: #EB0909;
}

.item-img-del::before {
    content: '';
    width: 16rpx;
    height: 1px;
    position: absolute;
    left: 10rpx;
    top: 18rpx;
    background-color: #fff;
}

.image-upload-add {
    font-weight: 100;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0;
    overflow: hidden;
    box-sizing: border-box;
    background-color: #F7F7F7;
}


/* Popup 弹窗样式 */
.uploader-popup {
    background-color: #fff;
    border-radius: 24rpx 24rpx 0 0;
    overflow: hidden;
}

.uploader-popup-header {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 32rpx 32rpx 24rpx;
    border-radius: 24rpx 24rpx 0 0;
    background-color: #f2f2f2;
}

.uploader-popup-close {
    position: absolute;
    top: 32rpx;
    right: 32rpx;
    cursor: pointer;
}

.uploader-popup-title {
    font-size: 30rpx;
    color: #333;
    font-weight: 600;
    text-align: center;
}

.uploader-popup-scroll-body {
    height: 50vh;
}


/* 上传选项 */
.uploader-options {
    flex-shrink: 0;
    background-color: #f2f2f2;
    display: flex;
    justify-content: space-around;
    padding: 40rpx 32rpx;
    gap: 24rpx;
}

.uploader-option {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    flex: 1;
    height: 160rpx;
    background-color: #fff;
    border-radius: 16rpx;
    transition: all 0.3s;
}

.uploader-option:active {
    background-color: #e8e9eb;
    transform: scale(0.95);
}

.uploader-option-icon {
    width: 80rpx;
    height: 80rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 16rpx;
}

.uploader-option-text {
    font-size: 24rpx;
    color: #333;
}

/* 在线图库 */
.online-gallery {
    background-color: #fff;
    padding: 0 32rpx 32rpx;
    display: flex;
    flex-direction: column;
}

.online-gallery-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24rpx;
    height: 80rpx;
    line-height: 80rpx;
}

.online-gallery-title {
    font-size: 30rpx;
    color: #333;
    font-weight: 600;
    margin-right: 30rpx;
}

.online-gallery-more {
    color: #999;
    font-size: 24rpx;
}

.online-gallery-item {
    position: relative;
    border-radius: 12rpx;
    overflow: hidden;
    flex-shrink: 0;
    transition: all 0.3s;
    margin-bottom: 32rpx;
    background: #f8f8f8;
    width: 100%;
    /* 使用 padding-bottom 维持 5:4 比例，兼容 iOS 14（不支持 aspect-ratio） */
    height: 0;
    padding-bottom: 80%;
}

.online-gallery-item:active {
    transform: scale(0.95);
    opacity: 0.8;
}

.online-gallery-image {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: block;
    object-fit: cover;
}

.online-gallery-tag {
    position: absolute;
    top: 8rpx;
    left: 8rpx;
    font-size: 20rpx;
    padding: 4rpx 12rpx;
    border-radius: 4rpx;
    color: #fff;
    z-index: 5;
}

.tag-review {
    background-color: #ff9900;
}

.tag-violation {
    background-color: #ee0a24;
}

.online-gallery-delete {
    position: absolute;
    top: 8rpx;
    right: 8rpx;
    width: 40rpx;
    height: 40rpx;
    background-color: rgba(0, 0, 0, 0.6);
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    z-index: 10;
}

.load-more-tip {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 40rpx 0;
}

</style>