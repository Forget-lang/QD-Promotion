<template>
    <t-popup placement="bottom" :visible="visible" :round="true" :close-on-overlay-click="canCloseOverlay" @visible-change="onVisibleChange">
        <view class="vip-upgrade" v-if="loaded">
            <view class="vip-handle"></view>
            <view class="vip-close" :style="closeBtnStyle" @click="close">
                <t-icon name="close" size="60rpx" color="#333"/>
            </view>
            <view class="vip-header">
                <view class="vip-title">升级VIP</view>
                <view class="vip-subtitle">选择VIP版本，助力同城私域引流获客，带来一单就是赚。</view>
            </view>
            <view class="vip-cards">
                <view v-for="item in buyableList" :key="item.id" class="vip-card"
                      :class="[themeClass(item), { active: String(selectedId) === String(item.id), current: Number(item.id) === currentId }]"
                      @click="selectEdition(item)">
                    <view class="vip-card-check" v-if="String(selectedId) === String(item.id)">
                        <t-icon name="check" size="20rpx" color="#fff"/>
                    </view>
                    <image class="vip-card-icon" :src="item.iconSmall" mode="aspectFit"/>
                    <view class="vip-card-name">{{ item.name }}</view>
                    <view class="vip-card-price">
                        <text class="vip-card-symbol">¥</text>
                        {{ item.priceYuan }}
                        <text class="vip-card-unit">/年</text>
                    </view>
                    <view class="vip-card-audience">{{ audienceText(item) }}</view>
                </view>
            </view>
            <view class="vip-feat-section" :class="themeClass(selected)" v-if="selectedFeatures.length">
                <view class="vip-feat-head">
                    <view class="vip-feat-head-left">
                        <image class="vip-feat-head-icon" :src="selected.iconSmall" mode="aspectFit"
                               v-if="selected.iconSmall"/>
                        <view class="vip-feat-head-row">
                            <view class="vip-feat-head-title-line">
                                <text class="vip-feat-head-title">{{ selected.name }} · 核心功能</text>
                                <view class="vip-feat-link" @click.stop="openFullFeatures">
                                    <text>完整功能</text>
                                    <t-icon name="chevron-right" size="24rpx" color="#007AFF"
                                            custom-style="margin-left: 2rpx;"/>
                                </view>
                            </view>
                            <text class="vip-feat-head-desc">{{ editionDesc(selected) }}</text>
                        </view>
                    </view>
                </view>
                <view class="vip-feat-grid">
                    <view class="vip-feat-item" v-for="(feat, idx) in selectedFeatures" :key="idx">
                        <view class="vip-feat-no">{{ idx + 1 }}</view>
                        <view class="vip-feat-name-wrap">
                            <text class="vip-feat-name">{{ feat.name }}</text>
                            <image
                                v-if="feat.isHot"
                                class="vip-feat-hot"
                                src="https://cdn.lenmy.com/quandao/2026/09/12/daibk4htv0e54qnjl4s0.png"
                                mode="aspectFit"
                            />
                        </view>
                    </view>
                </view>
            </view>
            <view class="vip-cur-section" v-if="currentId">
                <view class="vip-cur-card" :class="themeClass({ id: currentId })">
                    <view class="vip-cur-row">
                        <view class="vip-cur-left">
                            <image class="vip-cur-icon" :src="currentIcon" mode="aspectFit" v-if="currentIcon"/>
                            <view class="vip-cur-info">
                                <view class="vip-cur-name">{{ currentName }}（当前版本）</view>
                                <view class="vip-cur-expire" v-if="isCurrentFree">永久免费</view>
                                <view class="vip-cur-expire" v-else-if="currentExpire">有效期至：{{ currentExpire }}（剩余
                                    {{ remainDays }} 天）
                                </view>
                                <view class="vip-cur-expire" v-else>未开通或已过期</view>
                            </view>
                        </view>
                    </view>
                </view>
            </view>
            <view class="vip-footer">
                <view class="vip-cta" :class="[{ disabled: !canPay || !agreeChecked }, themeClass(selected)]" @click="onPay">
                    <text v-if="paying">支付中，请勿关闭此页面。</text>
                    <text v-else>{{ payBtnText }}</text>
                </view>
                <view class="vip-agreement" @click="toggleAgree">
                    <view class="vip-agree-box" :class="{ checked: agreeChecked }">
                        <t-icon name="check" size="20rpx" color="#fff" v-if="agreeChecked"/>
                    </view>
                    <text class="vip-agree-text">购买即同意
                        <text class="vip-agree-link" @click.stop="openAgreement">《服务协议》</text>
                        ，7天无理由退款，不自动续费。
                    </text>
                </view>
            </view>
        </view>
    </t-popup>
</template>

<script setup>
import {ref, computed, onMounted, onUnmounted} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useAuth} from '@/hooks/useAuth'
import {PERM_MERCHANT} from '@/constants/permission'
import {EDITION_ID_FREE, getEditionTheme} from '@/constants/edition'
import {VIP_UPGRADE_CLOSE, VIP_UPGRADE_OPEN, VIP_UPGRADE_SUCCESS} from '@/constants/vipUpgrade'

const {checkPermission, getSession} = useAuth()
// 是否有版本升级支付权限（仅创建人、品牌管理员，控制台分配 MerchantUpgrade 权限）
const hasUpgradePerm = computed(() => checkPermission(PERM_MERCHANT.UPGRADE))

// 完整功能对比页 H5 地址
const PRICE_TABLE_H5 = 'https://www.quandaokabao.com/price-table/'
// 弹窗是否可见
const visible = ref(false)
// 是否已完成首次数据加载
const loaded = ref(false)
// 是否正在支付中
const paying = ref(false)
// 是否勾选服务协议
const agreeChecked = ref(true)
// 可购买版本列表
const buyableList = ref([])
// 当前商户版本 ID
const currentId = ref(null)
// 当前商户版本名称
const currentName = ref('')
// 当前商户版本小图标
const currentIcon = ref('')
// 当前商户版本到期日期（YYYY-MM-DD）
const currentExpire = ref('')
// 当前选中的待开通版本 ID
const selectedId = ref(null)
// 版本受众文案映射
const audienceMap = {
    '标准版': '适合个体商户',
    '专业版': '推荐大多商家使用',
    '企业版': '适合连锁/商场商家',
}
// 版本简介文案映射
const editionDescMap = {
    '标准版': '满足基础经营需求，快速开启门店优惠活动',
    '专业版': '助力同城私域引流获客，低成本获客复购',
    '企业版': '全功能解锁，支撑大商家/商场/异业合作运营',
}

// 当前选中的可购买版本
const selected = computed(() => buyableList.value.find(i => String(i.id) === String(selectedId.value)))

// 当前是否免费版（免费版不展示到期时间）
const isCurrentFree = computed(() => String(currentId.value) === String(EDITION_ID_FREE))

// 是否选中了当前已开通版本（续费）
const isRenew = computed(() => !!selected.value && Number(selected.value.id) === currentId.value)

// 是否跨版本（付费版换另一付费版）
const isCrossEdition = computed(() => {
    if (!selected.value) return false
    if (Number(selected.value.id) === currentId.value) return false
    return String(currentId.value) !== String(EDITION_ID_FREE)
})

// 是否可点击支付按钮（需具备版本升级支付权限）
const canPay = computed(() => hasUpgradePerm.value && !!selected.value && !paying.value)

// 支付中禁用遮罩点击关闭弹窗，避免用户误以为关窗即取消扣款
const canCloseOverlay = computed(() => !paying.value)

// 支付中关闭按钮置灰视觉反馈（t-icon 在 v-if 分支内，scoped 类选择器易失配，用内联样式兜底）
const closeBtnStyle = computed(() => `opacity: ${paying.value ? 0.4 : 1};`)

// 支付按钮文案
const payBtnText = computed(() => {
    if (!hasUpgradePerm.value) return '仅创建人或品牌管理员可升级'
    if (!selected.value) return '请选择要开通的版本'
    const label = isRenew.value ? '立即续费' : '立即开通'
    return `${label}${selected.value.name} ¥${selected.value.priceYuan}/年`
})

// 当前版本剩余有效天数
const remainDays = computed(() => {
    if (!currentExpire.value) return 0
    const t = new Date(currentExpire.value.replace(/-/g, '/'))
    return Math.ceil((t.getTime() - Date.now()) / 86400000)
})

// 选中版本的核心功能列表
const selectedFeatures = computed(() => selected.value?.coreFeatures || [])

// 按版本 ID 返回主题 class（tone 为视觉色名 blue/orange/purple，对应 .theme-* 样式类；免费版无主题色，返回空串走兜底样式）
const themeClass = (i) => {
    const t = getEditionTheme(i?.id)
    return t.tone ? `theme-${t.tone}` : ''
}

// 按版本名返回受众文案
const audienceText = (i) => audienceMap[i.name] || ''

// 按版本名返回简介文案
const editionDesc = (i) => editionDescMap[i?.name] || ''

// 拉取可购买版本列表
const fetchBuyable = async () => {
    const res = await request.get('/seller/order/edition/buyable', {}, {
        showLoading: false,
    })
    buyableList.value = res.data.items || []
}

// 拉取并应用当前商户版本信息（统一走 useAuth 的 getSession，每次打开都重新请求）
const getCurrentEdition = async () => {
    const d = (await getSession()) || {}
    currentId.value = Number(d.editionId)
    currentName.value = d.editionName
    currentIcon.value = d.editionIconSmall
    currentExpire.value = String(d.editionExpiredAt || '').slice(0, 10)
}

// 打开升级弹窗（版本列表仅首次拉取；当前版本每次直拉）
// targetEditionId：可选，传入时直接选中该可购买版本（版本受限提醒跳转场景），否则默认选中当前版本
const open = async (targetEditionId) => {
    visible.value = true
    if (!loaded.value) {
        await fetchBuyable()
        loaded.value = true
    }
    await getCurrentEdition()
    const target = targetEditionId != null
        ? buyableList.value.find(i => Number(i.id) === Number(targetEditionId))
        : null
    const cur = target || buyableList.value.find(i => Number(i.id) === currentId.value)
    selectedId.value = cur ? cur.id : buyableList.value[0]?.id
}

// 关闭升级弹窗（支付中禁止关闭，避免误以为关窗即取消扣款）
const close = () => {
    if (paying.value) {
        utils.toast('支付处理中，请勿关闭此页面')
        return
    }
    visible.value = false
}

// 弹层可见性变化回调（支付中拦截组件内部的关闭请求）
const onVisibleChange = (v) => {
    if (!v && paying.value) return
    visible.value = v
}

// 切换服务协议勾选（支付中禁止改动）
const toggleAgree = () => {
    if (paying.value) return
    agreeChecked.value = !agreeChecked.value
}

// 选择版本卡片
const selectEdition = (item) => {
    if (paying.value) return
    selectedId.value = item.id
}

// 打开服务协议页
const openAgreement = () => {
    uni.navigateTo({url: '/pages_assist/agreement/agreement'})
}

// 打开完整功能对比 H5
const openFullFeatures = () => {
    uni.navigateTo({
        url: `/pages_assist/help/article?url=${encodeURIComponent(PRICE_TABLE_H5)}&title=${encodeURIComponent('完整功能对比')}`,
    })
}

// 校验微信基础库与 iOS 客户端版本是否满足虚拟支付
const checkPayEnv = () => {
    const si = uni.getSystemInfoSync()
    if (si.SDKVersion) {
        const p = si.SDKVersion.split('.').map(Number)
        if (p[0] < 2 || (p[0] === 2 && p[1] < 19) || (p[0] === 2 && p[1] === 19 && p[2] < 2)) {
            utils.toast('请升级微信版本后再试')
            return false
        }
    }
    if (si.platform === 'ios' && si.version) {
        const v = si.version.split('.').map(Number)
        if (v[0] < 8 || (v[0] === 8 && v[1] === 0 && (v[2] || 0) < 68)) {
            utils.toast('iOS 端支付需微信 8.0.68 及以上，请升级微信')
            return false
        }
    }
    return true
}

// 发起虚拟支付开通或续费选中版本
const onPay = async () => {
    if (!hasUpgradePerm.value) {
        uni.showModal({
            title: '提示',
            content: '仅创建人或品牌管理员可升级版本',
            showCancel: false,
            confirmText: '知道了',
        })
        return
    }
    if (!selected.value || paying.value) return
    if (!agreeChecked.value) {
        utils.toast('请先同意服务协议')
        return
    }
    if (isCrossEdition.value) {
        uni.showModal({
            title: '提示',
            content: '不支持跨版本升级，请版本过期后购买或联系客服',
            showCancel: false,
            confirmText: '知道了',
        })
        return
    }
    if (!checkPayEnv()) return
    paying.value = true
    try {
        const {code: loginCode} = await new Promise((r, j) => wx.login({success: r, fail: j}))
        if (!loginCode) {
            utils.toast('登录失败，请重试')
            return
        }
        const res = await request.post('/seller/order/virtual/create', {
            editionId: selected.value.id,
            loginCode,
        })
        const {signData, paySig, signature, mode, offerId, buyQuantity, env, orderId} = res.data
        await new Promise((r, j) => wx.requestVirtualPayment({
            signData,
            paySig,
            signature,
            mode,
            offerId,
            buyQuantity,
            env,
            success: r,
            fail: j,
        }))
        await pollOrderStatus(orderId)
        // 成功分支先行复位 paying，否则 close() 会被支付中守卫拦截、弹窗关不掉
        paying.value = false
        utils.toast(isRenew.value ? '续费成功' : '开通成功')
        uni.$emit(VIP_UPGRADE_SUCCESS, {orderId, editionId: selected.value.id})
        uni.navigateTo({url: `/pages_merchant/order/success?orderId=${orderId}`})
        close()
    } catch (e) {
        if (e?.errMsg?.indexOf('cancel') > -1) {
            utils.toast('已取消支付')
            return
        }
        utils.alert(e?.message || e?.errMsg || '支付失败')
    } finally {
        paying.value = false
    }
}

// 轮询虚拟支付订单状态直至成功/关闭/超时
const pollOrderStatus = (orderId) => new Promise((resolve, reject) => {
    let times = 0
    const timer = setInterval(async () => {
        times++
        try {
            const res = await request.get('/seller/order/virtual/status', {orderId}, {disableErrorToast: true})
            const status = res.data.orderStatus
            if (status === 'success') {
                clearInterval(timer)
                resolve(res.data)
                return
            }
            if (status === 'closed') {
                clearInterval(timer)
                reject(new Error('订单已关闭'))
                return
            }
            if (times > 10) {
                clearInterval(timer)
                reject(new Error('支付结果确认超时'))
            }
        } catch (e) {
            if (times > 10) {
                clearInterval(timer)
                reject(e)
            }
        }
    }, 500)
})

// 解析打开事件载荷：兼容无参、{ editionId }、历史误传裸 id
const resolveOpenEditionId = (payload) => {
    if (payload == null || payload === '') return undefined
    if (typeof payload === 'object' && !Array.isArray(payload)) {
        return payload.editionId
    }
    return payload
}

// 宿主页面路由（组件创建时页面栈顶即宿主；须常驻挂载，勿放 v-if）
// App.vue 不能写 template（uni-app 官方），故各业务页各挂一份；仅栈顶宿主响应，防止多实例同开
const hostRoute = getCurrentPages().slice(-1)[0]?.route

const onUpgradeOpen = (payload) => {
    const topRoute = getCurrentPages().slice(-1)[0]?.route
    if (topRoute !== hostRoute) return
    open(resolveOpenEditionId(payload))
}

onMounted(() => {
    uni.$on(VIP_UPGRADE_OPEN, onUpgradeOpen)
    uni.$on(VIP_UPGRADE_CLOSE, close)
})

onUnmounted(() => {
    uni.$off(VIP_UPGRADE_OPEN, onUpgradeOpen)
    uni.$off(VIP_UPGRADE_CLOSE, close)
})

defineExpose({open, close})
</script>

<style scoped lang="scss">
/* 弹窗容器：白底圆角面板，限高滚动，适配底部安全区 */
.vip-upgrade {
    max-height: 80vh;
    overflow-y: auto;
    background: #fff;
    border-radius: 24rpx 24rpx 0 0;
}

/* 顶部拖拽指示条 */
.vip-handle {
    width: 64rpx;
    height: 8rpx;
    border-radius: 4rpx;
    background: #e0e0e0;
    margin: 16rpx auto 0;
}

/* 右上角关闭按钮 */
.vip-close {
    position: absolute;
    top: 28rpx;
    right: 32rpx;
    z-index: 10;
}

/* 头部标题区 */
.vip-header {
    padding: 12rpx 32rpx 28rpx;
}

.vip-title {
    font-size: 40rpx;
    font-weight: bold;
    color: #1a1a1a;
}

.vip-subtitle {
    margin-top: 12rpx;
    font-size: 26rpx;
    color: #999;
}

/* 版本卡片 3列等宽 */
.vip-cards {
    display: flex;
    gap: 16rpx;
    padding: 0 32rpx;
}

.vip-card {
    position: relative;
    flex: 1;
    padding: 26rpx 12rpx 32rpx;
    border: 3rpx solid transparent;
    border-radius: 20rpx;
    text-align: center;
    background: #fff;
}

/* 选中兜底描边（无主题色版本） */
.vip-card.active {
    border-color: var(--edition-standard-color, #007AFF);
}

/* 选中角标：卡片右上角内侧 */
.vip-card-check {
    position: absolute;
    top: 4rpx;
    right: 4rpx;
    width: 36rpx;
    height: 36rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
}

.vip-card-icon {
    width: 80rpx;
    height: 80rpx;
    margin: 0 auto;
    display: block;
}

.vip-card-icon-fallback {
    width: 64rpx;
    height: 64rpx;
    margin: 0 auto 16rpx;
    border-radius: 16rpx;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 32rpx;
    color: #999;
}

.vip-card-name {
    font-size: 28rpx;
    font-weight: bold;
    color: #333;
}

.vip-card-price {
    margin-top: 12rpx;
    font-size: 40rpx;
    font-weight: bold;
    color: #1a1a1a;
}

/* 价格 ¥ 符号缩小 */
.vip-card-symbol {
    font-size: 26rpx;
}

/* /年 跟随主题价格色 */
.vip-card-unit {
    font-size: 24rpx;
    font-weight: normal;
    color: inherit;
}

.vip-card-audience {
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #999;
}

/* 主题变量别名：主色/浅底引用 App.vue 全局 --edition-* 变量；light 浅背景、半透明描边、编号底为本组件派生色（换主题色需与 constants/edition.js 同步） */
.theme-blue {
    --theme-color: var(--edition-standard-color, #007AFF);
    --theme-bg: var(--edition-standard-bg, #E6F2FF);
    --theme-light: #E9F3FF;
    --theme-no-bg: #CDE4FF;
    --theme-border-alpha: #007AFF50;
    background: var(--theme-bg);
    border-color: transparent;
}

.theme-blue.active {
    border-color: var(--theme-color);
}

.theme-blue .vip-card-check {
    background: var(--theme-color);
}

.theme-blue .vip-card-price {
    color: var(--theme-color);
}

.theme-orange {
    --theme-color: var(--edition-professional-color, #FF9500);
    --theme-bg: var(--edition-professional-bg, #FFF5E6);
    --theme-light: #FFF6E9;
    --theme-no-bg: #FFE2B8;
    --theme-border-alpha: #FF950050;
    background: var(--theme-bg);
    border-color: transparent;
}

.theme-orange.active {
    border-color: var(--theme-color);
}

.theme-orange .vip-card-check {
    background: var(--theme-color);
}

.theme-orange .vip-card-price {
    color: var(--theme-color);
}

.theme-purple {
    --theme-color: var(--edition-enterprise-color, #7B61FF);
    --theme-bg: var(--edition-enterprise-bg, #F0EBFF);
    --theme-light: #F1ECFF;
    --theme-no-bg: #DDD4FF;
    --theme-border-alpha: #7B61FF50;
    background: var(--theme-bg);
    border-color: transparent;
}

.theme-purple.active {
    border-color: var(--theme-color);
}

.theme-purple .vip-card-check {
    background: var(--theme-color);
}

.theme-purple .vip-card-price {
    color: var(--theme-color);
}

/* 核心功能区：白卡 + 主题色头部横带 */
.vip-feat-section {
    margin: 24rpx 32rpx 0;
    padding: 0;
    background: #fff;
    border: 2rpx solid #F0F2F5;
    border-radius: 20rpx;
    overflow: hidden;
}

.vip-feat-section.theme-blue {
    border-color: var(--theme-border-alpha);
}

.vip-feat-section.theme-orange {
    border-color: var(--theme-border-alpha);
}

.vip-feat-section.theme-purple {
    border-color: var(--theme-border-alpha);
}

.vip-feat-head {
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 20rpx 14rpx 36rpx;
    background: #F7F9FC;
}

.vip-feat-section.theme-blue .vip-feat-head {
    background: var(--theme-light);
}

.vip-feat-section.theme-orange .vip-feat-head {
    background: var(--theme-light);
}

.vip-feat-section.theme-purple .vip-feat-head {
    background: var(--theme-light);
}

.vip-feat-head-left {
    display: flex;
    align-items: center;
    width: 100%;
    min-width: 0;
}

.vip-feat-head-row {
    flex: 1;
    min-width: 0;
    margin-left: 6rpx;
}

.vip-feat-head-title-line {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12rpx;
}

.vip-feat-head-icon {
    width: 70rpx;
    height: 70rpx;
    margin-right: 10rpx;
    flex-shrink: 0;
}

.vip-feat-head-title {
    flex: 1;
    min-width: 0;
    font-size: 30rpx;
    font-weight: bold;
    color: #1a1a1a;
}

.vip-feat-head-desc {
    display: block;
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #999;
}

.vip-feat-link {
    display: flex;
    align-items: center;
    flex-shrink: 0;
    font-size: 24rpx;
    color: #007AFF;
    padding: 0;
}

/* 核心功能：三列编号卡片，颜色跟随版本主题 */
.vip-feat-grid {
    display: grid;
    grid-template-columns: 1fr 1fr 1fr;
    gap: 16rpx;
    padding: 24rpx 20rpx 16rpx;
    margin-top: -20rpx;
    background: #FFFFFF;
    border-radius: 20rpx;
}

.vip-feat-item {
    display: flex;
    align-items: center;
    min-width: 0;
    padding: 18rpx 14rpx;
    border-radius: 12rpx;
    background: #F7F8FA;
}

.vip-feat-no {
    width: 36rpx;
    height: 36rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-shrink: 0;
    margin-right: 10rpx;
    font-size: 22rpx;
    font-weight: 600;
    color: #666;
    background: #E8E8E8;
}

.vip-feat-name-wrap {
    position: relative;
    flex: 1;
    min-width: 0;
    padding-right: 8rpx;
}

.vip-feat-name {
    display: block;
    font-size: 24rpx;
    font-weight: 600;
    color: #333;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.vip-feat-hot {
    position: absolute;
    top: -14rpx;
    right: -6rpx;
    width: 28rpx;
    height: 28rpx;
}

.vip-feat-section.theme-blue .vip-feat-item {
    background: var(--theme-light);
}

.vip-feat-section.theme-blue .vip-feat-no {
    color: var(--theme-color);
    background: var(--theme-no-bg);
}

.vip-feat-section.theme-orange .vip-feat-item {
    background: var(--theme-bg);
}

.vip-feat-section.theme-orange .vip-feat-no {
    color: var(--theme-color);
    background: var(--theme-no-bg);
}

.vip-feat-section.theme-purple .vip-feat-item {
    background: var(--theme-light);
}

.vip-feat-section.theme-purple .vip-feat-no {
    color: var(--theme-color);
    background: var(--theme-no-bg);
}

/* 当前版本：浅灰卡 + 卡内标题 */
.vip-cur-section {
    margin: 24rpx 32rpx 0;
}

.vip-cur-card {
    padding: 24rpx 28rpx;
    background: #F7F8FA;
    border-radius: 20rpx;
}

/* 当前版本卡片底色跟随当前版本主题（默认浅灰，如免费版） */
.vip-cur-card.theme-blue {
    background: var(--theme-bg);
}

.vip-cur-card.theme-orange {
    background: var(--theme-bg);
}

.vip-cur-card.theme-purple {
    background: var(--theme-bg);
}

.vip-cur-row {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.vip-cur-left {
    display: flex;
    align-items: center;
    flex: 1;
}

.vip-cur-icon {
    width: 72rpx;
    height: 72rpx;
    margin-right: 16rpx;
}

.vip-cur-name {
    font-size: 30rpx;
    font-weight: bold;
    color: #1a1a1a;
}

.vip-cur-expire {
    font-size: 22rpx;
    color: #666;
    margin-top: 6rpx;
}

/* 底部：CTA 在上，协议居中在下 */
.vip-footer {
    padding: 32rpx 32rpx 40rpx 32rpx;
}

.vip-agreement {
    display: flex;
    align-items: center;
    justify-content: center;
    margin-top: 24rpx;
}

.vip-agree-box {
    width: 32rpx;
    height: 32rpx;
    border: 2rpx solid #ccc;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-right: 12rpx;
}

.vip-agree-box.checked {
    background: #007AFF;
    border-color: #007AFF;
}

.vip-agree-text {
    font-size: 24rpx;
    color: #999;
}

.vip-agree-link {
    color: #007AFF;
}

.vip-cta {
    height: 88rpx;
    border-radius: 44rpx;
    background: #007AFF;
    display: flex;
    align-items: center;
    justify-content: center;
    color: #fff;
    font-size: 30rpx;
    font-weight: bold;
}

/* CTA 跟随选中版本主题色（disabled 置灰优先级更高，规则需位于其后） */
.vip-cta.theme-blue {
    background: var(--theme-color);
}

.vip-cta.theme-orange {
    background: var(--theme-color);
}

.vip-cta.theme-purple {
    background: var(--theme-color);
}

.vip-cta.disabled {
    background: #ccc;
}
</style>
