<template>
    <view :class="['card-panel', 'times-card', {'is-inactive': isInactive}]" :style="panelStyle">
        <image class="times-card-deco times-card-deco-bg" :src="cardBg" mode="aspectFill"/>
        <view class="times-card-deco times-card-deco-glow" :style="glowStyle"></view>
        <view class="times-card-deco times-card-deco-fade" :style="fadeStyle"></view>

        <view class="times-card-aside">
            <text class="times-card-merchant-name text-ellipsis">{{ merchantName || '商户名称' }}</text>
            <image v-if="cover" class="times-card-cover" :src="cover" mode="aspectFill"/>
            <view v-else class="times-card-cover times-card-cover-empty">
                <t-icon name="gift-filled" size="36rpx" color="rgba(255,255,255,0.6)"/>
            </view>
        </view>

        <view class="times-card-inner">
            <view class="times-card-focus">
                <view class="times-card-name text-ellipsis-break">{{ title }}</view>
                <view class="times-card-times" v-if="cardType !== CARD_TYPE.UNLIMITED">
                    <text class="times-card-times-num">{{ remainTimes !== null ? remainTimes : totalTimes }}</text>
                    <text class="times-card-times-unit">次</text>
                    <text v-if="remainTimes !== null" class="times-card-total">/ 共 {{ totalTimes }} 次</text>
                </view>

                <!-- 通卡：展示已使用次数（仅顾客端传入 usedTimes 时显示，商家端模板不传则隐藏） -->
                <view class="times-card-times" v-else-if="usedTimes !== null && usedTimes > 0">
                    <text class="times-card-times-num">{{ usedTimes }}</text>
                    <text class="times-card-times-unit">次</text>
                    <text class="times-card-total">/ 已使用</text>
                </view>

            </view>

            <view class="times-card-foot">
                <view class="times-card-badge">{{ badgeText }}</view>
                <text class="times-card-valid text-ellipsis">{{ validLabel }}</text>
            </view>
        </view>

        <!-- 非可用状态印戳：商家模板 / 顾客已领均传 status + statusLabel -->
        <view v-if="showStatusStamp" class="times-card-stamp">
            <text class="times-card-stamp-text">{{ statusLabel }}</text>
        </view>
    </view>
</template>

<script setup>
import {computed} from 'vue'
import {getTheme, getThemeStyle} from '@/utils/theme.js'
import {CARD_TYPE} from '@/constants/card'

defineOptions({
    options: {
        styleIsolation: 'shared',
    },
})

// 磁卡背景图
const cardBg = 'https://cdn.lenmy.com/quandao/2026/07/09/d97i2q5b4ek5e3hu8pn0.png'

const props = defineProps({
    theme: {type: Number, default: 1},
    merchantName: {type: String, default: ''},
    cover: {type: String, default: ''},
    title: {type: String, default: ''},
    // 通卡（UNLIMITED）不展示任何数量
    cardType: {type: Number, default: CARD_TYPE.BENEFIT},
    totalTimes: {type: Number, default: 0},
    remainTimes: {type: Number, default: null},
    // 通卡已核销次数（仅顾客端传入时展示；商家端模板不传，默认 null 不显示）
    usedTimes: {type: Number, default: null},
    validLabel: {type: String, default: ''},
    // 商家端：模板 CardStatus；顾客端：已领 CardReceiveStatus（数值语义不同，文案用 statusLabel）
    status: {type: Number, default: 0},
    statusLabel: {type: String, default: ''},
})

// 卡面角标：通卡/次卡/权益卡区分
const badgeText = computed(() => {
    if (props.cardType === CARD_TYPE.UNLIMITED) return '通卡'
    if (props.cardType === CARD_TYPE.TIMES) return '次卡'
    return '权益卡'
})

// 当前主题色值
const themeColor = computed(() => getTheme(props.theme).color)

// 卡片根节点样式（背景色 + 主题 CSS 变量）
const panelStyle = computed(() => getThemeStyle(props.theme))

// 非可用（status 有值且不为 1）
const isInactive = computed(() => Number(props.status) > 1)

// 有文案时才打印戳
const showStatusStamp = computed(() => isInactive.value && !!props.statusLabel)

// 十六进制颜色转 rgba
const hexToRgba = (hex, alpha) => {
    const value = String(hex || '').replace('#', '')
    if (value.length !== 6) {
        return `rgba(255, 255, 255, ${alpha})`
    }
    const r = parseInt(value.slice(0, 2), 16)
    const g = parseInt(value.slice(2, 4), 16)
    const b = parseInt(value.slice(4, 6), 16)
    return `rgba(${r}, ${g}, ${b}, ${alpha})`
}

// 右上角光晕装饰层样式
const glowStyle = computed(() => ({
    background: `radial-gradient(circle at 88% 6%, rgba(255, 255, 255, 0.22) 0%, transparent 54%)`,
}))

// 主题色渐变蒙层样式
const fadeStyle = computed(() => ({
    background: `linear-gradient(165deg, ${hexToRgba(themeColor.value, 0.15)} 0%, transparent 42%, rgba(0, 0, 0, 0.12) 100%)`,
}))
</script>

<style scoped>
.times-card {
    position: relative;
    border-radius: 24rpx;
    padding: 32rpx;
    overflow: hidden;
    /* 固定卡片高度：避免通卡缺少次数行时与次卡/权益卡高度不一致 */
    height: 296rpx;
    box-sizing: border-box;
}

.times-card.is-inactive {
    opacity: 0.82;
}

.times-card-stamp {
    position: absolute;
    right: 48rpx;
    top: 50%;
    z-index: 3;
    transform: translateY(-50%) rotate(-18deg);
    pointer-events: none;
}

.times-card-stamp-text {
    display: block;
    padding: 8rpx 20rpx;
    font-size: 28rpx;
    font-weight: 600;
    line-height: 1.2;
    color: rgba(255, 255, 255, 0.88);
    border: 3rpx solid rgba(255, 255, 255, 0.55);
    border-radius: 8rpx;
    letter-spacing: 4rpx;
    white-space: nowrap;
}

.times-card-deco {
    position: absolute;
    inset: 0;
    pointer-events: none;
    border-radius: 24rpx;
}

.times-card-deco-bg {
    z-index: 0;
    width: 100%;
    height: 100%;
}

.times-card-inner {
    position: relative;
    z-index: 1;
    display: flex;
    flex-direction: column;
    height: 100%;
}

.times-card-aside {
    position: absolute;
    top: 45rpx;
    right: 32rpx;
    width: 220rpx;
    display: flex;
    flex-direction: column;
    align-items: flex-end;
    z-index: 2;
}

.times-card-merchant-name {
    max-width: 100%;
    font-size: 24rpx;
    font-weight: 500;
    color: rgba(255, 255, 255, 0.72);
    text-align: right;
    line-height: 1.4;
    margin-bottom: 28rpx;
}

.times-card-cover {
    width: 140rpx;
    height: 100rpx;
    border-radius: 12rpx;
    flex-shrink: 0;
    display: block;
    background: rgba(255, 255, 255, 0.12);
}

.times-card-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
}

.times-card-focus {
    padding-right: 230rpx;
}

.times-card-name {
    font-size: 44rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.35;
}

.times-card-times {
    margin-top: 28rpx;
    display: flex;
    align-items: baseline;
}

.times-card-times-num {
    font-size: 64rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1;
}

.times-card-times-unit {
    margin-left: 6rpx;
    font-size: 30rpx;
    color: rgba(255, 255, 255, 0.88);
}

.times-card-total {
    margin-left: 10rpx;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.72);
}

.times-card-foot {
    margin-top: auto;
    padding-top: 40rpx;
    display: flex;
    align-items: flex-end;
    justify-content: space-between;
    gap: 24rpx;
}

.times-card-badge {
    flex-shrink: 0;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.88);
    padding: 6rpx 16rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.35);
    border-radius: 8rpx;
}

.times-card-valid {
    flex: 1;
    min-width: 0;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.72);
    text-align: right;
    line-height: 1.5;
}
</style>
