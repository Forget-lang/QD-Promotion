<template>
    <t-navbar :title="props.title" :t-class="props.class" :z-index="props.zIndex">
        <template #title>
            <view class="title-slot-wrapper">
                <slot name="title"></slot>
            </view>
        </template>
        <template #capsule>
            <view class="custom-capsule" :style="capsuleStyle">
                <t-icon
                    size="40rpx"
                    aria-role="button"
                    aria-label="返回"
                    name="chevron-left"
                    :color="iconColor"
                    :t-class="getIconTClass('back')"
                    :class="''+getIconClass('back')"
                    @click="onBack"
                />
                <view class="capsule-divider" :style="{ background: dividerColor }"></view>
                <t-icon
                    size="34rpx"
                    aria-role="button"
                    aria-label="首页"
                    name="home"
                    :color="iconColor"
                    :t-class="getIconTClass('home')"
                    :class="''+getIconClass('home')"
                    @click="onGoHome"
                />
            </view>
        </template>
    </t-navbar>
</template>

<script setup>
import {onMounted, ref, computed} from 'vue'
import {canUseVirtualHost} from '@/uni_modules/tdesign-uniapp/components/common/version'
import {useLink} from '@/hooks/useLink'

const {reLaunch, back} = useLink()

defineOptions({
    options: {
        styleIsolation: 'shared',
    }
})

const props = defineProps({
    title: {
        type: String,
        default: ''
    },
    class: {
        type: String,
        default: ''
    },
    scrollY: {
        type: Number,
        default: 0
    },
    threshHeight: {
        type: Number,
        default: 200
    },
    hasCover: {
        type: Boolean,
        default: true
    },
    homeUrl: {
        type: String,
        default: '/pages/index/index'
    },
    // 导航栏层级（透传 t-navbar）：默认 10，需高于封面页 hero-info(3) / member-card(4) 等内容层，避免滚动到顶部时被内容遮挡
    zIndex: {
        type: Number,
        default: 10
    }
})

const isCanBack = ref(false)

const iconColor = computed(() => {
    if (opacity.value >= 1) return "#333"
    if (!props.hasCover) return "#333"
    return "#fff"
})
const dividerColor = computed(() => {
    if (opacity.value >= 1) return "rgba(51,51,51,0.8)"
    if (!props.hasCover) return "rgba(51,51,51,0.8)"
    return "rgba(255,255,255,0.8)"
})

const opacity = computed(() => {
    return Math.min(props.scrollY / props.threshHeight, 1)
})

const capsuleStyle = computed(() => {
    if (opacity.value >= 1) {
        return {
            background: 'rgba(0, 0, 0, 0.1)',
            backdropFilter: 'blur(0px)',
            border: '0.5px solid rgba(0, 0, 0, 0.08)'
        }
    }
    //页面背景为浅色，capsule 需要用深色样式保证可见性
    if (!props.hasCover) {
        return {
            background: 'rgba(0, 0, 0, 0.06)',
            backdropFilter: 'blur(0px)',
            border: '0.5px solid rgba(0, 0, 0, 0.08)'
        }
    }
    const blur = 10 + opacity.value * 10
    const bgAlpha = 0.15 + opacity.value * 0.25
    return {
        background: `rgba(255, 255, 255, ${bgAlpha})`,
        backdropFilter: `blur(${blur}px)`,
        border: `0.5px solid rgba(255, 255, 255, ${0.15 + opacity.value * 0.1})`
    }
})

const onBack = () => {
    if (isCanBack.value) {
        back()
    } else {
        onGoHome()
    }
}
const onGoHome = () => {
    reLaunch(props.homeUrl)
}
const getIconTClass = (name) => {
    return canUseVirtualHost() ? getIconRealClass(name) : ''
}
const getIconClass = (name) => {
    return !canUseVirtualHost() ? getIconRealClass(name) : ''
}
const getIconRealClass = (name) => {
    return `custom-capsule__icon ${name}`
}
onMounted(() => {
    const pages = getCurrentPages()
    isCanBack.value = pages.length > 1
})

</script>

<style scoped>

.title-slot-wrapper {
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.custom-capsule {
    width: 100%;
    height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 16px;
    padding: 0 2px;
    transition: background 0.3s, backdrop-filter 0.3s;
    box-sizing: border-box;
}

:deep(.custom-capsule__icon) {
    flex: 1;
    position: relative;
}

.capsule-divider {
    width: 1px;
    height: 18px;
    opacity: 0.3;
}

</style>