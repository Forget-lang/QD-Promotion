<template>
	<view>
        <t-cell v-if="!props.hidden" t-class="mb-16" :required="props.required" :title="props.title" :bordered="false" arrow hover @click="onOpen">
            <template #note>
                <text class="text-black lh-24" v-if="valueLabel">{{valueLabel}}</text>
                <text class="lh-24" v-else>{{placeholder}}</text>
            </template>
		</t-cell>

		<!-- 选择弹框 -->
		<t-popup v-model:visible="showPopup" placement="bottom">
			<view class="popup-header">
				<view class="popup-header-cancel" @click="onCancel">取消</view>
				<view class="popup-header-title">请选择员工</view>
				<view class="popup-header-confirm" @click="onConfirm">确定</view>
			</view>
			<scroll-view class="popup-body" :scroll-y="true" :show-scrollbar="true">
				<!-- 多选模式 -->
				<t-checkbox-group v-model:value="tempValue" v-if="staffList.length > 0 && props.multiple">
					<t-checkbox v-for="(item,index) in staffList" :key="index" :value="item.id"
						:label="staffLabel(item)" :disabled="!isStaffEnabled(item)" placement="right" />
				</t-checkbox-group>
				<!-- 单选模式 -->
				<t-radio-group v-model:value="tempRadioValue" v-else-if="staffList.length > 0 && !props.multiple" @change="onRadioChange">
					<t-radio v-for="(item,index) in staffList" :key="index" :value="item.id"
						:label="staffLabel(item)" :disabled="!isStaffEnabled(item)" placement="right" />
				</t-radio-group>
				<m-empty v-else>
					<view>暂无员工</view>
					<view v-if="placeholder" class="mt-2 text-danger">{{ placeholder }}</view>
				</m-empty>
                <!-- 引导去添加员工 -->
                <view class="d-flex flex-column align-items-center justify-content-center mt-5">
                    <view class="text-muted" @click="push('/pages_merchant/staff/invite')">
                        <text>没有可选的员工？立即前往 </text>
                        <text class="text-wechat">邀请员工</text>
                    </view>
                    <view class="d-flex align-items-center justify-content-center text-wechat mt-2" @click="onRefresh">
                        <t-loading v-if="refreshing" theme="circular" size="18px" inherit-color custom-style="margin-right: 4rpx;"/>
                        <text>{{ refreshing ? '刷新中...' : '刷新列表' }}</text>
                    </view>
                </view>
			</scroll-view>
            <view class="popup-bottom-action" v-if="staffList.length > 0 && props.multiple">
				<view class="popup-footer-count">已选 {{ tempValue.length }} 个员工</view>
				<view class="popup-footer-right">
					<t-button theme="default" variant="outline" size="extra-small" @click="onClear">清除</t-button>
					<t-button theme="primary" size="extra-small" @click="onSelectAll">全选</t-button>
				</view>
			</view>
		</t-popup>
	</view>
</template>

<script setup>
import {ref, computed, onMounted, watch} from 'vue'
import request from "@/hooks/request.js"
import {STAFF_STATUS} from "@/constants/merchant.js"
import {useLink} from '@/hooks/useLink.js'

const {push} = useLink()

const props = defineProps({
    gateway: {
        type: String,
        default: '/seller/staff/list'
    },
    title: {
        type: String,
        default: '员工',
    },
    placeholder: {
        type: String,
        default: '请选择员工'
    },
    required: {
        type: Boolean,
        default: false
    },
    multiple: {
        type: Boolean,
        default: true
    },
    params: {
        type: Object,
        default: () => ({})
    },
    hidden: {
        type: Boolean,
        default: false
    },
    // 显示全部员工（含非正常状态），非正常状态置灰不可选
    showDisabled: {
        type: Boolean,
        default: false
    }
})

const emit = defineEmits(['labelChange'])

const modelValue = defineModel('value', {
    type: [String, Number, Array],
    default: ''
})
const showPopup = ref(false)
const tempValue = ref([]) // 多选临时值
const tempRadioValue = ref('') // 单选临时值
// 刷新列表加载中（点击「刷新列表」时置位，getItems 完成后复位）
const refreshing = ref(false)

const staffList = ref([])

const getMatchedStaff = (value) => {
    return staffList.value.find(item => String(item.id) === String(value))
}

// 员工是否可选（正常在职可点；接口未返回 status 时默认可选，兼容 staff/list 等不含状态的接口）
const isStaffEnabled = (item) => {
	if (item.status === undefined || item.status === null) return true
	return item.status === STAFF_STATUS.NORMAL
}

// 选项展示文案：正常显示姓名，非正常追加状态标签
const staffLabel = (item) => {
	if (isStaffEnabled(item)) return item.name
	return item.name + '（' + (item.statusLabel || '不可用') + '）'
}

	const valueLabel = computed(() => {
		if (props.multiple) {
			if (Array.isArray(modelValue.value) && modelValue.value.length > 0) {
				return modelValue.value.length + '个员工'
			}
		} else {
			if (modelValue.value) {
                const staff = getMatchedStaff(modelValue.value)
				return staff ? staff.name : ''
			}
		}
		return ''
	})

	// 打开弹框，将当前值复制到临时值
	const onOpen = () => {
		if (props.multiple) {
			tempValue.value = Array.isArray(modelValue.value) ? [...modelValue.value] : []
		} else {
            const staff = getMatchedStaff(modelValue.value)
            tempRadioValue.value = staff ? staff.id : ''
		}
		showPopup.value = true
	}

	// 清除已选中但状态异常的员工（非正常员工不可选，选中状态应自动失效）
	const clearInvalidSelected = () => {
		const validSet = new Set(staffList.value.filter(item => isStaffEnabled(item)).map(item => String(item.id)))
		if (props.multiple) {
			const next = Array.isArray(modelValue.value) ? modelValue.value.filter(id => validSet.has(String(id))) : []
			modelValue.value = next
			if (showPopup.value) tempValue.value = [...next]
		} else {
			if (modelValue.value && !validSet.has(String(modelValue.value))) {
				modelValue.value = ''
				tempRadioValue.value = ''
				emit('labelChange', '')
			}
		}
	}

	// 单选变更时直接确认关闭
	const onRadioChange = (e) => {
		tempRadioValue.value = e.value
		modelValue.value = e.value
		showPopup.value = false
        const item = getMatchedStaff(e.value)
		emit('labelChange', item ? item.name : '')
	}

	// 取消：关闭弹框，不保存
	const onCancel = () => {
		showPopup.value = false
	}

	// 确定：将临时值同步到modelValue
	const onConfirm = () => {
		if (props.multiple) {
			modelValue.value = [...tempValue.value]
		} else {
			modelValue.value = tempRadioValue.value || ''
		}
		showPopup.value = false
		emit('labelChange', valueLabel.value)
	}

	// 全选：仅选中正常在职的员工（非正常员工不可选，故全选时跳过）
	const onSelectAll = () => {
		tempValue.value = staffList.value.filter(item => isStaffEnabled(item)).map(item => item.id)
	}

	// 清除
	const onClear = () => {
		tempValue.value = []
	}

	// 手动刷新列表（带加载状态）
	const onRefresh = () => {
		if (refreshing.value) return
		refreshing.value = true
		getItems()
	}

	// 加载员工列表（首次挂载 / 参数变化 / 手动刷新共用）
	const getItems = () => {
		// 显示全部时去掉 status 过滤，加载包含非正常状态的完整列表
		const params = {...props.params}
		if (props.showDisabled) delete params.status
        request.get(props.gateway, params).then(res => {
            staffList.value = res.data && Array.isArray(res.data.items) ? res.data.items : []
			// 列表刷新后，清理已失效（状态异常）的选中项
			clearInvalidSelected()
		}).finally(() => {
			setTimeout(() => {
				refreshing.value = false
			}, 800)
		})
	}

	onMounted(() => {
		getItems()
	})

watch([() => props.gateway, () => JSON.stringify(props.params)], () => {
    getItems()
})

	defineExpose({
		onOpen
	})
</script>

<style scoped>
	.popup-footer-count {
		font-size: 28rpx;
		color: #999;
	}

	.popup-footer-right {
		display: flex;
		align-items: center;
		gap: 20rpx;
	}
</style>
