<template>
    <view>
        <t-cell-group theme="card" t-class="mt-2">
            <t-cell title="超时时间">
                <template #description>
                    <view>
                        <view class="mt-2 bottom-line">
                            <m-tag-select v-model:value="issueForm.expireMinute" :column="5"
                                          :options="durationOptions"></m-tag-select>
                        </view>
                        <view class="text-muted">
                            <text>超过有效期后，领取链接失效，需要重新发放。</text>
                        </view>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card">
            <t-cell title="发放方式">
                <template #description>
                    <view class="private-issue-type">
                        <t-button theme="primary" :variant="issueForm.channelType === CHANNEL_TYPE.PRIVATE_WECHAT ? 'base' : 'outline'" block
                                  @click="changeIssueType(CHANNEL_TYPE.PRIVATE_WECHAT)">
                            <view class="d-flex align-items-center">
                                <t-icon t-class="mr-1" name="logo-wechat-stroke-filled" size="40rpx"/>
                                微信好友
                            </view>
                        </t-button>
                        <t-button theme="primary" :variant="issueForm.channelType === CHANNEL_TYPE.PRIVATE_QRCODE ? 'base' : 'outline'" block
                                  @click="changeIssueType(CHANNEL_TYPE.PRIVATE_QRCODE)">
                            <view class="d-flex align-items-center">
                                <t-icon t-class="mr-1" name="qrcode" size="40rpx"/>
                                二维码
                            </view>
                        </t-button>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2">
            <t-cell title="发放备注">
                <template #description>
                    <textarea
                        class="remark-textarea"
                        placeholder="请输入备注信息（选填，仅商家可见）"
                        v-model="issueForm.remark"
                        maxlength="32"
                    />
                </template>
            </t-cell>
        </t-cell-group>

        <m-submit :disabled="loading" @click="getIssueParam">
            <text v-if="issueForm.channelType === CHANNEL_TYPE.PRIVATE_WECHAT">生成微信好友分享链接</text>
            <text v-if="issueForm.channelType === CHANNEL_TYPE.PRIVATE_QRCODE">生成发放二维码</text>
        </m-submit>

        <t-popup placement="bottom" :visible="privateQrcodePopupVisible" :overlay-props="{ zIndex: 10999 }">
            <view class="popup-header">
                <view class="popup-header-title">私密一对一领次卡码</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="24px" @click="privateQrcodePopupVisible = false"/>
                </view>
            </view>
            <view class="container container-safety mt-5">
                <view class="text-center">
                    <image class="qrcode-image" :src="issueParam.qrcode" mode="widthFix"
                           v-if="issueParam.qrcode"></image>
                    <m-loading v-else/>
                </view>
                <view class="private-qrcode-tip">出示给客户扫码领取，领后此码失效。</view>
            </view>
        </t-popup>

        <t-popup placement="bottom" :visible="privateWechatSharePopupVisible" :overlay-props="{ zIndex: 10999 }">
            <view class="popup-header">
                <view class="popup-header-title">私密一对一微信好友</view>
                <view class="popup-header-close">
                    <t-icon name="close" size="24px" @click="privateWechatSharePopupVisible = false"/>
                </view>
            </view>
            <view class="container container-safety">
                <view class="private-qrcode-content">
                    <view class="private-qrcode-icon">
                        <t-icon name="check-circle-filled" size="100rpx" color="#07c160"/>
                    </view>
                    <view class="private-qrcode-tip">分享链接创建成功，仅能领取一次，领后失效。</view>
                </view>
                <view class="qrcode-actions d-flex justify-content-center">
                    <t-button openType="share" theme="primary">
                        <view class="d-flex align-items-center">
                            <t-icon t-class="mr-1" name="share-1" size="20px"/>
                            分享给微信好友
                        </view>
                    </t-button>
                </view>
            </view>
        </t-popup>
    </view>
</template>

<script setup>
import {onLoad, onShareAppMessage} from "@dcloudio/uni-app";
import {ref} from "vue";
import request from "@/hooks/request";
import {CHANNEL_TYPE} from "@/constants/common";
import utils from "@/utils/utils";

const shareTitle = ref('')
const shareCover = ref('')
const loading = ref(false)
const issueParam = ref({
    qrcode: '',
    appletPath: ''
});

const issueForm = ref({
    cardId: '',
    expireMinute: 1440,
    remark: '',
    channelType: CHANNEL_TYPE.PRIVATE_WECHAT,
});

const durationOptions = [
    {label: '5分钟', value: 5},
    {label: '1天', value: 1440},
    {label: '7天', value: 10080},
    {label: '30天', value: 43200},
    {label: '永久', value: 0},
]

const privateQrcodePopupVisible = ref(false)
const privateWechatSharePopupVisible = ref(false)

const changeIssueType = (type) => {
    issueForm.value.channelType = type;
}

const getIssueParam = () => {
    if (loading.value) {
        return
    }
    loading.value = true
    request.post('/seller/card/issue/private/create', issueForm.value, {showLoading: true}).then(res => {
        issueParam.value = res.data
        if (issueForm.value.channelType === CHANNEL_TYPE.PRIVATE_WECHAT) {
            privateWechatSharePopupVisible.value = true
        } else if (issueForm.value.channelType === CHANNEL_TYPE.PRIVATE_QRCODE) {
            privateQrcodePopupVisible.value = true
        }
    }).catch(err => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    issueForm.value.cardId = e.cardId;
    issueForm.value.channelType = utils.isNumeric(e.channelType) ? Number(e.channelType) : e.channelType;
    shareTitle.value = e.shareTitle ? e.shareTitle : '';
    shareCover.value = e.shareImage ? e.shareImage : '';
})

// 转发给微信好友：分享触发后关闭私密分享弹框
onShareAppMessage(() => {
    const path = issueParam.value.appletPath
    if (!path) {
        utils.toast('请先生成分享链接')
        return {}
    }
    privateWechatSharePopupVisible.value = false
    return {
        title: shareTitle.value,
        imageUrl: shareCover.value,
        path: issueParam.value.appletPath,
    }
})
</script>

<style scoped>
.remark-textarea {
    width: 100%;
    height: 160rpx;
    padding: 20rpx;
    margin-top: 20rpx;
    background-color: #f5f5f5;
    border-radius: 8rpx;
    font-size: 28rpx;
}

.private-issue-type {
    margin-top: 20rpx;
    display: flex;
    gap: 20rpx;
}

.qrcode-image {
    width: 100%;
    max-width: 400rpx;
    border-radius: 8rpx;
    margin: 20rpx auto;
}

.private-qrcode-content {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    padding: 80rpx 0;
}

.private-qrcode-icon {
    width: 160rpx;
    height: 160rpx;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    margin-bottom: 30rpx;
}

.private-qrcode-tip {
    font-size: 28rpx;
    color: #999;
    text-align: center;
}

.qrcode-actions {
    margin-top: 50rpx;
    padding: 30rpx 32rpx calc(30rpx + env(safe-area-inset-bottom));
}
</style>
