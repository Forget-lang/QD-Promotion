<template>
    <m-result v-if="showSuccess" theme="success" title="修改成功" back></m-result>
    <template v-else>
        <t-cell-group theme="card" t-class="mt-2">
            <m-staff-select required title="指定员工" :multiple="true" :show-disabled="true"
                            v-model:value="form.staffIds"></m-staff-select>
        </t-cell-group>

        <!-- 邀请员工辅助发券 -->
        <view class="text-center pt-2">
            <text class="text-wechat" @click="push('/pages_merchant/staff/invite')">邀请员工辅助发券</text>
        </view>

        <!-- 提交按钮 -->
        <m-submit v-if="checkPermission(PERM_CARD.UPDATE)" :loading="loading" :disabled="loading" @click="onSubmit">确认修改</m-submit>

        <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_CARD} from '@/constants/permission.js'

const {push, back} = useLink()
const {checkPermission} = useAuth()

// 次卡ID
const cardId = ref('')
// 表单数据
const form = ref({
    staffIds: []
})
// 加载状态
const loading = ref(false)
// 是否显示成功反馈
const showSuccess = ref(false)

// 获取次卡信息
const getCardInfo = () => {
    request.get('/seller/card/get/detail', {id: cardId.value}).then((res) => {
        form.value.staffIds = res.data.staffIds || []
    })
}

// 提交修改
const onSubmit = () => {
    if (!form.value.staffIds || form.value.staffIds.length === 0) {
        utils.toast('请至少选择一名发券员工')
        return
    }
    loading.value = true
    request.post('/seller/card/update-staffs', {
        id: cardId.value,
        staffIds: form.value.staffIds
    }).then(() => {
        showSuccess.value = true
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    if (!e.cardId) {
        utils.toast('缺少次卡ID')
        setTimeout(() => {
            back()
        }, 1500)
        return
    }
    cardId.value = e.cardId
    getCardInfo()
})
</script>

<style scoped></style>
