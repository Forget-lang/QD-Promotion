<template>
    <m-loading v-if="items === undefined"></m-loading>
    <template v-else-if="is.Array(items)">
        <m-empty v-if="items.length === 0">暂无发券员工</m-empty>
        <view v-else class="container-safety">
            <t-cell-group theme="card" t-class="mt-2">
                <t-cell :arrow="true" v-for="item in items" :key="item.id" :title="item.name" :image="item.avatar"
                        @tap="push('/pages_merchant/staff/detail?staffId=' + item.id)">
                    <template #description>
                        <view class="m-flex mt-1">
                            <t-tag theme="success" variant="light-outline" size="small">{{ item.storeName }}</t-tag>
                            <t-tag theme="warning" variant="light" size="small">{{ item.roleName }}</t-tag>
                        </view>
                    </template>
                    <template #note>
                        <text class="text-muted" :class="item.status === ISSUE_STAFF_STATUS.VALID ? 'text-success' : 'text-danger'">
                            {{ item.statusLabel }}
                        </text>
                    </template>
                </t-cell>
            </t-cell-group>

            <view class="mt-2 p-3 text-center text-muted text-small">
                共 {{ total }} 名发券员工
            </view>
        </view>
    </template>
    <m-submit v-if="items && checkPermission(PERM_CARD.UPDATE) && cardStatus !== CARD_STATUS.DISCARDED" @click="push('/pages_card/issue/update_staff?cardId=' + cardId)">设置发券员工</m-submit>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {useLink} from '@/hooks/useLink'
import {useAuth} from "@/hooks/useAuth";
import {PERM_CARD} from "@/constants/permission";
import {CARD_STATUS, ISSUE_STAFF_STATUS} from '@/constants/card'
import is from "@/hooks/is";
import to from "@/hooks/to";

const {push} = useLink()
const {checkPermission} = useAuth()

const cardId = ref()
const items = ref()
const total = ref(0)
// 加载中（防重复请求）
const loading = ref(false)
const cardStatus = ref(0)

const getItems = () => {
    if (loading.value) return
    loading.value = true
    request.get('/seller/card/staff/list', {cardId: cardId.value, page: 1, pageSize: 100}).then(res => {
        items.value = to.Array(res.data.items)
        total.value = res.data.total
    }).finally(() => {
        loading.value = false
    })
}

onLoad((e) => {
    if (e.cardId) {
        cardId.value = e.cardId
    }
    if (e.status !== undefined && e.status !== ''){
        cardStatus.value = Number(e.status)
    }
})

onShow(() => {
    getItems()
})

onPullDownRefresh(() => {
    getItems()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})
</script>

<style scoped></style>
