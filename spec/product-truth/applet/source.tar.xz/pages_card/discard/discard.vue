<template>
    <m-result v-if="showSuccess" title="作废成功" description="所有已被领取的次卡也一并作废。" back></m-result>
    <template v-else>
        <view class="container mt-3">
            <view class="section p-3 section-alert">
                <view class="h4">作废须知：</view>
                <view class="mt-1 text-small">1. 此次卡模版下所有
                    <text class="text-danger">已领取且使用中的次卡都将作废</text>
                    ，请谨慎操作！
                </view>
                <view class="mt-1 text-small">2. 作废后次卡模版不可恢复，所有已领取使用中的次卡不可恢复。</view>
                <view class="mt-1 text-small">3. 作废后将无法继续发放与核销此次卡。</view>
            </view>
        </view>
        <t-cell-group t-class="mt-2" theme="card">
            <t-textarea required label="作废原因" v-model:value="form.reason" :maxlength="32" :indicator="true"
                        placeholder="请输入作废原因"></t-textarea>
        </t-cell-group>
        <view class="mt-3">
            <t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless icon="circle"
                        relation-key="-1" custom-style="background-color: transparent;">
                <template #label>
                    <view class="agreement">
                        我已阅读并知晓作废次卡的风险，确认要作废次卡模版及所有已领取数据。
                    </view>
                </template>
            </t-checkbox>
        </view>
        <m-submit :loading="loading" :disabled="loading || !allowAgreement" @click="onSubmit">确认作废</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request.js'
import MResult from '@/components/m/m-result/m-result.vue'
import utils from '@/utils/utils'

const cardId = ref()
const allowAgreement = ref(false)
const loading = ref(false)
const form = ref({
    reason: ''
})
const showSuccess = ref(false)

const onSubmit = () => {
    if (!form.value.reason) {
        utils.toast('请输入作废原因')
        return
    }
    loading.value = true
    request.post('/seller/card/discard', {id: cardId.value, reason: form.value.reason}).then(() => {
        uni.$emit('onCardDiscard', {id: cardId.value})
        showSuccess.value = true
    }).finally(() => {
        loading.value = false
    }).catch((err) => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    cardId.value = e.cardId
})
</script>

<style scoped>

</style>
