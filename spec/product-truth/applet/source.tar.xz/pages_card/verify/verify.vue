<template>
    <view class="container-search">
        <view class="input-search">
            <t-input
                :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                placeholder="请输入次卡领取码"
                v-model:value="verifyCode"
                borderless
                size="small"
                :clearable="{ name: 'close-circle-filled', size: '36rpx' }"
                @enter="onSearch"
            />
            <view class="input-search-actions">
                <t-button theme="default" size="large" variant="text" icon="scan" @click="onScan"></t-button>
            </view>
        </view>
    </view>

    <m-loading v-if="loading"/>
    <m-result
        v-else-if="verifyResult"
        :type="resultOk ? 'success' : 'danger'"
        :title="resultTitle"
        :description="verifyDescription"
    />
    <m-empty v-else-if="cardInfo === null">未搜索到次卡</m-empty>
    <view v-else-if="cardInfo" class="container-safety">
        <view v-if="cardInfo.isQrcodeExpired" class="container mt-2">
            <view class="alert-error">{{ cardInfo.qrcodeExpiredTip }}</view>
        </view>
        <view v-else-if="cardInfo.transferLock" class="container mt-2">
            <view class="alert-error">次卡转赠中，暂不可核销</view>
        </view>
        <view v-else-if="cardInfo.verifyIntervalTip" class="container mt-2">
            <view class="alert-error">{{ cardInfo.verifyIntervalTip }}</view>
        </view>

        <!-- 磁卡卡面 -->
        <view class="container mt-2">
            <m-card-magnetic-face
                :theme="Number(cardInfo.theme) || 1"
                :merchant-name="cardInfo.merchantName"
                :cover="cardInfo.cover"
                :title="cardInfo.cardName"
                :card-type="cardInfo.cardType"
                :total-times="cardInfo.totalTimes"
                :remain-times="cardInfo.remainCount"
                :valid-label="cardInfo.validLabel"
                :status="cardInfo.status"
                :status-label="cardInfo.statusLabel"
            />
        </view>

        <!-- 核销记录（最近 5 条） -->
        <view class="container mt-3">
            <view class="section">
                <view class="section-header">
                    <view class="section-title">核销记录</view>
                    <view class="section-more" @tap="push('/pages_card/receive/verify_list?id=' + cardInfo.id)">
                        <text>全部记录</text>
                        <t-icon name="chevron-right" size="28rpx" color="#999"/>
                    </view>
                </view>
                <view v-if="verifyItems.length === 0" class="verify-empty">暂无核销记录</view>
                <view
                    class="verify-item"
                    v-for="item in verifyItems"
                    :key="item.id"
                    @tap="push('/pages_card/verify/detail?id=' + item.id)"
                >
                    <view class="verify-item-head">
                        <text class="verify-item-title">
                            第 {{ item.useSort }} 次
                            <template v-if="item.benefitLabel"> · {{ item.benefitLabel }}</template>
                        </text>
                        <view class="verify-item-side">
                            <text class="verify-item-time">{{ item.verifiedAt }}</text>
                            <t-tag
                                :theme="item.status === VERIFY_STATUS.SUCCESS ? 'success' : 'danger'"
                                variant="light" size="small">
                                {{ item.statusLabel }}
                            </t-tag>
                        </view>
                    </view>
                    <view class="verify-item-remark" v-if="item.verifyRemark">备注：{{ item.verifyRemark }}</view>
                    <view class="verify-item-sub">
                        {{ item.verifyStoreName || '-' }} / {{ item.verifyStaffName || '-' }}
                    </view>
                </view>
            </view>
        </view>

        <!-- 优惠内容（仅权益卡展示权益项进度） -->
        <view class="container mt-3" v-if="cardInfo.cardType === CARD_TYPE.BENEFIT">
            <view class="section">
                <view class="section-header">
                    <view class="section-title">优惠内容</view>
                </view>
                <view class="card-usage-body">
                    <m-card-benefit-list
                        :items="cardInfo.items"
                        :theme="cardInfo.theme"
                    />
                </view>
            </view>
        </view>

        <t-cell-group title="领取信息" t-title-class="mt-2" theme="card">
            <t-cell title="领取渠道" :note="cardInfo.channelTypeLabel"/>
            <t-cell title="领取时间" :note="cardInfo.receivedAt"/>
            <t-cell title="发放门店" :note="cardInfo.issueStoreName || '-'"/>
            <t-cell title="发放员工" :note="cardInfo.issueStaffName || '-'"/>
            <t-cell title="发放备注" :note="cardInfo.issueRemark || '-'"/>
        </t-cell-group>

        <!-- 作废本次（弱操作入口，对齐优惠券核销页「作废该优惠券」） -->
        <view v-if="canDiscard" class="mt-3 mb-3 text-center" @click="discardVisible = true">
            <text class="text-muted text-small">作废本次</text>
        </view>

        <t-popup placement="bottom" :visible="verifyVisible" @visible-change="onVerifyPopupChange">
            <view class="popup-container">
                <view class="popup-header">
                    <view class="popup-header-title">核销次卡</view>
                    <view class="popup-header-close">
                        <t-icon name="close" size="24px" @click="verifyVisible = false"/>
                    </view>
                </view>
                <view class="popup-body">
                    <t-cell-group theme="card">
                        <m-store-select v-model:value="form.storeId" title="核销门店" :multiple="false"
                                        :auto-selected="true" gateway="/seller/card/verify/stores"
                                        :params="{cardId: cardInfo.cardId}"></m-store-select>
                    </t-cell-group>
                    <t-cell-group t-class="mt-2" theme="card">
                        <t-textarea
                            custom-style="height:260rpx"
                            placeholder="请输入核销备注（选填）"
                            v-model:value="form.remark"
                            :maxlength="32"
                            :cursor-spacing="120"
                        />
                    </t-cell-group>
                </view>
                <view class="popup-footer">
                    <t-button theme="danger" size="large" block t-class="mt-3" :loading="submitLoading" @click="onConfirmVerify">
                        确认核销
                    </t-button>
                </view>
            </view>
        </t-popup>

        <!-- 作废本次确认弹框 -->
        <t-popup placement="bottom" :visible="discardVisible" @visible-change="onDiscardPopupChange">
            <view class="popup-container">
                <view class="popup-header">
                    <view class="popup-header-title">作废本次</view>
                    <view class="popup-header-close">
                        <t-icon name="close" size="24px" @click="discardVisible = false"/>
                    </view>
                </view>
                <view class="popup-body">
                    <t-cell-group theme="card">
                        <m-store-select v-model:value="discardForm.storeId" title="作废门店" :multiple="false"
                                        :auto-selected="true" gateway="/seller/card/verify/stores"
                                        :params="{cardId: cardInfo.cardId}"></m-store-select>
                    </t-cell-group>
                    <t-cell-group t-class="mt-2" theme="card">
                        <t-textarea
                            custom-style="height:260rpx"
                            placeholder="请输入作废原因（此作废记录顾客可见）"
                            v-model:value="discardForm.remark"
                            :maxlength="32"
                            :indicator="true"
                            :cursor-spacing="120"
                        />
                    </t-cell-group>
                </view>
                <view class="popup-footer">
                    <t-button theme="danger" size="large" block t-class="mt-3" :loading="discardLoading"
                              @click="onConfirmDiscard">
                        确认作废
                    </t-button>
                </view>
            </view>
        </t-popup>

        <m-submit v-if="canVerify" :loading="submitLoading" @click="onSubmit">确认核销</m-submit>
    </view>
    <view v-else class="empty-state-container">
        <view class="empty-state-title">请扫描或输入次卡码</view>
    </view>

    <m-submit v-if="verifyResult" @click="onReset">继续核销</m-submit>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request.js'
import {RECEIVE_STATUS, BENEFIT_TYPE, CARD_TYPE, VERIFY_STATUS} from '@/constants/card'
import {PERM_CARD} from '@/constants/permission.js'
import is from '@/hooks/is'
import to from '@/hooks/to'
import {useLink} from '@/hooks/useLink.js'
import utils from '@/utils/utils'
import {useAuth} from '@/hooks/useAuth'

const {isLoggedIn, isEntry, checkPermission} = useAuth()
const {reLaunch, push} = useLink()

const verifyCode = ref('')
const loading = ref(false)
const cardReceiveId = ref('')
const verifySign = ref('')
const source = ref(2)
const cardInfo = ref()
const verifyResult = ref(null)
// 最近核销记录（最多 5 条）
const verifyItems = ref([])
const submitLoading = ref(false)
const verifyVisible = ref(false)
const form = ref({storeId: '', remark: ''})
const discardVisible = ref(false)
const discardLoading = ref(false)
const discardForm = ref({storeId: '', remark: ''})

// 通卡不限次数，remainCount 恒为 0，不参与可核销/可作废判断
const isUnlimited = computed(() => cardInfo.value?.cardType === CARD_TYPE.UNLIMITED)

const canVerify = computed(() => {
    if (!cardInfo.value) return false
    if (cardInfo.value.status !== RECEIVE_STATUS.VALID) return false
    if (!isUnlimited.value && cardInfo.value.remainCount <= 0) return false
    if (cardInfo.value.isQrcodeExpired) return false
    if (cardInfo.value.transferLock) return false
    if (cardInfo.value.verifyIntervalTip) return false
    return true
})

// 对齐优惠券核销页：领取信息下方弱入口；使用中、有剩余、未转赠、有核销权限
// 间隔未满时不展示（作废同样受间隔限制，避免点进去才报错）
// 通卡不限次数，没有「用完」一说，不提供作废单次核销的入口
const canDiscard = computed(() => {
    if (!cardInfo.value) return false
    if (isUnlimited.value) return false
    if (cardInfo.value.status !== RECEIVE_STATUS.VALID) return false
    if (cardInfo.value.remainCount <= 0) return false
    if (cardInfo.value.transferLock) return false
    if (cardInfo.value.verifyIntervalTip) return false
    return checkPermission(PERM_CARD.VERIFY)
})

const resultOk = computed(() => {
    const r = verifyResult.value
    if (!r) return false
    return !!(r.isVerify || r.isDiscard)
})

const resultTitle = computed(() => {
    const r = verifyResult.value
    if (!r) return ''
    if (r.isDiscard) return '作废成功'
    if (r.isVerify) return '核销成功'
    return r.action === 'discard' ? '作废失败' : '核销失败'
})

// 结果描述：失败展示原因；成功按权益项类型拼装提示
const verifyDescription = computed(() => {
    const result = verifyResult.value
    if (!result) return ''
    if (!resultOk.value) {
        if (result.action === 'discard') return result.message || '作废失败'
        return result.message || '核销失败'
    }
    return buildSuccessDescription(result)
})

// 定位本次核销消耗的权益项：核销接口直接返回权益字段时优先使用，否则按核销次数序号匹配卡面权益列表，再退回当前可使用项
const findVerifiedItem = (result, useSort) => {
    if (result.benefitType || result.benefitTypeLabel) return result
    const items = to.Array(cardInfo.value?.items)
    if (useSort) {
        const matched = items.find(item => to.Int(item.sort) === useSort)
        if (matched) return matched
    }
    return items.find(item => item.isCurrent) || null
}

// 判定权益项类型：优先取数字型 benefitType，其次按后端 benefitTypeLabel 文案归一到枚举
const resolveBenefitType = (item) => {
    const benefitType = to.Int(item.benefitType)
    if (benefitType === BENEFIT_TYPE.AMOUNT || benefitType === BENEFIT_TYPE.DISCOUNT || benefitType === BENEFIT_TYPE.SERVICE) {
        return benefitType
    }
    const typeLabel = to.String(item.benefitTypeLabel)
    if (typeLabel === '金额') return BENEFIT_TYPE.AMOUNT
    if (typeLabel === '折扣') return BENEFIT_TYPE.DISCOUNT
    if (typeLabel === '服务') return BENEFIT_TYPE.SERVICE
    return 0
}

// 按权益项类型生成权益文案：金额→抵扣¥10 / 折扣→享8.5折 / 服务→服务内容，均基于后端 benefitLabel 直出拼装
const getBenefitText = (result, item) => {
    if (item) {
        const benefitLabel = to.String(item.benefitLabel).trim()
        if (benefitLabel) {
            const benefitType = resolveBenefitType(item)
            if (benefitType === BENEFIT_TYPE.AMOUNT) return `抵扣${benefitLabel}`
            if (benefitType === BENEFIT_TYPE.DISCOUNT) return `享${benefitLabel}`
            return benefitLabel
        }
    }
    return result.benefitLabel || '核销完成'
}

// 计算核销后剩余次数：优先取核销接口返回值，其次用卡面剩余次数减一，无数据返回 -1 表示未知
const getRemainCount = (result) => {
    if (is.Int(result.remainCount)) return result.remainCount
    if (is.Object(cardInfo.value) && is.Int(cardInfo.value.remainCount)) {
        return Math.max(cardInfo.value.remainCount - 1, 0)
    }
    return -1
}

// 拼装成功描述：第X次 + 权益内容 + 剩余次数
const buildSuccessDescription = (result) => {
    const useSort = to.Int(result.useSort)
    const benefitText = getBenefitText(result, findVerifiedItem(result, useSort))
    const actionLabel = result.isDiscard ? '已作废' : '已核销'
    const head = useSort ? `第${useSort}次：${benefitText}（${actionLabel}）` : `${benefitText}（${actionLabel}）`
    if (isUnlimited.value) return head
    const remain = getRemainCount(result)
    if (remain > 0) return `${head}，剩余${remain}次可用`
    if (remain === 0) return `${head}，本次为该次卡最后一次`
    return head
}

const onSearch = () => {
    const code = verifyCode.value.trim()
    if (!code) {
        utils.toast('请输入次卡领取码')
        return
    }
    cardReceiveId.value = code
    source.value = 2
    getCardInfo()
}

const getCardInfo = () => {
    if (!isLoggedIn.value) {
        wx.showModal({
            title: '提示',
            content: '您还未登录，请先登录！',
            showCancel: false,
            success: () => reLaunch('/pages/merchant/index')
        })
        return
    }
    if (!isEntry.value) {
        wx.showModal({
            title: '提示',
            content: '您还未加入商家，请先加入！',
            showCancel: false,
            success: () => reLaunch('/pages/merchant/index')
        })
        return
    }
    loading.value = true
    cardInfo.value = undefined
    verifyResult.value = null
    form.value = {storeId: '', remark: ''}
    discardForm.value = {storeId: '', remark: ''}
    const params = {cardReceiveId: cardReceiveId.value}
    if (source.value === 1) {
        params.verifySign = verifySign.value
    }
    request.get('/seller/card/verify/info', params).then(res => {
        cardInfo.value = res.data
        getVerifyItems()
    }).catch(() => {
        cardInfo.value = null
    }).finally(() => {
        loading.value = false
    })
}

// 获取该领取记录最近 5 条核销记录（时间倒序）
const getVerifyItems = () => {
    request.get('/seller/card/verify/list', {
        page: 1,
        pageSize: 5,
        cardReceiveId: cardReceiveId.value,
        sorter: 'desc',
    }, {showLoading: false}).then(res => {
        verifyItems.value = to.Array(res.data.items)
    }).catch(() => {
        verifyItems.value = []
    })
}

const onVerifyPopupChange = (e) => {
    verifyVisible.value = e?.visible ?? !!e
}

const onDiscardPopupChange = (e) => {
    const visible = e && typeof e === 'object' ? e.visible : !!e
    discardVisible.value = visible
    if (!visible) {
        discardForm.value = {storeId: discardForm.value.storeId || '', remark: ''}
    }
}

const onSubmit = () => {
    if (!canVerify.value) {
        utils.toast('此次卡不可核销')
        return
    }
    verifyVisible.value = true
}

const onConfirmVerify = () => {
    if (!form.value.storeId) {
        utils.toast('请选择核销门店')
        return
    }
    submitLoading.value = true
    request.post('/seller/card/verify', {
        cardReceiveId: cardReceiveId.value,
        storeId: form.value.storeId,
        verifySign: verifySign.value,
        source: source.value,
        remark: form.value.remark,
    }, {disableErrorToast: true}).then(res => {
        verifyVisible.value = false
        verifyResult.value = {...res.data, isVerify: true, action: 'verify'}
    }).catch(err => {
        verifyVisible.value = false
        verifyResult.value = {isVerify: false, action: 'verify', message: err?.message || '核销失败'}
    }).finally(() => {
        submitLoading.value = false
    })
}

const onConfirmDiscard = () => {
    if (!canDiscard.value) {
        utils.toast('此次卡不可作废')
        return
    }
    if (!discardForm.value.storeId) {
        utils.toast('请选择作废门店')
        return
    }
    if (!String(discardForm.value.remark || '').trim()) {
        utils.toast('请输入作废原因')
        return
    }
    discardLoading.value = true
    request.post('/seller/card/verify/discard', {
        cardReceiveId: cardReceiveId.value,
        storeId: discardForm.value.storeId,
        verifySign: verifySign.value,
        source: source.value,
        remark: discardForm.value.remark,
    }, {disableErrorToast: true}).then(res => {
        discardVisible.value = false
        verifyResult.value = {...res.data, isDiscard: true, action: 'discard'}
    }).catch(err => {
        discardVisible.value = false
        verifyResult.value = {isDiscard: false, action: 'discard', message: err?.message || '作废失败'}
    }).finally(() => {
        discardLoading.value = false
    })
}

const onScan = () => {
    uni.scanCode({
        success: (res) => {
            console.log('扫码成功：', res)
            if (res.path && res.path.includes('/verify')) {
                var path = ''
                if (!res.path.startsWith('/')) {
                    path = '/' + res.path
                } else {
                    path = res.path
                }
                // 从路径中提取 scene 参数填入输入框并自动搜索
                const match = path.match(/scene=([^&]+)/)
                if (!match?.[1]) {
                    utils.toast('请提供正确的核销码')
                    return
                }
                decodeScene(match[1])
            } else {
                utils.toast('请提供正确的核销码')
            }
        },
        fail: (err) => {
            console.log('扫码失败：', err)
            if (err.errMsg !== 'scanCode:fail cancel') {
                utils.toast(err.errMsg)
            }
        }
    })
}

const decodeScene = (scene) => {
    const arr = String(scene).split('-')
    if (arr.length !== 2) {
        utils.toast('请提供正确的核销码')
        return
    }
    cardReceiveId.value = arr[0]
    verifySign.value = arr[1]
    source.value = 1
    getCardInfo()
}

const onReset = () => {
    verifyCode.value = ''
    cardReceiveId.value = ''
    verifySign.value = ''
    cardInfo.value = undefined
    verifyResult.value = null
    verifyItems.value = []
    form.value = {storeId: '', remark: ''}
    discardForm.value = {storeId: '', remark: ''}
    onScan()
}

onLoad((e) => {
    if (e.scene) {
        const parts = decodeURIComponent(e.scene).split('-')
        if (parts.length >= 2) {
            cardReceiveId.value = parts[0]
            verifySign.value = parts[1]
            source.value = 1
            getCardInfo()
        }
    }
    if (e.cardReceiveId) {
        cardReceiveId.value = e.cardReceiveId
        source.value = 2
        getCardInfo()
    }
})
</script>

<style scoped>
.summary-card {
    background: #fff;
    border-radius: 20rpx;
    padding: 32rpx;
}

.summary-metrics {
    display: flex;
    align-items: center;
    justify-content: space-around;
}

.metric-item {
    text-align: center;
}

.metric-num {
    font-size: 44rpx;
    font-weight: 700;
}

.metric-used {
    color: #e84c59;
}

.metric-remain {
    color: #07c160;
}

.metric-label {
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #999;
}

.metric-divider {
    width: 1rpx;
    height: 60rpx;
    background: #eee;
}

.card-usage-body {
    padding: 32rpx;
}

/* 核销记录 */
.verify-empty {
    padding: 20rpx 32rpx 40rpx;
    text-align: center;
    font-size: 26rpx;
    color: #999;
}

.verify-item {
    margin: 0 32rpx;
    padding: 24rpx 0;
    border-top: 1rpx solid #f0f0f0;
}

.verify-item:last-child {
    padding-bottom: 32rpx;
}

.verify-item-head {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.verify-item-title {
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
}

.verify-item-side {
    display: flex;
    align-items: center;
    flex-shrink: 0;
    gap: 12rpx;
}

.verify-item-time {
    font-size: 24rpx;
    color: #999;
}

.verify-item-remark {
    margin-top: 8rpx;
    font-size: 26rpx;
    color: #555;
    line-height: 40rpx;
}

.verify-item-sub {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.empty-state-container {
    padding: 120rpx 40rpx;
    text-align: center;
    color: #999;
}

.popup-footer {
    display: flex;
    gap: 24rpx;
    padding: 24rpx 24rpx calc(24rpx + env(safe-area-inset-bottom));
}

</style>
