<template>
    <m-loading v-if="detail === undefined"/>
    <m-empty v-else-if="detail === null">领取记录不存在</m-empty>
    <view class="container-safety" v-else>
        <view class="container mt-2">
            <view class="summary-card">
                <view class="summary-head" @tap="onViewCustomer">
                    <view class="user-avatar">
                        <image v-if="detail.avatar" :src="detail.avatar" mode="aspectFill"/>
                        <text v-else>{{ displayName.charAt(0) }}</text>
                    </view>
                    <view class="summary-info">
                        <view class="summary-name">{{ displayName }}</view>
                        <view class="summary-time">领取于 {{ detail.receivedAt }}</view>
                    </view>
                    <t-tag :theme="detail.status === RECEIVE_STATUS.VALID ? 'success' : 'danger'" variant="light" size="small">
                        <text :class="detail.status === RECEIVE_STATUS.VALID ? 'text-success' : 'text-danger'">
                            {{ detail.statusLabel }}
                        </text>
                    </t-tag>
                    <t-icon v-if="detail.userId && detail.userId !== '0'" name="chevron-right" size="40rpx"
                            color="#ccc"/>
                </view>
                <t-divider/>
                <view class="summary-metrics">
                    <view class="metric-item">
                        <view class="metric-num">{{ detail.totalTimes }}</view>
                        <view class="metric-label">总次数</view>
                    </view>
                    <view class="metric-divider"/>
                    <view class="metric-item">
                        <view class="metric-num metric-used">{{ detail.verifyCount ?? 0 }}</view>
                        <view class="metric-label">已核销</view>
                    </view>
                    <view class="metric-divider"/>
                    <view class="metric-item">
                        <view class="metric-num metric-discard">{{ detail.discardCount ?? 0 }}</view>
                        <view class="metric-label">已作废</view>
                    </view>
                    <view class="metric-divider"/>
                    <view class="metric-item">
                        <view class="metric-num">{{ detail.remainCount }}</view>
                        <view class="metric-label">剩余</view>
                    </view>
                </view>
            </view>
        </view>

        <view class="container mt-2">
            <m-card-magnetic-face
                :theme="detail.theme"
                :merchant-name="detail.merchantName"
                :cover="detail.cover"
                :title="detail.cardName"
                :card-type="detail.cardType"
                :total-times="detail.totalTimes"
                :remain-times="detail.remainCount"
                :valid-label="detail.validLabel"
                :status="detail.status"
                :status-label="detail.statusLabel"
            />
        </view>

        <view class="container mt-2">
            <!-- 次卡权益项内容 -->
            <m-card-benefit-list
                :items="detail.items"
                :theme="detail.theme"
            />
        </view>

        <t-cell-group theme="card" t-class="mt-2">
            <t-cell title="卡号" :note="detail.id" arrow hover
                    @click="utils.copyClipboard(detail.id)"/>
            <t-cell title="发放渠道" :note="detail.channelTypeLabel"/>
            <t-cell title="发放门店" :note="detail.issueStoreName || '-'"/>
            <t-cell title="发放员工" :note="detail.issueStaffName || '-'"/>
            <t-cell title="发放备注" :note="detail.issueRemark || '-'"/>
        </t-cell-group>

        <t-cell-group title="作废信息" t-title-class="mt-2" theme="card" v-if="detail.status === RECEIVE_STATUS.DISCARDED">
            <t-cell title="作废原因" :note="detail.discardRemark || '-'"/>
            <t-cell title="作废门店" :note="detail.discardStoreName || '-'"/>
            <t-cell title="作废员工" :note="detail.discardStaffName || '-'"/>
            <t-cell title="作废时间" :note="detail.discardAt || '-'"/>
        </t-cell-group>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import {RECEIVE_STATUS} from '@/constants/card'
import {PERM_CARD} from '@/constants/permission'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'

const {push} = useLink()
const {checkPermission} = useAuth()

// 领取记录 ID
const id = ref('')
// 领取详情
const detail = ref()

// 展示用用户名称
const displayName = computed(() => detail.value?.nickname || '用户')

// 获取次卡领取详情
const getDetail = () => {
    request.get('/seller/card/verify/detail', {id: id.value}).then(res => {
        detail.value = res.data
    }).catch(() => {
        detail.value = null
    })
}

// 跳转客户详情
const onViewCustomer = () => {
    if (!detail.value?.userId || detail.value.userId === '0') {
        return
    }
    push('/pages_merchant/customer/detail?userId=' + detail.value.userId)
}

// 作废此次卡领取记录
const onDiscard = () => {
    uni.showModal({
        title: '作废次卡',
        editable: true,
        placeholderText: '请输入作废原因',
        success: (res) => {
            if (!res.confirm) return
            const reason = res.content?.trim() || '商家作废'
            request.post('/seller/card/receive/discard', {id: id.value, reason}).then(() => {
                utils.toast('已作废')
                getDetail()
            }).catch(err => utils.toast(err.message))
        }
    })
}

onLoad((e) => {
    id.value = e.id
    getDetail()
})

onPullDownRefresh(() => {
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})
</script>

<style scoped>
.summary-card {
    background: #fff;
    border-radius: 20rpx;
    padding: 32rpx;
}

.summary-head {
    display: flex;
    align-items: center;
    gap: 16rpx;
}

.user-avatar {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.user-avatar image {
    width: 100%;
    height: 100%;
}

.summary-info {
    flex: 1;
}

.summary-name {
    font-size: 30rpx;
    font-weight: 600;
}

.summary-time {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.summary-metrics {
    margin-top: 24rpx;
    display: flex;
    align-items: center;
    justify-content: space-around;
}

.metric-item {
    text-align: center;
}

.metric-num {
    font-size: 36rpx;
    font-weight: 700;
}

.metric-used {
    color: #e84c59;
}

.metric-discard {
    color: #999;
}

.metric-label {
    margin-top: 8rpx;
    font-size: 20rpx;
    color: #999;
}

.metric-divider {
    width: 1rpx;
    height: 60rpx;
    background: #eee;
}
</style>
