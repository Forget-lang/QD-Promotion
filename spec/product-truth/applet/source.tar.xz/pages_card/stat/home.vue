<template>
    <t-cell-group t-class="mt-2" theme="card">
        <t-cell title="我的业绩" arrow
                :url="'/pages_card/stat/staff_overview?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_CHANNEL_RANK)" title="发放渠道统计" arrow
                :url="'/pages_card/stat/channel_issue_rank?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_STORE_RANK)" title="门店发放统计" arrow
                :url="'/pages_card/stat/store_issue_rank?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_STORE_RANK)" title="门店核销统计" arrow
                :url="'/pages_card/stat/store_verify_rank?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_STAFF_RANK)" title="员工发放统计" arrow
                :url="'/pages_card/stat/staff_issue_rank?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_STAFF_RANK)" title="员工核销统计" arrow
                :url="'/pages_card/stat/staff_verify_rank?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_USER_TRANSFER)" title="顾客转赠统计" arrow
                :url="'/pages_card/stat/user_transfer_rank?cardId=' + cardId"/>
        <t-cell v-if="checkPermission(PERM_CARD.STAT_USER_VERIFY)" title="顾客核销统计" arrow
                :url="'/pages_card/stat/user_verify_rank?cardId=' + cardId"/>
    </t-cell-group>
</template>

<script setup>
import {ref} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import {useAuth} from "@/hooks/useAuth.js";
import {PERM_CARD} from "@/constants/permission.js";

const {checkPermission} = useAuth();
const cardId = ref();
onLoad((e) => {
    cardId.value = e.cardId
})
</script>

<style scoped>

</style>