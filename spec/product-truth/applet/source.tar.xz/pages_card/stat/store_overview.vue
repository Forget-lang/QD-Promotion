<template>
    <view class="stat-filter">
        <view class="stat-date-filter">
            <text class="stat-filter-item" :class="{active:options.timeType === 'today'}"
                  @click="onChangeTimeRange('today')">今天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'yesterday'}"
                  @click="onChangeTimeRange('yesterday')">昨天
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'month'}"
                  @click="onChangeTimeRange('month')">本月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'lastMonth'}"
                  @click="onChangeTimeRange('lastMonth')">上月
            </text>
            <text class="stat-filter-item" :class="{active:options.timeType === 'cumulative'}"
                  @click="onChangeTimeRange('cumulative')">累计
            </text>
        </view>
    </view>
    <view class="container">
        <!-- 员工业绩 -->
        <view class="section mt-3">
            <view class="section-header bottom-line">
                <view class="section-title">本店发放业绩</view>
            </view>
            <view class="section-body">
                <view class="overview-grid">
                    <view class="ov-item">
                        <view class="ov-label">有效发放张数</view>
                        <view class="ov-value">{{ storeOverview.receiveCount || 0 }}</view>
                    </view>
                    <view class="ov-item">
                        <view class="ov-label">有效发放且核销次数</view>
                        <view class="ov-value">{{ storeOverview.receiveVerifyCount || 0 }}</view>
                    </view>
                </view>
            </view>
        </view>

        <view class="section mt-3">
            <view class="section-header bottom-line">
                <view class="section-title">本店核销业绩</view>
            </view>
            <view class="section-body">
                <view class="overview-grid">
                    <view class="ov-item">
                        <view class="ov-label">本店核销次数</view>
                        <view class="ov-value">{{ storeOverview.verifyCount || 0 }}</view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {ref, reactive, computed} from "vue";
import {onLoad} from "@dcloudio/uni-app";
import request from "@/hooks/request";

const cardId = ref()

const options = ref({
    timeType: 'cumulative',
})

// 门店业绩
const storeOverview = ref({});
const getStoreOverview = () => {
    request.get('/seller/card/stat/store-overview', {
        cardId: cardId.value,
        ...options.value,
    }).then(res => {
        storeOverview.value = res.data
    })
}

const onChangeTimeRange = (timeType) => {
    options.value.timeType = timeType
    getStoreOverview()
}


onLoad((e) => {
    cardId.value = e.cardId
    getStoreOverview()
})
</script>

<style scoped>
.stat-filter {
    background: #fff;
    height: 80rpx;
    display: flex;
    align-items: center;
    gap: 20rpx;
    padding: 0 32rpx;
}

.stat-filter-item {
}

.stat-filter-item.active {
    font-weight: bold;
    color: #00b359;
}

/* 概览网格 */
.overview-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 20rpx;
}

.ov-item {
    background: #f9fafb;
    border-radius: 16rpx;
    padding: 20rpx;
}

.ov-label {
    font-size: 22rpx;
    color: #6b7280;
}

.ov-value {
    font-size: 44rpx;
    font-weight: 700;
    color: #0f172a;
    margin-top: 8rpx;
}

.ov-value-unit {
    font-size: 22rpx;
    font-weight: 500;
    color: #9ca3af;
    margin-left: 4rpx;
}

.ov-extra {
    font-size: 20rpx;
    color: #94a3b8;
    margin-top: 4rpx;
}

.ov-extra-bold {
    color: #0f172a;
    font-weight: 500;
}
</style>