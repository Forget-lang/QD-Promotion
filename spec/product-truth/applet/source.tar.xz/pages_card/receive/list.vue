<template>
    <view class="container-search">
        <view class="input-search">
            <t-input
                :custom-style="{paddingTop:0,paddingBottom:0,paddingRight:0}"
                placeholder="支持次卡卡号搜索"
                v-model:value="search.cardReceiveId"
                borderless
                size="small"
                :clearable="{ name: 'close-circle-filled', size: '36rpx' }"
                @clear="onClearKeyword"
                @enter="onKeywordSearch"
            />
            <view class="input-search-actions">
                <t-button theme="default" size="small" variant="text" icon="search" @click="onKeywordSearch"/>
            </view>
        </view>
    </view>

    <!-- 筛选条 -->
    <view class="filter-bar">
        <view class="filter-bar-left">
            <view class="filter-bar-item" @tap="showOrderPicker = true">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.sorter === 'desc' }">{{ search.sorter === 'desc' ? '最新' : '最早' }}</text>
                <t-icon name="chevron-down" size="24rpx" :color="search.sorter === 'desc' ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showTimePicker = true">
                <text class="filter-bar-label filter-bar-time" :class="{ 'filter-bar-active': search.startTime && search.endTime }">
                    时间
                </text>
                <t-icon name="chevron-down" size="24rpx" :color="search.startTime && search.endTime ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="showChannelPicker = true">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.channelType }">渠道</text>
                <t-icon name="chevron-down" size="24rpx"
                        :color="search.channelType ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="storeSelectRef?.onOpen">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.issueStoreId }">门店</text>
                <t-icon name="chevron-down" size="24rpx" :color="search.issueStoreId ? 'var(--td-brand-color)' : '#999'"/>
            </view>
            <view class="filter-bar-item" @tap="staffSelectRef?.onOpen">
                <text class="filter-bar-label" :class="{ 'filter-bar-active': search.issueStaffId }">员工</text>
                <t-icon name="chevron-down" size="24rpx" :color="search.issueStaffId ? 'var(--td-brand-color)' : '#999'"/>
            </view>
        </view>
        <view class="filter-bar-right" @tap="onResetFilter">
            <text class="filter-bar-action">重置</text>
        </view>
    </view>

    <view v-if="total > 0" class="paragraph">共 {{ total }} 条领取记录</view>

    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"/>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无领取记录</m-empty>
            <template v-else>
                <view
                    class="record-item"
                    v-for="item in items"
                    :key="item.id"
                    @tap="goDetail(item.id)"
                >
                    <view class="record-header">
                        <view class="record-user">
                            <view class="user-avatar">
                                <image v-if="item.avatar" :src="item.avatar" mode="aspectFill"/>
                                <text v-else>{{ displayName(item).charAt(0) }}</text>
                            </view>
                            <view class="user-info">
                                <view class="user-name">{{ displayName(item) }}</view>
                                <view class="user-time">{{ item.receivedAt }}</view>
                            </view>
                        </view>
                        <t-tag :theme="item.status === RECEIVE_STATUS.VALID ? 'success' : 'danger'" variant="light" size="small">
                            <text :class="item.status === RECEIVE_STATUS.VALID ? 'text-success' : 'text-danger'">
                                {{ item.statusLabel }}
                            </text>
                        </t-tag>
                    </view>
                    <view class="card-name-row" v-if="!search.cardId">{{ item.cardName }}</view>
                    <view class="times-metrics" v-if="item.cardType === CARD_TYPE.UNLIMITED">
                        <view class="times-metric">
                            <text class="times-metric-num times-metric-verify">{{ item.verifyCount ?? 0 }}</text>
                            <text class="times-metric-label">已核销</text>
                        </view>
                    </view>
                    <view class="times-metrics" v-else>
                        <view class="times-metric">
                            <text class="times-metric-num">{{ item.totalTimes ?? 0 }}</text>
                            <text class="times-metric-label">总次数</text>
                        </view>
                        <view class="times-metric-divider"/>
                        <view class="times-metric">
                            <text class="times-metric-num times-metric-verify">{{ item.verifyCount ?? 0 }}</text>
                            <text class="times-metric-label">已核销</text>
                        </view>
                        <view class="times-metric-divider"/>
                        <view class="times-metric">
                            <text class="times-metric-num times-metric-discard">{{ item.discardCount ?? 0 }}</text>
                            <text class="times-metric-label">已作废</text>
                        </view>
                        <view class="times-metric-divider"/>
                        <view class="times-metric">
                            <text class="times-metric-num times-metric-remain">{{ remainOf(item) }}</text>
                            <text class="times-metric-label">剩余</text>
                        </view>
                    </view>
                    <view class="record-body">
                        <view class="issue-grid">
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">发放渠道</text>
                                <view class="issue-grid-value-row">
                                    <text class="issue-grid-value">{{ item.channelTypeLabel }}</text>
                                    <text class="transfer-badge"
                                          v-if="item.transferId && item.transferId !== '0'">转赠领取
                                    </text>
                                </view>
                            </view>
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">发券门店</text>
                                <text class="issue-grid-value text-ellipsis">{{ item.issueStoreName || '-' }}</text>
                            </view>
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">发券人</text>
                                <text class="issue-grid-value text-ellipsis">{{ item.issueStaffName || '-' }}</text>
                            </view>
                            <view class="issue-grid-item">
                                <text class="issue-grid-label">发放备注</text>
                                <text class="issue-grid-value text-ellipsis">{{ item.issueRemark || '无' }}</text>
                            </view>
                        </view>
                        <view class="transfer-tip" v-if="item.transferUserName">转赠人：{{ item.transferUserName }}</view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
    <m-submit v-if="items && items.length > 0 && checkPermission(PERM_CARD.EXPORT)" @click="onExportList">导出领取记录</m-submit>

    <!-- 时间选择弹框 -->
    <t-popup placement="bottom" v-model:visible="showTimePicker" @visible-change="onTimePickerChange" :z-index="10000" :overlay-props="{ zIndex: 9999 }">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-cancel" @tap="showTimePicker = false">取消</view>
                <view class="popup-header-title">选择时间</view>
                <view class="popup-header-confirm" @tap="onClearTime">清空</view>
            </view>
            <view class="popup-body" style="height: 600rpx;">
                <t-cell-group theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.startTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="开始时间"
                        placeholder="请选择开始时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <t-cell-group t-class="mt-2" theme="card">
                    <m-datetime-picker
                        v-model:value="tempTime.endTime"
                        startDate="2026-05-01"
                        startMode="fixed"
                        title="结束时间"
                        placeholder="请选择结束时间"
                        :popupProps="{ zIndex: 50000, showOverlay: true }"
                    ></m-datetime-picker>
                </t-cell-group>
                <view class="popup-footer mt-5">
                    <t-button theme="danger" size="large" block @click="onConfirmTime">确认</t-button>
                </view>
            </view>
        </view>
    </t-popup>

    <!-- 排序选择 ActionSheet -->
    <t-action-sheet
        :visible="showOrderPicker"
        :items="orderItems"
        @selected="onSelectOrder"
        @cancel="showOrderPicker = false"
    ></t-action-sheet>

    <!-- 领取渠道选择 ActionSheet -->
    <t-action-sheet
        :visible="showChannelPicker"
        :items="channelActionItems"
        @selected="onSelectChannel"
        @cancel="showChannelPicker = false"
    ></t-action-sheet>

    <!-- 门店选择 -->
    <m-store-select
        ref="storeSelectRef"
        v-model:value="search.issueStoreId"
        title="发放门店"
        placeholder="请选择发放门店"
        :multiple="false"
        :hidden="true"
        @label-change="onStoreLabelChange"
    />

    <!-- 员工选择 -->
    <m-staff-select
        ref="staffSelectRef"
        v-model:value="search.issueStaffId"
        title="发放员工"
        placeholder="请选择发放员工"
        :multiple="false"
        :hidden="true"
        @label-change="onStaffLabelChange"
    />

    <!-- VIP 升级抽屉：承接导出接口 2006 版本拦截 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad, onReachBottom, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {RECEIVE_STATUS, CARD_TYPE} from '@/constants/card'
import {useLink} from '@/hooks/useLink'
import utils from '@/utils/utils'
import {useAuth} from '@/hooks/useAuth'
import {PERM_CARD} from '@/constants/permission'
import {saveBase64Excel} from '@/hooks/useFile'
import dayjs from "dayjs";
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()

// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    cardReceiveId: undefined,
    cardId: '',
    sorter: 'desc',
    startTime: undefined,
    endTime: undefined,
    channelType: undefined,
    issueStoreId: undefined,
    issueStaffId: undefined,
    userId: undefined,
})
// 领取记录列表
const items = ref()
// 列表总数
const total = ref(0)
// 是否已加载完
const isCompleted = ref(false)
// 是否正在加载更多
const loadingMore = ref(false)

// 筛选相关
const showTimePicker = ref(false)
const showOrderPicker = ref(false)
const showChannelPicker = ref(false)
const storeSelectRef = ref()
const storeLabel = ref()
const staffSelectRef = ref()
const staffLabel = ref()
// 时间选择临时变量
const tempTime = ref({
    startTime: '',
    endTime: '',
})
// 排序选项
const orderItems = [
    {label: '最新', value: 'desc'},
    {label: '最早', value: 'asc'},
]
// 领取渠道选项
const channelOptions = [
    {label: '微信好友/群', value: 1},
    {label: '二维码', value: 2},
    {label: '海报', value: 3},
    {label: '公众号', value: 4},
]
const channelActionItems = channelOptions.map(o => ({label: o.label, value: o.value}))

// 展示用用户名称
const displayName = (item) => item.nickname || '用户'

// 剩余次数 = 总次数 - 已消耗（核销+作废）
const remainOf = (item) => {
    const total = Number(item.totalTimes) || 0
    const used = Number(item.usedCount) || 0
    return Math.max(total - used, 0)
}

// 门店选择标签变更后刷新列表
const onStoreLabelChange = (label) => {
    storeLabel.value = label
    applyFilterAndRefresh()
}

// 员工选择标签变更后刷新列表
const onStaffLabelChange = (label) => {
    staffLabel.value = label
    applyFilterAndRefresh()
}

// 时间弹框显隐；打开时回填已选时间
const onTimePickerChange = (visible) => {
    showTimePicker.value = visible
    if (visible) {
        tempTime.value.startTime = search.value.startTime || ''
        tempTime.value.endTime = search.value.endTime || ''
    }
}

// 确认时间筛选
const onConfirmTime = () => {
    search.value.startTime = tempTime.value.startTime || undefined
    search.value.endTime = tempTime.value.endTime || undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

// 清空时间筛选
const onClearTime = () => {
    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    search.value.startTime = undefined
    search.value.endTime = undefined
    showTimePicker.value = false
    applyFilterAndRefresh()
}

// 选择排序方式
const onSelectOrder = (e) => {
    search.value.sorter = e.selected.value
    showOrderPicker.value = false
    applyFilterAndRefresh()
}

// 选择发放渠道
const onSelectChannel = (e) => {
    search.value.channelType = e.selected.value
    showChannelPicker.value = false
    applyFilterAndRefresh()
}

// 清空卡号搜索关键词
const onClearKeyword = () => {
    search.value.cardReceiveId = undefined
    applyFilterAndRefresh()
}

// 卡号搜索
const onKeywordSearch = () => {
    search.value.cardReceiveId = search.value.cardReceiveId || undefined
    applyFilterAndRefresh()
}

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取次卡领取记录列表
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/card/receive/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 下拉刷新：重置到第一页
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 应用筛选条件并重新加载第一页
const applyFilterAndRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

// 重置筛选（保留从详情页带入的 cardId / userId）
const onResetFilter = () => {
    const userId = search.value.userId
    const cardId = search.value.cardId
    search.value.startTime = undefined
    search.value.endTime = undefined
    search.value.sorter = 'desc'
    search.value.channelType = undefined
    search.value.issueStoreId = undefined
    search.value.issueStaffId = undefined
    search.value.cardReceiveId = undefined
    search.value.userId = userId
    search.value.cardId = cardId

    tempTime.value.startTime = ''
    tempTime.value.endTime = ''
    staffLabel.value = ''
    storeLabel.value = ''

    applyFilterAndRefresh()
}

// 跳转领取详情
const goDetail = (id) => {
    push('/pages_card/receive/detail?id=' + id)
}

// 按当前筛选条件导出领取记录
const onExportList = async () => {
    utils.showLoading()
    try {
        const res = await request.post('/seller/card/receive/export', search.value)
        await saveBase64Excel(res.data.file, '次卡领取记录')
    } catch (err) {
        // ignore
    } finally {
        utils.hideLoading()
    }
}

onLoad((e) => {
    if (e.cardId) {
        search.value.cardId = e.cardId
    }
    if (e.userId) {
        search.value.userId = e.userId
    }
    if (e.type === 'today') {
        search.value.startTime = dayjs().format('YYYY-MM-DD') + ' 00:00:00'
        search.value.endTime = dayjs().format('YYYY-MM-DD') + ' 23:59:59'
    }
    getItems()
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
/* 筛选条 */
.filter-bar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 20rpx 32rpx;
    background: #fff;
    border-bottom: 1rpx solid #eee;
}

.filter-bar-left {
    display: flex;
    align-items: center;
    gap: 40rpx;
}

.filter-bar-item {
    display: flex;
    align-items: center;
    gap: 6rpx;
    padding: 8rpx 0;
}

.filter-bar-label {
    font-size: 28rpx;
    color: #666;
    max-width: 70rpx;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.filter-bar-time {
    max-width: 180rpx;
}

.filter-bar-active {
    color: var(--td-brand-color) !important;
}

.filter-bar-right {
    display: flex;
    align-items: center;
}

.filter-bar-action {
    font-size: 28rpx;
    color: var(--td-brand-color);
}

.popup-footer {
    display: flex;
    padding: 24rpx 32rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
}

.record-item {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
    margin-bottom: 20rpx;
}

.record-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.record-user {
    display: flex;
    align-items: center;
}

.user-avatar {
    width: 72rpx;
    height: 72rpx;
    border-radius: 50%;
    background: #f5f5f5;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
}

.user-avatar image {
    width: 100%;
    height: 100%;
}

.user-info {
    margin-left: 16rpx;
}

.user-name {
    font-size: 28rpx;
    font-weight: 600;
}

.user-time {
    margin-top: 6rpx;
    font-size: 22rpx;
    color: #999;
}

.card-name-row {
    margin: 16rpx 0 0;
    font-size: 28rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
}

.times-metrics {
    display: flex;
    align-items: stretch;
    margin: 16rpx 0;
    padding: 20rpx 8rpx;
    background: #fafafa;
    border-radius: 12rpx;
}

.times-metric {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    gap: 8rpx;
}

.times-metric-num {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.2;
}

.times-metric-verify {
    color: #07c160;
}

.times-metric-discard {
    color: #e84c59;
}

.times-metric-remain {
    color: #1989fa;
}

.times-metric-label {
    font-size: 22rpx;
    color: #999;
}

.times-metric-divider {
    width: 1rpx;
    align-self: stretch;
    margin: 4rpx 0;
    background: #eee;
}

.record-body {
    padding-bottom: 4rpx;
}

.issue-grid {
    display: grid;
    grid-template-columns: repeat(2, 1fr);
    gap: 16rpx;
}

.issue-grid-item {
    background: #fafafa;
    border-radius: 12rpx;
    padding: 16rpx 20rpx;
    /* grid 子项默认最小宽度为 auto，会导致内部 text-ellipsis 失效而撑开格子，置 0 让省略生效 */
    min-width: 0;
}

.issue-grid-label {
    display: block;
    font-size: 22rpx;
    color: #999;
    margin-bottom: 8rpx;
}

.issue-grid-value-row {
    display: flex;
    align-items: center;
    flex-wrap: wrap;
    gap: 8rpx;
}

.issue-grid-value {
    display: block;
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
}

</style>
