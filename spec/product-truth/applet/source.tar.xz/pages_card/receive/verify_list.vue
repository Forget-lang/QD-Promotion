<template>
    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"/>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">暂无核销记录</m-empty>
            <template v-else>
                <view class="list-summary">
                    <text>共 {{ total }} 条核销记录</text>
                </view>
                <view
                    class="record-item"
                    v-for="item in items"
                    :key="item.id"
                    @tap="push('/pages_card/verify/detail?id=' + item.id)"
                >
                    <view class="record-header">
                        <view class="record-time">{{ item.verifiedAt }}</view>
                        <t-tag
                            :theme="item.status === VERIFY_STATUS.SUCCESS ? 'success' : 'danger'"
                            variant="light" size="small">
                            {{ item.statusLabel }}
                        </t-tag>
                    </view>
                    <view class="issue-grid">
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">核销优惠</text>
                            <text class="issue-grid-value text-ellipsis">
                                第 {{ item.useSort }} 次
                                <template v-if="item.benefitLabel"> · {{ item.benefitLabel }}</template>
                            </text>
                        </view>
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">核销门店</text>
                            <text class="issue-grid-value text-ellipsis">{{ item.verifyStoreName || '-' }}</text>
                        </view>
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">核销员工</text>
                            <text class="issue-grid-value text-ellipsis">{{ item.verifyStaffName || '-' }}</text>
                        </view>
                        <view class="issue-grid-item">
                            <text class="issue-grid-label">核销备注</text>
                            <text class="issue-grid-value text-ellipsis">{{ item.verifyRemark || '无' }}</text>
                        </view>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {VERIFY_STATUS} from '@/constants/card'
import {useLink} from '@/hooks/useLink'
import to from '@/hooks/to'

const {push} = useLink()

// 领取记录 ID
const id = ref('')
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    cardReceiveId: undefined,
    sorter: 'desc',
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 核销记录总数
const total = ref(0)
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取核销记录列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/card/verify/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

onLoad((e) => {
    id.value = e.id
    search.value.cardReceiveId = e.id
    getItems()
})

onPullDownRefresh(() => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.list-summary {
    padding: 0 8rpx 20rpx;
    font-size: 24rpx;
    color: #999;
}

.record-item {
    background: #fff;
    border-radius: 16rpx;
    padding: 24rpx;
    margin-bottom: 20rpx;
}

.record-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 16rpx;
}

.record-time {
    font-size: 26rpx;
    color: #999;
}

.issue-grid {
    display: grid;
    /* minmax(0, 1fr)：允许列宽收缩到 0，避免长文本按内容固有宽度撞开列轨 */
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 16rpx;
}

.issue-grid-item {
    background: #fafafa;
    border-radius: 12rpx;
    padding: 16rpx 20rpx;
    /* grid 子项隐式最小宽度为 auto，需置 0 才能让内部 text-ellipsis 生效 */
    min-width: 0;
}

.issue-grid-label {
    display: block;
    font-size: 22rpx;
    color: #999;
    margin-bottom: 8rpx;
}

.issue-grid-value {
    display: block;
    font-size: 26rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
}
</style>
