<template>
    <m-result v-if="isSuccess"
              type="success"
              title="创建成功"
              description="次卡已创建，可前往详情查看"
              confirmText="查看详情"
              cancelText="返回"
              @confirm="replace('/pages_card/card/detail?cardId=' + cardId)"
              @cancel="back()"
    ></m-result>
    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view class="">封面图片</view>
                <view class="text-small text-success">必填，用于私密发放与企微分享</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="coverImages"
                    :max="1"
                    :cropperWidth="300"
                    :cropperHeight="240"
                    emitName="cardCover"
                />
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-input
                placeholder="最多32个字"
                align="right"
                :maxlength="32"
                v-model:value="form.name"
            >
                <template #label>
                    <view class="input-custom-label-required">次卡名称</view>
                </template>
            </t-input>
            <t-input
                placeholder="最少1张，最多1万张"
                type="number"
                align="right"
                v-model:value="form.totalStock"
                suffix="张"
            >
                <template #label>
                    <view class="input-custom-label-required">制作数量</view>
                </template>
            </t-input>
            <t-input
                placeholder="最少1张，最多100张"
                type="number"
                align="right"
                v-model:value="form.userLimit"
                suffix="张"
            >
                <template #label>
                    <view class="input-custom-label-required">每人限领</view>
                </template>
            </t-input>
            <t-input
                v-if="form.cardType === CARD_TYPE.TIMES"
                :placeholder="timesPlaceholder"
                type="number"
                align="right"
                v-model:value="form.times"
                suffix="次"
            >
                <template #label>
                    <view class="input-custom-label-required">每张包含次数</view>
                </template>
            </t-input>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-select
                required
                title="有效期类型"
                v-model:value="form.validType"
                :options="validTypeOptions"
            />
            <t-input
                v-if="form.validType !== VALID_TYPE.CUSTOM"
                :placeholder="validDayPlaceholder"
                type="number"
                align="right"
                v-model:value="form.validDay"
                suffix="天"
            >
                <template #label>
                    <view class="input-custom-label-required">有效期</view>
                </template>
            </t-input>
            <m-datetime-picker
                v-if="form.validType === VALID_TYPE.CUSTOM"
                required
                v-model:value="form.validStartTime"
                format="YYYY-MM-DD"
                title="有效开始时间"
                placeholder="选择开始时间"
                mode="date"
            />
            <m-datetime-picker
                v-if="form.validType === VALID_TYPE.CUSTOM"
                required
                v-model:value="form.validEndTime"
                format="YYYY-MM-DD"
                title="有效结束时间"
                placeholder="选择结束时间"
                mode="date"
            />
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="限制核销间隔" description="0=每天1次，1=间隔1天，最多30天">
                <template #note>
                    <t-switch v-model:value="form.isVerifyInterval" :default-value="false"/>
                </template>
            </t-cell>
            <t-input
                v-if="form.isVerifyInterval"
                placeholder="0~30，0表示每天1次"
                type="number"
                align="right"
                v-model:value="form.verifyIntervalDay"
                suffix="天"
            >
                <template #label>
                    <view class="input-custom-label-required">核销间隔</view>
                </template>
            </t-input>
            <t-cell description="开启后">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启动态核销码</text>
                        <m-edition-badge :feature="EDITION_FEATURES.VERIFY_SIGN" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isVerifySign" @change="onVerifySignChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <view class="mt-2">
            <m-theme-select v-model:value="form.theme"/>
        </view>

        <template v-if="form.cardType === CARD_TYPE.BENEFIT">
            <view class="mt-2 container">
                <m-card-item-editor v-model:value="form.items"/>
            </view>

            <view class="mt-2 container" v-if="form.items.length > 0">
                <m-card-benefit-list :items="form.items" :theme="form.theme" :showStatus="false"/>
            </view>
        </template>

        <t-cell-group v-else t-class="mt-2" theme="card" :bordered="false">
            <t-textarea
                label="优惠内容"
                v-model:value="form.benefitContent"
                :maxlength="500"
                :indicator="true"
                :placeholder="benefitContentPlaceholder"
            />
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-store-select
                required
                title="适用门店"
                :multiple="true"
                :bordered="true"
                :show-disabled="true"
                :auto-selected="true"
                v-model:value="form.storeIds"
            />
            <m-staff-select
                required
                title="发券员工"
                :multiple="true"
                :show-disabled="true"
                v-model:value="form.staffIds"
            />
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="允许转赠">
                <template #note>
                    <t-switch v-model:value="form.isTransfer" :default-value="true"/>
                </template>
            </t-cell>
            <t-cell>
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>填写手机号</text>
                        <m-edition-badge :feature="EDITION_FEATURES.GET_MOBILE" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isGetMobile" :default-value="false" @change="onGetMobileChange"/>
                </template>
            </t-cell>
            <t-cell :bordered="false" description="该商户下从未领过优惠券、券包、次卡的顾客才可领取">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>仅新客户可领</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_NEW_CUSTOMER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyNewCustomer" :default-value="false"
                              @change="onOnlyNewCustomerChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea
                label="使用须知"
                v-model:value="form.content"
                :maxlength="500"
                :indicator="true"
                placeholder="请输入使用须知"
            />
            <m-cover-uploader
                v-model:value="form.productImages"
                :max="9"
                tip="可上传活动长图、店内环境、菜单等图片"
                emitName="cardProduct"
            />
            <view class="usage-toolbar">
                <view class="usage-toolbar-tip">
                    <t-icon name="lightbulb" size="28rpx" color="var(--td-brand-color)"/>
                    <text class="usage-toolbar-tip-text">不会写？一键套用模版</text>
                </view>
                <view class="usage-toolbar-actions">
                    <t-button theme="primary" variant="text" size="small" @click="onUseContentTemplate(1)">通用模版</t-button>
                    <t-button t-class="ml-2" theme="default" variant="text" size="small" :disabled="!form.content"
                              custom-style="background-color: transparent;" @click="onClearContent">清空
                    </t-button>
                </view>
            </view>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" :disabled="loading" @click="onSubmit">
                创建次卡
            </t-button>
        </view>

        <!-- VIP 升级抽屉：承接接口 2006 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import {CARD_TYPE, VALID_TYPE} from '@/constants/card'
import {EDITION_FEATURES, getFeatureQuota} from '@/constants/edition'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import {useVipGuard} from '@/hooks/useVipGuard'

const {replace, back} = useLink()
const {getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()
const loading = ref(false)
const isSuccess = ref(false)
const cardId = ref('')

// 优惠内容占位文案
const benefitContentPlaceholder = computed(() => {
    if (form.value.cardType === CARD_TYPE.UNLIMITED) {
        return '例如：景区年卡'
    } else if (form.value.cardType === CARD_TYPE.TIMES) {
        return '例如：洗车10次卡'
    }
    return ''
})

// 每张包含次数上限：按版本档位取值（免费 7 / 标准 30 / 专业 100 / 企业 365）
const timesMax = computed(() => getFeatureQuota(EDITION_FEATURES.CARD_TIMES, staffSession.value?.editionId))
// 次数输入提示（随版本动态变化）
const timesPlaceholder = computed(() => `最少1次，最多${timesMax.value}次`)

// 有效期上限：按版本档位取值（365/365/365/1095）
const validDayMax = computed(() => getFeatureQuota(EDITION_FEATURES.CARD_VALID_DAY, staffSession.value?.editionId))
// 有效期输入提示（随版本动态变化）
const validDayPlaceholder = computed(() => `最少1天，最多${validDayMax.value}天`)

const validTypeOptions = [
    { label: '固定有效期', value: VALID_TYPE.CUSTOM },
    { label: '自领券日起N天内有效', value: VALID_TYPE.TODAY },
    { label: '自领券次日起N天内有效', value: VALID_TYPE.NEXT_DAY }
]

const coverImages = ref([])
const form = ref({
    cardType: CARD_TYPE.BENEFIT,
    name: '',
    cover: '',
    userLimit: undefined,
    totalStock: undefined,
    validType: 2,
    validDay: null,
    validStartTime: '',
    validEndTime: '',
    isVerifyInterval: false,
    verifyIntervalDay: 0,
    times: undefined,
    benefitContent: '',
    items: [],
    storeIds: [],
    staffIds: [],
    isTransfer: false,
    isGetMobile: false,
    isOnlyNewCustomer: false,
    isVerifySign: false,
    content: '',
    productImages: [],
    theme: 1,
})

onLoad((options) => {
    const cardType = Number(options?.cardType)
    if (cardType === CARD_TYPE.UNLIMITED || cardType === CARD_TYPE.TIMES || cardType === CARD_TYPE.BENEFIT) {
        form.value.cardType = cardType
    }
})

// 每次进入页面刷新员工会话，保证版本预检数据最新
onShow(() => {
    getSession()
})

// 开启动态核销码：企业版及以上支持，受限则回退开关
const onVerifySignChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.VERIFY_SIGN).then((allowed) => {
        if (!allowed) form.value.isVerifySign = false
    })
}

// 开启填写手机号：标准版及以上支持，受限则回退开关
const onGetMobileChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.GET_MOBILE).then((allowed) => {
        if (!allowed) form.value.isGetMobile = false
    })
}

// 开启仅新客户可领：标准版及以上支持，受限则回退开关
const onOnlyNewCustomerChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_NEW_CUSTOMER).then((allowed) => {
        if (!allowed) form.value.isOnlyNewCustomer = false
    })
}

const onUseContentTemplate = (templateId) => {
    if (templateId === 1) {
        form.value.content = `● 遗失处理：次卡仅限本人使用，请勿转借他人。因手机丢失、账号泄露等原因导致次卡被他人核销，责任由用户自行承担。
● 使用方式：到店消费时，请在结账前主动出示本次卡电子码，由店员扫码核销本次权益；一卡可多次核销，每次核销对应卡内设定的优惠内容。
● 核销规则：每次核销消耗 1 次，核销后不可撤销；若商家设置了核销间隔，需按间隔要求到店使用。
● 找零兑现：本次卡权益不兑现、不找零；是否允许转赠以商家设置为准。
● 有效期说明：逾期未核销的次数将自动作废，不支持延期或补发；若遇门店临时停业（如装修、节假日调整），有效期不顺延。
● 适用范围：特价商品、团购套餐、礼品卡充值等特殊项目不适用（具体以门店公示为准）。
● 特别说明：严禁通过虚假交易等违规方式使用本次卡，一经发现，门店有权取消核销资格并追回优惠金额。
● 最终解释权：在法律允许范围内，本店拥有本次活动最终解释权。如有疑问可联系门店客服。`
    }
}

// 一键清空使用须知（二次确认防止误触）
const onClearContent = () => {
    uni.showModal({
        title: '提示',
        content: '确定清空使用须知吗？',
        success: (res) => {
            if (res.confirm) {
                form.value.content = ''
            }
        }
    })
}

const onSubmit = utils.throttle(() => {
    if (!coverImages.value?.length) {
        utils.toast('请上传次卡封面')
        return
    }
    loading.value = true
    request.post('/seller/card/create', {
        ...form.value,
        cover: coverImages.value[0],
    }).then((res) => {
        isSuccess.value = true
        cardId.value = res.data.cardId
        uni.$emit('onCardCreate')
    }).finally(() => {
        loading.value = false
    })
}, 800)
</script>

<style>
/*
 * 自定义样式原因：使用须知工具栏为「灯泡图标引导 + 文字按钮」单行内联组合，
 * app.css 的 .tips-card 是整块提示卡（含标题/多行），不适合单行工具条；TDesign 亦无对应组件。
 * 替代方案：白底融入卡片、细分隔线区隔内容，图标色取 --td-brand-color，仅补缺位视觉层。
 */
.usage-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16rpx 16rpx 16rpx 32rpx;
    background-color: #FFFFFF;
    border-top: 1rpx solid #F0F0F0;
}

.usage-toolbar-tip {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 16rpx;
}

.usage-toolbar-tip-text {
    font-size: 24rpx;
    color: #666;
    margin-left: 8rpx;
}

.usage-toolbar-actions {
    display: flex;
    align-items: center;
    flex-shrink: 0;
}
</style>
