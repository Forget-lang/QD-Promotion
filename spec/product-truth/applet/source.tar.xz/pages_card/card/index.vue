<template>
    <t-tabs v-model:value="currentTab" bottom-line-mode="auto" @change="onTabChange">
        <t-tab-panel label="可用次卡" :value="1"></t-tab-panel>
        <t-tab-panel label="失效次卡" :value="2"></t-tab-panel>
    </t-tabs>

    <view class="container mt-2 container-safety">
        <m-loading v-if="items === undefined"></m-loading>
        <m-empty v-else-if="items === null">
            <view>加载失败</view>
            <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
        </m-empty>
        <template v-else>
            <m-empty v-if="items.length === 0">
                {{ currentTab === 1 ? '暂无可用次卡，点击下方制作' : '暂无失效次卡' }}
            </m-empty>
            <template v-else>
                <view class="list-summary">
                    <text>共 {{ total }} 张次卡</text>
                    <text v-if="!isCompleted" class="list-summary-hint">已加载 {{ items.length }} 张</text>
                </view>
                <view
                    class="list-card mb-2"
                    v-for="(item, index) in items"
                    :key="item.id"
                    @tap="push('/pages_card/card/detail?cardId=' + item.id)"
                >
                    <m-card-magnetic-face
                        :theme="Number(item.theme) || 1"
                        :merchant-name="item.merchantName"
                        :cover="item.cover"
                        :title="item.name"
                        :card-type="item.cardType"
                        :total-times="item.totalTimes"
                        :valid-label="item.validLabel"
                        :status="item.status"
                        :status-label="item.statusLabel"
                    />
                    <view v-if="item.auditStatus !== CARD_AUDIT_STATUS.PASSED" class="card-audit mt-1">
                        <t-tag theme="warning" variant="light-outline" size="small">{{ item.auditStatusLabel }}</t-tag>
                    </view>
                </view>
                <m-loading v-if="loadingMore" text="正在加载..."/>
                <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
            </template>
        </template>
    </view>
    <m-submit v-if="checkPermission(PERM_CARD.CREATE)" @click="push('/pages_card/card/choose_type')">制作次卡</m-submit>
</template>

<script setup>
import {onLoad, onUnload, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {CARD_AUDIT_STATUS} from '@/constants/card'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_CARD} from '@/constants/permission.js'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission} = useAuth()
// 当前 Tab：1 可用 2 失效
const currentTab = ref(1)
// 列表查询参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: 1,
})
// 次卡列表
const items = ref()
// 列表总数
const total = ref(0)
// 是否已加载完
const isCompleted = ref(false)
// 是否正在加载更多
const loadingMore = ref(false)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 获取次卡列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/card/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            items.value = null
        } else {
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

// 刷新列表（事件监听复用）
const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// Tab 切换
const onTabChange = (e) => {
    search.value.status = e.value
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    onRefresh()
}

const registerEvent = () => {
    uni.$on('onCardDelete', (e) => {
        if (!e?.id || !items.value?.length) return
        const deleteIndex = items.value.findIndex(item => item.id === e.id)
        if (deleteIndex >= 0) {
            items.value.splice(deleteIndex, 1)
            if (total.value > 0) {
                total.value--
            }
        }
    })
    uni.$on('onCardDiscard', (e) => {
        if (!e?.id || !items.value?.length) return
        if (currentTab.value !== 1) return
        const index = items.value.findIndex(item => item.id === e.id)
        if (index >= 0) {
            items.value.splice(index, 1)
            if (total.value > 0) total.value--
        }
    })
    uni.$on('onCardUpdate', (e) => {
        if (!e?.id || !items.value?.length) return
        const editIndex = items.value.findIndex(item => item.id === e.id)
        if (editIndex >= 0) {
            items.value.splice(editIndex, 1, e)
        }
    })
    uni.$on('onCardCreate', () => {
        if (currentTab.value !== 1) return
        onRefresh()
    })
}

onLoad(() => {
    registerEvent()
    getItems()
})

onUnload(() => {
    uni.$off('onCardDelete')
    uni.$off('onCardDiscard')
    uni.$off('onCardUpdate')
    uni.$off('onCardCreate')
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.list-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 8rpx 20rpx;
    font-size: 24rpx;
    color: #999;
}

.list-summary-hint {
    color: #ccc;
}

.card-audit {
    padding: 0 8rpx;
}
</style>
