<template>
    <m-loading v-if="card === undefined"></m-loading>
    <template v-else>
        <m-result type="info" v-if="card.status !== CARD_STATUS.DISCARDED && card.status !== CARD_STATUS.EXPIRED" title="删除条件不足"
                  description="仅已作废和已过期的次卡可以删除">
            <template #action>
                <t-button @click="push('/pages_card/discard/discard?cardId=' + cardId)" theme="primary">
                    去作废次卡
                </t-button>
            </template>
        </m-result>
        <view v-if="card.status === CARD_STATUS.DISCARDED || card.status === CARD_STATUS.EXPIRED">
            <t-cell-group theme="card" t-class="mt-2">
                <t-checkbox-group v-model:value="checks">
                    <t-checkbox
                        :value="1"
                        label="你需确认删除后不可恢复，关联的发券员工与适用门店将一并解除。"
                    />
                    <t-checkbox
                        :value="2"
                        label="你需确认删除后，客户已领取的次卡将一并删除。"
                    />
                    <t-checkbox
                        :value="3"
                        label="你需确认若当前次卡配置了企业微信，将自动解除绑定。"
                    />
                </t-checkbox-group>
            </t-cell-group>
        </view>
        <m-submit v-if="checkPermission(PERM_CARD.DELETE)" @click="onDelete" :disabled="checks.length !== 3">删除次卡
        </m-submit>
        <m-submit v-else :disabled="true">您没有删除权限</m-submit>
    </template>
</template>

<script setup>
import {onLoad, onShow} from '@dcloudio/uni-app'
import {ref, computed} from 'vue'
import request from '@/hooks/request'
import {CARD_STATUS} from '@/constants/card'
import utils from '@/utils/utils'
import tools from '@/uni_modules/tdesign-uniapp/components/common/utils.wxs.js'
import {useLink} from '@/hooks/useLink'
import {useAuth} from "@/hooks/useAuth";
import {PERM_CARD} from "@/constants/permission";

const {push, back} = useLink()
const {checkPermission} = useAuth()
const cardId = ref('')
const card = ref()
const checks = ref([])

const cardCustomStyle = computed(() => {
    return tools._style({
        borderRadius: '24rpx',
        margin: '16px',
        overflow: 'hidden',
    })
})

const getCard = () => {
    request.get('/seller/card/get/detail', {id: cardId.value}).then(res => {
        card.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

const onDelete = () => {
    if ((card.value.status === CARD_STATUS.DISCARDED || card.value.status === CARD_STATUS.EXPIRED) && checks.value.length !== 3) {
        utils.toast('请确认所有选项')
        return
    }
    request.post('/seller/card/delete', {id: cardId.value}).then(() => {
        uni.$emit('onCardDelete', {id: cardId.value})
        utils.alert('删除成功', () => {
            back(2)
        })
    }).catch(() => {
    })
}

onLoad((e) => {
    cardId.value = e.cardId
})

onShow(() => {
    getCard()
})
</script>
