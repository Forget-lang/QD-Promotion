<template>
    <m-result
        v-if="isSuccess"
        type="success"
        title="修改成功"
        description="次卡信息已更新"
        back
    />

    <m-loading v-else-if="card === undefined"></m-loading>
    <m-empty v-else-if="card === null">次卡不存在</m-empty>

    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view class="">封面图片</view>
                <view class="text-small text-success">必填，用于私密发放与企微分享</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="coverImages"
                    :max="1"
                    emitName="cardCover"
                />
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-input placeholder="最多32个字" align="right" :maxlength="32" v-model:value="form.name">
                <template #label>
                    <view class="input-custom-label-required">次卡名称</view>
                </template>
            </t-input>
            <t-cell title="次卡类型" :note="card.cardTypeLabel" description="类型创建后不可修改"/>
            <t-cell title="制作数量" :note="form.totalStock + '张'" description="调整库存请在详情页操作"/>
            <t-input
                v-if="canEditItems"
                placeholder="最少1张，最多100张"
                type="number"
                align="right"
                v-model:value="form.userLimit"
                suffix="张"
            >
                <template #label>
                    <view class="input-custom-label-required">每人限领</view>
                </template>
            </t-input>
            <t-cell v-else title="每人限领" :note="form.userLimit + '张'" description="已有领取记录，不可修改"/>
            <template v-if="form.cardType === CARD_TYPE.TIMES">
                <t-input
                    v-if="canEditItems"
                    :placeholder="timesPlaceholder"
                    type="number"
                    align="right"
                    v-model:value="form.times"
                    suffix="次"
                >
                    <template #label>
                        <view class="input-custom-label-required">每张包含次数</view>
                    </template>
                </t-input>
                <t-cell v-else title="每张包含次数" :note="form.times + '次'" description="已有领取记录，不可修改"/>
            </template>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <template v-if="canEditItems">
                <m-select required title="有效期类型" v-model:value="form.validType" :options="validTypeOptions"/>
                <t-input
                    v-if="form.validType !== VALID_TYPE.CUSTOM"
                    :placeholder="validDayPlaceholder"
                    type="number"
                    align="right"
                    v-model:value="form.validDay"
                    suffix="天"
                >
                    <template #label>
                        <view class="input-custom-label-required">有效期</view>
                    </template>
                </t-input>
                <m-datetime-picker
                    v-if="form.validType === VALID_TYPE.CUSTOM"
                    required
                    v-model:value="form.validStartTime"
                    format="YYYY-MM-DD"
                    title="有效开始时间"
                    mode="date"
                />
                <m-datetime-picker
                    v-if="form.validType === VALID_TYPE.CUSTOM"
                    required
                    v-model:value="form.validEndTime"
                    format="YYYY-MM-DD"
                    title="有效结束时间"
                    mode="date"
                />
            </template>
            <t-cell
                v-else
                title="有效期"
                :note="card.validLabel"
            />
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <template v-if="canEditItems">
                <t-cell title="限制核销间隔" description="0=每天1次，1=间隔1天，最多30天">
                    <template #note>
                        <t-switch v-model:value="form.isVerifyInterval" :default-value="false"/>
                    </template>
                </t-cell>
                <t-input
                    v-if="form.isVerifyInterval"
                    placeholder="0~30，0表示每天1次"
                    type="number"
                    align="right"
                    v-model:value="form.verifyIntervalDay"
                    suffix="天"
                >
                    <template #label>
                        <view class="input-custom-label-required">核销间隔</view>
                    </template>
                </t-input>
            </template>
            <t-cell
                v-else
                title="核销间隔"
                :note="verifyIntervalNote"
            />
            <t-cell>
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>开启动态核销码</text>
                        <m-edition-badge :feature="EDITION_FEATURES.VERIFY_SIGN" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isVerifySign" @change="onVerifySignChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <view class="mt-2">
            <m-theme-select v-model:value="form.theme"/>
        </view>

        <template v-if="form.cardType === CARD_TYPE.BENEFIT">
            <view class="mt-2 px-3" v-if="canEditItems">
                <m-card-item-editor v-model:value="form.items"/>
                <view class="mt-2">
                    <view class="paragraph mb-2">优惠进度预览</view>
                    <m-card-benefit-list :items="form.items" :theme="form.theme" :showStatus="false"/>
                </view>
            </view>
            <t-cell-group v-else t-class="mt-2" theme="card">
                <t-cell title="优惠内容" :note="card.totalTimes + ' 项'" description="已有领取记录，优惠项不可修改"/>
            </t-cell-group>
        </template>
        <t-cell-group v-else t-class="mt-2" theme="card" :bordered="false">
            <t-textarea
                label="优惠内容"
                v-model:value="form.benefitContent"
                :maxlength="500"
                :indicator="canEditItems"
                :disabled="!canEditItems"
                :placeholder="benefitContentPlaceholder"
            />
            <t-cell v-if="!canEditItems" description="已有领取记录，优惠内容不可修改" :bordered="false"/>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-store-select required title="适用门店" :multiple="true" :show-disabled="true"
                            v-model:value="form.storeIds"/>
            <m-staff-select required title="发券员工" :multiple="true" :show-disabled="true"
                            v-model:value="form.staffIds"/>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="允许转赠">
                <template #note>
                    <t-switch v-model:value="form.isTransfer"/>
                </template>
            </t-cell>
            <t-cell>
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>填写手机号</text>
                        <m-edition-badge :feature="EDITION_FEATURES.GET_MOBILE" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isGetMobile" @change="onGetMobileChange"/>
                </template>
            </t-cell>
            <t-cell :bordered="false" description="该商户下从未领过优惠券、券包、次卡的顾客才可领取">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>仅新客户可领</text>
                        <m-edition-badge :feature="EDITION_FEATURES.ONLY_NEW_CUSTOMER" class="ml-1"/>
                    </view>
                </template>
                <template #note>
                    <t-switch v-model:value="form.isOnlyNewCustomer" :default-value="false"
                              @change="onOnlyNewCustomerChange"/>
                </template>
            </t-cell>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea label="使用须知" v-model:value="form.content" :maxlength="500" :indicator="true"/>
            <m-cover-uploader
                v-model:value="form.productImages"
                :max="9"
                tip="可上传活动长图、店内环境、菜单等图片"
                emitName="cardProduct"
            />
            <view class="usage-toolbar">
                <view class="usage-toolbar-tip">
                    <t-icon name="lightbulb" size="28rpx" color="var(--td-brand-color)"/>
                    <text class="usage-toolbar-tip-text">不会写？一键套用模版</text>
                </view>
                <view class="usage-toolbar-actions">
                    <t-button theme="primary" variant="text" size="small" @click="onUseContentTemplate(1)">通用模版</t-button>
                    <t-button t-class="ml-2" theme="default" variant="text" size="small" :disabled="!form.content"
                              custom-style="background-color: transparent;" @click="onClearContent">清空
                    </t-button>
                </view>
            </view>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" @click="onSubmit">保存修改</t-button>
        </view>

        <!-- VIP 升级抽屉：承接接口 2006 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {computed, ref} from 'vue'
import {onLoad, onShow} from '@dcloudio/uni-app'
import request from '@/hooks/request'
import {CARD_TYPE, VALID_TYPE} from '@/constants/card'
import {EDITION_FEATURES, getFeatureQuota} from '@/constants/edition'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink.js'
import {useAuth} from '@/hooks/useAuth.js'
import {useVipGuard} from '@/hooks/useVipGuard'

const {replace, back} = useLink()
const {getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()
const cardId = ref('')
const card = ref()
const coverImages = ref([])
const loading = ref(false)
const isSuccess = ref(false)

// 优惠内容占位文案
const benefitContentPlaceholder = computed(() => {
    if (form.value.cardType === CARD_TYPE.UNLIMITED) {
        return '例如：景区年卡'
    } else if (form.value.cardType === CARD_TYPE.TIMES) {
        return '例如：洗车10次卡'
    }
    return ''
})

const validTypeOptions = [
    {label: '固定有效期', value: VALID_TYPE.CUSTOM},
    {label: '自领取日起N天内有效', value: VALID_TYPE.TODAY},
    {label: '自领取次日起N天内有效', value: VALID_TYPE.NEXT_DAY},
]

const form = ref()

const canEditItems = computed(() => card.value && card.value.receiveCount === 0)

const verifyIntervalNote = computed(() => {
    if (!form.value?.isVerifyInterval) return '不限制'
    const day = Number(form.value.verifyIntervalDay) || 0
    return day === 0 ? '每天可核销 1 次' : `间隔 ${day} 天可核销 1 次`
})

const getDetail = () => {
    request.get('/seller/card/get/detail', {id: cardId.value}).then(res => {
        card.value = res.data
        form.value = {
            ...res.data,
            times: res.data.cardType === CARD_TYPE.TIMES ? res.data.totalTimes : undefined,
            benefitContent: res.data.benefitContent || '',
            productImages: Array.isArray(res.data.productImages) ? res.data.productImages : [],
        }
        coverImages.value = res.data.cover ? [res.data.cover] : []
    }).catch(() => {
        card.value = null
    })
}

const onUseContentTemplate = (templateId) => {
    if (templateId === 1) {
        form.value.content = `● 遗失处理：次卡仅限本人使用，请勿转借他人。因手机丢失、账号泄露等原因导致次卡被他人核销，责任由用户自行承担。
● 使用方式：到店消费时，请在结账前主动出示本次卡电子码，由店员扫码核销本次权益；一卡可多次核销，每次核销对应卡内设定的优惠内容。
● 核销规则：每次核销消耗 1 次，核销后不可撤销；若商家设置了核销间隔，需按间隔要求到店使用。
● 找零兑现：本次卡权益不兑现、不找零；是否允许转赠以商家设置为准。
● 有效期说明：逾期未核销的次数将自动作废，不支持延期或补发；若遇门店临时停业（如装修、节假日调整），有效期不顺延。
● 适用范围：特价商品、团购套餐、礼品卡充值等特殊项目不适用（具体以门店公示为准）。
● 特别说明：严禁通过虚假交易等违规方式使用本次卡，一经发现，门店有权取消核销资格并追回优惠金额。
● 最终解释权：在法律允许范围内，本店拥有本次活动最终解释权。如有疑问可联系门店客服。`
    }
}

// 一键清空使用须知（二次确认防止误触）
const onClearContent = () => {
    uni.showModal({
        title: '提示',
        content: '确定清空使用须知吗？',
        success: (res) => {
            if (res.confirm) {
                form.value.content = ''
            }
        }
    })
}

const onSubmit = utils.throttle(() => {
    if (!coverImages.value?.length) {
        utils.toast('请上传次卡封面')
        return
    }
    loading.value = true
    request.post('/seller/card/update', {
        ...form.value,
        cover: coverImages.value[0],
    }).then(() => {
        return request.get('/seller/card/get/detail', {id: cardId.value})
    }).then(res => {
        uni.$emit('onCardUpdate', res.data)
        isSuccess.value = true
    }).finally(() => {
        loading.value = false
    })
}, 800)

onLoad((options) => {
    cardId.value = options.cardId
    getDetail()
})

// 每次进入页面刷新员工会话，保证版本预检数据最新
onShow(() => {
    getSession()
})

// 每张包含次数上限：按版本档位取值（免费 7 / 标准 30 / 专业 100 / 企业 365）
const timesMax = computed(() => getFeatureQuota(EDITION_FEATURES.CARD_TIMES, staffSession.value?.editionId))
// 次数输入提示（随版本动态变化）
const timesPlaceholder = computed(() => `最少1次，最多${timesMax.value}次`)

// 有效期上限：按版本档位取值（365/365/365/1095）
const validDayMax = computed(() => getFeatureQuota(EDITION_FEATURES.CARD_VALID_DAY, staffSession.value?.editionId))
// 有效期输入提示（随版本动态变化）
const validDayPlaceholder = computed(() => `最少1天，最多${validDayMax.value}天`)

// 开启动态核销码：企业版及以上支持，受限则回退开关
const onVerifySignChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.VERIFY_SIGN).then((allowed) => {
        if (!allowed) form.value.isVerifySign = false
    })
}

// 开启填写手机号：标准版及以上支持，受限则回退开关
const onGetMobileChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.GET_MOBILE).then((allowed) => {
        if (!allowed) form.value.isGetMobile = false
    })
}

// 开启仅新客户可领：标准版及以上支持，受限则回退开关
const onOnlyNewCustomerChange = (e) => {
    if (!e?.value) return
    check(EDITION_FEATURES.ONLY_NEW_CUSTOMER).then((allowed) => {
        if (!allowed) form.value.isOnlyNewCustomer = false
    })
}
</script>

<style>
/*
 * 自定义样式原因：使用须知工具栏为「灯泡图标引导 + 文字按钮」单行内联组合，
 * app.css 的 .tips-card 是整块提示卡（含标题/多行），不适合单行工具条；TDesign 亦无对应组件。
 * 替代方案：白底融入卡片、细分隔线区隔内容，图标色取 --td-brand-color，仅补缺位视觉层。
 */
.usage-toolbar {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 16rpx 16rpx 16rpx 32rpx;
    background-color: #FFFFFF;
    border-top: 1rpx solid #F0F0F0;
}

.usage-toolbar-tip {
    display: flex;
    align-items: center;
    flex: 1;
    margin-right: 16rpx;
}

.usage-toolbar-tip-text {
    font-size: 24rpx;
    color: #666;
    margin-left: 8rpx;
}

.usage-toolbar-actions {
    display: flex;
    align-items: center;
    flex-shrink: 0;
}
</style>
