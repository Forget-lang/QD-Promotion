<template>
    <view>
        <t-cell-group t-class="mt-2" theme="card">
            <t-cell description="例如：景区年卡/会员卡/月卡，有效期内不限次数使用，凭卡核销进入" arrow hover
                    @click="onSelectCardType(CARD_TYPE.UNLIMITED)">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>通卡</text>
                        <m-edition-badge :feature="EDITION_FEATURES.UNLIMITED_CARD" class="ml-1"/>
                    </view>
                </template>
                <template #left-icon>
                    <view class="type-icon" style="background-color: #0052d9;">
                        <t-icon name="cardmembership" size="44rpx" color="#ffffff"/>
                    </view>
                </template>
            </t-cell>
            <t-cell title="次卡" description="例如：洗车10次卡，按次数核销" arrow hover
                    :url="`/pages_card/card/create?cardType=${CARD_TYPE.TIMES}`">
                <template #left-icon>
                    <view class="type-icon" style="background-color: #ed7b2f;">
                        <t-icon name="time-filled" size="44rpx" color="#ffffff"/>
                    </view>
                </template>
            </t-cell>
            <t-cell description="例如：护理套餐卡，每次核销对应一项权益" arrow hover
                    @click="onSelectCardType(CARD_TYPE.BENEFIT)">
                <template #title>
                    <view class="d-flex align-items-center">
                        <text>权益卡</text>
                        <m-edition-badge :feature="EDITION_FEATURES.BENEFIT_CARD" class="ml-1"/>
                    </view>
                </template>
                <template #left-icon>
                    <view class="type-icon" style="background-color: #e84c59;">
                        <t-icon name="gift-filled" size="44rpx" color="#ffffff"/>
                    </view>
                </template>
            </t-cell>
        </t-cell-group>

        <!-- VIP 升级抽屉：门禁 check 确认后经事件打开 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {CARD_TYPE} from '@/constants/card'
import {EDITION_FEATURES} from '@/constants/edition'
import {useLink} from '@/hooks/useLink.js'
import {useVipGuard} from '@/hooks/useVipGuard'

const {push} = useLink()
const {check} = useVipGuard()

// 选择通卡/权益卡：专业版及以上支持，检测通过后进入创建页
const onSelectCardType = (cardType) => {
    const feature = cardType === CARD_TYPE.UNLIMITED ? EDITION_FEATURES.UNLIMITED_CARD : EDITION_FEATURES.BENEFIT_CARD
    check(feature).then((allowed) => {
        if (allowed) {
            push(`/pages_card/card/create?cardType=${cardType}`)
        }
    })
}
</script>

<style>
.type-icon {
    width: 80rpx;
    height: 80rpx;
    border-radius: 16rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}
</style>
