<template>
    <!-- 成功反馈 -->
    <m-result v-if="showSuccess" theme="success" title="修改成功" back></m-result>
    <template v-else>
        <!-- 门店选择 -->
        <t-cell-group :title="'当前适用门店'+currentStoreCount+'个'" theme="card">
            <m-store-select
                title="适用门店"
                required
                :multiple="true"
                :show-disabled="true"
                v-model:value="form.storeIds"
            ></m-store-select>
        </t-cell-group>

        <!-- 提交按钮 -->
        <m-submit :loading="loading" :disabled="loading" @click="onSubmit">确认修改</m-submit>

        <!-- VIP 升级抽屉：承接提交接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </template>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app';
import {ref} from 'vue';
import request from '@/hooks/request.js';
import utils from '@/utils/utils';
import {useLink} from '@/hooks/useLink.js';
import MStoreSelect from '@/components/m/m-store-select/m-store-select.vue';
import MResult from '@/components/m/m-result/m-result.vue';
import MSubmit from '@/components/m/m-submit/m-submit.vue';

const {back} = useLink();

const cardId = ref('');
const form = ref({
    storeIds: []
});
const loading = ref(false);
const showSuccess = ref(false);
const currentStoreCount = ref(0);

// 获取次卡信息
const getCardInfo = () => {
    request.get('/seller/card/get/detail', {id: cardId.value}).then((res) => {
        form.value.storeIds = res.data.storeIds || []
        currentStoreCount.value = (res.data.storeIds || []).length
    })
};

// 提交修改
const onSubmit = () => {
    if (!form.value.storeIds || form.value.storeIds.length === 0) {
        utils.toast('请至少选择一个适用门店');
        return;
    }

    loading.value = true;
    request.post('/seller/card/update-stores', {
        id: cardId.value,
        storeIds: form.value.storeIds
    }).then(() => {
        showSuccess.value = true
    }).catch((err) => {
        utils.toast(err.message)
    }).finally(() => {
        loading.value = false
    })
};

onLoad((e) => {
    if (!e.cardId) {
        utils.toast('缺少次卡ID');
        setTimeout(() => {
            back();
        }, 1500);
        return;
    }
    cardId.value = e.cardId;
    getCardInfo();
});
</script>

<style scoped></style>
