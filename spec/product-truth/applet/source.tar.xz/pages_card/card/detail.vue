<template>
    <m-loading v-if="card === undefined"></m-loading>
    <m-empty v-else-if="card === null">次卡不存在</m-empty>
    <view class="container-safety" v-else>
        <view class="detail-header">
            <view class="container">
                <m-card-magnetic-face
                    class="mt-3"
                    :theme="card.theme"
                    :merchant-name="card.merchantName"
                    :cover="card.cover"
                    :title="card.name"
                    :card-type="card.cardType"
                    :total-times="card.totalTimes"
                    :valid-label="card.validLabel"
                    :status="card.status"
                    :status-label="card.statusLabel"
                />
                <view v-if="card.auditStatus !== CARD_AUDIT_STATUS.PASSED" class="mt-2">
                    <t-tag theme="warning" variant="light-outline" size="small">{{ card.auditStatusLabel }}</t-tag>
                </view>

                <view class="section mt-2">
                    <view class="row col-3 mt-3">
                        <view class="stat">
                            <view class="stat-value">{{ card.receiveCount }}</view>
                            <view class="stat-label">已领取（张）</view>
                        </view>
                        <view class="stat">
                            <view class="stat-value">{{ card.verifyCount }}</view>
                            <view class="stat-label">已核销（次）</view>
                        </view>
                        <view class="stat">
                            <view class="stat-value">{{ card.discardCount ?? 0 }}</view>
                            <view class="stat-label">已作废（次）</view>
                        </view>
                    </view>

                    <t-divider/>

                    <view class="container">
                        <view class="d-flex justify-content-between align-items-center">
                            <view>
                                <view class="text-muted text-small mb-2">剩余库存</view>
                                <view>
                                    <text style="font-size:42rpx">{{ card.remainStock || 0 }}</text>
                                    /
                                    <text class="text-muted">{{ card.totalStock }} 张</text>
                                </view>
                            </view>
                            <view>
                                <view v-if="checkPermission(PERM_CARD.UPDATE) && card.status !== CARD_STATUS.DISCARDED" class="button-gold"
                                      @click="push('/pages_card/card/update_stock?cardId=' + cardId)">调整库存
                                </view>
                            </view>
                        </view>
                        <t-progress :percentage="Number(remainPercent)" :show-info="false" :stroke-width="6"
                                    color="#00c553"/>
                    </view>

                    <t-divider/>

                    <t-grid :column="4">
                        <t-grid-item v-if="checkPermission(PERM_CARD.RECEIVE_LIST)" text="领取明细" icon="task"
                                     :url="'/pages_card/receive/list?cardId=' + cardId"/>
                        <t-grid-item v-if="checkPermission(PERM_CARD.VERIFY_LIST)" text="核销明细" icon="assignment"
                                     :url="'/pages_card/verify/list?cardId=' + cardId"/>
                        <t-grid-item text="优惠内容" icon="view-list" @click="showItemsPopup = true"/>
                        <t-grid-item text="数据统计" icon="chart-analytics"
                                     :url="'/pages_card/stat/home?cardId=' + cardId"/>
                    </t-grid>
                </view>
            </view>
        </view>

        <t-cell-group title="操作设置" t-title-class="mt-2" theme="card">
            <t-grid :column="4">
                <t-grid-item v-if="checkPermission(PERM_CARD.UPDATE) && card.status !== CARD_STATUS.DISCARDED" text="修改次卡" icon="edit-2"
                             @click="checkPermission(PERM_CARD.UPDATE) && push('/pages_card/card/update?cardId=' + cardId)"/>
                <t-grid-item v-if="checkPermission(PERM_CARD.UPDATE) && card.status === CARD_STATUS.ISSUING" text="暂停发放" icon="pause-circle-stroke"
                             @click="pauseVisible = true"/>
                <t-grid-item v-if="checkPermission(PERM_CARD.UPDATE) && card.status === CARD_STATUS.PAUSED" text="恢复发放" icon="play-circle-stroke"
                             @click="startVisible = true"/>
                <t-grid-item v-if="checkPermission(PERM_CARD.DISCARD) && card.status !== CARD_STATUS.DISCARDED" text="作废次卡" icon="delete-time"
                             @click="push('/pages_card/discard/discard?cardId=' + cardId)"/>
                <t-grid-item v-if="checkPermission(PERM_CARD.UPDATE)" text="删除次卡" icon="delete"
                             @click="push('/pages_card/card/delete?cardId=' + cardId)"/>
                <t-grid-item v-if="checkPermission(PERM_CARD.UPDATE)" text="发券员工" icon="user-setting"
                             :url="'/pages_card/issue/staff?cardId=' + cardId + '&status=' + card.status"/>
                <t-grid-item v-if="checkPermission(PERM_CARD.UPDATE)" text="适用门店" icon="store"
                             @click="push('/pages_card/card/store_list?cardId=' + cardId + '&status=' + card.status)"/>
                <t-grid-item text="使用须知" icon="file-1" @click="showContentPopup = true"/>
            </t-grid>
        </t-cell-group>
    </view>

    <m-submit v-if="card && card.hasIssuePermission && checkPermission(PERM_CARD.ISSUE)"
              :disabled="card.status !== CARD_STATUS.ISSUING || card.auditStatus !== CARD_AUDIT_STATUS.PASSED"
              @click="issuePopupVisible = true">发放次卡
        <template v-if="card.auditStatus !== CARD_AUDIT_STATUS.PASSED"> [{{ card.auditStatusLabel || '未通过审核' }}]</template>
        <template v-else-if="card.status === CARD_STATUS.PAUSED"> [已暂停]</template>
    </m-submit>
    <m-submit v-else-if="card" :disabled="true">您没有发放权限</m-submit>

    <t-action-sheet :visible="pauseVisible" :items="[{ label: '确定暂停发放' }]" @selected="onPauseSelected"
                    @cancel="pauseVisible = false"/>
    <t-action-sheet :visible="startVisible" :items="[{ label: '确定恢复发放' }]" @selected="onStartSelected"
                    @cancel="startVisible = false"/>

    <t-popup placement="bottom" v-model:visible="issuePopupVisible">
        <view class="popup-header">
            <view class="popup-header-title">私密发放</view>
            <view class="popup-header-close">
                <t-icon name="close" @click="issuePopupVisible = false" :size="20"></t-icon>
            </view>
        </view>
        <view class="text-center text-muted text-small">适合一对一/储值回馈/消费奖励/给指定客户</view>
        <t-divider/>
        <t-grid :column="3">
            <t-grid-item text="微信好友/群"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2nl4lbp0mqcs77du0.png"
                         @click="goPrivateConfig(CHANNEL_TYPE.PRIVATE_WECHAT)"/>
            <t-grid-item text="二维码"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2o2slbp0mqcs77dug.png"
                         @click="goPrivateConfig(CHANNEL_TYPE.PRIVATE_QRCODE)"/>
            <t-grid-item v-if="checkPermission(PERM_WECOM.CORP_CONFIG)" text="企微加好友发次卡"
                         image="https://cdn.lenmy.com/quandao/2026/06/24/d8thsq5b4ek0dhdbngc0.png"
                         @click="goPrivateConfig(CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT)"/>
        </t-grid>
        <view class="popup-bottom-cancel mt-5" @click="issuePopupVisible = false">取消</view>
    </t-popup>

    <t-popup v-model:visible="showItemsPopup" placement="bottom">
        <view class="popup-header">
            <view class="popup-header-title">
                优惠内容
                <template v-if="card?.cardType === CARD_TYPE.BENEFIT">（{{ card?.items?.length || 0 }} 项）</template>
            </view>
            <view class="popup-header-close">
                <t-icon name="close" @click="showItemsPopup = false" :size="20"/>
            </view>
        </view>
        <view class="popup-body items-popup-body">
            <div class="container">
                <template v-if="card?.cardType === CARD_TYPE.BENEFIT">
                    <m-card-benefit-list
                        v-if="card?.items?.length"
                        :items="card.items"
                        :theme="card.theme"
                        :showStatus="false"
                    />
                    <m-empty v-else>暂无优惠内容</m-empty>
                </template>
                <view v-else class="text-content" style="white-space: pre-line">{{
                        card?.benefitContent || '暂无优惠内容'
                    }}
                </view>
            </div>
        </view>
    </t-popup>

    <t-popup v-model:visible="showContentPopup" placement="bottom">
        <view class="popup-header">
            <view class="popup-header-title">使用须知</view>
            <view class="popup-header-close">
                <t-icon name="close" @click="showContentPopup = false" :size="20"/>
            </view>
        </view>
        <scroll-view scroll-y class="popup-body">
            <view class="container">
                <view class="text-content mb-2" v-if="card?.isVerifyInterval">
                    核销间隔：{{
                        Number(card.verifyIntervalDay) === 0 ? '每天可核销 1 次' : ('间隔 ' + card.verifyIntervalDay + ' 天可核销 1 次')
                    }}
                </view>
                <text class="text-content" v-if="card?.content">{{ card.content }}</text>
                <view v-if="card?.productImages?.length" class="product-images">
                    <image
                        v-for="(img, index) in card.productImages"
                        :key="index"
                        class="product-image"
                        :src="img"
                        mode="widthFix"
                    />
                </view>
                <m-empty v-if="!card?.isVerifyInterval && !card?.content && !card?.productImages?.length">暂未设置
                </m-empty>
            </view>
        </scroll-view>
    </t-popup>
</template>

<script setup>
import {onLoad, onShow, onUnload, onPullDownRefresh} from '@dcloudio/uni-app'
import {computed, ref} from 'vue'
import request from '@/hooks/request'
import {CARD_STATUS, CARD_AUDIT_STATUS, CARD_TYPE} from '@/constants/card'
import {CHANNEL_TYPE} from '@/constants/common'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_CARD, PERM_WECOM} from '@/constants/permission.js'

const {push} = useLink()
const {checkPermission} = useAuth()

// 次卡 ID
const cardId = ref('')
// 次卡详情
const card = ref()
// 优惠内容弹窗
const showItemsPopup = ref(false)
// 使用须知弹窗
const showContentPopup = ref(false)
// 私密发放渠道弹窗
const issuePopupVisible = ref(false)
// 暂停发放确认
const pauseVisible = ref(false)
// 恢复发放确认
const startVisible = ref(false)

// 剩余库存占比（进度条）
const remainPercent = computed(() => {
    if (!card.value || !card.value.totalStock) return 0
    return utils.formatPercent(card.value.remainStock / card.value.totalStock)
})

// 跳转私密发放配置页（分享图一律用 cover）
const goPrivateConfig = (channelType) => {
    if (!card.value?.cover) {
        utils.toast('请先上传次卡封面')
        return
    }
    issuePopupVisible.value = false
    const shareTitle = card.value.name
    const cover = card.value.cover
    if (channelType === CHANNEL_TYPE.WECOM_EXTERNAL_CONTACT) {
        push('/pages_wecom/staff/list?productType=3&productId=' + cardId.value)
        return
    }
    push('/pages_card/issue/private?cardId=' + cardId.value + '&shareTitle=' + (shareTitle || '') + '&shareImage=' + (cover || '') + '&channelType=' + channelType)
}

// 获取次卡详情
const getDetail = () => {
    request.get('/seller/card/get/detail', {id: cardId.value}).then(res => {
        card.value = res.data
        uni.setNavigationBarTitle({title: res.data.name})
    }).catch(() => {
        card.value = null
    })
}

// 暂停发放次卡
const onPauseSelected = () => {
    request.post('/seller/card/pause', {id: cardId.value}).then(() => {
        utils.toast('次卡已暂停')
        pauseVisible.value = false
        getDetail()
    }).catch(err => utils.toast(err.message))
}

// 恢复发放次卡
const onStartSelected = () => {
    request.post('/seller/card/start', {id: cardId.value}).then(() => {
        utils.toast('次卡已恢复')
        startVisible.value = false
        getDetail()
    }).catch(err => utils.toast(err.message))
}

// 是否已删除（收到删除通知后标记，避免 onShow 再次请求）
const isDeleted = ref(false)

// 次卡删除事件回调：标记已删除，导航由 delete.vue 统一处理
const onCardDelete = (e) => {
    if (e?.id && e.id === cardId.value) {
        isDeleted.value = true
    }
}

onLoad((options) => {
    cardId.value = options.cardId
    uni.$on('onCardDelete', onCardDelete)
})

onUnload(() => {
    uni.$off('onCardDelete', onCardDelete)
})

onShow(() => {
    // 已删除的次卡不再请求，避免报"次卡不存在"
    if (isDeleted.value) return
    if (cardId.value) getDetail()
})

onPullDownRefresh(() => {
    // 已删除的次卡不再请求
    if (isDeleted.value) {
        uni.stopPullDownRefresh()
        return
    }
    getDetail()
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})
</script>

<style scoped>
.detail-header {
    padding-top: 20rpx;
    min-height: 400px;
}

.stat {
    text-align: center;
}

.stat-value {
    font-size: 36rpx;
    font-weight: 600;
}

.stat-label {
    margin-top: 8rpx;
    font-size: 22rpx;
    color: #999;
}

.product-images {
    margin-top: 24rpx;
}

.product-image {
    display: block;
    width: 100%;
    border-radius: 12rpx;
}

.product-image + .product-image {
    margin-top: 16rpx;
}

.items-popup-body {
    height: auto;
    max-height: 70vh;
    padding: 24rpx 0 calc(24rpx + env(safe-area-inset-bottom));
    overflow-x: hidden;
}
</style>
