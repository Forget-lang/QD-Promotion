<template>
    <view class="container container-safety">
        <m-loading v-if="categories === undefined"></m-loading>

        <template v-if="categories">
            <!-- 热门问题区域 -->
            <view class="section mt-2" v-if="hotItems.length > 0">
                <view class="section-header bottom-line">
                    <text class="section-title">热门问题</text>
                </view>
                <view>
                    <t-cell v-for="(item, index) in hotItems" :key="item.url || index"
                            :title="item.title"
                            t-class-center="cell-center--overflow"
                            t-class-title="cell-title--ellipsis"
                            @tap="utils.openPosition(item)" arrow>
                        <template #left-icon>
                            <image class="type-icon" src="/static/img/channel.png" v-if="item.recommendType === RECOMMEND_TYPE.VIDEO_CHANNEL"></image>
                            <image class="type-icon" src="/static/img/wechat.png" v-if="item.recommendType === RECOMMEND_TYPE.OFFICIAL_ACCOUNT"></image>
                            <image class="type-icon" src="/static/img/weapp.png" v-if="item.recommendType === RECOMMEND_TYPE.MINI_PROGRAM_PAGE"></image>
                        </template>
                    </t-cell>
                </view>
            </view>

            <!-- 问题分类区域 -->
            <view v-if="categories && categories.length > 0" class="section mt-2">
                <view class="section-header bottom-line">
                    <text class="section-title">问题分类</text>
                </view>
                <t-grid :column="4" hover theme="card">
                    <t-grid-item v-for="(item, index) in categories" :key="item.url || index" :image="item.thumb"
                                 :text="item.title" @click="utils.openPosition(item)"></t-grid-item>
                </t-grid>
            </view>
            <m-empty v-if="categories.length === 0 && hotItems.length === 0">暂无教程</m-empty>
        </template>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh, onShareAppMessage, onShareTimeline} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {RECOMMEND_TYPE, POSITION_ID} from '@/constants/common'
import {useLink} from '@/hooks/useLink.js'
import utils from "@/utils/utils";

const {push} = useLink()

// 热门问题
const hotItems = ref([])

// 固定分类列表（模拟数据）
const categories = ref()

// 获取热门问题推荐位
const getHotItems = () => {
    return request.get('/position', {id: POSITION_ID.HELP_HOT}, {showLoading: false}).then(res => {
        hotItems.value = res.data?.items?.slice(0, 5) || []
    })
}
// 获取问题分类推荐位
const getCategories = () => {
    return request.get('/position', {id: POSITION_ID.HELP_CATEGORY}, {showLoading: false}).then(res => {
        categories.value = res.data?.items || []
    })
}
// 并行加载页面数据；任一失败不影响另一个，且保证下拉刷新一定会停止
const loadData = () => {
    return Promise.allSettled([getHotItems(), getCategories()]).finally(() => {
        // categories 用于控制骨架屏，兜底给空数组，避免请求失败时永久 loading
        if (categories.value === undefined) categories.value = []
        setTimeout(() => uni.stopPullDownRefresh(), 300)
    })
}

onLoad(() => {
    loadData()
})
onPullDownRefresh(() => {
    loadData()
})

// 右上角菜单分享给微信好友 / 群聊
onShareAppMessage(() => ({
    title: '使用教程 - 券到卡包',
    path: '/pages_assist/help/index',
}))

// 右上角菜单分享到朋友圈
onShareTimeline(() => ({
    title: '使用教程 - 券到卡包',
    path: '/pages_assist/help/index',
}))
</script>

<style scoped>
:deep(.cell-center--overflow) {
    overflow: hidden;
    min-width: 0;
}

:deep(.cell-title--ellipsis) {
    display: block !important;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.type-icon {
    width: 48rpx;
    height: 48rpx;
}
</style>
