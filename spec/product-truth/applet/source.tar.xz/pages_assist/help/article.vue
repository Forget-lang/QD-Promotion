<template>
    <view>
        <!-- 加载失败提示（用 cover-view 覆盖 web-view） -->
        <cover-view v-if="loadError" class="error-mask" @click="reload">
            <cover-view class="error-icon">!</cover-view>
            <cover-view class="error-text">页面加载失败</cover-view>
            <cover-view class="error-detail">{{ errorMsg }}</cover-view>
            <cover-view class="error-retry">点击重试</cover-view>
        </cover-view>
        <web-view :src="url" @load="onLoadSuccess" @error="onLoadError"></web-view>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'

const url = ref('')

const loadError = ref(false)
const errorMsg = ref('')

onLoad((options) => {
    url.value = decodeURIComponent(options.url || '')
    if (options.title) {
        uni.setNavigationBarTitle({title: decodeURIComponent(options.title)})
    }
    // 显示原生 loading（不会被 web-view 覆盖）
    uni.showLoading({ title: '加载中...', mask: true })
})

function onLoadSuccess() {
    uni.hideLoading()
    loadError.value = false
}

function onLoadError(e) {
    console.log('web-view----onLoadError')
    uni.hideLoading()
    loadError.value = true
    // 提取错误信息
    const detail = e?.detail || {}
    errorMsg.value = detail.errMsg || '未知错误'
    console.log('web-view load error:', errorMsg.value)
}

function reload() {
    loadError.value = false
    errorMsg.value = ''
    uni.showLoading({ title: '加载中...', mask: true })
    const currentUrl = url.value
    url.value = ''
    setTimeout(() => {
        url.value = currentUrl
    }, 50)
}
</script>

<style scoped>
.error-mask {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    background: rgba(245, 245, 245, 0.95);
    z-index: 999;
}
.error-text {
    margin-top: 20rpx;
    font-size: 28rpx;
    color: #999;
}
.error-detail {
    margin-top: 12rpx;
    font-size: 26rpx;
    color: #666;
    padding: 0 40rpx;
    text-align: center;
    word-break: break-all;
}
.error-retry {
    margin-top: 32rpx;
    padding: 16rpx 48rpx;
    font-size: 28rpx;
    color: #07c160;
    border: 2rpx solid #07c160;
    border-radius: 8rpx;
}
.error-icon {
    width: 80rpx;
    height: 80rpx;
    border-radius: 50%;
    background: #ff4d4f;
    color: #fff;
    font-size: 48rpx;
    text-align: center;
    line-height: 80rpx;
}
</style>
