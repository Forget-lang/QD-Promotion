<template>
    <view>
        <m-loading v-if="items === undefined"></m-loading>
        <view v-else class="container-safety mt-2">
            <template v-if="items && items.length > 0">
                <t-cell-group theme="card">
                    <t-cell :arrow="true" v-for="(item, index) in items" :key="item.url || index"
                            :title="item.title"
                            t-class-center="cell-center--overflow"
                            t-class-title="cell-title--ellipsis"
                            @tap="utils.openPosition(item)">
                        <template #left-icon>
                            <image class="type-icon" src="/static/img/channel.png" v-if="item.recommendType === RECOMMEND_TYPE.VIDEO_CHANNEL"></image>
                            <image class="type-icon" src="/static/img/wechat.png" v-if="item.recommendType === RECOMMEND_TYPE.OFFICIAL_ACCOUNT"></image>
                            <image class="type-icon" src="/static/img/weapp.png" v-if="item.recommendType === RECOMMEND_TYPE.MINI_PROGRAM_PAGE"></image>
                        </template>
                    </t-cell>
                </t-cell-group>
            </template>
            <m-empty v-if="items && items.length === 0">暂无教程</m-empty>
        </view>
    </view>
</template>

<script setup>
import {onLoad, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {RECOMMEND_TYPE} from '@/constants/common'
import {useLink} from '@/hooks/useLink.js'
import utils from "@/utils/utils";

const {push} = useLink()
const items = ref()
const positionId = ref()

// 获取推荐位数据
const getItems = () => {
    request.get('/position', {id: positionId.value}, {showLoading: false}).then(res => {
        items.value = res.data.items || []
        wx.setNavigationBarTitle({title: res.data.name})
    }).catch(() => {
        items.value = []
    }).finally(() => {
        setTimeout(() => uni.stopPullDownRefresh(), 300)
    })
}

onLoad((options) => {
    positionId.value = decodeURIComponent(options.positionId || '')
    getItems()
})

onPullDownRefresh(() => {
    getItems()
})
</script>

<style scoped>
:deep(.cell-center--overflow) {
    overflow: hidden;
    min-width: 0;
}

:deep(.cell-title--ellipsis) {
    display: block !important;
    overflow: hidden;
    white-space: nowrap;
    text-overflow: ellipsis;
}
.type-icon {
    width: 48rpx;
    height: 48rpx;
}
</style>
