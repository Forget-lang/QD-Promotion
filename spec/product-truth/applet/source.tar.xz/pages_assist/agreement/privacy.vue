<template>
    <view class="container">
        <view class="h1">隐私政策</view>
        <view class="p">
            欢迎使用微信小程序「券到卡包」。本政策适用于「券到卡包」全部用户（含商家端员工与顾客端用户）。
        </view>
        <view class="p">
            「券到卡包」由郑州百桨数字科技有限公司（以下称「本公司」或「我们」）所有和运营。本小程序 AppID 为
            wxcb35468c13e5ac7e，同一小程序内包含商家端与用户（顾客）端能力。
        </view>
        <view class="ps w">
            我们深知个人信息对您的重要性，并会尽力保护您的个人信息安全可靠。我们恪守权责一致、目的明确、选择同意、最小必要、确保安全、主体参与、公开透明等原则，并依据真实、准确、完整原则发布本政策，按业界成熟的安全标准采取相应保护措施。
        </view>
        <view class="ps w">
            请在使用我们的产品或服务前，仔细阅读并了解本《隐私政策》，特别是加粗条款，与您的权益存在重大关系，请您特别予以关注。
        </view>

        <view class="title">一、我们如何收集和使用信息</view>
        <view class="p">
            根据法律规定，我们仅处理实现小程序功能所必要的信息。为提供服务，我们可能收集并使用下列信息。若您不提供相关信息，仍可浏览公开内容，但可能无法使用对应功能。
        </view>

        <view class="ps">（一）商家端</view>
        <view class="p">· 手机号：在您明示同意后收集，用于商家注册、门店创建、优惠活动及实名认证等。</view>
        <view class="p">· 位置信息：在您明示同意后收集，用于商家查找并设置门店位置。</view>
        <view class="p">· 相册（仅写入）：在您明示同意后使用，用于保存优惠券海报及小程序码到手机。</view>
        <view class="p">· 摄像头：在您明示同意后访问，用于扫码核销优惠券、券包或次卡。</view>
        <view class="p">· 微信昵称、头像：在您明示同意后收集，用于完善商家会员信息、员工展示与区分管理。</view>
        <view class="p">· 您选中的照片或视频：用于上传优惠券商品图片、海报及门头图等展示。</view>
        <view class="p">· 您选中的文件：用于商家上传券码 Excel 等业务文件。</view>
        <view class="p">· 商家认证资料：营业执照、法定代表人身份证件、统一社会信用代码等，用于商家真实性审核。</view>
        <view class="p">·
            企业微信相关信息：若您授权绑定企业微信，我们可能处理与授权安装、通讯录同步相关的必要信息（详见下文第三方插件说明）。
        </view>
        <view class="p">· 设备信息：用于适配界面、排查故障、保障服务安全与稳定。</view>
        <view class="p">· 剪切板：在您操作「复制」时读取/写入剪切板，用于快速复制卡券编码等业务编号。</view>

        <view class="ps">（二）顾客端</view>
        <view class="p">· 微信登录标识（如 openid / unionid）：用于账号识别与登录态维持。</view>
        <view class="p">· 微信昵称、头像：在您明示同意后收集，用于完善商家会员信息，以及便于领券后商家核对您的身份信息。
        </view>
        <view class="p">· 手机号：在您明示同意后收集（如需完善资料或特定领券场景），用于账号绑定与联系。</view>
        <view class="p">· 位置信息：在您明示同意后收集，用于便于您选择距离最近的门店。</view>
        <view class="p">· 地址：用于便于填写提货券的收货地址。</view>
        <view class="p">· 领券、核销、转赠等业务记录：用于向您展示卡券状态与历史。</view>
        <view class="p">· 设备信息：用于适配界面、排查故障、保障服务安全与稳定。</view>
        <view class="p">· 剪切板：在您操作「复制」时读取/写入剪切板，用于快速复制卡券编码。</view>

        <view class="title">二、信息的使用规则</view>
        <view class="p">
            我们将在本政策明示的用途内使用收集的信息，包括：提供与改进服务、身份核验、安全风控、客户支持、履行法律法规要求。
        </view>
        <view class="p">
            如我们使用您的信息超出本政策目的或合理范围，将再次征得您的同意；您也可通过在线客服、意见反馈或邮件告知我们，或停止使用、注销账号。
        </view>

        <view class="title">三、我们对信息的存储</view>
        <view class="p">
            除法律法规另有规定外，我们对您的信息的保存期限为实现处理目的所必要的最短时间。一般而言，在您的账号存续期间保存；账号注销后，我们将删除或匿名化处理相关个人信息，但法律法规要求留存或为解决争议所必需的除外。
        </view>
        <view class="p">
            您的个人信息存储于中华人民共和国境内。我们不会向境外提供您的个人信息；如将来确需跨境传输，将另行告知并依法征得同意或履行其他法定义务。
        </view>

        <view class="title">四、信息对外提供</view>
        <view class="p">
            我们承诺，不会主动共享或转让您的信息至任何第三方；如确需共享或转让，应当直接征得或确认第三方征得您的单独同意（法律法规另有规定的除外）。
        </view>
        <view class="p">
            我们承诺，不会对外公开披露您的信息；如必须公开披露，应当向您告知目的、信息类型及可能涉及的信息，并征得您的单独同意（法律法规另有规定的除外）。
        </view>
        <view class="p">
            本小程序基于微信开放能力运行，部分能力由腾讯提供。您使用相关能力时，亦应遵守微信平台规则。我们仅在实现功能所必要的范围内处理与微信开放接口相关的信息。
        </view>

        <view class="title">五、第三方插件 / SDK 信息</view>
        <view class="p">
            为实现特定功能，我们可能会接入由第三方提供的插件 / SDK。第三方插件 / SDK
            的个人信息处理规则，请以其公示的官方说明为准。「券到卡包」小程序接入的第三方插件 / SDK 信息如下：
        </view>

        <view class="ps">（一）第三方插件</view>
        <view class="p">1. 插件名称：企业微信通讯录安全插件</view>
        <view class="p">　插件提供方：深圳市腾讯计算机系统有限公司</view>
        <view class="p">　用途说明：用于企业微信相关通讯录安全能力。</view>

        <view class="p">2. 插件名称：一键快捷授权登录</view>
        <view class="p">　插件提供方：郑州百桨数字科技有限公司</view>
        <view class="p">　用途说明：为方便领券后商家核对您的身份信息，开发者将在获得您的明示同意后，收集您的微信昵称、头像。
        </view>

        <view class="ps">（二）第三方 SDK</view>
        <view class="p">1. SDK 名称：一键快捷授权登录</view>
        <view class="p">　SDK 提供方：郑州百桨数字科技有限公司</view>
        <view class="p">　用途说明：在您明示同意后，收集您的微信昵称、头像，用于完善商家会员信息。</view>

        <view class="title">六、您的权利</view>
        <view class="p">
            关于位置信息、相册（仅写入）、摄像头等权限，您可通过：小程序主页右上角「…」—「设置」—点击对应权限—选择「不允许」，撤回授权。
        </view>
        <view class="p">
            关于个人信息，您可通过小程序内账号注销等功能，依法行使查阅、复制、更正、删除等权利；也可通过意见反馈或下方联系方式向我们提出请求。
        </view>

        <view class="title">七、未成年人保护</view>
        <view class="p">
            我们的产品与服务主要面向实体经营商家及其顾客。若您为未满十四周岁的未成年人，请在监护人陪同下阅读本政策，并在取得监护人同意后使用；我们不会主动收集未成年人的个人信息。如我们发现在未获监护人同意的情况下收集了相关信息，将尽快删除。
        </view>

        <view class="title">八、联系我们</view>
        <view class="p">
            若您认为我们未遵守上述约定，或有其他投诉建议、未成年人个人信息保护相关问题，可通过小程序内「意见反馈」或以下邮箱与我们联系：
        </view>
        <view class="p">邮箱：mac@lenmy.com</view>

        <view class="p mt-5 top-line pt-2">
            更新日期：2026-07-20　生效日期：2026-07-20
        </view>
    </view>
</template>

<script setup>

</script>
<style>
page {
    background-color: #fff;
}
</style>
<style scoped>
.container {
    padding: 30rpx;
}

.h1 {
    font-size: 32rpx;
    text-align: center;
    color: #333;
    margin: 60rpx auto;
}

.title {
    font-size: 30rpx;
    color: #333;
    margin-top: 30rpx;
    margin-bottom: 10rpx;
    font-weight: bold;
}

.p {
    color: #666;
    font-size: 24rpx;
    margin-top: 10rpx;
    line-height: 44rpx;
    margin-bottom: 25rpx;
}

.ps {
    color: #666;
    font-size: 24rpx;
    margin-top: 10rpx;
    line-height: 44rpx;
    margin-bottom: 16rpx;
    font-weight: bold;
}

.w {
    font-weight: bold;
}
</style>
