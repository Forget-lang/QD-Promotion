<template>
    <view class="container container-safety mt-2">
        <!-- 商户中心推荐位：获客玩法 -->
        <m-position :key="refreshKey" :id="POSITION_ID.MERCHANT_CENTER" :theme="2"/>
    </view>
</template>

<script setup>
import {ref} from 'vue'
import {onLoad, onShow, onPullDownRefresh, onShareAppMessage, onShareTimeline} from '@dcloudio/uni-app'
import {POSITION_ID} from '@/constants/common.js'

const refreshKey = ref(0)

const SHARE_PATH = '/pages_assist/position/play'
const SHARE_TITLE = '获客玩法 - 券到卡包'

const enableShareMenu = () => {
    uni.showShareMenu({
        withShareTicket: false,
        menus: ['shareAppMessage', 'shareTimeline'],
    })
}

onLoad(() => {
    enableShareMenu()
})

onShow(() => {
    enableShareMenu()
})

onPullDownRefresh(() => {
    refreshKey.value += 1
    setTimeout(() => uni.stopPullDownRefresh(), 500)
})

onShareAppMessage(() => ({
    title: SHARE_TITLE,
    path: SHARE_PATH,
}))

onShareTimeline(() => ({
    title: SHARE_TITLE,
    query: '',
}))
</script>

<style scoped>
</style>
