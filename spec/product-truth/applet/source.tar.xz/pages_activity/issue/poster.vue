<template>
    <m-loading v-if="shareParam === undefined"></m-loading>
    <view v-else class="container-safety">
        <view class="container-poster">
            <m-poster ref="posterRef" :width="750" :height="1200" @ready="onPosterReady" :pixel="2"></m-poster>
            <image v-if="posterUrl" class="image-poster" :src="posterUrl" mode="widthFix"></image>
            <m-loading v-else/>
        </view>
        <view class="d-flex justify-content-center">
            <view class="theme-bar mt-2">
                <view class="theme-bar-list">
                    <view
                        v-for="(item, idx) in themes"
                        :key="item.value"
                        class="theme-dot"
                        :class="{ active: themeIndex === idx }"
                        :style="{ background: item.color }"
                        @click="onSelectTheme(idx)"
                    >
                        <view v-if="themeIndex === idx" class="theme-dot-check"></view>
                    </view>
                </view>
            </view>
        </view>
        <m-submit v-if="posterUrl" @click="onSavePoster">保存海报</m-submit>
    </view>
</template>

<script setup>
import {onLoad} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import utils from "@/utils/utils";
import {saveImageToAlbum} from '@/hooks/useFile.js'
import MSubmit from "@/components/m/m-submit/m-submit.vue";
import {themes} from '@/utils/theme.js'

const activityId = ref('');
const activityName = ref('');
const activityCover = ref('');
const shareParam = ref();
const posterRef = ref()
const posterUrl = ref('')
const isInit = ref(false)

// 主题色：复用券包/次卡公用配置（@/utils/theme.js），不在此自定义
// 公用 themes 项为 {value, label, color, desc}，仅 color 一个颜色字段，
// 渐变浅色在运行时由 color 派生（不修改公用配置）
const themeIndex = ref(0)

// 从 hex 主色派生浅色（向白色混合 amount 比例），用于渐变
const lighten = (hex, amount = 0.25) => {
    const h = (hex || '#000000').replace('#', '')
    const r = parseInt(h.substring(0, 2), 16)
    const g = parseInt(h.substring(2, 4), 16)
    const b = parseInt(h.substring(4, 6), 16)
    const mix = c => Math.round(c + (255 - c) * amount)
    return '#' + [mix(r), mix(g), mix(b)].map(c => c.toString(16).padStart(2, '0')).join('')
}

// 拉取活动详情（name/cover 走接口 JSON，避免路由参数 encodeURIComponent 二次解码乱码）
const getDetail = () => {
    return request.get('/seller/activity-poster/detail', {id: activityId.value}).then(res => {
        activityName.value = res.data?.name || '活动海报'
        activityCover.value = res.data?.cover || ''
    }).catch(err => {
        utils.toast(err.message)
    })
}

const getShareParam = () => {
    return request.post('/seller/activity-poster/share', {id: activityId.value, channel: 'poster'}).then(res => {
        return res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

const onPosterReady = () => {
    isInit.value = true
    setTimeout(posterDraw, 300)
}

const onSelectTheme = (idx) => {
    if (themeIndex.value === idx) return
    themeIndex.value = idx
    posterUrl.value = ''
    posterDraw()
}

// m-poster 的 drawRadiusRect 会把 borderRadius 除以 2，所以要让视觉圆角为 N rpx，
// 需传入 2N；要让 rect 成为正圆，需 borderRadius = width (= height)。
const R = (visual) => visual * 2

// 预下载网络图片并缓存（按 URL），失败返回空串（不 reject），避免拖累整张海报生成；
// 切换主题色重绘时复用缓存，不重复下载
const imgCache = {}
const downloadImg = (url) => {
    if (!url || !/^https?:\/\//i.test(url)) return Promise.resolve('')
    if (imgCache[url]) return Promise.resolve(imgCache[url])
    return new Promise(resolve => {
        uni.downloadFile({
            url,
            success: res => {
                imgCache[url] = res.tempFilePath || ''
                resolve(imgCache[url])
            },
            fail: () => resolve('')
        })
    })
}

const posterDraw = async () => {
    if (!isInit.value || !shareParam.value?.qrcode) return
    let theme, data
    try {
        theme = themes[themeIndex.value]
        const themeColor = theme.color
        const themeLight = lighten(themeColor, 0.25)
        const cover = activityCover.value

        // ===== 预下载图片（与海报绘制解耦，任一失败不影响整张海报）=====
        const [coverSrc, qrSrc] = await Promise.all([
            downloadImg(cover),
            downloadImg(shareParam.value.qrcode)
        ])
        if (!qrSrc) {
            console.error('[poster] 二维码下载失败', shareParam.value.qrcode)
            utils.toast('二维码加载失败，请检查域名白名单')
            return
        }

        // ===== 几何参数集中管理 =====
        // 画布 750 x 1200，主题色渐变铺满整张海报
        const canvas = {width: 750, height: 1200, centerX: 375}
        // 封面图：顶部留 40 边距
        const coverRect = {left: 40, top: 40, width: 670, height: 420}
        // 封面图与白色区域间距 40
        const gap = 40
        // 白色内容区域
        const whiteCard = {
            left: 40,
            top: coverRect.top + coverRect.height + gap,  // 500
            width: 670,
            height: canvas.height - (coverRect.top + coverRect.height + gap) - 40  // 底部留 40 边距 = 660
        }
        // 白色区域内边距 20
        const pad = 20
        const content = {
            left: whiteCard.left + pad,           // 60
            right: whiteCard.left + whiteCard.width - pad,  // 690
            top: whiteCard.top + pad,             // 520
            bottom: whiteCard.top + whiteCard.height - pad  // 1140
        }
        content.width = content.right - content.left   // 630
        content.centerX = (content.left + content.right) / 2  // 375

        // 二维码尺寸 & 居中
        // 二维码尺寸 & 居中（360rpx 保证保存到相册后手机可正常扫码）
        const qrSize = 360
        const qr = {
            left: (canvas.width - qrSize) / 2,    // 195
            top: 0,                                // 后面计算
            width: qrSize,
            height: qrSize
        }

        data = [
            // 1. 主题色渐变背景，覆盖整张海报
            {
                type: 'rect',
                style: {
                    left: 0, top: 0, width: canvas.width, height: canvas.height,
                    backgroundColor: themeColor,
                    gradientColor: themeLight,
                    gradientType: 1
                }
            },
            // 2. 装饰圆（主题色背景上，溢出画布边缘露出圆弧；borderRadius = width 才是正圆）
            // 右上角
            {
                type: 'rect',
                style: {
                    left: 580,
                    top: -60,
                    width: 200,
                    height: 200,
                    backgroundColor: 'rgba(255,255,255,0.16)',
                    borderRadius: 200
                }
            },
            // 左下角
            {
                type: 'rect',
                style: {
                    left: -70,
                    top: 1080,
                    width: 180,
                    height: 180,
                    backgroundColor: 'rgba(255,255,255,0.14)',
                    borderRadius: 180
                }
            },
            // 左上角小圆
            {
                type: 'rect',
                style: {
                    left: -50,
                    top: -50,
                    width: 120,
                    height: 120,
                    backgroundColor: 'rgba(255,255,255,0.18)',
                    borderRadius: 120
                }
            },
            // 3. 封面图（已预下载为本地路径，imgType=1）
            {
                type: 'image',
                imgType: 1,
                src: coverSrc,
                style: {
                    left: coverRect.left,
                    top: coverRect.top,
                    width: coverRect.width,
                    height: coverRect.height,
                    borderRadius: R(16)
                }
            },
            // 4. 白色内容区域
            {
                type: 'rect',
                style: {
                    left: whiteCard.left,
                    top: whiteCard.top,
                    width: whiteCard.width,
                    height: whiteCard.height,
                    backgroundColor: '#FFFFFF',
                    borderRadius: R(24)
                }
            },
            // ===== 白色区域内内容（内边距 20）=====
            // 活动名称（String 保护，避免 undefined/非字符串渲染异常）
            {
                type: 'text',
                text: String(activityName.value || '活动海报'),
                style: {
                    left: content.left, top: content.top + 60, width: content.width,
                    fontSize: 40, color: '#1A1A1A', fontWeight: 'bold',
                    textAlign: 'left', rows: 2, lineHeight: 56
                }
            },
            // 主题色装饰短线
            {
                type: 'rect',
                style: {
                    left: content.left,
                    top: content.top + 90,
                    width: 180,
                    height: 6,
                    backgroundColor: themeColor,
                    borderRadius: R(3)
                }
            },
            // 副标题
            {
                type: 'text',
                text: '精选好券 · 限时领取 · 扫码即得',
                style: {
                    left: content.left, top: content.top + 156, width: content.width,
                    fontSize: 26, color: '#888888', textAlign: 'left', rows: 1, lineHeight: 36
                }
            },
        ]

        // 二维码 top：在副标题与底部提示之间垂直居中
        const subtitleBottom = content.top + 156  // 副标题底
        const footerTop = content.bottom          // 底部提示位置
        qr.top = Math.round((subtitleBottom + footerTop - qrSize) / 2)
        data.push({
            type: 'image',
            imgType: 1,
            src: qrSrc,
            style: {left: qr.left, top: qr.top, width: qr.width, height: qr.height}
        })

        // 底部提示：贴白色区域底部内边距
        data.push({
            type: 'text',
            text: '长按识别二维码 · 立即参与活动',
            style: {
                left: content.centerX, top: footerTop, width: content.width,
                fontSize: 24, color: '#999999', textAlign: 'center', rows: 1, lineHeight: 24
            }
        })
    } catch (e) {
        console.error('[poster] 构建海报数据异常', e)
        utils.toast('海报生成失败')
        return
    }

    posterRef.value.draw(data, (url) => {
        if (url) {
            posterUrl.value = url
        } else {
            console.error('[poster] canvasToTempFilePath 返回 false')
            utils.toast('海报生成失败')
        }
    })
}

const onSavePoster = () => {
    if (!posterUrl.value) return
    saveImageToAlbum(posterUrl.value)
}

onLoad((e) => {
    activityId.value = e.id;
    Promise.all([getDetail(), getShareParam()]).then(([, shareData]) => {
        if (shareData) {
            shareParam.value = shareData
        }
    })
})
</script>

<style scoped>
.container-poster {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    margin-top: 50rpx;
    min-height: 1000rpx;
}
.image-poster {
    width: 100%;
    max-width: 600rpx;
    border-radius: 16rpx;
    box-shadow: 0 4rpx 24rpx rgba(0, 0, 0, 0.08);
}

.theme-bar {
    display: flex;
    align-items: center;
    padding: 24rpx 32rpx;
}

.theme-bar-list {
    display: flex;
    align-items: center;
    flex: 1;
    gap: 20rpx;
}

.theme-dot {
    position: relative;
    width: 56rpx;
    height: 56rpx;
    border-radius: 50%;
    box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.12);
}

.theme-dot.active {
    transform: scale(1.1);
}

.theme-dot-check {
    position: absolute;
    left: 50%;
    top: 50%;
    width: 20rpx;
    height: 20rpx;
    margin-left: -10rpx;
    margin-top: -10rpx;
    border-radius: 50%;
    background: #fff;
    box-shadow: inset 0 0 0 4rpx rgba(255, 255, 255, 0.95);
}

.theme-bar-name {
    font-size: 26rpx;
    color: #666;
    margin-left: 24rpx;
    min-width: 96rpx;
    text-align: right;
}
</style>
