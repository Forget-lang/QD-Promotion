<template>
    <m-loading v-if="shareParam === undefined"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <view class="tips-card mt-2">
                <text class="tips-title">使用说明</text>
                <view class="tips-item">
                    <text class="tips-text">保存二维码图片，顾客使用微信扫一扫即可打开活动</text>
                </view>
            </view>
            <view class="section section-body mt-2">
                <view class="text-center">
                    <image class="qrcode-image" :src="shareParam.qrcode" mode="widthFix"
                           v-if="shareParam.qrcode"></image>
                    <m-loading v-else/>
                </view>
            </view>
        </view>
        <m-submit @click="downloadImage(shareParam.qrcode)">下载活动码</m-submit>
    </template>
</template>

<script setup>
import {onLoad} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import utils from "@/utils/utils";
import {downloadImage} from "@/hooks/useFile";

const activityId = ref('');
const shareParam = ref();

const getShareParam = () => {
    request.post('/seller/activity-poster/share', {id: activityId.value, channel: 'qrcode'}).then(res => {
        shareParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    activityId.value = e.id;
    getShareParam()
})
</script>

<style scoped>
.qrcode-image {
    width: 100%;
    max-width: 400rpx;
    border-radius: 8rpx;
    margin: 20rpx auto;
}
</style>
