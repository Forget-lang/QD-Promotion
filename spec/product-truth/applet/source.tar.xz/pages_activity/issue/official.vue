<template>
    <m-loading v-if="shareParam === undefined"></m-loading>
    <view v-else class="container container-safety">
        <view class="tips-card mt-2">
            <text class="tips-title">使用说明</text>
            <view class="tips-item">
                <text class="tips-text">小程序AppID和路径可用于生成小程序码，或在公众号文章中添加小程序卡片</text>
            </view>
            <view class="tips-item">
                <text class="tips-text">公众号链接适用于公众号图文消息</text>
            </view>
        </view>

        <view class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-miniprogram-filled" size="60rpx" color="#605AB0"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">小程序AppID</view>
                        <view class="text-small text-muted">{{ shareParam.appId || '' }}</view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold" @click="utils.copyClipboard(shareParam.appId,'小程序AppID已复制')">
                            复制
                        </view>
                    </view>
                </view>
            </view>
        </view>

        <view class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-wechat-stroke-filled" size="60rpx" color="#03da6b"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">小程序路径</view>
                        <view class="text-small text-muted text-scroll-hidden" style="max-width: 380rpx">
                            {{ shareParam.appletPath || '' }}
                        </view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold"
                              @click="utils.copyClipboard(shareParam.appletPath,'小程序路径已复制')">复制
                        </view>
                    </view>
                </view>
            </view>
        </view>

        <view class="section section-body mt-2">
            <view class="media">
                <view class="media-header">
                    <t-icon name="logo-ie-filled" size="60rpx" color="#1280f5"/>
                </view>
                <view class="media-body">
                    <view class="media-content">
                        <view class="lh-25">公众号链接</view>
                        <view class="text-small text-muted text-scroll-hidden" style="max-width: 380rpx">
                            {{ shareParam.appletHref || '' }}
                        </view>
                    </view>
                    <view class="media-action">
                        <view class="button-gold"
                              @click="utils.copyClipboard(shareParam.appletHref,'公众号链接已复制')">复制
                        </view>
                    </view>
                </view>
            </view>
        </view>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'

const activityId = ref('')
const shareParam = ref()

const getShareParam = () => {
    request.post('/seller/activity-poster/share', {id: activityId.value, channel: 'official'}).then(res => {
        shareParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onLoad((e) => {
    activityId.value = e.id
    getShareParam()
})
</script>

<style scoped>
</style>
