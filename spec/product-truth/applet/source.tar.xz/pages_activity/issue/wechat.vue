<template>
    <m-loading v-if="shareParam === undefined"></m-loading>
    <template v-else>
        <view class="container container-safety">
            <view class="tips-card mt-2">
                <text class="tips-title">使用说明</text>
                <view class="tips-item">
                    <text class="tips-text">以小程序卡片分享给微信好友或群</text>
                </view>
                <view class="tips-item">
                    <text class="tips-text">顾客打开后可选择活动中的优惠券领取</text>
                </view>
            </view>
            <view class="section section-body mt-2" style="height: 600rpx">
                <m-result style="height: 600rpx" type="success" title="分享链接已生成"
                          description="请将活动分享给微信好友或群"></m-result>
            </view>
        </view>
        <div class="submit">
            <div class="submit-btn">
                <t-button openType="share" block theme="danger" size="large">分享给微信好友/群</t-button>
            </div>
        </div>
    </template>
</template>

<script setup>
import {onLoad, onShareAppMessage} from "@dcloudio/uni-app";
import {ref} from 'vue';
import request from "@/hooks/request";
import utils from "@/utils/utils";

const activityId = ref('');
const shareParam = ref();
const shareTitle = ref("");
const shareCover = ref("");

const getShareParam = () => {
    request.post('/seller/activity-poster/share', {id: activityId.value, channel: 'wechat'}).then(res => {
        shareParam.value = res.data
    }).catch(err => {
        utils.toast(err.message)
    })
}

onShareAppMessage(() => {
    return {
        title: shareTitle.value,
        imageUrl: shareCover.value,
        path: shareParam.value.appletPath,
    }
})

onLoad((e) => {
    activityId.value = e.id;
    shareTitle.value = decodeURIComponent(e.name || '活动海报');
    shareCover.value = decodeURIComponent(e.cover || '');
    getShareParam()
})
</script>

<style scoped>
.submit {
    background: #FFF;
    position: fixed;
    bottom: 0;
    width: 100%;
    z-index: 99;
    padding-bottom: constant(safe-area-inset-bottom);
    padding-bottom: env(safe-area-inset-bottom);
}

.submit-btn {
    padding: 30rpx 30rpx;
}
</style>
