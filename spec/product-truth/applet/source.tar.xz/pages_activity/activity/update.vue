<template>
    <m-loading v-if="loadingDetail"></m-loading>
    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view>封面图片</view>
                <view class="text-small text-success">推荐尺寸：5:4</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="form.coverImages"
                    :max="1"
                    :cropperWidth="300"
                    :cropperHeight="240"
                    emitName="activityPosterCover"
                ></m-cover-uploader>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-input
                placeholder="最多32个字"
                align="right"
                :maxlength="32"
                v-model:value="form.name"
            >
                <template #label>
                    <view class="input-custom-label-required">活动名称</view>
                </template>
            </t-input>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-activity-coupon-select
                required
                title="优惠券列表"
                tip="仅可选择有效的公开领取优惠券"
                v-model:value="form.coupons"
            ></m-activity-coupon-select>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea
                label="活动须知"
                v-model:value="form.notice"
                :maxlength="500"
                :indicator="true"
                placeholder="请输入活动须知"
            ></t-textarea>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="展示在商家主页">
                <template #note>
                    <t-switch v-model:value="form.isShowHome"/>
                </template>
            </t-cell>
            <t-cell title="允许分享" description="开启后顾客可转发活动页">
                <template #note>
                    <t-switch v-model:value="form.isShare"/>
                </template>
            </t-cell>
            <m-select
                required
                title="状态"
                v-model:value="form.status"
                :options="statusOptions"
            ></m-select>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" :disabled="loading" @click="onSubmit">
                保存修改
            </t-button>
        </view>
    </view>
</template>

<script setup>
import {onLoad} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink.js'

const {back} = useLink()
const loading = ref(false)
const loadingDetail = ref(true)
const activityId = ref('')

const statusOptions = [
    {label: '上架', value: 1},
    {label: '下架', value: 2},
]

const form = ref({
    coverImages: [],
    name: '',
    coupons: [],
    notice: '',
    isShowHome: false,
    isShare: false,
    status: 1,
})

const loadDetail = () => {
    loadingDetail.value = true
    request.get('/seller/activity-poster/detail', {id: activityId.value}).then(res => {
        const data = res.data
        form.value = {
            coverImages: data.cover ? [data.cover] : [],
            name: data.name,
            coupons: (data.coupons || []).map(item => ({
                couponId: item.couponId,
                couponName: item.couponName,
                couponType: item.couponType,
                remainStock: item.remainStock,
            })),
            notice: data.notice || '',
            isShowHome: !!data.isShowHome,
            isShare: !!data.isShare,
            status: data.status,
        }
    }).finally(() => {
        loadingDetail.value = false
    })
}

const onSubmit = utils.throttle(() => {
    if (!form.value.name) {
        return utils.toast('请输入活动名称')
    }
    if (!form.value.coverImages?.length) {
        return utils.toast('请上传封面图')
    }
    if (!form.value.coupons?.length) {
        return utils.toast('请选择优惠券')
    }
    loading.value = true
    request.post('/seller/activity-poster/update', {
        id: activityId.value,
        name: form.value.name,
        cover: form.value.coverImages[0],
        notice: form.value.notice,
        couponIds: form.value.coupons.map(item => item.couponId),
        isShowHome: form.value.isShowHome,
        isShare: form.value.isShare,
        status: form.value.status,
    }).then(() => {
        return request.get('/seller/activity-poster/detail', {id: activityId.value})
    }).then(res => {
        uni.$emit('onActivityUpdate', res.data)
        utils.toast('保存成功')
        setTimeout(() => back(), 500)
    }).finally(() => {
        loading.value = false
    })
}, 800)

onLoad((e) => {
    activityId.value = e.id
    loadDetail()
})
</script>
