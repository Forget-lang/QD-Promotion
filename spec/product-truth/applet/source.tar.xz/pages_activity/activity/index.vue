<template>
    <t-tabs v-model:value="currentTab" bottom-line-mode="auto" @change="onTabChange">
        <t-tab-panel label="上架中" :value="1"></t-tab-panel>
        <t-tab-panel label="已下架" :value="2"></t-tab-panel>
    </t-tabs>

    <m-loading v-if="items === undefined"></m-loading>
    <m-empty v-else-if="items === null">
        <view>加载失败</view>
        <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
    </m-empty>

    <view class="container mt-2 container-safety" v-else>
        <m-empty v-if="items.length === 0">
            {{ currentTab === 1 ? '暂无上架活动，点击下方创建' : '暂无下架活动' }}
        </m-empty>
        <template v-else>
            <view class="list-summary">
                <text>共 {{ total }} 个活动</text>
                <text v-if="!isCompleted" class="list-summary-hint">已加载 {{ items.length }} 个</text>
            </view>

            <view
                class="poster-card"
                :class="{'is-inactive': currentTab === 2}"
                v-for="item in items"
                :key="item.id"
                @tap="push('/pages_activity/activity/detail?id=' + item.id)"
            >
                <view class="poster-cover-wrap">
                    <image class="poster-cover" :src="item.cover" mode="aspectFill"/>
                    <view class="poster-cover-mask"></view>
                    <view class="poster-badges" v-if="item.isShowHome || currentTab === 2">
                        <text v-if="item.isShowHome" class="badge badge-home">主页展示</text>
                        <text v-if="currentTab === 2" class="badge badge-off">已下架</text>
                    </view>
                </view>
                <view class="poster-body">
                    <view class="poster-name text-ellipsis-2">{{ item.name }}</view>
                    <view class="poster-footer">
                        <view class="poster-stats">
                            <view class="poster-stat">
                                <t-icon name="coupon" size="28rpx" color="#999"/>
                                <text>{{ item.couponCount || 0 }} 张券</text>
                            </view>
                            <view class="poster-stat">
                                <t-icon name="browse" size="28rpx" color="#999"/>
                                <text>{{ item.viewCount || 0 }} 浏览</text>
                            </view>
                        </view>
                        <view class="poster-more">
                            <text>详情</text>
                            <t-icon name="chevron-right" size="32rpx" color="#ccc"/>
                        </view>
                    </view>
                </view>
            </view>
            <m-loading v-if="loadingMore" text="正在加载..."/>
            <m-nomore v-else-if="isCompleted" backgroundColor="transparent"></m-nomore>
        </template>
    </view>
    <m-submit v-if="checkPermission(PERM_ACTIVITY.POSTER_CREATE)" @click="onAddPoster">创建活动
    </m-submit>

    <!-- VIP 升级抽屉：打开走 useVipGuard / 事件 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad, onShow, onUnload, onPullDownRefresh, onReachBottom} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {EDITION_FEATURES, getQuotaOverflow} from '@/constants/edition'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth'
import {useVipGuard} from '@/hooks/useVipGuard'
import {PERM_ACTIVITY} from '@/constants/permission'
import to from '@/hooks/to'

const {push} = useLink()
const {checkPermission, getSession, session: staffSession} = useAuth()
const {check} = useVipGuard()
// 当前 Tab（1上架中/2已下架）
const currentTab = ref(1)
// 列表查询筛选参数
const search = ref({
    page: 1,
    pageSize: 20,
    status: 1,
})
// 列表数据（undefined 加载中 / null 加载失败 / [] 空 / 有数据）
const items = ref()
// 活动总数
const total = ref(0)
// 是否没有更多数据
const isCompleted = ref(false)
// 加载更多中
const loadingMore = ref(false)

// 重新加载（网络重试）
const onRetry = () => {
    items.value = undefined
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 点击创建活动：达到当前版本档位上限时走统一受限提醒（升级抽屉预选目标版本），通过后进入创建页
const onAddPoster = () => {
    const overflow = getQuotaOverflow(EDITION_FEATURES.ACTIVITY_POSTER, staffSession.value?.editionId, total.value)
    if (overflow) {
        check(overflow)
        return
    }
    push('/pages_activity/activity/create')
}

// 获取活动列表数据
const getItems = () => {
    if (loadingMore.value) return
    loadingMore.value = true
    request.get('/seller/activity-poster/list', search.value).then(res => {
        if (search.value.page === 1) {
            items.value = []
        }
        items.value = (items.value || []).concat(to.Array(res.data.items))
        isCompleted.value = res.data.total === items.value.length
        total.value = res.data.total || 0
    }).catch(() => {
        if (search.value.page === 1) {
            //只有首次加载失败（请求超时等情况），页面显示网络错误样式，可重试请求
            items.value = null
        } else {
            // 加载失败，页码减一（因为onReachBottom已触发page+1，需要减掉）
            search.value.page--
        }
    }).finally(() => {
        setTimeout(() => {
            loadingMore.value = false
            uni.stopPullDownRefresh()
        }, 500)
    })
}

const onTabChange = (e) => {
    search.value.status = e.value
    search.value.page = 1
    isCompleted.value = false
    items.value = undefined
    loadingMore.value = false
    getItems()
}

const onRefresh = () => {
    search.value.page = 1
    isCompleted.value = false
    loadingMore.value = false
    getItems()
}

// 注册全局事件监听，创建/修改/删除后同步列表数据
const registerEvent = () => {
    // 创建活动后刷新列表
    uni.$on('onActivityCreate', () => {
        if (currentTab.value !== 1) return
        onRefresh()
    })
    // 修改活动后更新列表对应项
    uni.$on('onActivityUpdate', (e) => {
        if (!e?.id || !items.value?.length) return
        const editIndex = items.value.findIndex(item => item.id === e.id)
        if (editIndex >= 0) {
            items.value.splice(editIndex, 1, e)
        } else {
            // 修改后可能切换了上下架状态，刷新列表
            onRefresh()
        }
    })
    // 删除活动后从列表移除
    uni.$on('onActivityDelete', (e) => {
        if (e?.id && items.value?.length) {
            const deleteIndex = items.value.findIndex(item => item.id === e.id)
            if (deleteIndex >= 0) {
                items.value.splice(deleteIndex, 1)
            }
        }
    })
}

onLoad(() => {
    registerEvent()
    getItems()
})

// 每次进入页面刷新员工会话，保证档位预检用的版本数据最新
onShow(() => {
    getSession()
})

onUnload(() => {
    uni.$off('onActivityCreate')
    uni.$off('onActivityUpdate')
    uni.$off('onActivityDelete')
})

onPullDownRefresh(() => {
    onRefresh()
})

onReachBottom(() => {
    if (!isCompleted.value && !loadingMore.value) {
        search.value.page++
        getItems()
    }
})
</script>

<style scoped>
.list-summary {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 0 8rpx 20rpx;
    font-size: 24rpx;
    color: #999;
}

.list-summary-hint {
    color: #ccc;
}

.poster-card {
    background: #fff;
    border-radius: 24rpx;
    overflow: hidden;
    margin-bottom: 24rpx;
    box-shadow: 0 4rpx 20rpx rgba(0, 0, 0, 0.04);
}

.poster-card.is-inactive {
    opacity: 0.78;
}

.poster-cover-wrap {
    position: relative;
    width: 100%;
    /* 封面推荐 5:4，列表略压扁一点更紧凑 */
    height: 360rpx;
    background: #f2f2f2;
}

.poster-cover {
    width: 100%;
    height: 100%;
    display: block;
}

.poster-cover-mask {
    position: absolute;
    left: 0;
    right: 0;
    bottom: 0;
    height: 80rpx;
    background: linear-gradient(to top, rgba(0, 0, 0, 0.18), transparent);
    pointer-events: none;
}

.poster-badges {
    position: absolute;
    top: 20rpx;
    left: 20rpx;
    display: flex;
    flex-wrap: wrap;
    gap: 12rpx;
}

.badge {
    font-size: 22rpx;
    line-height: 1;
    padding: 10rpx 16rpx;
    border-radius: 8rpx;
    color: #fff;
}

.badge-home {
    background: rgba(226, 69, 61, 0.92);
}

.badge-off {
    background: rgba(0, 0, 0, 0.45);
}

.poster-body {
    padding: 24rpx 28rpx 26rpx;
}

.poster-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #222;
    line-height: 1.4;
    min-height: 44rpx;
}

.text-ellipsis-2 {
    overflow: hidden;
    word-break: break-all;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
}

.poster-footer {
    margin-top: 18rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.poster-stats {
    display: flex;
    align-items: center;
    gap: 24rpx;
}

.poster-stat {
    display: flex;
    align-items: center;
    gap: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.poster-more {
    display: flex;
    align-items: center;
    gap: 2rpx;
    font-size: 24rpx;
    color: #bbb;
}
</style>
