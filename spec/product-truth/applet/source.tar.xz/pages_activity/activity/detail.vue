<template>
    <m-loading v-if="detail === undefined"></m-loading>
    <m-empty v-else-if="detail === null">活动不存在</m-empty>
    <view class="container-safety" v-else>
        <view class="detail-header">
            <view class="container">
                <image class="cover mt-2" :src="detail.cover" mode="aspectFill"/>

                <view class="info-card mt-2">
                    <view class="info-name">{{ detail.name }}</view>
                    <view class="info-tags">
                        <t-tag
                            :theme="detail.status === ACTIVITY_STATUS.ONLINE ? 'success' : 'warning'"
                            variant="light-outline"
                            size="small"
                        >{{ detail.statusLabel }}
                        </t-tag>
                        <t-tag v-if="detail.isShowHome" theme="danger" variant="light-outline" size="small">
                            主页展示
                        </t-tag>
                    </view>
                    <view class="info-divider"></view>
                    <view class="info-stats">
                        <view class="info-stat">
                            <view class="info-stat-value">{{ detail.viewCount || 0 }}</view>
                            <view class="info-stat-label">浏览量</view>
                        </view>
                        <view class="info-stat">
                            <view class="info-stat-value">{{ detail.coupons ? detail.coupons.length : 0 }}</view>
                            <view class="info-stat-label">优惠券</view>
                        </view>
                    </view>
                </view>

                <view class="section mt-2">
                    <t-grid :column="4">
                        <t-grid-item
                            text="优惠券列表"
                            icon="layers"
                            :badge-props="{ count: detail.coupons ? detail.coupons.length : 0 }"
                            @click="showCouponPopup = true"
                        />
                        <t-grid-item text="活动须知" icon="file-1" @click="showNoticePopup = true"/>
                    </t-grid>
                </view>
            </view>
        </view>

        <t-cell-group title="操作" t-title-class="mt-2" theme="card">
            <t-grid :column="4">
                <t-grid-item v-if="checkPermission(PERM_ACTIVITY.POSTER_UPDATE)" text="修改活动" icon="edit-2"
                             @click="push('/pages_activity/activity/update?id=' + activityId)"/>
                <t-grid-item text="预览活动" icon="browse"
                             @click="push('/pages_user/activity_poster/detail?id=' + activityId)"/>
                <t-grid-item v-if="checkPermission(PERM_ACTIVITY.POSTER_DELETE)" text="删除活动" icon="delete"
                             @click="deleteVisible = true"/>
            </t-grid>
        </t-cell-group>
    </view>

    <m-submit
        v-if="detail"
        :disabled="detail.status !== ACTIVITY_STATUS.ONLINE"
        @click="shareVisible = true"
    >分享活动
        <template v-if="detail.status === ACTIVITY_STATUS.OFFLINE"> [已下架]</template>
    </m-submit>

    <t-action-sheet :visible="deleteVisible" :items="[{ label: '确定删除活动' }]" @selected="onDelete"
                    @cancel="deleteVisible = false"/>

    <t-popup placement="bottom" v-model:visible="shareVisible">
        <view class="popup-header">
            <view class="popup-header-title">分享活动</view>
            <view class="popup-header-close">
                <t-icon name="close" @click="shareVisible = false" :size="20"></t-icon>
            </view>
        </view>
        <view class="text-center text-muted text-small">顾客打开后可选择活动中的优惠券领取</view>
        <t-divider/>
        <t-grid :column="4">
            <t-grid-item text="微信好友/群"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2nl4lbp0mqcs77du0.png"
                         @click="goShare('wechat')"/>
            <t-grid-item text="二维码"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2o2slbp0mqcs77dug.png"
                         @click="goShare('qrcode')"/>
            <t-grid-item text="海报"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2onclbp0mqcs77dvg.png"
                         @click="goShare('poster')"/>
            <t-grid-item text="公众号"
                         image="https://cdn.lenmy.com/quandao/2026/05/07/d7u2oeclbp0mqcs77dv0.png"
                         @click="goShare('official')"/>
        </t-grid>
        <view class="popup-bottom-cancel mt-5" @click="shareVisible = false">取消</view>
    </t-popup>

    <t-popup v-model:visible="showCouponPopup" placement="bottom">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-title">优惠券列表</view>
                <view class="popup-header-close">
                    <t-icon t-class="mr-2" name="close" size="50rpx" @click="showCouponPopup = false"/>
                </view>
            </view>
            <scroll-view class="popup-body" scroll-y :show-scrollbar="true">
                <view class="coupon-popup-list" v-if="detail?.coupons?.length">
                    <view class="receive mb-2" v-for="item in detail.coupons" :key="item.couponId">
                        <view class="coupon-top">
                            <view class="coupon-top-type">{{ item.couponTypeLabel }}</view>
                            <view class="coupon-top-extra">剩余 {{ item.remainStock }}</view>
                        </view>
                        <view class="coupon-line"></view>
                        <view class="coupon">
                            <view class="coupon-header">
                                <image class="coupon-thumb" :src="item.cover" mode="aspectFill"/>
                            </view>
                            <view class="coupon-body">
                                <view class="coupon-content">
                                    <view class="coupon-content-info">
                                        <view class="coupon-content-name text-ellipsis-break">{{
                                                item.couponName
                                            }}
                                        </view>
                                        <view class="coupon-content-value">
                                            <template v-if="isAmountFace(item.couponType)">
                                                <view class="coupon-content-amount">
                                                    <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                    <view class="coupon-amount-discount">元券</view>
                                                </view>
                                            </template>
                                            <template v-else-if="item.couponType === COUPON_TYPE.DISCOUNT">
                                                <view class="coupon-content-amount">
                                                    <view class="coupon-amount-money">{{ item.couponAmount }}</view>
                                                    <view class="coupon-amount-discount">折券</view>
                                                </view>
                                            </template>
                                            <template v-else-if="item.couponType === COUPON_TYPE.EXCHANGE">
                                                <view class="coupon-amount">
                                                    <image class="exchange-icon" src="/static/img/exchange.png"
                                                           mode="aspectFit"/>
                                                </view>
                                            </template>
                                            <view class="coupon-threshold">{{ item.threshold }}</view>
                                        </view>
                                        <view class="coupon-content-valid text-ellipsis">{{ item.validLabel }}</view>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </view>
                </view>
                <m-empty v-else>暂无优惠券</m-empty>
            </scroll-view>
        </view>
    </t-popup>

    <t-popup v-model:visible="showNoticePopup" placement="bottom">
        <view class="popup-header">
            <view class="popup-header-title">活动须知</view>
            <view class="popup-header-close">
                <t-icon name="close" size="50rpx" @click="showNoticePopup = false"/>
            </view>
        </view>
        <scroll-view class="popup-body" scroll-y :show-scrollbar="true">
            <view class="popup-card">
                <view class="item-text" v-if="detail?.notice">{{ detail.notice }}</view>
                <m-empty v-else>暂无活动须知</m-empty>
            </view>
        </scroll-view>
    </t-popup>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {ACTIVITY_STATUS} from '@/constants/activity'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink'
import {useAuth} from '@/hooks/useAuth.js'
import {PERM_ACTIVITY} from '@/constants/permission.js'

const {push, back} = useLink()
const {checkPermission} = useAuth()

const activityId = ref('')
const detail = ref()
const deleteVisible = ref(false)
const shareVisible = ref(false)
const showCouponPopup = ref(false)
const showNoticePopup = ref(false)

const getDetail = () => {
    request.get('/seller/activity-poster/detail', {id: activityId.value}).then(res => {
        detail.value = res.data
    }).catch(() => {
        detail.value = null
    }).finally(() => {
        uni.stopPullDownRefresh()
    })
}

const onDelete = () => {
    deleteVisible.value = false
    request.post('/seller/activity-poster/delete', {id: activityId.value}).then(() => {
        uni.$emit('onActivityDelete', {id: activityId.value})
        utils.toast('已删除')
        setTimeout(() => back(), 500)
    })
}

const goShare = (type) => {
    shareVisible.value = false
    const q = '?id=' + activityId.value + '&name=' + encodeURIComponent(detail.value.name || '') + '&cover=' + encodeURIComponent(detail.value.cover || '')
    if (type === 'wechat') {
        push('/pages_activity/issue/wechat' + q)
    } else if (type === 'qrcode') {
        push('/pages_activity/issue/qrcode' + q)
    } else if (type === 'poster') {
        push('/pages_activity/issue/poster' + q)
    } else if (type === 'official') {
        push('/pages_activity/issue/official' + q)
    }
}

onLoad((e) => {
    activityId.value = e.id
})

onShow(() => {
    if (activityId.value) {
        getDetail()
    }
})

onPullDownRefresh(() => {
    getDetail()
})
</script>

<style scoped>
.cover {
    width: 100%;
    height: 360rpx;
    border-radius: 16rpx;
    background: #f5f5f5;
    display: block;
}

.info-card {
    background: #fff;
    border-radius: 16rpx;
    padding: 28rpx 32rpx;
}

.info-name {
    font-size: 34rpx;
    font-weight: 600;
    color: #333;
    line-height: 1.4;
    word-break: break-all;
}

.info-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 12rpx;
    margin-top: 16rpx;
}

.info-divider {
    height: 1rpx;
    background: #f0f0f0;
    margin: 24rpx 0;
}

.info-stats {
    display: flex;
    align-items: center;
}

.info-stat {
    flex: 1;
    text-align: center;
}

.info-stat-value {
    font-size: 40rpx;
    font-weight: 700;
    color: #333;
    line-height: 1.2;
}

.info-stat-label {
    margin-top: 8rpx;
    font-size: 24rpx;
    color: #999;
}

.popup-card {
    padding: 24rpx 32rpx;
}

.item-text {
    font-size: 28rpx;
    color: #666;
    line-height: 1.7;
    white-space: pre-wrap;
}

.coupon-popup-list {
    padding: 0 24rpx 24rpx;
}

.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.coupon-top {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 24rpx 32rpx 8rpx;
}

.coupon-top-type {
    font-size: 26rpx;
    font-weight: 600;
    color: #373737;
}

.coupon-top-extra {
    font-size: 22rpx;
    color: #999;
}

.coupon {
    padding: 10rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon-header {
    margin-right: 24rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
    background: #f5f5f5;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    /* 金额较长时让内容行可在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    /* 金额支持小数点，min-width:0 允许该行在 flex 容器内收缩，避免撑爆父元素把按钮挤出屏幕 */
    min-width: 0;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    /* 金额较长时让金额块可收缩，避免与 threshold 重叠 */
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    /* 「元券/折券」是核心标签，不允许被压缩消失 */
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    /*金额为关键信息，固定不收缩、保证单行完整显示 */
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    /* flex:1 让门槛文案只占金额剩余空间，剩余空间不足时收缩为省略号，保证金额完整且不与按钮重叠 */
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}
</style>
