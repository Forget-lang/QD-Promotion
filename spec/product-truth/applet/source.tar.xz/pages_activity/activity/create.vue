<template>
    <m-result v-if="isSuccess"
              type="success"
              title="创建成功"
              description="可前往详情分享活动"
              confirmText="查看详情"
              cancelText="返回"
              @confirm="replace('/pages_activity/activity/detail?id=' + activityId)"
              @cancel="back()"
    ></m-result>
    <view class="container-safety" v-else>
        <view class="container">
            <view class="paragraph d-flex justify-content-between align-items-baseline">
                <view>封面图片</view>
                <view class="text-small text-success">推荐尺寸：5:4</view>
            </view>
            <view class="section p-3">
                <m-cover-uploader
                    v-model:value="form.coverImages"
                    :max="1"
                    :cropperWidth="300"
                    :cropperHeight="240"
                    emitName="activityPosterCover"
                ></m-cover-uploader>
            </view>
        </view>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-input
                placeholder="最多32个字"
                align="right"
                :maxlength="32"
                v-model:value="form.name"
            >
                <template #label>
                    <view class="input-custom-label-required">活动名称</view>
                </template>
            </t-input>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <m-activity-coupon-select
                required
                title="优惠券列表"
                tip="仅可选择有效的公开领取优惠券"
                v-model:value="form.coupons"
            ></m-activity-coupon-select>
        </t-cell-group>

        <t-cell-group theme="card" t-class="mt-2" :bordered="false">
            <t-textarea
                label="活动须知"
                v-model:value="form.notice"
                :maxlength="500"
                :indicator="true"
                placeholder="请输入活动须知"
            ></t-textarea>
        </t-cell-group>

        <t-cell-group t-class="mt-2" theme="card" :bordered="false">
            <t-cell title="展示在商家主页">
                <template #note>
                    <t-switch v-model:value="form.isShowHome"/>
                </template>
            </t-cell>
            <t-cell title="允许分享" description="开启后顾客可转发活动页">
                <template #note>
                    <t-switch v-model:value="form.isShare"/>
                </template>
            </t-cell>
            <m-select
                required
                title="状态"
                v-model:value="form.status"
                :options="statusOptions"
            ></m-select>
        </t-cell-group>

        <view class="container mt-3">
            <t-button block theme="danger" size="large" :loading="loading" :disabled="loading" @click="onSubmit">
                创建活动
            </t-button>
        </view>

        <!-- VIP 升级抽屉：承接创建接口 2006 版本拦截 -->
        <m-vip-upgrade/>
    </view>
</template>

<script setup>
import {ref} from 'vue'
import request from '@/hooks/request'
import utils from '@/utils/utils'
import {useLink} from '@/hooks/useLink.js'

const {replace, back} = useLink()
const loading = ref(false)
const isSuccess = ref(false)
const activityId = ref('')

const statusOptions = [
    {label: '上架', value: 1},
    {label: '下架', value: 2},
]

const form = ref({
    coverImages: [],
    name: '',
    coupons: [],
    notice: '',
    isShowHome: false,
    isShare: false,
    status: 1,
})

const onSubmit = utils.throttle(() => {
    if (!form.value.name) {
        return utils.toast('请输入活动名称')
    }
    if (!form.value.coverImages?.length) {
        return utils.toast('请上传封面图')
    }
    if (!form.value.coupons?.length) {
        return utils.toast('请选择优惠券')
    }
    loading.value = true
    request.post('/seller/activity-poster/create', {
        name: form.value.name,
        cover: form.value.coverImages[0],
        notice: form.value.notice,
        couponIds: form.value.coupons.map(item => item.couponId),
        isShowHome: form.value.isShowHome,
        isShare: form.value.isShare,
        status: form.value.status,
    }).then((res) => {
        isSuccess.value = true
        activityId.value = res.data.id
        uni.$emit('onActivityCreate')
        form.value = undefined
    }).finally(() => {
        loading.value = false
    })
}, 800)
</script>
