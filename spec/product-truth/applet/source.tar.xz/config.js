// 切换环境：改下面这一行即可（业务代码统一 import '@/config'）
export { default } from './config.prod.js'
// export {default} from './config.test.js'
