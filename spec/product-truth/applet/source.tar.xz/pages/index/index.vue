<template>
    <view class="home-page">
        <!-- 门头 -->
        <view class="hero">
            <image class="hero-cover" :src="heroCover" mode="scaleToFill"/>
            <view class="hero-mask"></view>

            <view class="hero-nav" :style="navStyle">
                <view class="hero-pill" @tap="onOpenSwitch">
                    <t-icon name="swap" size="28rpx" color="#fff"/>
                    <text>切换商家</text>
                    <t-icon name="chevron-right" size="24rpx" color="#fff"/>
                </view>
            </view>

            <view class="hero-info">
                <view class="hero-name-row">
                    <view class="hero-name text-ellipsis">
                        {{ merchant?.name || (isLoggedIn ? '暂无商家' : '登录后查看卡包') }}
                    </view>
                    <view v-if="isMerchantVerified" class="member-badge" :style="memberBadgeStyle">
                        <image class="member-badge-icon" src="/static/img/home-badge-crown.png" mode="aspectFit"/>
                        <text>已认证</text>
                    </view>
                </view>
                <view v-if="merchant?.address" class="hero-address" @tap="onOpenLocation">
                    <t-icon name="location" size="24rpx" color="rgba(255,255,255,0.88)"/>
                    <text class="text-ellipsis">{{ merchant.address }}</text>
                </view>
                <view class="hero-tags">
                    <view class="hero-tag" @tap="onGoCouponCenter">
                        <t-icon name="gift" size="26rpx" color="#fff"/>
                        <text>领券中心</text>
                    </view>
                    <view class="hero-tag" @tap="onGoMemberBenefit">
                        <t-icon name="usergroup" size="26rpx" color="#fff"/>
                        <text>会员权益</text>
                    </view>
                    <view class="hero-tag" @tap="onCallPhone">
                        <t-icon name="call" size="26rpx" color="#fff"/>
                        <text>客服电话</text>
                    </view>
                </view>
            </view>
        </view>

        <!-- 主题色信息卡 -->
        <view class="member-card" :style="memberCardStyle">
            <view class="member-card-deco">
                <view class="member-card-glow"></view>
                <view class="member-card-orb"></view>
            </view>
            <view class="user-row">
                <template v-if="!isLoggedIn">
                    <get-user-info @success="onGetUserInfoSuccess">
                        <image class="user-avatar" :src="avatar" mode="aspectFill"/>
                    </get-user-info>
                </template>
                <image v-else class="user-avatar" :src="avatar" mode="aspectFill"/>
                <view class="user-main">
                    <view class="user-name-row">
                        <template v-if="!isLoggedIn">
                            <get-user-info @success="onGetUserInfoSuccess">
                                <view class="user-name">登录</view>
                            </get-user-info>
                        </template>
                        <view v-else class="user-name text-ellipsis">{{ nickname || '微信用户' }}</view>
                        <m-member-level-badge
                            v-if="isLoggedIn && memberLevel"
                            class="user-level-badge"
                            :name="memberLevel.name"
                            :icon-key="memberLevel.iconKey"
                            :color="memberLevel.color"
                            @click="onGoMemberBenefit"
                        />
                    </view>
                    <view class="user-sub">
                        {{ isLoggedIn ? `累计积分 ${stats.pointBalance}` : '登录后查看会员信息' }}
                    </view>
                </view>
                <view class="user-actions">
                    <view class="user-code" @tap="onMemberQrcode">
                        <t-icon name="qrcode" size="48rpx" color="#fff"/>
                    </view>
                    <view class="user-code" @tap="onGoSetting">
                        <t-icon name="setting" size="48rpx" color="#fff"/>
                    </view>
                </view>
            </view>

            <view class="stats-row">
                <view class="stat" @tap="onPointTap">
                    <view class="stat-head">
                        <image class="stat-icon" src="/static/img/home-point.png" mode="aspectFit"/>
                        <view class="stat-num">{{ stats.pointBalance }}</view>
                    </view>
                    <view class="stat-label">积分</view>
                    <view class="stat-link">
                        <text>查看我的积分</text>
                        <t-icon name="chevron-right" size="22rpx" color="rgba(255,255,255,0.55)"/>
                    </view>
                </view>
                <view class="stat-divider"></view>
                <view class="stat" @tap="onStatTap('/pages_user/coupon/index')">
                    <view class="stat-head">
                        <image class="stat-icon" src="/static/img/home-stat-ticket.png" mode="aspectFit"/>
                        <view class="stat-num">{{ stats.couponCount }}
                            <text class="stat-unit">张</text>
                        </view>
                    </view>
                    <view class="stat-label">优惠券</view>
                    <view class="stat-link">
                        <text>查看可用优惠券</text>
                        <t-icon name="chevron-right" size="22rpx" color="rgba(255,255,255,0.55)"/>
                    </view>
                </view>
                <view class="stat-divider"></view>
                <view class="stat" @tap="onStatTap('/pages_user/card/index')">
                    <view class="stat-head">
                        <image class="stat-icon" src="/static/img/home-card.png" mode="aspectFit"/>
                        <view class="stat-num">{{ stats.cardCount }}
                            <text class="stat-unit">张</text>
                        </view>
                    </view>
                    <view class="stat-label">次卡</view>
                    <view class="stat-link">
                        <text>查看我的次卡</text>
                        <t-icon name="chevron-right" size="22rpx" color="rgba(255,255,255,0.55)"/>
                    </view>
                </view>
            </view>
            <image class="member-wave" src="/static/img/home-card-wave.png" mode="scaleToFill"/>
        </view>

        <!-- 未登录 -->
        <template v-if="!isLoggedIn">
            <!-- 广告位 -->
            <view class="section container">
                <ad-custom :unit-id="config.adUnit.couponHome"></ad-custom>
            </view>
            <m-empty v-if="!isLoggedIn" :height="280">登录后查看本店优惠券、券包和次卡</m-empty>
        </template>


        <template v-else>
            <!-- 广告位 -->
            <view class="section container" v-if="adUnitHome">
                <ad-custom :unit-id="adUnitHome"></ad-custom>
            </view>

            <m-loading v-if="pageLoading && !merchant"></m-loading>
            <m-empty v-else-if="loadError" :height="280">
                <view>加载失败</view>
                <t-button theme="primary" size="small" variant="outline" t-class="mt-3" @click="onRetry">重新加载</t-button>
            </m-empty>
            <m-empty v-else-if="!merchantId" :height="280">暂无商家，领券后这里会按店展示</m-empty>
            <template v-else>
                <!-- 我的优惠券 -->
                <view class="asset-section" v-if="stats.couponCount > 0">
                    <view class="section-header">
                        <view class="section-title">我的优惠券
                            <text class="section-count">({{ stats.couponCount }}张)</text>
                        </view>
                        <view class="section-more" @tap="onStatTap('/pages_user/coupon/index')">
                            <text>全部优惠券</text>
                            <t-icon name="chevron-right" size="28rpx" color="#999"/>
                        </view>
                    </view>
                    <view class="receive" v-if="latestCoupon">
                        <view class="merchant">
                            <image class="merchant-logo" :src="latestCoupon.merchantLogo" mode="aspectFill"/>
                            <view class="merchant-header">
                                <view class="merchant-header-title">
                                    <view class="d-flex align-items-center">
                                        <text class="text-ellipsis">{{ latestCoupon.merchantName }}</text>
                                    </view>
                                </view>
                                <view class="merchant-header-extra">
                                    <view class="coupon-type">{{ latestCoupon.couponTypeLabel }}</view>
                                </view>
                            </view>
                        </view>
                        <view class="coupon-line"></view>
                        <view class="coupon" @tap="push('/pages_user/coupon/detail?id=' + latestCoupon.id)">
                            <view class="coupon-header">
                                <image class="coupon-thumb" :src="latestCoupon.cover" mode="scaleToFill"/>
                            </view>
                            <view class="coupon-body">
                                <view class="coupon-content">
                                    <view class="coupon-content-info">
                                        <view class="coupon-content-name text-ellipsis-break">{{
                                                latestCoupon.couponName
                                            }}
                                        </view>
                                        <view class="coupon-content-value">
                                            <template v-if="isAmountFace(latestCoupon.couponType)">
                                                <view class="coupon-content-amount">
                                                    <view class="coupon-amount-money">{{
                                                            latestCoupon.couponAmount
                                                        }}
                                                    </view>
                                                    <view class="coupon-amount-discount">元券</view>
                                                </view>
                                            </template>
                                            <template v-else-if="latestCoupon.couponType === COUPON_TYPE.DISCOUNT">
                                                <view class="coupon-content-amount">
                                                    <view class="coupon-amount-money">{{
                                                            latestCoupon.couponAmount
                                                        }}
                                                    </view>
                                                    <view class="coupon-amount-discount">折券</view>
                                                </view>
                                            </template>
                                            <template v-else-if="latestCoupon.couponType === COUPON_TYPE.EXCHANGE">
                                                <view class="coupon-amount">
                                                    <img class="exchange-icon" src="/static/img/exchange.png" alt="">
                                                </view>
                                            </template>
                                            <view class="coupon-threshold">{{ latestCoupon.threshold }}</view>
                                        </view>
                                        <view class="coupon-content-valid text-ellipsis">{{
                                                latestCoupon.validLabel
                                            }}
                                        </view>
                                    </view>
                                    <view class="coupon-content-action">
                                        <view class="button-gold" @click.stop="onUse(latestCoupon)">使用</view>
                                    </view>
                                </view>
                            </view>
                        </view>
                    </view>
                </view>

                <!-- 我的次卡：没有次卡时整块不展示 -->
                <view v-if="stats.cardCount > 0" class="asset-section">
                    <view class="section-header">
                        <view class="section-title">我的次卡
                            <text class="section-count">({{ stats.cardCount }}张)</text>
                        </view>
                        <view class="section-more" @tap="onStatTap('/pages_user/card/index')">
                            <text>全部次卡</text>
                            <t-icon name="chevron-right" size="28rpx" color="#999"/>
                        </view>
                    </view>
                    <view v-if="latestCard" class="card-wrap" @tap="push('/pages_user/card/detail?id=' + latestCard.id)">
                        <m-card-magnetic-face
                            :theme="Number(latestCard.theme) || 1"
                            :merchant-name="latestCard.merchantName"
                            :cover="latestCard.cover"
                            :title="latestCard.cardName"
                            :card-type="latestCard.cardType"
                            :remain-times="latestCard.remainCount"
                            :total-times="latestCard.totalTimes"
                            :valid-label="latestCard.validLabel"
                            :used-times="latestCard.verifyCount"
                            :status="latestCard.status"
                            :status-label="latestCard.statusLabel"
                        />
                    </view>
                </view>

                <!-- 我的券包：没有券包时整块不展示 -->
                <view v-if="stats.bundleCount > 0" class="asset-section">
                    <view class="section-header">
                        <view class="section-title">我的券包
                            <text class="section-count">({{ stats.bundleCount }}个)</text>
                        </view>
                        <view class="section-more" @tap="onStatTap('/pages_user/bundle/index')">
                            <text>全部券包</text>
                            <t-icon name="chevron-right" size="28rpx" color="#999"/>
                        </view>
                    </view>
                    <view
                        v-if="latestBundle"
                        class="bundle"
                        :style="getThemeStyle(latestBundle.theme)"
                        @tap="push('/pages_user/bundle/detail?id=' + latestBundle.id)"
                    >
                        <view class="bundle-header">
                            <view class="bundle-name text-ellipsis-2">{{ latestBundle.bundleName }}</view>
                            <text class="bundle-merchant-name text-ellipsis">{{ latestBundle.merchantName }}</text>
                        </view>
                        <view class="bundle-body">
                            <view class="bundle-count">
                                <text class="bundle-count-num">{{ latestBundle.couponKindCount }}</text>
                                <text class="bundle-count-unit">种券</text>
                                <text class="bundle-count-sep">·共</text>
                                <text class="bundle-count-num">{{ latestBundle.itemCount }}</text>
                                <text class="bundle-count-unit">张</text>
                            </view>
                            <image v-if="latestBundle.cover" class="bundle-cover" :src="latestBundle.cover"
                                   mode="aspectFill"/>
                            <view v-else class="bundle-cover bundle-cover-empty">
                                <t-icon name="gift-filled" size="36rpx" color="rgba(255,255,255,0.6)"/>
                            </view>
                        </view>
                        <view class="bundle-footer">
                            <view class="bundle-tags">
                                <view class="bundle-tag">券包</view>
                            </view>
                            <text class="bundle-time">领取于 {{ formatTime(latestBundle.receivedAt) }}</text>
                        </view>
                    </view>
                </view>

                <!-- 券 / 次卡 / 券包数量全为 0 时显示统一空状态 -->
                <m-empty v-if="stats.couponCount === 0 && stats.cardCount === 0 && stats.bundleCount === 0"
                         :height="280">暂无卡券数据</m-empty>
            </template>
        </template>
    </view>

    <t-popup placement="bottom" :visible="switchVisible" @visible-change="onSwitchPopupChange">
        <view class="popup-container">
            <view class="popup-header">
                <view class="popup-header-title">切换商家</view>
                <view class="popup-header-close">
                    <t-icon name="close" @click="switchVisible = false" :size="20"></t-icon>
                </view>
            </view>
            <scroll-view scroll-y class="popup-body switch-popup-body">
                <view class="container">
                    <m-empty v-if="merchantList.length === 0" :height="240">暂无商家</m-empty>
                    <view
                        v-for="item in merchantList"
                        :key="item.id"
                        class="switch-merchant"
                    >
                        <view class="switch-cover-wrap">
                            <image v-if="item.cover" class="switch-cover" :src="item.cover" mode="aspectFill"/>
                            <view v-else class="switch-cover switch-cover-empty">
                                <t-icon name="shop-1" size="48rpx" color="#ccc"/>
                            </view>
                        </view>
                        <view class="switch-body">
                            <view class="switch-head">
                                <view class="switch-name text-ellipsis">{{ item.name }}</view>
                                <view
                                    v-if="item.authStatus != null"
                                    class="switch-auth"
                                    :class="item.authStatus === AUTH_STATUS.SUCCESS ? 'is-verified' : 'is-unverified'"
                                >
                                    <t-icon name="verified-filled" size="24rpx"/>
                                    <text>{{ item.authStatus === AUTH_STATUS.SUCCESS ? '已认证' : '未认证' }}</text>
                                </view>
                            </view>
                            <view v-if="item.industry" class="switch-tags">
                                <view class="switch-tag">
                                    <view class="switch-tag-dot"></view>
                                    <text>{{ item.industry }}</text>
                                </view>
                            </view>
                            <view v-if="item.address" class="switch-address">
                                <t-icon name="location" size="22rpx" color="#b6b6b6"/>
                                <text class="text-ellipsis">{{ item.address }}</text>
                            </view>
                        </view>
                        <view class="button-gold" @click.stop="onPickMerchant(item)">切换</view>
                    </view>
                </view>
            </scroll-view>
        </view>
    </t-popup>

    <t-popup placement="center" :visible="memberQrcodeVisible" @visible-change="onMemberQrcodePopupChange">
        <view class="member-qrcode-popup">
            <view class="member-qrcode-popup-header">
                <text class="member-qrcode-popup-title">客户码</text>
                <t-icon name="close" size="44rpx" color="#999" @click="memberQrcodeVisible = false"/>
            </view>
            <view class="member-qrcode-popup-body">
                <m-loading v-if="memberQrcodeLoading"></m-loading>
                <template v-else-if="memberQrcode">
                    <image
                        class="member-qrcode-image"
                        :src="memberQrcode"
                        mode="aspectFit"
                        show-menu-by-longpress
                    />
                    <view v-if="memberUserId" class="member-qrcode-userid text-muted text-small" @click="onCopyUserId">
                        客户编码：{{ memberUserId }}
                        <t-icon name="copy" size="32rpx" color="#999" custom-style="margin-left: 8rpx; vertical-align: middle;"/>
                    </view>
                </template>
                <m-empty v-else :height="320">暂无客户码</m-empty>
            </view>
            <view class="member-qrcode-popup-tip text-muted text-small">向商家出示此码识别客户身份</view>
        </view>
    </t-popup>

    <view class="subscribe-gif-wrap" v-if="showSubscribeGif" @click="showSubscribeGif = false">
        <image class="subscribe-gif" src="https://cdn.lenmy.com/quandao/img/subscribe_message.gif" mode="widthFix"/>
    </view>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh, onShareAppMessage} from '@dcloudio/uni-app'
import {computed, ref, watch} from 'vue'
import dayjs from 'dayjs'
import request from '@/hooks/request'
import {COUPON_TYPE, isAmountFace} from '@/constants/coupon'
import {AUTH_STATUS} from '@/constants/merchant'
import {useAuth} from '@/hooks/useAuth'
import {useLink} from '@/hooks/useLink'
import utils from '@/utils/utils'
import config from '@/config'
import to from '@/hooks/to'
import {getThemeStyle} from '@/utils/theme'
import {applyHomeThemeBackground, getHomeThemeColorStyle, getHomeThemeStyle} from '@/utils/homeTheme'

// 本地记住上次选的店；登出时 session.logout 会清除
const HOME_MERCHANT_KEY = 'userHomeMerchantId'
// 商家切换列表分页大小
const LIST_PAGE_SIZE = 50

const {login, isLoggedIn, avatar, nickname} = useAuth()
const {push} = useLink()

// 自定义导航栏样式（避让胶囊）
const navStyle = ref({})
// 首页首屏加载中
const pageLoading = ref(false)
// 首页加载失败
const loadError = ref(false)
// 切换商家弹层是否可见
const switchVisible = ref(false)
// 当前选中的商家 ID
const merchantId = ref('')
// 当前商家详情
const merchant = ref(null)
// 顾客关联的商家列表（切换用）
const merchantList = ref([])
// 本店最新一张可用优惠券
const latestCoupon = ref()
// 本店最新一张使用中次卡
const latestCard = ref()
// 本店最新一个券包
const latestBundle = ref()
// 本店卡包数量与积分余额
const stats = ref({
    couponCount: 0,
    bundleCount: 0,
    cardCount: 0,
    pointBalance: 0,
})
// 会员码弹层是否可见
const memberQrcodeVisible = ref(false)
// 会员码图片
const memberQrcode = ref('')
// 会员码弹层展示的客户编码
const memberUserId = ref('')
// 会员码加载中
const memberQrcodeLoading = ref(false)
// 是否展示订阅消息引导动图
const showSubscribeGif = ref(false)

// 会员卡区域主题样式
const memberCardStyle = computed(() => getHomeThemeStyle(merchant.value?.homeTheme))

// 会员等级徽章主题色
const memberBadgeStyle = computed(() => getHomeThemeColorStyle(merchant.value?.homeTheme))

// 当前顾客在本店的会员等级
const memberLevel = computed(() => merchant.value?.memberLevel || null)

// 门头封面图，无则用默认图
const heroCover = computed(() => merchant.value?.cover || config.default.cover)

// 流量主广告 unit-id（商家版本允许投广告时才返回）
const adUnitHome = computed(() => {
    if (config.adUnit?.couponHome && merchant.value?.allowAd) {
        return config.adUnit.couponHome
    }
    return ''
})

// 当前商家是否已认证
const isMerchantVerified = computed(() => merchant.value?.authStatus === AUTH_STATUS.SUCCESS)

// 比较两个商家 ID 是否同一家（兼容 number / string）
const sameMerchant = (a, b) => String(a || '') === String(b || '')

// 监听主题色变化，同步页面背景
watch(() => merchant.value?.homeTheme, (theme) => {
    applyHomeThemeBackground(theme)
}, {immediate: true})

// 格式化领取时间展示
const formatTime = (t) => {
    if (!t) return ''
    return dayjs(t).format('YYYY-MM-DD HH:mm')
}

// 切换或加载当前店：拉商家详情（数量 + 最新券/卡/包）
const applyMerchant = (id) => {
    merchantId.value = id || ''
    if (!id) {
        merchant.value = null
        stats.value = {couponCount: 0, bundleCount: 0, cardCount: 0, pointBalance: 0}
        latestCoupon.value = null
        latestCard.value = null
        latestBundle.value = null
        return Promise.resolve()
    }
    return request.get('/user/merchant/detail', {id}, {showLoading: false}).then((res) => {
        const data = res.data
        merchant.value = data
        stats.value = {
            couponCount: to.Int(data?.couponCount),
            bundleCount: to.Int(data?.bundleCount),
            cardCount: to.Int(data?.cardCount),
            pointBalance: to.Int(data?.pointBalance),
        }
        latestCoupon.value = data?.latestCoupon || null
        latestCard.value = data?.latestCard || null
        latestBundle.value = data?.latestBundle || null
    }).catch(() => {
        // 详情失败时至少用列表里的商家信息撑门头，资产清空
        merchant.value = merchantList.value.find((item) => sameMerchant(item.id, id)) || null
        stats.value = {couponCount: 0, bundleCount: 0, cardCount: 0, pointBalance: 0}
        latestCoupon.value = null
        latestCard.value = null
        latestBundle.value = null
    })
}

// 加载首页：商家列表 → 定店 → 详情
const loadPage = () => {
    if (!isLoggedIn.value) {
        merchantId.value = ''
        merchant.value = null
        merchantList.value = []
        latestCoupon.value = null
        latestCard.value = null
        latestBundle.value = null
        stats.value = {couponCount: 0, bundleCount: 0, cardCount: 0, pointBalance: 0}
        loadError.value = false
        pageLoading.value = false
        uni.stopPullDownRefresh()
        return
    }
    pageLoading.value = true
    loadError.value = false
    request.get('/user/merchant/list', {
        page: 1,
        pageSize: LIST_PAGE_SIZE
    }, {showLoading: false}).then((merchantsRes) => {
        merchantList.value = to.Array(merchantsRes.data.items)
        // 默认店：本地缓存仍在列表里则用缓存，否则取列表第一项（后端按加入时间倒序）并写入缓存
        const stored = uni.getStorageSync(HOME_MERCHANT_KEY)
        let id = ''
        if (stored && merchantList.value.some((item) => sameMerchant(item.id, stored))) {
            id = stored
        } else if (merchantList.value[0]?.id) {
            id = merchantList.value[0].id
            uni.setStorageSync(HOME_MERCHANT_KEY, id)
        }
        return applyMerchant(id)
    }).catch(() => {
        loadError.value = true
    }).finally(() => {
        pageLoading.value = false
        setTimeout(() => uni.stopPullDownRefresh(), 300)
    })
}

// 加载失败后重试
const onRetry = () => {
    loadPage()
}

// 授权头像昵称后登录并刷新首页
const onGetUserInfoSuccess = (e) => {
    login({
        nickname: e.detail.userInfo.nickName,
        avatar: e.detail.userInfo.avatarUrl,
    }).then(() => {
        loadPage()
    })
}

// 跳转全部优惠券 / 次卡 / 券包列表，带上当前商家
const onStatTap = (path) => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    if (!merchantId.value) {
        utils.toast('请先选择商家')
        return
    }
    const sep = path.includes('?') ? '&' : '?'
    push(path + sep + 'merchantId=' + merchantId.value)
}

// 进入积分明细，尽量先请求积分变动订阅
const onPointTap = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    if (!merchantId.value) {
        utils.toast('请先选择商家')
        return
    }
    const tmplIds = (config.subscribeMessage.pointChange || []).filter(Boolean)
    if (!tmplIds.length) {
        push('/pages_user/point/list?merchantId=' + merchantId.value)
        return
    }
    uni.requestSubscribeMessage({
        tmplIds,
        complete() {
            push('/pages_user/point/list?merchantId=' + merchantId.value)
        }
    })
}

// 打开顾客设置页
const onGoSetting = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    push('/pages_user/setting/index')
}

// 打开切换商家弹层
const onOpenSwitch = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    switchVisible.value = true
}

// 切换商家弹层显隐回调
const onSwitchPopupChange = (e) => {
    const visible = e && typeof e === 'object' ? e.visible : !!e
    switchVisible.value = visible
}

// 选中商家：写本地缓存后重新拉详情
const onPickMerchant = (item) => {
    if (!item?.id) return
    uni.setStorageSync(HOME_MERCHANT_KEY, item.id)
    switchVisible.value = false
    applyMerchant(item.id)
}

// 进入商家主页（领券中心）
const onGoCouponCenter = () => {
    if (!merchantId.value) {
        utils.toast(isLoggedIn.value ? '暂无商家' : '请先登录')
        return
    }
    push('/pages_user/merchant/home?id=' + merchantId.value)
}

// 进入会员权益页
const onGoMemberBenefit = () => {
    if (!merchantId.value) {
        utils.toast(isLoggedIn.value ? '暂无商家' : '请先登录')
        return
    }
    push('/pages_user/merchant/member-benefit?merchantId=' + merchantId.value)
}

// 打开商家地图定位
const onOpenLocation = () => {
    const d = merchant.value
    if (!d) return
    if (d.lat > 0 && d.lng > 0) {
        uni.openLocation({
            latitude: d.lat,
            longitude: d.lng,
            scale: 18,
            name: d.name,
            address: d.address,
            fail: () => {
                uni.showToast({icon: 'none', title: '打开地图失败'})
            },
        })
        return
    }
    uni.showToast({icon: 'none', title: '商家尚未设置地图位置'})
}

// 拨打商家客服电话
const onCallPhone = () => {
    utils.makePhoneCall(merchant.value?.servicePhone, '尚未设置客服电话')
}

// 拉取会员码与客户编码并打开弹层
const loadMemberQrcode = () => {
    memberQrcodeVisible.value = true
    memberQrcode.value = ''
    memberUserId.value = ''
    memberQrcodeLoading.value = true
    request.get('/user/user/qrcode').then((res) => {
        memberQrcode.value = res.data.qrcode || ''
        memberUserId.value = res.data.userId || ''
    }).catch(() => {
        memberQrcodeVisible.value = false
    }).finally(() => {
        memberQrcodeLoading.value = false
    })
}

// 出示会员码，尽量先请求积分变动订阅
const onMemberQrcode = () => {
    if (!isLoggedIn.value) {
        utils.toast('请先登录')
        return
    }
    const tmplIds = (config.subscribeMessage.pointChange || []).filter(Boolean)
    if (!tmplIds.length) {
        loadMemberQrcode()
        return
    }
    uni.requestSubscribeMessage({
        tmplIds,
        complete() {
            loadMemberQrcode()
        }
    })
}

// 会员码弹层显隐回调，关闭时清空码图与编码
const onMemberQrcodePopupChange = (e) => {
    const visible = e && typeof e === 'object' ? e.visible : !!e
    memberQrcodeVisible.value = visible
    if (!visible) {
        memberQrcode.value = ''
        memberUserId.value = ''
    }
}

// 复制客户编码到剪贴板
const onCopyUserId = () => {
    if (!memberUserId.value) return
    utils.copyClipboard(memberUserId.value, '客户编码已复制')
}

// 判断领券订阅模板是否仍有未决定项，决定是否显示引导动图
const willShowSubscribePopup = () => {
    uni.getSetting({
        withSubscriptions: true,
        success(res) {
            const itemSettings = res.subscriptionsSetting
            const hasUndecided = config.subscribeMessage.couponReceive.some(
                (tmplId) => itemSettings[tmplId] !== 'accept' && itemSettings[tmplId] !== 'reject',
            )
            showSubscribeGif.value = hasUndecided
        },
        fail() {
        },
    })
}

// 首页点「使用」：先订阅消息再进券详情
const onUse = utils.debounce((item) => {
    utils.showLoading()
    uni.requestSubscribeMessage({
        tmplIds: config.subscribeMessage.couponReceive,
        complete() {
            utils.hideLoading()
            showSubscribeGif.value = false
            push('/pages_user/coupon/detail?id=' + item.id)
        }
    })
    willShowSubscribePopup()
})

// 按右上角胶囊计算自定义导航栏位置
const initNavStyle = () => {
    try {
        const menu = wx.getMenuButtonBoundingClientRect()
        const sys = uni.getWindowInfo()
        navStyle.value = {
            top: menu.top + 'px',
            height: menu.height + 'px',
            paddingRight: (sys.windowWidth - menu.left + 8) + 'px',
        }
    } catch (e) {
        navStyle.value = {
            top: '48px',
            height: '32px',
            paddingRight: '120px',
        }
    }
}

// 页面加载：初始化导航栏
onLoad(() => {
    initNavStyle()
})

// 每次显示刷新首页数据
onShow(() => {
    loadPage()
})

// 下拉刷新首页
onPullDownRefresh(() => {
    if (!isLoggedIn.value) {
        uni.stopPullDownRefresh()
        return
    }
    loadPage()
})

// 分享给好友
onShareAppMessage(() => {
    return {
        path: '/pages/index/index?source=券到卡包',
        imageUrl: 'https://cdn.lenmy.com/quandao/2026/09/06/daemup1tv0e0b38kr810.jpg',
        title: '再小的店，也能拥有自己的电子卡券小程序。',
    }
})
</script>

<style scoped>
.home-page {
    min-height: 100vh;
    background: #f6f6f6;
    padding-bottom: 24rpx;
}

.hero {
    position: relative;
    width: 100%;
    height: 0;
    /* 门头固定 3:2（宽:高），与商家主页 pages_user/merchant/home 保持一致；*/
    padding-top: 66.666%;
    overflow: hidden;
}

.hero-cover {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    display: block;
    background: #1a3d32;
}

.hero-cover-empty {
    background: linear-gradient(160deg, #0f3d30 0%, #16352c 55%, #0a4b37 100%);
}

.hero-mask {
    position: absolute;
    inset: 0;
    background: rgba(0, 0, 0, 0.42);
}

.hero-nav {
    position: absolute;
    left: 24rpx;
    right: 0;
    z-index: 3;
    display: flex;
    align-items: center;
    justify-content: flex-start;
    box-sizing: content-box;
}

.hero-pill {
    display: flex;
    align-items: center;
    gap: 6rpx;
    height: 56rpx;
    padding: 0 18rpx;
    border-radius: 28rpx;
    background: rgba(0, 0, 0, 0.38);
    color: #fff;
    font-size: 24rpx;
    line-height: 1;
}

.hero-info {
    position: absolute;
    left: 32rpx;
    right: 32rpx;
    bottom: 108rpx;
    z-index: 3;
    color: #fff;
}

.hero-name-row {
    display: flex;
    align-items: center;
    justify-content: flex-start;
    gap: 15px;
    margin-bottom: 24rpx;
}

.member-badge {
    flex-shrink: 0;
    display: inline-flex;
    align-items: center;
    gap: 6rpx;
    height: 36rpx;
    padding: 0 14rpx;
    border-radius: 36rpx;
    background: #0C453D;
    color: #fff;
    font-size: 20rpx;
    line-height: 1;
}

.member-badge-icon {
    width: 22rpx;
    height: 22rpx !important;
    display: block;
}

.hero-name {
    flex: 0 1 auto;
    min-width: 0;
    max-width: 70%;
    font-size: 40rpx;
    font-weight: 700;
    line-height: 1.35;
}

.hero-address {
    display: flex;
    align-items: center;
    gap: 8rpx;
    margin-bottom: 28rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.88);
}

.hero-address text {
    min-width: 0;
}

.hero-tags {
    display: flex;
    flex-direction: row;
    align-items: center;
    flex-wrap: nowrap;
    gap: 16rpx;
}

.hero-tag {
    display: inline-flex;
    align-items: center;
    gap: 8rpx;
    height: 52rpx;
    padding: 0 20rpx;
    border-radius: 26rpx;
    background: rgba(255, 255, 255, 0.2);
    border: 1rpx solid rgba(255, 255, 255, 0.28);
    color: #fff;
    font-size: 24rpx;
    line-height: 1;
}

.member-card {
    position: relative;
    z-index: 4;
    margin: -72rpx 24rpx 8rpx;
    padding: 40rpx 28rpx 0;
    background: linear-gradient(160deg, #0d6754 0%, #0C453D 48%, #04362d 100%);
    border-radius: 24rpx 24rpx 0 0;
    box-sizing: border-box;
}

.member-card-deco {
    position: absolute;
    inset: 0;
    overflow: hidden;
    pointer-events: none;
    border-radius: 24rpx 24rpx 0 0;
}

.member-card-glow {
    position: absolute;
    inset: 0;
    pointer-events: none;
    background: radial-gradient(ellipse 90% 70% at 100% 0%, rgba(255, 255, 255, 0.16) 0%, transparent 52%),
    radial-gradient(ellipse 70% 55% at 0% 100%, rgba(232, 194, 122, 0.1) 0%, transparent 48%);
}

.member-card-orb {
    position: absolute;
    top: -80rpx;
    right: -40rpx;
    width: 220rpx;
    height: 220rpx;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.05);
    pointer-events: none;
}

.user-row,
.stats-row,
.member-wave {
    position: relative;
    z-index: 1;
}

.user-row {
    display: flex;
    align-items: flex-start;
    gap: 16rpx;
}

.user-avatar {
    width: 96rpx;
    height: 96rpx !important;
    border-radius: 50%;
    flex-shrink: 0;
    background: rgba(255, 255, 255, 0.16);
}

.user-main {
    flex: 1;
    min-width: 0;
    padding-top: 6rpx;
}

.user-name-row {
    display: flex;
    align-items: center;
    min-width: 0;
    gap: 12rpx;
}

.user-level-badge {
    flex-shrink: 0;
}

.user-name {
    font-size: 36rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.25;
}

.user-sub {
    margin-top: 10rpx;
    font-size: 24rpx;
    color: #fff;
    line-height: 1.2;
}

.user-actions {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 30rpx;
    padding-top: 8rpx;
}

.user-code {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
}

.stats-row {
    display: flex;
    align-items: stretch;
    margin-top: 40rpx;
    padding-bottom: 12rpx;
}

.stat {
    flex: 1;
    min-width: 0;
    display: flex;
    flex-direction: column;
    align-items: center;
    text-align: center;
}

.stat-head {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8rpx;
}

.stat-icon {
    width: 44rpx;
    height: 44rpx !important;
    display: block;
    flex-shrink: 0;
}

.stat-num {
    font-size: 48rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1;
}

.stat-unit {
    font-size: 28rpx;
    font-weight: 400;
}

.stat-label {
    margin-top: 10rpx;
    font-size: 30rpx;
    color: #fff;
    line-height: 1.2;
}

.stat-link {
    margin-top: 22rpx;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 2rpx;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.55);
    line-height: 1.2;
}

.stat-divider {
    width: 1rpx;
    margin: 16rpx 0 20rpx;
    background: rgba(255, 255, 255, 0.12);
    flex-shrink: 0;
}

.member-wave {
    display: block;
    width: calc(100% + 56rpx);
    height: 72rpx !important;
    margin: 20rpx -28rpx 0;
}

.asset-section {
    margin: 0 24rpx;
}

.asset-section + .asset-section {
    margin-top: 28rpx;
}

.asset-section .section-header {
    padding: 20rpx 0;
}

.asset-section .section-more {
    font-weight: 600;
}

.section-count {
    margin-left: 8rpx;
    font-size: 24rpx;
    font-weight: 600;
    color: #000;
}

.card-wrap {
    border-radius: 24rpx;
    overflow: hidden;
}

.receive {
    border-radius: 24rpx;
    background: #fff;
    position: relative;
    overflow: hidden;
}

.merchant {
    display: flex;
    align-items: center;
    margin-bottom: 10rpx;
    padding: 32rpx 32rpx 10rpx 32rpx;
}

.merchant-logo {
    width: 50rpx;
    height: 50rpx;
    border-radius: 50%;
    margin-right: 10rpx;
    flex-shrink: 0;
}

.merchant-header {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.merchant-header-title {
    flex: 1;
    font-size: 28rpx;
    font-weight: 600;
    color: #373737;
}

.coupon {
    padding: 10rpx 32rpx 32rpx 32rpx;
    display: flex;
    align-items: center;
}

.coupon-header {
    margin-right: 30rpx;
}

.coupon-thumb {
    flex-shrink: 0;
    width: 120rpx;
    height: 120rpx;
    border-radius: 12rpx;
    display: block;
}

.coupon-body {
    position: relative;
    flex: 1;
    min-width: 0;
}

.coupon-content {
    display: flex;
    align-items: center;
    min-width: 0;
}

.coupon-content-info {
    flex: 1;
    min-width: 0;
    padding-right: 12rpx;
}

.coupon-content-name {
    font-size: 32rpx;
    font-weight: 600;
}

.coupon-type {
    color: #999;
    font-size: 20rpx;
}

.coupon-content-value {
    display: flex;
    align-items: baseline;
    line-height: 1.3;
    min-width: 0;
}

.coupon-content-action {
    flex-shrink: 0;
    min-width: 120rpx;
    text-align: right;
}

.coupon-content-amount {
    color: #e84c59;
    display: flex;
    align-items: baseline;
    min-width: 0;
}

.coupon-amount-discount {
    font-size: 28rpx;
    font-weight: 600;
    margin-left: 5rpx;
    flex-shrink: 0;
}

.coupon-amount-money {
    font-size: 48rpx;
    font-weight: 700;
    flex-shrink: 0;
    white-space: nowrap;
}

.exchange-icon {
    width: 68rpx;
    height: 68rpx;
}

.coupon-threshold {
    margin-left: 10rpx;
    font-size: 28rpx;
    color: #b6b6b6;
    flex: 1;
    min-width: 0;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.coupon-content-valid {
    font-size: 28rpx;
    color: #b6b6b6;
    margin-top: 6rpx;
}

.bundle {
    position: relative;
    border-radius: 24rpx;
    padding: 28rpx 28rpx 24rpx;
    overflow: hidden;
    box-shadow: 0 6rpx 24rpx rgba(0, 0, 0, 0.08);
}

.bundle-header {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 16rpx;
}

.bundle-name {
    flex: 1;
    min-width: 0;
    font-size: 34rpx;
    font-weight: 700;
    color: #fff;
    line-height: 1.35;
}

.bundle-merchant-name {
    flex-shrink: 0;
    max-width: 240rpx;
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.62);
    white-space: nowrap;
    padding-top: 6rpx;
}

.bundle-body {
    margin-top: 20rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20rpx;
}

.bundle-count {
    flex: 1;
    min-width: 0;
    display: flex;
    align-items: baseline;
    line-height: 1;
}

.bundle-count-num {
    font-size: 44rpx;
    font-weight: 700;
    color: #fff;
}

.bundle-count-unit {
    margin-left: 4rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.82);
}

.bundle-count-sep {
    margin: 0 8rpx 0 10rpx;
    font-size: 24rpx;
    color: rgba(255, 255, 255, 0.62);
}

.bundle-cover {
    width: 140rpx;
    height: 100rpx;
    border-radius: 12rpx;
    flex-shrink: 0;
    display: block;
    background: rgba(255, 255, 255, 0.12);
}

.bundle-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
}

.bundle-footer {
    margin-top: 22rpx;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16rpx;
}

.bundle-tags {
    display: flex;
    align-items: center;
    gap: 12rpx;
    flex-shrink: 0;
}

.bundle-tag {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.92);
    padding: 4rpx 14rpx;
    border: 1rpx solid rgba(255, 255, 255, 0.4);
    border-radius: 8rpx;
    background: rgba(255, 255, 255, 0.12);
}

.bundle-time {
    font-size: 22rpx;
    color: rgba(255, 255, 255, 0.62);
}

.text-ellipsis-2 {
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 2;
    overflow: hidden;
}

.switch-popup-body {
    background: #f6f6f6;
    padding-top: 8rpx;
    padding-bottom: calc(24rpx + env(safe-area-inset-bottom));
    box-sizing: border-box;
}

.switch-merchant {
    display: flex;
    align-items: center;
    gap: 20rpx;
    margin-bottom: 20rpx;
    padding: 20rpx;
    background: #fff;
    border-radius: 20rpx;
}

.switch-cover-wrap {
    flex-shrink: 0;
}

.switch-cover {
    width: 140rpx;
    height: 140rpx !important;
    border-radius: 16rpx;
    display: block;
    background: #f2f2f2;
}

.switch-cover-empty {
    display: flex;
    align-items: center;
    justify-content: center;
    background: linear-gradient(135deg, #fafafa 0%, #f0f0f0 100%);
}

.switch-body {
    flex: 1;
    min-width: 0;
}

.switch-head {
    display: flex;
    align-items: center;
    gap: 15px;
    min-width: 0;
}

.switch-name {
    flex: 0 1 auto;
    min-width: 0;
    font-size: 30rpx;
    font-weight: 600;
    color: #181818;
    line-height: 1.4;
}

.switch-auth {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    gap: 4rpx;
    font-size: 22rpx;
    line-height: 1;
}

.switch-auth.is-verified {
    color: #07c160;
}

.switch-auth.is-unverified {
    color: #b6b6b6;
}

.switch-tags {
    display: flex;
    flex-wrap: wrap;
    gap: 12rpx;
    margin-top: 12rpx;
}

.switch-tag {
    display: inline-flex;
    align-items: center;
    gap: 8rpx;
    padding: 4rpx 14rpx 4rpx 12rpx;
    border-radius: 8rpx;
    background: rgba(232, 76, 89, 0.06);
    color: #e84c59;
    font-size: 22rpx;
    line-height: 1.5;
}

.switch-tag-dot {
    width: 8rpx;
    height: 8rpx;
    border-radius: 50%;
    background: #e84c59;
    box-shadow: 0 0 0 3rpx rgba(232, 76, 89, 0.12);
}

.switch-address {
    display: flex;
    align-items: center;
    margin-top: 12rpx;
    font-size: 22rpx;
    color: #999;
}

.switch-address text {
    margin-left: 6rpx;
    min-width: 0;
}

.switch-merchant .button-gold {
    flex-shrink: 0;
}

.member-qrcode-popup {
    width: 600rpx;
    background: #fff;
    border-radius: 24rpx;
    padding: 32rpx;
    box-sizing: border-box;
}

.member-qrcode-popup-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    margin-bottom: 24rpx;
}

.member-qrcode-popup-title {
    font-size: 32rpx;
    font-weight: 600;
    color: #333;
}

.member-qrcode-popup-body {
    min-height: 400rpx;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
}

.member-qrcode-image {
    width: 400rpx;
    height: 400rpx;
}

.member-qrcode-userid {
    margin-top: 24rpx;
    display: flex;
    align-items: center;
    justify-content: center;
}

.member-qrcode-popup-tip {
    text-align: center;
    margin-top: 24rpx;
}

.subscribe-gif-wrap {
    position: fixed;
    top: 25vh;
    right: 0;
    left: 0;
    z-index: 9999;
    display: flex;
    align-items: center;
    justify-content: center;
}

.subscribe-gif {
    width: 600rpx;
    border-radius: 16rpx;
}
</style>
