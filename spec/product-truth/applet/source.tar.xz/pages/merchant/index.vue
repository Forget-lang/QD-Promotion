<template>
    <t-navbar t-class="merchant-navbar">
        <template #left>
            <view v-if="isEntry" class="nav-switch" @click="push('/pages/merchant/select')">
                <t-icon custom-style="margin-right: 6rpx;" name="swap" size="32rpx" color="currentColor"/>
                <text style="color: white;">切换商家</text>
            </view>
        </template>
    </t-navbar>

    <template v-if="isEntry">
        <!-- 如果已选中商户 -->
        <!-- 头部 -->
        <view class="header-container" :style="{ paddingTop: navHeight + 'px' }">
            <view class="shop-wrap">
                <view class="shop-header">
                    <image class="shop-logo" :src="home.merchantLogo" mode="aspectFill"></image>
                </view>
                <view class="shop-body">
                    <view class="shop-information">
                        <view class="shop-name-row">
                            <text class="shop-name">{{ home.storeName }}</text>
                            <!-- 版本标牌图（图内自带版本名），点击打开续费/开通弹窗 -->
                            <image
                                v-if="editionIcon"
                                class="shop-edition-icon"
                                :src="editionIcon"
                                mode="aspectFit"
                                @click.stop="openVipUpgrade"
                            />
                            <text
                                v-else-if="editionName"
                                class="shop-edition-name"
                                @click.stop="openVipUpgrade"
                            >{{ editionName }}
                            </text>
                            <!-- 免费版：版本图标右侧引导升级 -->
                            <text
                                v-if="isFreeEdition"
                                class="shop-edition-upgrade"
                                @click.stop="openVipUpgrade"
                            >升级VIP
                            </text>
                        </view>
                        <view class="shop-state-tags">
                            <view class="staff-info">
                                <text @click="onShowLogoutSheet">{{ home.staffName }}</text>
                                <text class="divider" v-if="home.roleName">|</text>
                                <text class="role-name">{{ home.roleName }}</text>
                                <text class="tag-danger ml-2" v-if="home.merchantStatus === 0">已冻结</text>
                            </view>
                        </view>
                    </view>
                    <view class="shop-message">
                        <view class="widget-button widget-button-badge" @click="onOpenStaffInbox">
                            <t-badge :count="staffInboxUnreadCount" :max-count="99">
                                <t-icon name="notification" :size="18" color="#666"></t-icon>
                            </t-badge>
                        </view>
                    </view>
                </view>
            </view>
            <!-- 商家数据统计 -->
            <view class="shop-static">
                <view class="static-item">
                    <view class="static-title">
                        <view class="d-flex align-items-center">今日领券</view>
                    </view>
                    <text class="static-number">{{ home.todayCouponReceiveCount }}</text>
                    <text class="static-number-yesterday">昨日：{{ home.yesterdayCouponReceiveCount }}</text>
                </view>
                <view class="static-item">
                    <view class="static-title">
                        <view class="d-flex align-items-center">今日核券</view>
                    </view>
                    <text class="static-number">{{ home.todayCouponVerifyCount }}</text>
                    <text class="static-number-yesterday">昨日：{{ home.yesterdayCouponVerifyCount }}</text>
                </view>
                <view class="static-item">
                    <view class="static-title">
                        <view class="d-flex align-items-center">今日领卡</view>
                    </view>
                    <text class="static-number">{{ home.todayCardReceiveCount }}</text>
                    <text class="static-number-yesterday">昨日：{{ home.yesterdayCardReceiveCount }}</text>
                </view>
                <view class="static-item">
                    <view class="static-title">
                        <view class="d-flex align-items-center">今日核卡</view>
                    </view>
                    <text class="static-number">{{ home.todayCardVerifyCount }}</text>
                    <text class="static-number-yesterday">昨日：{{ home.yesterdayCardVerifyCount }}</text>
                </view>
            </view>
        </view>
        <!-- /头部 -->

        <!-- 常用操作 -->
        <view class="operation-container">
            <t-grid :column="4" hover theme="card">
                <t-grid-item v-if="checkPermission(PERM_COUPON.VERIFY) || checkPermission(PERM_CARD.VERIFY)" @click="onScan">
                    <view class="menu-item">
                        <image class="menu-item-icon menu-item-icon-large" src="@/static/img/3-scan.png"></image>
                        <text class="menu-item-label">扫码核销</text>
                    </view>
                </t-grid-item>
                <t-grid-item
                    v-if="checkPermission(PERM_COUPON.CREATE) || checkPermission(PERM_BUNDLE.CREATE) || checkPermission(PERM_CARD.CREATE)">
                    <view class="menu-item" @tap="onShowCreateSheet">
                        <image class="menu-item-icon menu-item-icon-large" src="@/static/img/3-add.png"></image>
                        <text class="menu-item-label">制作卡券</text>
                    </view>
                </t-grid-item>
                <t-grid-item v-if="checkPermission(PERM_COUPON.VERIFY)" url="/pages_assist/position/play">
                    <view class="menu-item">
                        <image class="menu-item-icon menu-item-icon-large" src="@/static/img/3-good.png"></image>
                        <text class="menu-item-label">获客玩法</text>
                    </view>
                </t-grid-item>
                <t-grid-item @click="push('/pages_assist/help/index')">
                    <view class="menu-item">
                        <image class="menu-item-icon menu-item-icon-large" src="@/static/img/3-help.png"></image>
                        <text class="menu-item-label">使用教程</text>
                    </view>
                </t-grid-item>

            </t-grid>
        </view>
        <!-- /常用操作 -->


        <!-- 待办与消息提醒 -->
        <t-cell-group t-class="mt-2" theme="card" v-if="showNoticeGroup">
            <t-cell v-if="showPendingStaff"
                    title="员工加入申请" left-icon="usergroup-add" arrow hover jump-type="navigateTo"
                    url="/pages_merchant/staff/pending">
                <template #note>
                    <t-badge :count="home.pendingStaffCount" style="display: inline-flex;"/>
                </template>
            </t-cell>
            <t-cell v-if="showStaffInbox" title="站内消息" left-icon="notification" arrow hover
                    @click="onOpenStaffInbox">
                <template #note>
                    <t-badge :count="staffInboxUnreadCount" :max-count="99" style="display: inline-flex;"/>
                </template>
            </t-cell>
        </t-cell-group>


        <!-- 功能菜单 -->
        <t-grid :column="4" hover t-class="mt-2" theme="card">
            <t-grid-item v-if="checkPermission(PERM_MODULE.COUPON)" url="/pages_coupon/coupon/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-coupon.png"></image>
                    <text class="menu-item-label">优惠券</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.BUNDLE)" url="/pages_bundle/bundle/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-wallet.png"></image>
                    <text class="menu-item-label">券包</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.CARD)" url="/pages_card/card/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-card.png"></image>
                    <text class="menu-item-label">次卡</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.POINT)" url="/pages_point/point/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-point.png"></image>
                    <text class="menu-item-label">积分</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.ACTIVITY_POSTER)" url="/pages_activity/activity/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-page.png"></image>
                    <text class="menu-item-label">活动海报</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.CUSTOMER)" url="/pages_merchant/customer/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-member.png"></image>
                    <text class="menu-item-label">客户管理</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.MERCHANT)" url="/pages_merchant/homepage/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-homepage.png"></image>
                    <text class="menu-item-label">商家主页</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.STORE)" url="/pages_merchant/store/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-store.png"></image>
                    <text class="menu-item-label">门店管理</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.STAFF)" url="/pages_merchant/staff/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-staff.png"></image>
                    <text class="menu-item-label">员工管理</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_MODULE.MERCHANT)" url="/pages_merchant/setting/index">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-setting.png"></image>
                    <text class="menu-item-label">商家设置</text>
                </view>
            </t-grid-item>
        </t-grid>
        <!-- /功能菜单 -->

        <!-- 服务菜单 -->
        <t-grid :column="4" hover t-class="mt-2" theme="card">
            <t-grid-item v-if="checkPermission(PERM_MODULE.MERCHANT)" @click="openVipUpgrade">
                <view class="menu-item">
                    <image class="menu-item-icon" src="@/static/img/3-vip.png"></image>
                    <text class="menu-item-label">升级VIP</text>
                </view>
            </t-grid-item>
            <t-grid-item v-if="checkPermission(PERM_COUPON.VERIFY)" url="/pages_coupon/verify/verify">
                <view class="menu-item">
                    <image class="menu-item-icon menu-item-icon-large" src="@/static/img/3-search.png"></image>
                    <text class="menu-item-label">券码查询</text>
                </view>
            </t-grid-item>
            <t-grid-item>
                <view class="menu-item" @tap="utils.openCustomerService()">
                    <image class="menu-item-icon" src="@/static/img/3-service.png"></image>
                    <text class="menu-item-label">联系客服</text>
                </view>
            </t-grid-item>
            <t-grid-item>
                <!-- 整个菜单项都包在分享按钮内，点击图标或文字均可触发转发 -->
                <t-button block openType="share" variant="text"
                          custom-style="width:100%; height:auto; min-height:0; padding:0; margin:0; background:transparent; border:none; line-height:normal; color:#333333; font-size:28rpx; font-weight:normal;">
                    <view class="menu-item">
                        <image class="menu-item-icon" src="@/static/img/3-share.png"></image>
                        <text class="menu-item-label">推荐给好友</text>
                    </view>
                </t-button>
            </t-grid-item>
        </t-grid>
        <!-- /服务菜单 -->
    </template>
    <!-- /选择了商户 -->

    <!-- 如果未选中商户 -->
    <template v-if="!isEntry">
        <!-- 头部 -->
        <view class="dashboard-container" :style="{ paddingTop: navHeight + 'px' }">
            <!-- 未登录 -->
            <template>
                <view class="d-flex justify-content-center mt-3 mb-3">
                    <image style="width:240rpx" src="https://cdn.lenmy.com/quandao/2026/07/06/d95kstlb4ek0s9ruhngg.png"
                           mode="widthFix"></image>
                </view>
                <view class="d-flex justify-content-center mt-4">
                    <template v-if="!isLoggedIn">
                        <get-user-info @success="onGetUserInfoSuccess" @fail="onGetUserInfoFail">
                            <view class="button-main">
                                <t-icon name="add-circle-filled" size="42rpx" color="#d82311"></t-icon>
                                <text class="ml-1">免费制作卡券</text>
                            </view>
                        </get-user-info>
                    </template>
                    <template v-else>
                        <!-- 已经登录，账户没有门店 -->
                        <view class="button-main" v-if="merchantCount <= 0" @click="push('/pages/merchant/create')">
                            <t-icon name="add-circle-filled" size="42rpx" color="#d82311"></t-icon>
                            <text class="ml-1">创建商户</text>
                        </view>

                        <!-- 已经登录，账户有门店，则去选择商户 -->
                        <view class="button-main" v-if="merchantCount > 0" @click="push('/pages/merchant/select')">
                            <t-icon name="swap" size="42rpx" color="#d82311"></t-icon>
                            <text class="ml-1">选择门店</text>
                        </view>
                    </template>
                </view>
            </template>
        </view>
        <view class="container operation-container">
            <m-position :id="POSITION_ID.MERCHANT_HOME"/>
        </view>
    </template>
    <!-- / 未选择商户 -->

    <t-action-sheet ref="sheetRef" @selected="onLogoutAction"></t-action-sheet>
    <t-action-sheet ref="createSheetRef" @selected="onCreateAction"></t-action-sheet>

    <m-footer :system-id="2"></m-footer>

    <!-- VIP 升级抽屉：App.vue 不能挂视图，须挂在业务页；打开走 useVipGuard / 事件 -->
    <m-vip-upgrade/>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh, onShareAppMessage} from '@dcloudio/uni-app'
import {ref, computed, watch} from 'vue'
import request from "@/hooks/request.js"
import config from "@/config.js"
import {useAuth} from "@/hooks/useAuth.js"
import {PERM_MODULE, PERM_COUPON, PERM_CARD, PERM_BUNDLE, PERM_STORE, PERM_CUSTOMER} from "@/constants/permission.js"
import {useLink} from "@/hooks/useLink.js"
import {useSessionStore} from '@/stores/session.js'
import {POSITION_ID} from "@/constants/common.js"
import {STAFF_STATUS} from "@/constants/merchant.js"
import utils from '@/utils/utils'
import to from '@/hooks/to.js'
import {ActionSheetPlugin, ActionSheetTheme} from "@/uni_modules/tdesign-uniapp/components";
import {EDITION_ID_FREE} from '@/constants/edition'
import {useVipGuard} from '@/hooks/useVipGuard'

const {
    login,
    isLoggedIn,
    merchantCount,
    isEntry,
    checkPermission,
    getAccount,
    setMerchant,
    nickname,
    avatar,
    logout
} = useAuth();
const {
    push
} = useLink();
const {open: openVipUpgrade} = useVipGuard()

const sessionStore = useSessionStore()

const navHeight = ref(0)
const home = ref({})

// 商家版本名称（仅图标缺失时兜底显示）
const editionName = computed(() => home.value.editionName || '')
// 商家版本图标（标牌图，图内自带版本名）
const editionIcon = computed(() => home.value.editionIcon || '')
// 是否免费版（免费版才展示「升级版本」标签）
const isFreeEdition = computed(() => String(home.value.editionId || '') === String(EDITION_ID_FREE))
// 站内信未读消息数
const staffInboxUnreadCount = ref(0)
// 退出登录操作面板实例
const sheetRef = ref(null)
// 制作卡券操作面板实例
const createSheetRef = ref(null)

// 员工加入申请 cell 是否展示（有审核权限且存在待审批申请）
const showPendingStaff = computed(() =>
    checkPermission(PERM_STORE.UPDATE) && home.value.isAuditStaffPermission && to.Int(home.value.pendingStaffCount) > 0
)

// 站内消息 cell 是否展示（存在未读消息）
const showStaffInbox = computed(() => to.Int(staffInboxUnreadCount.value) > 0)

// 待办与消息提醒卡片是否展示（两类提醒均无时整卡片隐藏）
const showNoticeGroup = computed(() => showPendingStaff.value || showStaffInbox.value)

// 获取站内信未读消息,关闭了错误提示
const getStaffInboxUnreadCount = () => {
    request.get('/seller/staff/inbox/unread/count', {}, {
        showLoading: false,
        disableErrorToast: true
    }).then((res) => {
        staffInboxUnreadCount.value = res.data?.count || 0
    }).catch(() => {
        staffInboxUnreadCount.value = 0
    })
}

// 打开站内信
const onOpenStaffInbox = () => {
    const staffInboxPath = '/pages_merchant/staff_inbox/list'
    const tmplIds = config.subscribeMessage.sellerMessage
    uni.requestSubscribeMessage({
        tmplIds,
        complete() {
            push(staffInboxPath)
        }
    })
}

// 用户授权成功事件
const onGetUserInfoSuccess = async (e) => {
    utils.showLoading()
    login({
        nickname: e.detail.userInfo.nickName,
        avatar: e.detail.userInfo.avatarUrl
    }).finally(() =>
        utils.hideLoading()
    )
}

// 用户一键授权失败事件
const onGetUserInfoFail = (e) => {

}

// 获取首页数据
const getHome = () => {
    request.get('/seller/merchant/get-home', {}, {
        showLoading: false
    }).then(res => {
        home.value = res.data
        // 同步更新最新的权限列表到 session
        if (res.data.permissions) {
            sessionStore.setPermissions(res.data.permissions)
        }
    })
}

const onStatClick = (perm, path) => {
    if (!checkPermission(perm)) {
        utils.toast('暂无权限')
        return
    }
    push(path)
}

const onShowLogoutSheet = () => {
    ActionSheetPlugin.show({
        theme: ActionSheetTheme.List,
        selector: '#sheetRef',
        context: this,
        description: '退出登录会清除您的登录信息，确认退出吗？',
        items: [
            {
                label: '退出登录',
                color: '#E3302D',
            },
        ],
    })
}

const onLogoutAction = (e) => {
    if (e.index === 0) {
        logout()
    }
}

const createSheetItems = ref([])

const onShowCreateSheet = () => {
    const items = []
    if (checkPermission(PERM_COUPON.CREATE)) {
        items.push({label: '制作优惠券', path: '/pages_coupon/coupon/choose_type'})
    }
    if (checkPermission(PERM_BUNDLE.CREATE)) {
        items.push({label: '制作券包', path: '/pages_bundle/bundle/create'})
    }
    if (checkPermission(PERM_CARD.CREATE)) {
        items.push({label: '制作次卡', path: '/pages_card/card/choose_type'})
    }
    if (items.length === 0) {
        utils.toast('暂无制作权限')
        return
    }
    createSheetItems.value = items
    ActionSheetPlugin.show({
        theme: ActionSheetTheme.List,
        selector: '#createSheetRef',
        context: this,
        items: items.map(({label}) => ({label})),
    })
}

const onCreateAction = (e) => {
    const item = createSheetItems.value[e.index]
    if (item?.path) {
        push(item.path)
    }
}

// 自动选择唯一门店
const autoSelectSingleMerchant = () => {
    if (!isLoggedIn.value || isEntry.value) return
    if (merchantCount.value !== 1) return

    request.get('/user/merchants', {}, {showLoading: false}).then(res => {
        if (res.data.items && res.data.items.length === 1) {
            const merchant = res.data.items[0]
            if (merchant.staffStatus === STAFF_STATUS.PENDING) {
                utils.toast('请等待管理员确认')
                return
            }
            if (merchant.staffStatus === STAFF_STATUS.LEAVED) {
                utils.toast('您的账号已离职')
                return
            }
            if (merchant.staffStatus === STAFF_STATUS.LOCKED) {
                utils.toast('您的账号已被冻结')
                return
            }
            setMerchant({
                merchantId: merchant.merchantId,
                merchantName: merchant.merchantName,
                merchantLogo: merchant.merchantLogo,
                permissions: merchant.permissions
            })
            // 清除卡券草稿
            sessionStore.clearTempCoupon()
            // 重新加载首页数据
            getHome()
            getStaffInboxUnreadCount()
        }
    }).catch(() => {
        // 静默失败，不影响用户操作
    })
}

//扫码核销 / 扫客户码跳转
const onScan = () => {
    if (!isLoggedIn.value) {
        return
    }
    if (!checkPermission(PERM_COUPON.VERIFY) && !checkPermission(PERM_CARD.VERIFY)) {
        return;
    }
    uni.scanCode({
        success: (res) => {
            console.log('扫码成功：', res)
            // 扫码结果路径（小程序码可能不带前导斜杠）
            const path = to.String(res.path)
            if (path.includes('/verify')) {
                // 核销码：次卡码校验次卡核销权限，其余按优惠券核销权限校验
                const perm = path.includes('/pages_card/') ? PERM_CARD.VERIFY : PERM_COUPON.VERIFY
                if (!checkPermission(perm)) {
                    utils.toast('暂无核销权限')
                    return
                }
            } else if (path.includes('/customer/detail')) {
                // 客户码：需要客户详情权限
                if (!checkPermission(PERM_CUSTOMER.DETAIL)) {
                    utils.toast('暂无客户详情权限')
                    return
                }
            } else {
                utils.toast('请提供正确的核销码')
                return
            }
            // 小程序码路径可能不带前导斜杠，补齐后再跳转
            push(path.startsWith('/') ? path : '/' + path)
        },
        fail: (err) => {
            console.log('扫码失败：', err)
            if (err.errMsg !== 'scanCode:fail cancel') {
                utils.toast(err.errMsg)
            }
        }
    })
}

// 监听 merchantCount 变化，当变为 1 时自动选择门店
watch(merchantCount, (newVal) => {
    console.log('merchantCount', newVal)
    if (newVal === 1) {
        autoSelectSingleMerchant()
    }
}, {immediate: false})

const MERCHANT_SOURCE_KEY = 'merchant_source'

onLoad((query) => {
    navHeight.value = utils.getNavBarHeight()
    if (query?.source) {
        uni.setStorageSync(MERCHANT_SOURCE_KEY, decodeURIComponent(query.source))
    }
})

onShow(() => {
    if (isEntry.value) {
        getHome()
        getStaffInboxUnreadCount()
    } else {
        if (isLoggedIn.value) {
            getAccount()
        }
    }
})

onPullDownRefresh(() => {
    if (isEntry.value) {
        getHome()
        getStaffInboxUnreadCount()
    } else {
        if (isLoggedIn.value) {
            getAccount()
        }
    }
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})

onShareAppMessage(() => {
    let source = '券到卡包'
    var share = {
        path: '/pages/merchant/index?source=' + source,
        imageUrl: 'https://cdn.lenmy.com/quandao/2026/09/06/daemup1tv0e0b38kr810.jpg',
        title: '再小的店，也能拥有自己的电子卡券小程序。',
    };
    return share
})

</script>
<style scoped>
.me-avatar image {
    width: 100%;
    border-radius: 100%;
    border: #fff 2px solid;
}

.nav-switch {
    width: 160rpx;
    height: 60rpx;
    line-height: 60rpx;
    border-radius: 30rpx;
    font-size: 24rpx;
    color: #FFFFFF;
    background-color: rgba(255, 255, 255, 0.12);
    display: flex;
    align-items: center;
    justify-content: center;
    transition: all 0.25s ease;
}

.nav-switch:active {
    transform: scale(0.95);
    opacity: 0.9;
}

/** #e2453d **/
.header-container {
    color: #fff;
    /*
     * 自定义渐变原因：纯平红底显得单薄，微渐变 + 右上光斑增加层次感。
     * 基于品牌红 #e2453d 派生，TDesign / app.css 无等价能力。
     */
    background:
        radial-gradient(ellipse 65% 45% at 100% 0%, rgba(255, 255, 255, 0.14) 0%, transparent 62%),
        linear-gradient(168deg, #ef5148 0%, #e2453d 55%, #d03a33 100%);
    padding: 0 20rpx 120rpx;
}

.dashboard-container {
    color: #fff;
    background: #e2453d url("https://cdn.lenmy.com/quandao/2026/07/06/d95l19db4ek0s9ruhnh0.jpg") no-repeat;
    background-size: cover;
    padding: 0 20rpx 120rpx;
}


.shop-wrap {
    padding: 20rpx;
    display: flex;
    align-items: flex-start;
}

.shop-body {
    flex: 1;
    display: flex;
    justify-content: space-between;
}

.shop-header {
    flex-shrink: 0;
    position: relative;
    width: 84rpx;
    height: 84rpx;
    margin-right: 20rpx;
}

.shop-name-row {
    display: flex;
    align-items: center;
    min-width: 0;
}

/*
 * 版本标牌图：原图 1500x600（2.5:1）
 * 显示尺寸按原始等比放大：110x44rpx，牌内文字与店号字号协调。
 */
.shop-edition-icon {
    flex-shrink: 0;
    display: block;
    width: 110rpx;
    height: 44rpx;
    margin-left: 12rpx;
}

/* 图标缺失时兜底显示的版本名文字 */
.shop-edition-name {
    flex-shrink: 0;
    margin-left: 14rpx;
    font-size: 24rpx;
    font-weight: 600;
    color: #ffe3b8;
}

/* 免费版升级引导：圆角小标签 */
.shop-edition-upgrade {
    flex-shrink: 0;
    margin-left: 10rpx;
    padding: 2rpx 12rpx;
    border-radius: 8rpx;
    font-size: 20rpx;
    line-height: 1.4;
    color: #fff;
    background-color: #c93a32;
}

.shop-logo {
    width: 100%;
    height: 100%;
    border-radius: 16rpx;
}

.shop-information {
    display: flex;
    flex-direction: column;
    flex: 1;
    min-width: 0;
}

.divider {
    color: rgba(255, 255, 255, 0.55);
    font-size: 24rpx;
    padding: 0 12rpx;
}

.role-name {
    font-size: 24rpx;
}

.shop-name {
    font-size: 32rpx;
    font-weight: 600;
    word-break: break-all;
    overflow: hidden;
    display: -webkit-box;
    -webkit-box-orient: vertical;
    -webkit-line-clamp: 1;
    line-height: 1.3;
}

.shop-state-tags {
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 24rpx;
    height: 36rpx;
    margin-top: 12rpx;
}

.staff-info {
    display: flex;
    align-items: center;
}

.shop-tag-item {
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 0 10rpx;
    border-radius: 6rpx;
    background-color: #FFFFFF;
    color: #666666;
    font-size: 24rpx;
    margin-left: 20rpx;
    height: 36rpx;
    line-height: 36rpx;
}

.shop-message {
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    padding: 10rpx;
}

.widget-button {
    display: flex;
    align-items: center;
    justify-content: center;
    height: 60rpx;
    width: 60rpx;
    border-radius: 16rpx;
    background-color: #fff;
    margin-left: 16rpx;
    box-shadow: 0 2rpx 8rpx rgba(0, 0, 0, 0.04);
    transition: all 0.2s;
}

.widget-button:active {
    transform: scale(0.95);
    box-shadow: 0 1rpx 4rpx rgba(0, 0, 0, 0.08);
}

.shop-static {
    margin-top: 30rpx;
    display: flex;
    align-items: center;
    justify-content: space-around;
}

.static-item {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    font-size: 28rpx;
    padding: 0 8rpx;
}

.static-title {
    display: flex;
    align-items: center;
    opacity: 0.85;
    font-size: 24rpx;
}

.static-number {
    font-size: 42rpx;
    letter-spacing: 1px;
    font-weight: 600;
    color: #FFFFFF;
    margin: 10rpx 0;
}

.static-number-yesterday {
    opacity: 0.6;
    font-size: 24rpx;
}

.operation-container {
    margin-top: -80rpx;
}

.menu-item {
    flex: 1;
    display: flex;
    flex-direction: column;
    align-items: center;
    transition: all 0.2s ease;
}

.menu-item-icon {
    text-align: center;
    vertical-align: middle;
    width: 60rpx;
    height: 60rpx;
}

.menu-item:hover .menu-item-icon {
    width: 60rpx;
    height: 60rpx;
}

.menu-item-icon-large {
    width: 60rpx;
    height: 60rpx;
}

.menu-item-label {
    display: block;
    text-align: center;
    color: #333333;
    font-size: 28rpx;
    white-space: nowrap;
    margin-top: 12rpx;
}

/****** 未登录样式 ******/
.button-main {
    display: flex;
    align-items: center;
    background: #fff;
    padding: 30rpx 100rpx;
    border-radius: 50rpx;
    color: #d82311;
    font-weight: bold;
    font-size: 32rpx;
}

</style>
