<template>
    <m-loading v-if="merchants === undefined"></m-loading>
    <template v-else>
        <m-empty v-if="merchants.length === 0">暂未加入商家</m-empty>
        <view v-else class="container container-safety">
            <view class="section mt-2 p-3" v-for="(item, index) in merchants" :key="index">
                <view class="shop-wrap">
                    <view class="logo-wrap">
                        <image class="shop-logo" :src="item.storeLogo" mode="aspectFill"></image>
                    </view>
                    <view class="shop-body">
                        <view class="shop-information">
                            <text class="merchant-name ellipsis-basic">{{ item.storeName }}</text>
                            <view v-if="item.merchantStatus !== STATUS.NORMAL" class="shop-state-tags pb-1">
                                <text class="role-name text-danger">已停用</text>
                            </view>
                            <view class="shop-state-tags">
                                <view class="staff-info">
                                    <text>{{ item.staffName }}</text>
                                    <text class="divider">|</text>
                                    <text class="role-name">{{ item.roleName }}</text>
                                </view>
                            </view>
                        </view>
                        <view class="operation flex-shrink">
                            <t-button :disabled="loading || item.merchantStatus !== STATUS.NORMAL" theme="danger" shape="round"
                                      custom-style="width: 120rpx; height: 50rpx; font-size: 24rpx;" @click="onChange(item)">进入
                            </t-button>
                        </view>
                    </view>
                </view>
            </view>
        </view>
        <m-submit v-if="createdCount === 0" @click="push('/pages/merchant/create')">创建商家</m-submit>
    </template>
</template>

<script setup>
import {onLoad, onShow, onPullDownRefresh} from '@dcloudio/uni-app'
import {ref} from 'vue';
import {useSessionStore} from '@/stores/session';
import request from '@/hooks/request';
import {useLink} from "@/hooks/useLink.js"
import utils from '@/utils/utils';
import to from "@/hooks/to";
import {STAFF_STATUS, STATUS} from "@/constants/merchant";

const {push, switchTab} = useLink();
const sessionStore = useSessionStore()

const merchants = ref()
const createdCount = ref()
const loading = ref(false)

const getMerchants = () => {
    request.get('/user/merchants', {}, {showLoading: false}).then(res => {
        try {
            merchants.value = to.Array(res.data.items)
            createdCount.value = res.data.createdCount
        } catch (err) {
            console.error('parse merchants failed', err)
            wx.reportEvent('biz_error', {
                level: '8',
                message: err.message || '',
                trace_id: err.traceId || '',
            })
            merchants.value = []
        }

    }).catch(() => {
        merchants.value = []
    })
}

const onChange = (item) => {
    if (item.merchantStatus !== STATUS.NORMAL) {
        utils.alert('当前商户已停用')
        return
    }
    if (item.staffStatus === STAFF_STATUS.PENDING) {
        utils.alert('请等待管理员确认')
        return
    }
    if (item.staffStatus === STAFF_STATUS.LEAVED) {
        utils.alert('您的账号已离职')
        return
    }
    if (item.staffStatus === STAFF_STATUS.LOCKED) {
        utils.alert('您的账号已被冻结')
        return
    }
    sessionStore.setMerchant({
        merchantId: item.merchantId,
        merchantName: item.merchantName,
        merchantLogo: item.merchantLogo,
        permissions: item.permissions
    })
    //切换商家清除卡券草稿
    sessionStore.clearTempCoupon()
    loading.value = true
    setTimeout(() => {
        switchTab('/pages/merchant/index')
    }, 800)
}

onLoad(() => {

})

onShow(() => {
    loading.value = false
    getMerchants()
})

onPullDownRefresh(() => {
    getMerchants()
    setTimeout(() => {
        uni.stopPullDownRefresh()
    }, 500)
})
</script>

<style scoped>
.shop-wrap {
    display: flex;
    color: #666;
    font-size: 24rpx;
}

.shop-body {
    flex: 1;
    display: flex;
    justify-content: space-between;
    align-items: center;
}

.logo-wrap {
    flex-shrink: 0;
    position: relative;
    width: 112rpx;
    height: 112rpx;
    margin-right: 20rpx;
}

.shop-logo {
    width: 100%;
    height: 100%;
    border-radius: 16rpx;
}

.shop-information {
    display: flex;
    flex-direction: column;
    justify-content: space-between;
    margin-right: 30rpx;
    flex: 1;
}

.divider {
    opacity: 0.8;
    padding: 0 16rpx;
}

.merchant-name {
    font-size: 32rpx;
    font-weight: 600;
    color: #000;
    margin-bottom: 10rpx;
}

.shop-state-tags {
    display: flex;
    align-items: center;
    justify-content: space-between;
}

.staff-info {
    display: flex;
    align-items: center;
}

</style>