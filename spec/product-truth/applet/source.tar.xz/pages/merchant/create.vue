<template>
	<m-result v-if="isSuccess" type="success" title="创建成功" description="立刻制作投入门店营销" confirmText="进入商家中心" cancelText="返回" @confirm="reLaunch('/pages/merchant/select')" @cancel="back()"></m-result>
	<view v-else>

        <!-- 企业微信绑定信息 -->
        <view v-if="hasWecomBind" class="container">
            <view class="section wecom-bind-card mt-2">
                <view class="wecom-bind-header">
                    <t-icon name="check-circle-filled" size="40rpx" color="#07C160"/>
                    <text class="wecom-bind-title">企业微信已授权</text>
                </view>
                <view class="wecom-bind-body">
                    <view class="corp-id-row">
                        <text class="corp-id-label">企业名称</text>
                        <text class="corp-id-value">{{ corpName }}</text>
                    </view>
                    <t-divider/>
                    <view class="corp-id-row">
                        <text class="corp-id-label">Corp ID</text>
                        <text class="corp-id-value">{{ corpId }}</text>
                    </view>
                </view>
            </view>
        </view>

		<view class="container">
			<view class="section mt-2">
                <m-cover v-model:value="form.cover" emitName="merchantCreatCover" scene="createMerchant"></m-cover>
			</view>
		</view>
		
		<t-cell-group t-class="mt-2" theme="card">
			<t-input label="商家名称" v-model:value="form.name" borderless placeholder="请输入营业执照商户简称" align="right"></t-input>
		</t-cell-group>
		
		<t-cell-group t-class="mt-2" theme="card">
			<m-area-picker @change="onChangeArea"></m-area-picker>
		</t-cell-group>
		
		<t-cell-group t-class="mt-2" theme="card">
			<t-input v-if="!form.address" label="运营地址" placeholder="点击选择地址(可编辑)" :readonly="!form.address" align="right" @click="chooseLocation">
				<template #extra>
					<t-icon name="location-filled" size="48rpx" color="#000" @click="chooseLocation"></t-icon>
				</template>
			</t-input>
			<template v-else>
				<t-textarea v-model:value="form.address" placeholder="请编辑地址" custom-style="height:160rpx"></t-textarea>
				<view class="text-muted bg-white p-3 top-line d-flex align-items-center justify-content-between" @click="chooseLocation">
					<text>地址如不准确，可编辑修改。</text>
					<t-icon name="location-filled" size="36rpx" color="#000"></t-icon>
				</view>
			</template>
		</t-cell-group>
		
		<t-cell-group t-class="mt-2" theme="card">
			<m-industry-picker v-model:value="form.industry"></m-industry-picker>
		</t-cell-group>
		
		<view class="container">
				<view class="paragraph">营业时间</view>
				<view class="section mt-2">
					<t-cell title="24小时营业">
						<template #note>
							<t-switch v-model:value="form.isAlwaysOpen"></t-switch>
						</template>
					</t-cell>
					<m-openhour-picker v-if="!form.isAlwaysOpen" v-model:value="form.openHour"></m-openhour-picker>
				</view>
			</view>
		
		<t-cell-group t-class="mt-2" theme="card">
			<t-cell title="客服电话" description="默认为注册手机号，注册后可修改。" arrow @click="showPhoneTips"></t-cell>
		</t-cell-group>

        <view v-if="showSourcePicker" class="container">
            <view class="paragraph">您是从哪里了解到我们的？</view>
            <view class="section mt-2 traffic-source-panel">
                <view
                    v-for="item in sourceOptions"
                    :key="item.value"
                    class="traffic-source-tag"
                    :class="{ active: form.source === item.value }"
                    @click="form.source = item.value"
                >{{ item.label }}
                </view>
            </view>
        </view>
		
		<view class="container mt-3">
			<t-checkbox t-class-icon="agreement-checkbox" v-model:checked="allowAgreement" borderless icon="rectangle" relation-key="-1" custom-style="background-color: transparent;">
				<template #label>
					<view class="user-agreement">
						<view>我已阅读并同意券到卡包</view>
                        <navigator class="link" url="/pages_assist/agreement/privacy" @click.stop>《隐私政策》</navigator>
						及
                        <navigator class="link" url="/pages_assist/agreement/agreement" @click.stop>《服务协议》
                        </navigator>
					</view>
				</template>
			</t-checkbox>
		</view>
		<view class="container mt-3">
			<t-button block theme="danger" size="large" :disabled="disable" :loading="loading"  openType="getPhoneNumber" @getphonenumber="getPhoneCode">创建商户</t-button>
		</view>
		<view class="mt-3 container text-remark d-flex align-items-center justify-content-center" style="padding-bottom: 80rpx;" @click="back()">取消</view>
	</view>
</template>

<script setup>
	import { ref, computed} from 'vue'
	import {onLoad} from '@dcloudio/uni-app'
	import request from "@/hooks/request.js"
	import { useLink } from "@/hooks/useLink.js"
	import utils from '@/utils/utils'

	const { back, reLaunch } = useLink();

    const MERCHANT_SOURCE_KEY = 'merchant_source'
    const sourceOptions = [
        {value: '抖音', label: '抖音'},
        {value: '小红书', label: '小红书'},
        {value: '视频号', label: '视频号'},
        {value: '朋友推荐', label: '朋友推荐'},
    ]

	// 企业微信绑定信息
	const corpId = ref('')
	const corpName = ref('')
	const hasWecomBind = ref(false)
    const showSourcePicker = ref(true)

	const isSuccess = ref(false)
	const form = ref({
		registerType: 1,
		isAlwaysOpen:false,
        source: '',
        openHour: [{//营业时间设置容易被忽略，设置一个默认值，防止未设置时，按钮没有active
            startTime: "09:00",
            endTime: "22:00",
        }],
	})
	const allowAgreement = ref(false)
	const loading = ref(false)
	
	// 按钮禁用
	const disable = computed(() => {
		if (form.value.cover &&
			form.value.name &&
			form.value.province &&
			form.value.city &&
			form.value.district &&
			form.value.address &&
			form.value.industry &&
            (form.value.isAlwaysOpen || form.value.openHour) &&
            form.value.source &&
			allowAgreement.value
		) {
			return false
		} else {
			return true
		}

	})
	
	const showPhoneTips = () => {
		uni.showModal({
			showCancel: false,
			content: '门店客服电话默认为注册手机号码，可在门店管理中修改。',
			success: (r) => {}
		})
	}

	const chooseLocation = () => {
		uni.chooseLocation({
			latitude: form.value.lat,
			longitude: form.value.lng,
			success(res) {
				console.log('地图选择信息：' + JSON.stringify(res))
				form.value.address = res.address
				form.value.lat = res.latitude
				form.value.lng = res.longitude
			},
			fail(err) {
				utils.toast('位置选择失败，请重新选择')
			}
		});
	}

	const getPhoneCode = (e) => {
		if (e.detail.errMsg === "getPhoneNumber:fail user deny") {
			utils.toast("已取消")
		} else {
            uni.login({
				success(login) {
					onCreate(login.code, e.detail.code)
				},
				fail: (e) => {
					utils.toast("获取loginCode失败")
				}
			})
		}
	}
	
	const onChangeArea = (e) => {
		if (e.length === 3) {
			form.value.province = e[0]
			form.value.city = e[1]
			form.value.district = e[2]
		}
	}

	const onCreate = (loginCode, phoneCode) => {
		loading.value = true
		form.value.wechatCode = loginCode
		form.value.phoneCode = phoneCode
		// 如果有企业微信绑定信息，一起提交
		if (hasWecomBind.value) {
			form.value.corpId = corpId.value
			form.value.corpName = corpName.value
		}
		request.post('/user/merchant/create', form.value).then(res => {
			isSuccess.value = true
		}).finally(()=>{
			loading.value = false
		})
	}

	onLoad((query) => {
		// 获取企业微信绑定参数
		if (query.corpId && query.corpName) {
			corpId.value = decodeURIComponent(query.corpId)
			corpName.value = decodeURIComponent(query.corpName)
			hasWecomBind.value = true
		}

        let source = ''
        if (query.source) {
            source = decodeURIComponent(query.source)
        } else {
            source = uni.getStorageSync(MERCHANT_SOURCE_KEY) || ''
            if (source) {
                uni.removeStorageSync(MERCHANT_SOURCE_KEY)
            }
        }
        if (source) {
            form.value.source = source
            showSourcePicker.value = false
        }
	})
</script>

<style>
	.agreement-checkbox {
		margin-right: 10rpx !important;
		scale: 0.8;
	}
</style>

<style scoped>
	.user-agreement {
		color: #999;
		font-size: 24rpx;
		display: flex;
		align-items: center;
		justify-content: center;
		flex-wrap: wrap;
	}

	.link {
		color: #07C160;
	}

	/* 企业微信绑定信息样式 */
	.wecom-bind-card {
		background: #fff;
		border-radius: 16rpx;
		overflow: hidden;
	}

	.wecom-bind-header {
		display: flex;
		align-items: center;
		padding: 24rpx 32rpx;
		background: #fff;
		border-bottom: 1px solid #e7e7e7;
	}

	.wecom-bind-title {
		font-size: 32rpx;
		font-weight: 600;
		color: #333;
		margin-left: 12rpx;
	}

	.wecom-bind-body {
		padding: 24rpx 32rpx;
	}

	.corp-id-row {
		display: flex;
		align-items: center;
		justify-content: space-between;
	}

	.corp-id-label {
		font-size: 24rpx;
		color: #999;
	}

	.corp-id-value {
		font-size: 24rpx;
		color: #666;
	}

    .traffic-source-panel {
        display: flex;
        flex-wrap: wrap;
        gap: 20rpx;
        padding: 28rpx 24rpx;
        background: #fff;
        border-radius: 16rpx;
    }

    .traffic-source-tag {
        min-width: 140rpx;
        padding: 16rpx 28rpx;
        text-align: center;
        font-size: 28rpx;
        color: #666;
        background: #f5f5f5;
        border-radius: 12rpx;
        border: 1px solid transparent;
        box-sizing: border-box;
    }

    .traffic-source-tag.active {
        color: #d82311;
        background: #fff5f4;
        border-color: #d82311;
        font-weight: 500;
    }

</style>